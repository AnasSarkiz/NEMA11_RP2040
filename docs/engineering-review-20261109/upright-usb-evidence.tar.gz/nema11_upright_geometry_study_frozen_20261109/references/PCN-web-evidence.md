# Manufacturer PCN evidence captured during study

Source: https://gct.co/files/pcns/gct%20usb4145%20a2%20pcn%2020230214.pdf
Retrieved through connected web tool during study on 2026-11-09. Tool identified a one-page PDF, with extraction lines 0–30. This file records that extraction's relevant facts; original PCN PDF bytes were not downloaded into the study and are not claimed to be archived.

Document: GCT QR18 Product Change Notice, USB4145 A2 PCN 20230214.
Notice date: 14 February 2023.
Product identifier: USB4145-03-XXXX-C.
Drawing revision: A2, effective immediately.
Change: slight revision to recommended PCB layout.
Reason, exact short excerpt: “Updated recommended PCB layout to accommodate reliable pick and placement”.
Manufacturer states no anticipated impact on form, fit, function or reliability and no inventory action required.

The separately archived drawing references/GCT-USB4145-drawing-A2.pdf is the exact existing project reference, visually inspected in this study, and bears drawing revision A2 dated 31 January 2023. Its pages 1 and 2 were rendered to the included PNGs. A current direct drawing download attempt returned HTTP 403; its body is retained as official-current-download-http403.html, not misrepresented as a PDF.
