import json, pathlib, math, collections, argparse
root=pathlib.Path(__file__).parent
parser=argparse.ArgumentParser(description='Recalculate upright USB study against frozen or supplied native geometry')
parser.add_argument('--board-json', type=pathlib.Path, default=root/'inputs/current-board-circuit.json')
parser.add_argument('--usb-json', type=pathlib.Path, default=root/'dist/usb/circuit.json')
parser.add_argument('--output', type=pathlib.Path, default=root/'geometry-results.json')
args=parser.parse_args()
j=json.load(open(args.board_json))
u=json.load(open(args.usb_json))
c={x['pcb_component_id']:x for x in j if x['type']=='pcb_component' and not x.get('do_not_place')}
s={x['source_component_id']:x for x in j if x['type']=='source_component'}
def area(pts):return abs(sum(p['x']*q['y']-p['y']*q['x'] for p,q in zip(pts,pts[1:]+pts[:1])))/2
rows=[dict(name=s[c[x['pcb_component_id']]['source_component_id']]['name'],area_mm2=area(x['outline'])) for x in j if x['type']=='pcb_courtyard_outline' and x['pcb_component_id']in c]
vertical=area(next(x for x in u if x['type']=='pcb_courtyard_outline')['outline'])
original=sum(r['area_mm2']for r in rows); flat=sum(r['area_mm2']for r in rows if r['name']in ['J_PD','J_DATA']);hyp=original-flat+2*vertical
out=dict(fitted_count=len(c),layers=dict(collections.Counter(x['layer']for x in c.values())),courtyard_count=len(rows),courtyard_area_sum_mm2=original,flat_usb_pair_mm2=flat,vertical_usb_each_mm2=vertical,hypothetical_vertical_sum_mm2=hyp,provisional_free_board_area_mm2=784-4*math.pi*2.35**2,provisional_remaining_area_mm2=784-4*math.pi*2.35**2-hyp,packing_proven=False,rows=rows,usb_holes=[x for x in u if x['type']=='pcb_hole'],paste_layers=dict(collections.Counter(x['layer']for x in u if x['type']=='pcb_solder_paste')))
args.output.write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items()if k not in ['rows','usb_holes']},indent=2))
