import React from 'react'
import fs from 'node:fs'
const labels={U_TEMP:{pin1:['SCL'],pin2:['GND'],pin3:['ALERT'],pin4:['ADD0'],pin5:['V_POS'],pin6:['SDA']},D_STATUS:{pin1:['R_NEG'],pin2:['G_NEG'],pin3:['B_NEG'],pin4:['_POS']}}
for(const mode of ['original','patched']){
 const {Circuit}=await import(`./core-${mode}/index.js`)
 for(const [name,pinLabels]of Object.entries(labels)){
  for(const form of ['array','string']){
   const circuit=new Circuit();circuit.add(React.createElement('board',{width:10,height:10,pcbDisabled:true,routingDisabled:true},React.createElement('chip',{name,pinLabels:form==='array'?pinLabels:Object.fromEntries(Object.entries(pinLabels).map(([k,v])=>[k,v[0]]))})))
   await circuit.renderUntilSettled();const json=circuit.getCircuitJson();fs.writeFileSync(new URL(`./size-${mode}-${name}-${form}.json`,import.meta.url),JSON.stringify(json,null,2));console.log(mode,name,form,json.filter(x=>x.type==='schematic_component').map(x=>x.size))
  }
 }
}
