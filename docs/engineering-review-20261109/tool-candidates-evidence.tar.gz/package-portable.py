from pathlib import Path
import tarfile,json,hashlib
root=Path(__file__).resolve().parent
files=set()
for p in root.iterdir():
 if p.is_file() and not p.is_symlink() and p.suffix not in ('.gz',):files.add(p)
for folder in ('upstream','candidate'):
 files.update(p for p in (root/folder).rglob('*') if p.is_file() and not p.is_symlink())
r=root/'full-board-replay'
files.update(p for p in r.iterdir() if p.is_file())
files.update(p for p in (r/'analyzer').rglob('*') if p.is_file() and not p.is_symlink() and 'node_modules' not in p.parts)
b=r/'board'
for folder in ('config','scripts','tests','emitted-tests','dist/index'):
 files.update(p for p in (b/folder).rglob('*') if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts and p.suffix!='.pyc')
for name in ['index.circuit.tsx','assets.d.ts','package.json','package-lock.json','tsconfig.json','tscircuit.config.json']:
 files.add(b/name)
status=json.loads((b/'checks/milestone-status.json').read_text())
for v in status['results'].values():files.add(b/v['log'])
for name in ['milestone-status.json','native-build-status.json','import-manifest.json','strict-netlist.json','strict-pin_specification.json','strict-source.json','strict-schematic.json','20261108-reconstruction/current-geometry-audit.json']:
 if (b/'checks'/name).is_file():files.add(b/'checks'/name)
archive=root/'nema11-tool-candidates-portable.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for p in sorted(files):
  rel=str(p.relative_to(root))
  if rel=='package.json':continue
  t.add(p,arcname=rel,recursive=False)
 t.add(root/'dependency-reference-package.json',arcname='package.json',recursive=False)
 t.add(root/'dependency-reference-package-lock.json',arcname='package-lock.json',recursive=False)
with tarfile.open(archive) as t:
 assert not any(x.issym() or x.islnk() or 'node_modules' in Path(x.name).parts or '.cache' in Path(x.name).parts for x in t.getmembers())
sha=hashlib.sha256(archive.read_bytes()).hexdigest();(root/'portable-archive-sha256.txt').write_text(f'{sha}  {archive.name}\n');print(archive,archive.stat().st_size,sha)
