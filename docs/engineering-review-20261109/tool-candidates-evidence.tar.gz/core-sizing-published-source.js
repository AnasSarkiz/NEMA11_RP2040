// lib/utils/schematic/getAllDimensionsForSchematicBox.ts
var DEFAULT_SCHEMATIC_BOX_PADDING_MM = 0.4;
var ESTIMATED_PIN_LABEL_CHARACTER_WIDTH = 0.1;
var PIN_LABEL_EDGE_PADDING = 0.1;
var getDisplayedPinLabel = (pinLabel) => typeof pinLabel === "string" ? pinLabel : pinLabel?.[0] ?? "";
var getEstimatedPinLabelWidth = (pinLabel) => Array.from(getDisplayedPinLabel(pinLabel)).length * ESTIMATED_PIN_LABEL_CHARACTER_WIDTH;
function isExplicitPinMappingArrangement(arrangement) {
  const a2 = arrangement;
  return a2.leftSide !== void 0 || a2.rightSide !== void 0 || a2.topSide !== void 0 || a2.bottomSide !== void 0;
}
var getAllDimensionsForSchematicBox = (params) => {
  const portDistanceFromEdge = params.portDistanceFromEdge ?? 0.4;
  let sidePinCounts = params.schPortArrangement ? getSizeOfSidesFromPortArrangement(params.schPortArrangement) : null;
  const sideLengths = {
    left: 0,
    right: 0,
    top: 0,
    bottom: 0
  };
  let pinCount = params.pinCount ?? null;
  if (pinCount === null) {
    if (sidePinCounts) {
      pinCount = sidePinCounts.leftSize + sidePinCounts.rightSize + sidePinCounts.topSize;
    } else {
      throw new Error("Could not determine pin count for the schematic box");
    }
  }
  if (pinCount && !sidePinCounts) {
    const rightSize = Math.floor(pinCount / 2);
    sidePinCounts = {
      leftSize: pinCount - rightSize,
      rightSize,
      topSize: 0,
      bottomSize: 0
    };
  }
  if (!sidePinCounts) {
    sidePinCounts = {
      leftSize: 0,
      rightSize: 0,
      topSize: 0,
      bottomSize: 0
    };
  }
  const getPinNumberUsingSideIndex = ({
    side,
    sideIndex,
    truePinIndex: truePinIndex2
  }) => {
    if (!params.schPortArrangement) return truePinIndex2 + 1;
    if (!isExplicitPinMappingArrangement(params.schPortArrangement))
      return truePinIndex2 + 1;
    const normalCcwDirection = {
      left: "top-to-bottom",
      bottom: "left-to-right",
      right: "bottom-to-top",
      top: "right-to-left"
    }[side];
    const directionAlongSide = params.schPortArrangement?.[`${side}Side`]?.direction ?? normalCcwDirection;
    const pinsDefinitionForSide = params.schPortArrangement?.[`${side}Side`]?.pins;
    let sideIndexWithDirectionCorrection = sideIndex;
    if (directionAlongSide !== normalCcwDirection) {
      sideIndexWithDirectionCorrection = pinsDefinitionForSide.length - sideIndex - 1;
    }
    return parsePinNumberFromLabelsOrThrow(
      pinsDefinitionForSide[sideIndexWithDirectionCorrection],
      params.pinLabels
    );
  };
  const orderedTruePorts = [];
  let currentDistanceFromEdge = 0;
  let truePinIndex = 0;
  for (let sideIndex = 0; sideIndex < sidePinCounts.leftSize; sideIndex++) {
    const pinNumber = getPinNumberUsingSideIndex({
      side: "left",
      sideIndex,
      truePinIndex
    });
    const pinStyle = params.numericSchPinStyle?.[`pin${pinNumber}`] ?? params.numericSchPinStyle?.[pinNumber];
    if (pinStyle?.topMargin) {
      currentDistanceFromEdge += pinStyle.topMargin;
    }
    orderedTruePorts.push({
      trueIndex: pinNumber - 1,
      pinNumber,
      side: "left",
      distanceFromOrthogonalEdge: currentDistanceFromEdge
    });
    if (pinStyle?.bottomMargin) {
      currentDistanceFromEdge += pinStyle.bottomMargin;
    }
    const isLastPinOnSide = sideIndex === sidePinCounts.leftSize - 1;
    if (!isLastPinOnSide) {
      currentDistanceFromEdge += params.schPinSpacing;
    } else {
      sideLengths.left = currentDistanceFromEdge;
    }
    truePinIndex++;
  }
  currentDistanceFromEdge = 0;
  for (let sideIndex = 0; sideIndex < sidePinCounts.bottomSize; sideIndex++) {
    const pinNumber = getPinNumberUsingSideIndex({
      side: "bottom",
      sideIndex,
      truePinIndex
    });
    const pinStyle = params.numericSchPinStyle?.[`pin${pinNumber}`] ?? params.numericSchPinStyle?.[pinNumber];
    if (pinStyle?.leftMargin) {
      currentDistanceFromEdge += pinStyle.leftMargin;
    }
    orderedTruePorts.push({
      trueIndex: pinNumber - 1,
      pinNumber,
      side: "bottom",
      distanceFromOrthogonalEdge: currentDistanceFromEdge
    });
    if (pinStyle?.rightMargin) {
      currentDistanceFromEdge += pinStyle.rightMargin;
    }
    const isLastPinOnSide = sideIndex === sidePinCounts.bottomSize - 1;
    if (!isLastPinOnSide) {
      currentDistanceFromEdge += params.schPinSpacing;
    } else {
      sideLengths.bottom = currentDistanceFromEdge;
    }
    truePinIndex++;
  }
  currentDistanceFromEdge = 0;
  for (let sideIndex = 0; sideIndex < sidePinCounts.rightSize; sideIndex++) {
    const pinNumber = getPinNumberUsingSideIndex({
      side: "right",
      sideIndex,
      truePinIndex
    });
    const pinStyle = params.numericSchPinStyle?.[`pin${pinNumber}`] ?? params.numericSchPinStyle?.[pinNumber];
    if (pinStyle?.bottomMargin) {
      currentDistanceFromEdge += pinStyle.bottomMargin;
    }
    orderedTruePorts.push({
      trueIndex: pinNumber - 1,
      pinNumber,
      side: "right",
      distanceFromOrthogonalEdge: currentDistanceFromEdge
    });
    if (pinStyle?.topMargin) {
      currentDistanceFromEdge += pinStyle.topMargin;
    }
    const isLastPinOnSide = sideIndex === sidePinCounts.rightSize - 1;
    if (!isLastPinOnSide) {
      currentDistanceFromEdge += params.schPinSpacing;
    } else {
      sideLengths.right = currentDistanceFromEdge;
    }
    truePinIndex++;
  }
  currentDistanceFromEdge = 0;
  for (let sideIndex = 0; sideIndex < sidePinCounts.topSize; sideIndex++) {
    const pinNumber = getPinNumberUsingSideIndex({
      side: "top",
      sideIndex,
      truePinIndex
    });
    const pinStyle = params.numericSchPinStyle?.[`pin${pinNumber}`] ?? params.numericSchPinStyle?.[pinNumber];
    if (pinStyle?.rightMargin) {
      currentDistanceFromEdge += pinStyle.rightMargin;
    }
    orderedTruePorts.push({
      trueIndex: pinNumber - 1,
      pinNumber,
      side: "top",
      distanceFromOrthogonalEdge: currentDistanceFromEdge
    });
    if (pinStyle?.leftMargin) {
      currentDistanceFromEdge += pinStyle.leftMargin;
    }
    const isLastPinOnSide = sideIndex === sidePinCounts.topSize - 1;
    if (!isLastPinOnSide) {
      currentDistanceFromEdge += params.schPinSpacing;
    } else {
      sideLengths.top = currentDistanceFromEdge;
    }
    truePinIndex++;
  }
  let resolvedSchWidth = params.schWidth;
  if (resolvedSchWidth === void 0) {
    resolvedSchWidth = Math.max(
      sideLengths.top + DEFAULT_SCHEMATIC_BOX_PADDING_MM,
      sideLengths.bottom + DEFAULT_SCHEMATIC_BOX_PADDING_MM
    );
    if (params.pinLabels) {
      const leftRightPins = orderedTruePorts.filter(
        (p2) => p2.side === "left" || p2.side === "right"
      );
      const hasLeftRightLabels = leftRightPins.some(
        (p2) => params.pinLabels?.[`pin${p2.pinNumber}`] || params.pinLabels?.[p2.pinNumber]
      );
      if (hasLeftRightLabels) {
        const MIN_WIDTH_FOR_SIDE_PINS = 0.5;
        resolvedSchWidth = Math.max(resolvedSchWidth, MIN_WIDTH_FOR_SIDE_PINS);
      }
    }
    const labelWidth = params.pinLabels ? Math.max(
      ...Object.values(params.pinLabels).map(
        (label) => label.length * ESTIMATED_PIN_LABEL_CHARACTER_WIDTH
      )
    ) : 0;
    const LABEL_PADDING = labelWidth > 0 ? 1.1 : 0;
    resolvedSchWidth = Math.max(resolvedSchWidth, labelWidth + LABEL_PADDING);
    const maxLabelWidthBySide = {
      left: 0,
      right: 0
    };
    for (const port of orderedTruePorts) {
      if (port.side !== "left" && port.side !== "right") continue;
      const pinLabel = params.pinLabels?.[`pin${port.pinNumber}`] ?? params.pinLabels?.[port.pinNumber];
      maxLabelWidthBySide[port.side] = Math.max(
        maxLabelWidthBySide[port.side],
        getEstimatedPinLabelWidth(pinLabel)
      );
    }
    resolvedSchWidth = Math.max(
      resolvedSchWidth,
      maxLabelWidthBySide.left + maxLabelWidthBySide.right + 2 * PIN_LABEL_EDGE_PADDING
    );
  }
  let schHeight = params.schHeight;
  if (!schHeight) {
    schHeight = Math.max(
      sideLengths.left + DEFAULT_SCHEMATIC_BOX_PADDING_MM,
      sideLengths.right + DEFAULT_SCHEMATIC_BOX_PADDING_MM
    );
  }
  if (params.pinLabels) {
    const CHAR_WIDTH = 0.13;
    const LABEL_EDGE_OFFSET = PIN_LABEL_EDGE_PADDING;
    const HALF_TEXT = 0.075;
    const getLabelLen = (pinNumber) => {
      const label = params.pinLabels[`pin${pinNumber}`] ?? params.pinLabels[`${pinNumber}`];
      return label ? label.length * CHAR_WIDTH : 0;
    };
    const leftLabels = orderedTruePorts.filter((p2) => p2.side === "left").map((p2) => ({
      y: sideLengths.left / 2 - p2.distanceFromOrthogonalEdge,
      len: getLabelLen(p2.pinNumber)
    })).filter((p2) => p2.len > 0);
    const rightLabels = orderedTruePorts.filter((p2) => p2.side === "right").map((p2) => ({
      y: -sideLengths.right / 2 + p2.distanceFromOrthogonalEdge,
      len: getLabelLen(p2.pinNumber)
    })).filter((p2) => p2.len > 0);
    const topLabels = orderedTruePorts.filter((p2) => p2.side === "top").map((p2) => ({
      x: sideLengths.top / 2 - p2.distanceFromOrthogonalEdge,
      len: getLabelLen(p2.pinNumber)
    })).filter((p2) => p2.len > 0);
    const bottomLabels = orderedTruePorts.filter((p2) => p2.side === "bottom").map((p2) => ({
      x: -sideLengths.bottom / 2 + p2.distanceFromOrthogonalEdge,
      len: getLabelLen(p2.pinNumber)
    })).filter((p2) => p2.len > 0);
    const rectsOverlap5 = (a2, b2) => Math.min(a2.maxX, b2.maxX) > Math.max(a2.minX, b2.minX) && Math.min(a2.maxY, b2.maxY) > Math.max(a2.minY, b2.minY);
    const getLeftRect = (label, width) => ({
      minX: -width / 2 + LABEL_EDGE_OFFSET,
      maxX: -width / 2 + LABEL_EDGE_OFFSET + label.len,
      minY: label.y - HALF_TEXT,
      maxY: label.y + HALF_TEXT
    });
    const getRightRect = (label, width) => ({
      minX: width / 2 - LABEL_EDGE_OFFSET - label.len,
      maxX: width / 2 - LABEL_EDGE_OFFSET,
      minY: label.y - HALF_TEXT,
      maxY: label.y + HALF_TEXT
    });
    const getTopRect = (label, height) => ({
      minX: label.x - HALF_TEXT,
      maxX: label.x + HALF_TEXT,
      minY: height / 2 - LABEL_EDGE_OFFSET - label.len,
      maxY: height / 2 - LABEL_EDGE_OFFSET
    });
    const getBottomRect = (label, height) => ({
      minX: label.x - HALF_TEXT,
      maxX: label.x + HALF_TEXT,
      minY: -height / 2 + LABEL_EDGE_OFFSET,
      maxY: -height / 2 + LABEL_EDGE_OFFSET + label.len
    });
    if (!params.schHeight) {
      let hasTopBottomLabelCollision = false;
      for (const topLabel of topLabels) {
        for (const bottomLabel of bottomLabels) {
          if (rectsOverlap5(
            getTopRect(topLabel, schHeight),
            getBottomRect(bottomLabel, schHeight)
          )) {
            hasTopBottomLabelCollision = true;
            schHeight = Math.max(
              schHeight,
              topLabel.len + bottomLabel.len + 2 * LABEL_EDGE_OFFSET
            );
          }
        }
      }
      if (hasTopBottomLabelCollision) {
        for (const topLabel of topLabels) {
          const topRect = getTopRect(topLabel, schHeight);
          for (const leftLabel of leftLabels) {
            const leftRect = getLeftRect(leftLabel, resolvedSchWidth);
            if (rectsOverlap5(topRect, leftRect)) {
              schHeight = Math.max(
                schHeight,
                2 * (leftRect.maxY + LABEL_EDGE_OFFSET + topLabel.len)
              );
            }
          }
          for (const rightLabel of rightLabels) {
            const rightRect = getRightRect(rightLabel, resolvedSchWidth);
            if (rectsOverlap5(topRect, rightRect)) {
              schHeight = Math.max(
                schHeight,
                2 * (rightRect.maxY + LABEL_EDGE_OFFSET + topLabel.len)
              );
            }
          }
        }
        for (const bottomLabel of bottomLabels) {
          const bottomRect = getBottomRect(bottomLabel, schHeight);
          for (const leftLabel of leftLabels) {
            const leftRect = getLeftRect(leftLabel, resolvedSchWidth);
            if (rectsOverlap5(bottomRect, leftRect)) {
              schHeight = Math.max(
                schHeight,
                2 * (LABEL_EDGE_OFFSET + bottomLabel.len - leftRect.minY)
              );
            }
          }
          for (const rightLabel of rightLabels) {
            const rightRect = getRightRect(rightLabel, resolvedSchWidth);
            if (rectsOverlap5(bottomRect, rightRect)) {
              schHeight = Math.max(
                schHeight,
                2 * (LABEL_EDGE_OFFSET + bottomLabel.len - rightRect.minY)
              );
            }
          }
        }
      }
    }
  }
  const trueEdgePositions = {
    // Top left corner
    left: {
      x: -resolvedSchWidth / 2 - portDistanceFromEdge,
      y: sideLengths.left / 2
    },
    // bottom left corner
    bottom: {
      x: -sideLengths.bottom / 2,
      y: -schHeight / 2 - portDistanceFromEdge
    },
    // bottom right corner
    right: {
      x: resolvedSchWidth / 2 + portDistanceFromEdge,
      y: -sideLengths.right / 2
    },
    // top right corner
    top: {
      x: sideLengths.top / 2,
      y: schHeight / 2 + portDistanceFromEdge
    }
  };
  const trueEdgeTraversalDirections = {
    left: { x: 0, y: -1 },
    right: { x: 0, y: 1 },
    top: { x: -1, y: 0 },
    bottom: { x: 1, y: 0 }
  };
  const truePortsWithPositions = orderedTruePorts.map((p2) => {
    const { distanceFromOrthogonalEdge, side } = p2;
    const edgePos = trueEdgePositions[side];
    const edgeDir = trueEdgeTraversalDirections[side];
    return {
      x: edgePos.x + distanceFromOrthogonalEdge * edgeDir.x,
      y: edgePos.y + distanceFromOrthogonalEdge * edgeDir.y,
      ...p2
    };
  });
  return {
    getPortPositionByPinNumber(pinNumber) {
      const port = truePortsWithPositions.find(
        (p2) => p2.pinNumber.toString() === pinNumber.toString()
      );
      if (!port) {
        return null;
      }
      return port;
    },
    getSize() {
      return { width: resolvedSchWidth, height: schHeight };
    },
    getSizeIncludingPins() {
      return {
        width: resolvedSchWidth + (sidePinCounts.leftSize || sidePinCounts.rightSize ? 0.4 : 0),
        height: schHeight + (sidePinCounts.topSize || sidePinCounts.bottomSize ? 0.4 : 0)
      };
    },
    pinCount
  };
};

