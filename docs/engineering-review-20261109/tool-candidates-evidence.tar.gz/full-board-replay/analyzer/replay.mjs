import {readFileSync,writeFileSync}from'node:fs'
import {createHash}from'node:crypto'
import {analyzeSchematicPlacement}from'./lib/analyze-schematic-placement.ts'
const path=process.argv[2],out=process.argv[3];const bytes=readFileSync(path);const native=JSON.parse(bytes);const before=JSON.stringify(native);const analysis=analyzeSchematicPlacement(native);const issues=analysis.getLineItems().flatMap(i=>i.lineItemType==='SchematicPlacementIssues'?i.issues:[]);if(before!==JSON.stringify(native))throw Error('Mutation');writeFileSync(out+'.json',JSON.stringify({inputSha256:createHash('sha256').update(bytes).digest('hex'),issues},null,2));writeFileSync(out+'.txt',analysis.toString());console.log(out,issues.length)
