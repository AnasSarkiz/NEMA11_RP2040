import { readFile } from 'node:fs/promises'
import { existsSync } from 'node:fs'
import { fileURLToPath, pathToFileURL } from 'node:url'
import ts from 'typescript'
const root = new URL('../', import.meta.url)
export async function resolve(specifier, context, next) {
  if (specifier.startsWith('lib/') || specifier.startsWith('tests/')) specifier = new URL(specifier, root).href
  if (specifier.startsWith('.') || specifier.startsWith('file:')) {
    const url = new URL(specifier, context.parentURL)
    for (const suffix of ['', '.ts', '.tsx', '/index.ts']) {
      const candidate = fileURLToPath(url) + suffix
      if (existsSync(candidate) && /\.[cm]?[jt]sx?$/.test(candidate)) return {url: pathToFileURL(candidate).href, shortCircuit: true}
    }
  }
  try { return await next(specifier, context) } catch (error) {
    if (error.code === "ERR_UNSUPPORTED_DIR_IMPORT") return resolve(error.url + "/index.ts", context, next)
    throw error
  }
}
export async function load(url, context, next) {
  const relative = url.startsWith(root.href) ? url.slice(root.href.length) : ''
  const baseline = new URL('validation/baseline-src/' + relative, root)
  const sourceUrl = process.env.BASELINE === '1' && existsSync(baseline) ? baseline : new URL(url)
  if (/\.tsx?$/.test(url)) return {format:'module', shortCircuit:true, source:ts.transpileModule(await readFile(sourceUrl,'utf8'), {compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,jsx:ts.JsxEmit.ReactJSX}}).outputText}
  return next(url, context)
}
