from pathlib import Path
import hashlib,json,collections
r=Path(__file__).resolve().parent
old=r.parent/'board-fixture.json';new=r/'board/dist/index/circuit.json'
a=json.loads(old.read_text());b=json.loads(new.read_text())
def grouping(x):
 out=collections.defaultdict(list)
 for e in x:out[e['type']].append(e)
 return out
A=grouping(a);B=grouping(b);report={'baseline_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256(new.read_bytes()).hexdigest(),'baseline_count':len(a),'candidate_count':len(b),'type_comparison':{},'changed_non_schematic_records':[]}
for t in sorted(A.keys()|B.keys()):
 report['type_comparison'][t]={'baseline':len(A[t]),'candidate':len(B[t]),'exact_equal':A[t]==B[t]}
 if not t.startswith('schematic') and A[t]!=B[t]:report['changed_non_schematic_records'].append({'type':t,'baseline':A[t],'candidate':B[t]})
report['all_physical_pcb_records_exact_equal']=all(A[t]==B[t] for t in A.keys()|B.keys() if t.startswith('pcb'))
report['all_source_records_exact_equal']=all(A[t]==B[t] for t in A.keys()|B.keys() if t.startswith('source'))
(r/'native-comparison.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k not in ['type_comparison','changed_non_schematic_records']},indent=2))
print('Changed types:',[t for t,v in report['type_comparison'].items() if not v['exact_equal']])
