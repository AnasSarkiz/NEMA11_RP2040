// lib/check-copper-pour-islands.ts
import {
  getFullConnectivityMapFromCircuitJson
} from "circuit-json-to-connectivity-map";
import { getPourPolygon as getPourPolygon2 } from "@tscircuit/circuit-json-util";

// lib/copper-pour-connectivity/create-copper-polygon-contact-tester.ts
import {
  Box,
  Polygon
} from "@flatten-js/core";
function createCopperPolygonContactTester(tolerance) {
  const cache = /* @__PURE__ */ new WeakMap();
  const getGeometry = (polygon) => {
    let geometry = cache.get(polygon);
    if (!geometry) {
      let localPolygon = polygon;
      if (polygon.constructor !== Polygon) {
        localPolygon = new Polygon(
          polygon.toJSON()
        );
      }
      geometry = {
        polygon: localPolygon,
        box: localPolygon.box,
        facePoints: [...localPolygon.faces].map((face) => face.first.start),
        edges: [...localPolygon.edges].map((edge) => edge.shape),
        edgeIndex: localPolygon.edges
      };
      cache.set(polygon, geometry);
    }
    return geometry;
  };
  return (a, b) => {
    if (a.isEmpty() || b.isEmpty()) return false;
    const ga = getGeometry(a);
    const gb = getGeometry(b);
    if (ga.box.xmin > gb.box.xmax + tolerance || ga.box.xmax < gb.box.xmin - tolerance || ga.box.ymin > gb.box.ymax + tolerance || ga.box.ymax < gb.box.ymin - tolerance)
      return false;
    if (ga.facePoints.some(
      (point2) => gb.box.contains(point2) && gb.polygon.contains(point2)
    ) || gb.facePoints.some(
      (point2) => ga.box.contains(point2) && ga.polygon.contains(point2)
    ))
      return true;
    const [small, large] = ga.edges.length <= gb.edges.length ? [ga, gb] : [gb, ga];
    for (const edge of small.edges) {
      const box = edge.box;
      const queryBox = new Box(
        box.xmin - tolerance,
        box.ymin - tolerance,
        box.xmax + tolerance,
        box.ymax + tolerance
      );
      const candidates = large.edgeIndex.search(
        queryBox
      );
      for (const candidate of candidates) {
        if (edge.distanceTo(candidate.shape)[0] <= tolerance) return true;
      }
    }
    return false;
  };
}

// lib/copper-pour-connectivity/get-copper-pour-connectivity.ts
import {
  getPrimaryId,
  getPlatedHolePolygon,
  getPourPolygon,
  getSmtPadPolygon,
  getTraceSegmentPolygon,
  getViaPolygon
} from "@tscircuit/circuit-json-util";
var getRouteEndpoint = (point2, side) => {
  if (point2.route_type === "wire") return { point: point2, layer: point2.layer };
  if (point2.route_type === "via")
    return {
      point: point2,
      layer: side === "start" ? point2.from_layer : point2.to_layer
    };
  return {
    point: point2[side],
    layer: side === "start" ? point2.start_layer : point2.end_layer
  };
};
function getCopperPourConnectivity(circuitJson, connectivity) {
  const scale = 1e6;
  const tolerance = 1e-7 * scale;
  const copperPolygonsTouch = createCopperPolygonContactTester(tolerance);
  const conductors = [];
  const pouredNets = /* @__PURE__ */ new Set();
  const netForId = (id) => connectivity.getNetConnectedToId(id);
  const add = (conductor) => {
    if (!conductor.polygon.isEmpty()) {
      conductors.push({
        ...conductor,
        polygon: conductor.polygon.scale(scale, scale)
      });
    }
  };
  for (const pour of circuitJson) {
    if (pour.type !== "pcb_copper_pour" || !pour.source_net_id) continue;
    const netId = netForId(pour.source_net_id) ?? pour.source_net_id;
    pouredNets.add(netId);
    add({
      polygon: getPourPolygon(pour),
      layers: [pour.layer],
      netId,
      isPour: true,
      pour
    });
  }
  const components = new Map(
    circuitJson.filter((e) => e.type === "pcb_component").map((e) => [e.pcb_component_id, e])
  );
  if (pouredNets.size > 0) {
    for (const copper of circuitJson) {
      if (copper.type === "pcb_trace") {
        const netId2 = netForId(copper.pcb_trace_id);
        if (!netId2 || !pouredNets.has(netId2)) continue;
        for (let i = 0; i < copper.route.length - 1; i++) {
          const start = copper.route[i];
          const end = copper.route[i + 1];
          const from = getRouteEndpoint(start, "end");
          const to = getRouteEndpoint(end, "start");
          if (from.layer !== to.layer) continue;
          const width = start.route_type === "via" ? end.route_type === "via" ? void 0 : end.width : start.width;
          if (width === void 0) continue;
          const endWidth = copper.route_thickness_mode === "interpolated" && end.route_type !== "via" ? end.width : width;
          add({
            polygon: getTraceSegmentPolygon(
              from.point,
              to.point,
              width,
              endWidth
            ),
            layers: [from.layer],
            netId: netId2
          });
        }
        continue;
      }
      if (copper.type !== "pcb_smtpad" && copper.type !== "pcb_plated_hole" && copper.type !== "pcb_via")
        continue;
      const netId = netForId(getPrimaryId(copper));
      if (!netId || !pouredNets.has(netId)) continue;
      if (copper.type === "pcb_smtpad") {
        add({
          polygon: getSmtPadPolygon(copper),
          layers: [copper.layer],
          netId,
          portIds: copper.pcb_port_id ? [copper.pcb_port_id] : [],
          isTerminal: !!copper.pcb_port_id
        });
      } else if (copper.type === "pcb_plated_hole") {
        add({
          polygon: getPlatedHolePolygon(
            copper,
            copper.pcb_component_id ? components.get(copper.pcb_component_id)?.rotation : 0
          ),
          layers: copper.layers,
          netId,
          portIds: copper.pcb_port_id ? [copper.pcb_port_id] : [],
          isTerminal: !!copper.pcb_port_id
        });
      } else {
        add({
          polygon: getViaPolygon(
            copper,
            copper.outer_diameter,
            copper.hole_diameter
          ),
          layers: copper.layers,
          netId,
          portIds: copper.pcb_port_ids,
          isTerminal: true
        });
      }
    }
  }
  const parent = conductors.map((_, i) => i);
  const find = (i) => {
    while (parent[i] !== i) {
      parent[i] = parent[parent[i]];
      i = parent[i];
    }
    return i;
  };
  const bounds = conductors.map((c) => c.polygon.box);
  const order = conductors.map((_, i) => i).sort((a, b) => bounds[a].xmin - bounds[b].xmin);
  for (let a = 0; a < order.length; a++) {
    const i = order[a];
    for (let b = a + 1; b < order.length; b++) {
      const j = order[b];
      if (bounds[j].xmin > bounds[i].xmax + tolerance) break;
      if (find(i) === find(j) || conductors[i].netId !== conductors[j].netId)
        continue;
      if (bounds[j].ymin > bounds[i].ymax + tolerance || bounds[j].ymax < bounds[i].ymin - tolerance)
        continue;
      if (!conductors[i].layers.some(
        (layer) => conductors[j].layers.includes(layer)
      ))
        continue;
      if (copperPolygonsTouch(conductors[i].polygon, conductors[j].polygon))
        parent[find(j)] = find(i);
    }
  }
  const pourRoots = new Set(
    conductors.flatMap((c, i) => c.isPour ? [find(i)] : [])
  );
  const rootsByPort = /* @__PURE__ */ new Map();
  for (const [i, conductor] of conductors.entries()) {
    if (!pourRoots.has(find(i))) continue;
    for (const portId of conductor.portIds ?? []) {
      const roots = rootsByPort.get(portId) ?? /* @__PURE__ */ new Set();
      roots.add(find(i));
      rootsByPort.set(portId, roots);
    }
  }
  const portsByNet = /* @__PURE__ */ new Map();
  for (const port of circuitJson) {
    if (port.type !== "pcb_port") continue;
    const netId = netForId(port.pcb_port_id);
    if (!netId || !pouredNets.has(netId)) continue;
    const ports = portsByNet.get(netId) ?? [];
    ports.push(port.pcb_port_id);
    portsByNet.set(netId, ports);
  }
  const terminalRoots = new Set(
    conductors.flatMap(
      (conductor, i) => conductor.isTerminal ? [find(i)] : []
    )
  );
  return {
    getIsolatedPours() {
      return conductors.flatMap(
        (conductor, i) => conductor.pour && !terminalRoots.has(find(i)) ? [conductor.pour] : []
      );
    },
    isPortConnectedToNet(portId, sourceNetIds) {
      const roots = rootsByPort.get(portId);
      return sourceNetIds.every(
        (id) => [...roots ?? []].some(
          (root) => conductors[root].netId === netForId(id) && // Distinct same-net islands are not a physical connection.
          (portsByNet.get(conductors[root].netId) ?? []).every(
            (peer) => rootsByPort.get(peer)?.has(root)
          )
        )
      );
    },
    arePortsConnected(portIds) {
      if (portIds.length < 2) return false;
      return [...rootsByPort.get(portIds[0]) ?? []].some(
        (root) => portIds.every((id) => rootsByPort.get(id)?.has(root))
      );
    }
  };
}

// lib/util/get-readable-names.ts
import {
  getReadableNameForElement,
  getBoundsOfPcbElements,
  getPrimaryId as getPrimaryId2
} from "@tscircuit/circuit-json-util";
var CIRCUIT_JSON_ID_PATTERN = /\b(?:pcb|source|schematic|subcircuit)_[a-z0-9_]+\b/i;
var sanitizeReadableName = (candidate, id, fallbackLabel) => {
  if (!candidate || candidate === id || id.length > 0 && candidate.includes(id) || CIRCUIT_JSON_ID_PATTERN.test(candidate)) {
    return fallbackLabel;
  }
  return candidate;
};
var firstReadableName = (candidates, id) => {
  for (const candidate of candidates) {
    const readableName = sanitizeReadableName(candidate, id, "");
    if (readableName) return readableName;
  }
  return "";
};
var getReadableNameForComponent = (circuitJson, pcbComponentId) => getReadableNameForElementId(circuitJson, pcbComponentId);
var getReadableNameForSourcePort = (circuitJson, sourcePort) => {
  const sourceComponent = circuitJson.find(
    (element) => element.type === "source_component" && element.source_component_id === sourcePort.source_component_id
  );
  const componentName = sourceComponent?.type === "source_component" ? firstReadableName(
    [sourceComponent.name],
    sourceComponent.source_component_id
  ) : "";
  const pinName = firstReadableName(
    [
      sourcePort.name,
      sourcePort.pin_number?.toString(),
      sourcePort.port_hints?.[0]
    ],
    sourcePort.source_port_id
  );
  return `${componentName || "unnamed component"}.${pinName || "unnamed pin"}`;
};
var getReadableNameForPort = (circuitJson, pcbPortId) => {
  const pcbPort = circuitJson.find(
    (element) => element.type === "pcb_port" && element.pcb_port_id === pcbPortId
  );
  if (pcbPort?.type === "pcb_port") {
    const sourcePort = circuitJson.find(
      (element) => element.type === "source_port" && element.source_port_id === pcbPort.source_port_id
    );
    const sourceComponent = sourcePort?.type === "source_port" ? circuitJson.find(
      (element) => element.type === "source_component" && element.source_component_id === sourcePort.source_component_id
    ) : null;
    const readableSourceComponentName = firstReadableName(
      [
        sourceComponent?.type === "source_component" ? sourceComponent.name : null
      ],
      sourceComponent?.type === "source_component" ? sourceComponent.source_component_id : ""
    );
    const readableSourcePortName = firstReadableName(
      [
        sourcePort?.type === "source_port" ? sourcePort.name : null,
        sourcePort?.type === "source_port" ? sourcePort.pin_number?.toString() : null,
        sourcePort?.type === "source_port" ? sourcePort.port_hints?.[0] : null
      ],
      sourcePort?.type === "source_port" ? sourcePort.source_port_id : ""
    );
    if (readableSourceComponentName && readableSourcePortName) {
      return `${readableSourceComponentName}.${readableSourcePortName}`;
    }
    if (readableSourcePortName) {
      return readableSourcePortName;
    }
  }
  return "unnamed port";
};
var getReadableNameForSourceTrace = (circuitJson, sourceTrace) => {
  const displayName = sanitizeReadableName(
    sourceTrace.display_name,
    sourceTrace.source_trace_id,
    ""
  );
  if (displayName) return displayName;
  const connectedPortNames = [];
  for (const sourcePortId of sourceTrace.connected_source_port_ids ?? []) {
    const pcbPort = circuitJson.find(
      (element) => element.type === "pcb_port" && element.source_port_id === sourcePortId
    );
    if (pcbPort?.type === "pcb_port") {
      const name = getReadableNameForPort(circuitJson, pcbPort.pcb_port_id);
      if (name !== "unnamed port") connectedPortNames.push(name);
    } else {
      const sourcePort = circuitJson.find(
        (element) => element.type === "source_port" && element.source_port_id === sourcePortId
      );
      if (sourcePort?.type !== "source_port") continue;
      const sourceComponent = circuitJson.find(
        (element) => element.type === "source_component" && element.source_component_id === sourcePort.source_component_id
      );
      const sourceComponentName = sourceComponent?.type === "source_component" ? sanitizeReadableName(
        sourceComponent.name,
        sourceComponent.source_component_id,
        ""
      ) : "";
      const sourcePortName = firstReadableName(
        [
          sourcePort.name,
          sourcePort.pin_number?.toString(),
          sourcePort.port_hints?.[0]
        ],
        sourcePort.source_port_id
      );
      if (sourceComponentName && sourcePortName) {
        connectedPortNames.push(`${sourceComponentName}.${sourcePortName}`);
      } else if (sourcePortName) {
        connectedPortNames.push(sourcePortName);
      }
    }
    if (connectedPortNames.length === 2) {
      return `${connectedPortNames[0]} to ${connectedPortNames[1]}`;
    }
  }
  if (connectedPortNames.length === 1) {
    return `trace connected to ${connectedPortNames[0]}`;
  }
  return "unnamed trace";
};
var getReadableNameForElementId = (circuitJson, elementId) => {
  const element = circuitJson.find(
    (record) => getPrimaryId2(record) === elementId
  );
  if (!element) return "unnamed element";
  if (element.type === "pcb_component" || element.type === "schematic_component") {
    const component = circuitJson.find(
      (record) => record.type === "source_component" && record.source_component_id === element.source_component_id
    );
    if (component?.type === "source_component")
      return sanitizeReadableName(
        component.name,
        component.source_component_id,
        "unnamed component"
      );
  }
  if ((element.type === "pcb_smtpad" || element.type === "pcb_plated_hole") && element.pcb_port_id) {
    const portName = getReadableNameForPort(circuitJson, element.pcb_port_id);
    if (portName !== "unnamed port") return portName;
  }
  if (element.type === "pcb_trace")
    return getReadableNameForTrace(circuitJson, elementId);
  const labels = {
    pcb_smtpad: "SMD pad",
    pcb_plated_hole: "through-hole pad",
    pcb_via: "via",
    pcb_hole: "hole",
    pcb_bend: "bend",
    pcb_stiffener: "stiffener",
    pcb_keepout: "keepout",
    pcb_cutout: "cutout",
    pcb_copper_pour: "copper pour"
  };
  const label = labels[element.type] ?? element.type.replace(/^(pcb|source|schematic)_/, "").replaceAll("_", " ");
  const explicitName = "name" in element ? element.name : void 0;
  const description = "description" in element ? element.description : void 0;
  return firstReadableName(
    [
      explicitName,
      description,
      getReadableNameForElement(circuitJson, elementId)
    ],
    elementId
  ) || `unnamed ${label}`;
};
var getReadableNameForTrace = (circuitJson, pcbTraceId) => {
  const trace = circuitJson.find(
    (record) => record.type === "pcb_trace" && record.pcb_trace_id === pcbTraceId
  );
  if (trace?.type === "pcb_trace" && trace.source_trace_id) {
    const sourceTrace = circuitJson.find(
      (record) => record.type === "source_trace" && record.source_trace_id === trace.source_trace_id
    );
    if (sourceTrace?.type === "source_trace")
      return getReadableNameForSourceTrace(circuitJson, sourceTrace);
  }
  if (trace?.type !== "pcb_trace") return "unnamed trace";
  const portIds = [
    ...new Set(
      trace.route.flatMap(
        (point2) => point2.route_type === "wire" ? [point2.start_pcb_port_id, point2.end_pcb_port_id] : []
      ).filter((id) => Boolean(id))
    )
  ];
  const portNames = portIds.map((id) => getReadableNameForPort(circuitJson, id)).filter((name) => name !== "unnamed port");
  if (portNames.length >= 2) return `${portNames[0]} to ${portNames[1]}`;
  if (portNames.length === 1) return `trace connected to ${portNames[0]}`;
  return "unnamed trace";
};
function getReadableNameForFootprintPad(circuitJson, pad, ordinal) {
  const padKind = pad.type === "pcb_smtpad" ? "SMD pad" : "through-hole pad";
  const portRef = pad.pcb_port_id ? getReadableNameForPort(circuitJson, pad.pcb_port_id) : null;
  const bounds = getBoundsOfPcbElements([pad]);
  const centerX = (bounds.minX + bounds.maxX) / 2;
  const centerY = (bounds.minY + bounds.maxY) / 2;
  const location = `(${centerX.toFixed(2)}mm, ${centerY.toFixed(2)}mm)`;
  if (portRef) return `${padKind} ${portRef} at ${location}`;
  return `${padKind} #${ordinal + 1} at ${location}`;
}

// lib/check-copper-pour-islands.ts
function checkCopperPourIslands(circuitJson, { connMap } = {}) {
  if (!circuitJson.some((e) => e.type === "pcb_copper_pour" && e.source_net_id))
    return [];
  connMap ??= getFullConnectivityMapFromCircuitJson(circuitJson);
  return getCopperPourConnectivity(circuitJson, connMap).getIsolatedPours().map((pour) => {
    const box = getPourPolygon2(pour).box;
    const center = {
      x: (box.xmin + box.xmax) / 2,
      y: (box.ymin + box.ymax) / 2
    };
    const netName = getReadableNameForElementId(
      circuitJson,
      pour.source_net_id
    );
    return {
      type: "pcb_copper_pour_isolated_warning",
      pcb_copper_pour_isolated_warning_id: `pcb_copper_pour_isolated_warning_${pour.pcb_copper_pour_id}`,
      warning_type: "pcb_copper_pour_isolated_warning",
      pcb_copper_pour_id: pour.pcb_copper_pour_id,
      source_net_id: pour.source_net_id,
      layer: pour.layer,
      center,
      message: `Copper pour for ${netName} has an isolated island on ${pour.layer} near (${center.x.toFixed(2)} mm, ${center.y.toFixed(2)} mm) with no physical connection to a same-net pad or via`,
      subcircuit_id: pour.subcircuit_id
    };
  });
}

// lib/check-traces-are-contiguous/is-point-in-pad.ts
import { pointToSegmentDistance } from "@tscircuit/math-utils";

// lib/check-each-pcb-trace-non-overlapping/segment-to-polygon-clearance.ts
import {
  distSq,
  getSegmentIntersection,
  isPointInsidePolygon,
  pointToSegmentClosestPoint,
  segmentToSegmentMinDistance
} from "@tscircuit/math-utils";
var rotatePoint = (point2, angleDegrees) => {
  const angle = angleDegrees * Math.PI / 180;
  return {
    x: point2.x * Math.cos(angle) - point2.y * Math.sin(angle),
    y: point2.x * Math.sin(angle) + point2.y * Math.cos(angle)
  };
};
var getRotatedRectPoints = ({
  x,
  y,
  width,
  height,
  ccwRotation
}) => {
  const halfWidth = width / 2;
  const halfHeight = height / 2;
  return [
    { x: -halfWidth, y: -halfHeight },
    { x: halfWidth, y: -halfHeight },
    { x: halfWidth, y: halfHeight },
    { x: -halfWidth, y: halfHeight }
  ].map((point2) => {
    const rotated = rotatePoint(point2, ccwRotation);
    return { x: x + rotated.x, y: y + rotated.y };
  });
};
var getPillCenterLineForPad = (pad) => {
  let width;
  let height;
  let radius;
  let ccwRotation = 0;
  if (pad.type === "pcb_hole") {
    width = pad.hole_width;
    height = pad.hole_height;
    radius = Math.min(width, height) / 2;
    if (pad.hole_shape === "rotated_pill") ccwRotation = pad.ccw_rotation;
  } else if (pad.type === "pcb_plated_hole") {
    width = pad.outer_width;
    height = pad.outer_height;
    radius = Math.min(width, height) / 2;
    ccwRotation = pad.ccw_rotation;
  } else {
    width = pad.width;
    height = pad.height;
    radius = pad.radius;
    if (pad.shape === "rotated_pill") ccwRotation = pad.ccw_rotation;
  }
  const halfLineLength = Math.max(Math.max(width, height) / 2 - radius, 0);
  const axis = width >= height ? { x: halfLineLength, y: 0 } : { x: 0, y: halfLineLength };
  const rotatedAxis = rotatePoint(axis, ccwRotation);
  return {
    start: { x: pad.x - rotatedAxis.x, y: pad.y - rotatedAxis.y },
    end: { x: pad.x + rotatedAxis.x, y: pad.y + rotatedAxis.y },
    radius
  };
};
var getPolygonPointsForPad = (pad) => {
  if (pad.type === "pcb_smtpad") {
    if (pad.shape === "polygon") return pad.points;
    if (pad.shape === "rotated_rect") {
      return getRotatedRectPoints({
        x: pad.x,
        y: pad.y,
        width: pad.width,
        height: pad.height,
        ccwRotation: pad.ccw_rotation
      });
    }
  }
  if (pad.type === "pcb_plated_hole" && "rect_pad_width" in pad && "rect_pad_height" in pad) {
    return getRotatedRectPoints({
      x: pad.x,
      y: pad.y,
      width: pad.rect_pad_width,
      height: pad.rect_pad_height,
      ccwRotation: "rect_ccw_rotation" in pad && typeof pad.rect_ccw_rotation === "number" ? pad.rect_ccw_rotation : 0
    });
  }
  throw new Error(
    `Expected polygonal pad geometry, got ${pad.type} with shape "${pad.shape}"`
  );
};
var getPolygonEdges = (points) => points.map(
  (point2, index) => [point2, points[(index + 1) % points.length]]
);
var getClosestPointsBetweenSegments = (a1, a2, b1, b2) => {
  const intersection = getSegmentIntersection(a1, a2, b1, b2);
  if (intersection) {
    return {
      distance: 0,
      pointOnA: intersection,
      pointOnB: intersection,
      center: intersection
    };
  }
  const candidates = [
    { pointOnA: a1, pointOnB: pointToSegmentClosestPoint(a1, b1, b2) },
    { pointOnA: a2, pointOnB: pointToSegmentClosestPoint(a2, b1, b2) },
    { pointOnA: pointToSegmentClosestPoint(b1, a1, a2), pointOnB: b1 },
    { pointOnA: pointToSegmentClosestPoint(b2, a1, a2), pointOnB: b2 }
  ];
  let best = candidates[0];
  let bestDistanceSquared = distSq(best.pointOnA, best.pointOnB);
  for (const candidate of candidates.slice(1)) {
    const candidateDistanceSquared = distSq(
      candidate.pointOnA,
      candidate.pointOnB
    );
    if (candidateDistanceSquared < bestDistanceSquared) {
      best = candidate;
      bestDistanceSquared = candidateDistanceSquared;
    }
  }
  return {
    distance: segmentToSegmentMinDistance(a1, a2, b1, b2),
    pointOnA: best.pointOnA,
    pointOnB: best.pointOnB,
    center: {
      x: (best.pointOnA.x + best.pointOnB.x) / 2,
      y: (best.pointOnA.y + best.pointOnB.y) / 2
    }
  };
};
var getSegmentToPolygonClearanceFromPoints = (start, end, polygon) => {
  if (polygon.length < 3) {
    return {
      distance: Number.POSITIVE_INFINITY,
      center: start,
      tracePoint: start,
      obstaclePoint: start
    };
  }
  const intersections = getPolygonEdges(polygon).map(
    ([edgeStart, edgeEnd]) => getSegmentIntersection(start, end, edgeStart, edgeEnd)
  ).filter((point2) => point2 !== null);
  if (intersections.length > 0) {
    const dx = end.x - start.x;
    const dy = end.y - start.y;
    const lengthSquared = dx * dx + dy * dy;
    intersections.sort((a, b) => {
      const ta = ((a.x - start.x) * dx + (a.y - start.y) * dy) / lengthSquared;
      const tb = ((b.x - start.x) * dx + (b.y - start.y) * dy) / lengthSquared;
      return ta - tb;
    });
    return {
      distance: 0,
      center: intersections[0],
      tracePoint: intersections[0],
      obstaclePoint: intersections[0]
    };
  }
  if (isPointInsidePolygon(start, polygon) || isPointInsidePolygon(end, polygon)) {
    const center = {
      x: (start.x + end.x) / 2,
      y: (start.y + end.y) / 2
    };
    return {
      distance: 0,
      center,
      tracePoint: center,
      obstaclePoint: center
    };
  }
  let best = getClosestPointsBetweenSegments(
    start,
    end,
    polygon[0],
    polygon[1]
  );
  for (const [edgeStart, edgeEnd] of getPolygonEdges(polygon).slice(1)) {
    const candidate = getClosestPointsBetweenSegments(
      start,
      end,
      edgeStart,
      edgeEnd
    );
    if (candidate.distance < best.distance) best = candidate;
  }
  return {
    distance: best.distance,
    center: best.center,
    tracePoint: best.pointOnA,
    obstaclePoint: best.pointOnB
  };
};
var getSegmentToPillClearance = (segment, pad) => {
  const pill = getPillCenterLineForPad(pad);
  const closest = getClosestPointsBetweenSegments(
    { x: segment.x1, y: segment.y1 },
    { x: segment.x2, y: segment.y2 },
    pill.start,
    pill.end
  );
  return {
    distance: closest.distance,
    center: closest.center,
    radius: pill.radius,
    tracePoint: closest.pointOnA,
    obstaclePoint: closest.pointOnB
  };
};

// lib/check-traces-are-contiguous/is-point-in-pad.ts
function getDistanceBetweenPoints(pointA, pointB) {
  return Math.sqrt((pointB.x - pointA.x) ** 2 + (pointB.y - pointA.y) ** 2);
}
var POINT_ON_SEGMENT_TOLERANCE_MM = 1e-9;
var POINT_IN_PAD_TOLERANCE_MM = 1e-9;
function isPointOnSegment(point2, segment) {
  const crossProduct = (point2.y - segment.start.y) * (segment.end.x - segment.start.x) - (point2.x - segment.start.x) * (segment.end.y - segment.start.y);
  if (Math.abs(crossProduct) > POINT_ON_SEGMENT_TOLERANCE_MM) return false;
  const dotProduct = (point2.x - segment.start.x) * (segment.end.x - segment.start.x) + (point2.y - segment.start.y) * (segment.end.y - segment.start.y);
  if (dotProduct < -POINT_ON_SEGMENT_TOLERANCE_MM) return false;
  const squaredLength = (segment.end.x - segment.start.x) ** 2 + (segment.end.y - segment.start.y) ** 2;
  return dotProduct <= squaredLength + POINT_ON_SEGMENT_TOLERANCE_MM;
}
function isPointInPolygon(point2, polygon) {
  let inside = false;
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const pi = polygon[i];
    const pj = polygon[j];
    if (isPointOnSegment(point2, { start: pi, end: pj })) return true;
    const intersects = pi.y > point2.y !== pj.y > point2.y && point2.x < (pj.x - pi.x) * (point2.y - pi.y) / (pj.y - pi.y) + pi.x;
    if (intersects) inside = !inside;
  }
  return inside;
}
function isPointInPad(point2, pad) {
  if (pad.type === "pcb_smtpad") {
    if (pad.shape === "circle") {
      return getDistanceBetweenPoints(point2, pad) <= pad.radius + POINT_IN_PAD_TOLERANCE_MM;
    }
    if (pad.shape === "rect") {
      const halfWidth = pad.width / 2;
      const halfHeight = pad.height / 2;
      return Math.abs(point2.x - pad.x) <= halfWidth + POINT_IN_PAD_TOLERANCE_MM && Math.abs(point2.y - pad.y) <= halfHeight + POINT_IN_PAD_TOLERANCE_MM;
    }
    if (pad.shape === "rotated_rect") {
      return isPointInPolygon(point2, getPolygonPointsForPad(pad));
    }
    if (pad.shape === "pill" || pad.shape === "rotated_pill") {
      if (pad.shape === "rotated_pill") {
        const pill = getPillCenterLineForPad(pad);
        return pointToSegmentDistance(point2, pill.start, pill.end) <= pill.radius + POINT_IN_PAD_TOLERANCE_MM;
      }
      const halfWidth = pad.width / 2;
      const halfHeight = pad.height / 2;
      const radius = pad.radius;
      if (Math.abs(point2.x - pad.x) <= halfWidth - radius + POINT_IN_PAD_TOLERANCE_MM && Math.abs(point2.y - pad.y) <= halfHeight + POINT_IN_PAD_TOLERANCE_MM) {
        return true;
      }
      const cornerX = Math.max(
        Math.abs(point2.x - pad.x) - (halfWidth - radius),
        0
      );
      const cornerY = Math.max(
        Math.abs(point2.y - pad.y) - (halfHeight - radius),
        0
      );
      const radiusWithTolerance = radius + POINT_IN_PAD_TOLERANCE_MM;
      return cornerX * cornerX + cornerY * cornerY <= radiusWithTolerance * radiusWithTolerance;
    }
    if (pad.shape === "polygon") {
      return isPointInPolygon(point2, pad.points);
    }
  }
  if (pad.type === "pcb_plated_hole") {
    if (pad.shape === "circle") {
      return getDistanceBetweenPoints(point2, pad) <= pad.outer_diameter / 2 + POINT_IN_PAD_TOLERANCE_MM;
    }
    if ("rect_pad_width" in pad && "rect_pad_height" in pad) {
      return isPointInPolygon(point2, getPolygonPointsForPad(pad));
    }
    if (pad.shape === "oval" || pad.shape === "pill") {
      return Math.abs(point2.x - pad.x) <= pad.outer_width / 2 + POINT_IN_PAD_TOLERANCE_MM && Math.abs(point2.y - pad.y) <= pad.outer_height / 2 + POINT_IN_PAD_TOLERANCE_MM;
    }
  }
  return false;
}

// lib/util/getLayersOfPcbElement.ts
import { all_layers } from "circuit-json";
function getLayersOfPcbElement(obj) {
  if (obj.type === "pcb_trace_segment") {
    return [obj.layer];
  }
  if (obj.type === "pcb_smtpad") {
    return [obj.layer];
  }
  if (obj.type === "pcb_plated_hole") {
    return Array.isArray(obj.layers) ? obj.layers : [...all_layers];
  }
  if (obj.type === "pcb_hole") {
    return [...all_layers];
  }
  if (obj.type === "pcb_via") {
    return Array.isArray(obj.layers) ? obj.layers : [...all_layers];
  }
  if (obj.type === "pcb_keepout") {
    return Array.isArray(obj.layers) ? obj.layers : [];
  }
  return [];
}

// lib/util/route-point-touches-pad.ts
function routePointTouchesPad(point2, pad) {
  return point2.route_type === "wire" && getLayersOfPcbElement(pad).includes(point2.layer) && isPointInPad(point2, pad);
}

// lib/check-dangling-traces/types.ts
var CONTACT_EPSILON_MM = 1e-9;

// lib/check-dangling-traces/endpoint-contact.ts
import { pointToSegmentDistance as pointToSegmentDistance3 } from "@tscircuit/math-utils";
import {
  getFullConnectivityMapFromCircuitJson as getFullConnectivityMapFromCircuitJson2
} from "circuit-json-to-connectivity-map";

// lib/check-dangling-traces/pour-contact-index.ts
import { Circle, Point, Polygon as Polygon2 } from "@flatten-js/core";
import { getPourPolygon as getPourPolygon3, getViaPolygon as getViaPolygon2 } from "@tscircuit/circuit-json-util";
var POLYGON_SCALE = 1e6;
function getContactCopperPolygon({
  center,
  radius,
  holeRadius = 0
}) {
  if (holeRadius > 0) {
    return getViaPolygon2(center, radius * 2, holeRadius * 2).scale(
      POLYGON_SCALE,
      POLYGON_SCALE
    );
  }
  return new Polygon2(
    new Circle(
      new Point(center.x * POLYGON_SCALE, center.y * POLYGON_SCALE),
      radius * POLYGON_SCALE
    )
  );
}
function getPourContactTester(circuitJson, connMap) {
  const pourPolygonsByNetId = /* @__PURE__ */ new Map();
  for (const pour of circuitJson) {
    if (pour.type !== "pcb_copper_pour" || !pour.source_net_id) continue;
    const netId = connMap.getNetConnectedToId(pour.source_net_id);
    if (!netId) continue;
    const pours = pourPolygonsByNetId.get(netId) ?? [];
    pours.push({
      layer: pour.layer,
      polygon: getPourPolygon3(pour).scale(POLYGON_SCALE, POLYGON_SCALE)
    });
    pourPolygonsByNetId.set(netId, pours);
  }
  const copperPolygonsTouch = createCopperPolygonContactTester(
    CONTACT_EPSILON_MM * POLYGON_SCALE
  );
  return (contact) => {
    const pours = (pourPolygonsByNetId.get(contact.netId) ?? []).filter(
      (pour) => contact.layers.includes(pour.layer)
    );
    if (contact.radius === 0) {
      const contactPoint = new Point(
        contact.center.x * POLYGON_SCALE,
        contact.center.y * POLYGON_SCALE
      );
      return pours.some((pour) => pour.polygon.contains(contactPoint));
    }
    if (pours.length === 0) return false;
    const contactPolygon = getContactCopperPolygon(contact);
    return pours.some(
      (pour) => copperPolygonsTouch(contactPolygon, pour.polygon)
    );
  };
}

// lib/check-dangling-traces/via-contact-index.ts
import {
  all_layers as all_layers2
} from "circuit-json";
import { getPrimaryId as getPrimaryId3 } from "@tscircuit/circuit-json-util";
import { pointToSegmentDistance as pointToSegmentDistance2 } from "@tscircuit/math-utils";

// lib/check-pad-clearance/common.ts
import {
  cju,
  distanceBetweenCircleAndCircle,
  distanceBetweenCircleAndPolygon,
  distanceBetweenPolygonAndPolygon,
  getBoundsOfPcbElements as getBoundsOfPcbElements2
} from "@tscircuit/circuit-json-util";
import {
  midpoint,
  pointToSegmentClosestPoint as pointToSegmentClosestPoint2,
  segmentToCircleMinDistance,
  segmentToSegmentMinDistance as segmentToSegmentMinDistance2
} from "@tscircuit/math-utils";

// node_modules/@tscircuit/jlcpcb-manufacturing-specs/lib/jlcpcb-manufacturing-specs.ts
var jlcMinTolerances = {
  min_trace_width: 0.1,
  min_via_hole_edge_to_via_hole_edge_clearance: 0.1,
  min_plated_hole_drill_edge_to_drill_edge_clearance: 0.15,
  min_trace_to_hole_edge_clearance: 0.2,
  min_trace_to_pad_edge_clearance: 0.1,
  min_pad_edge_to_pad_edge_clearance: 0.1,
  min_board_edge_clearance: 0.2,
  min_via_hole_diameter: 0.2,
  min_via_pad_diameter: 0.3
};

// lib/drc-defaults.ts
var DEFAULT_TRACE_MARGIN = 0.1;
var DEFAULT_TRACE_THICKNESS = jlcMinTolerances.min_trace_width;
var DEFAULT_VIA_DIAMETER = jlcMinTolerances.min_via_pad_diameter;
var DEFAULT_VIA_BOARD_MARGIN = jlcMinTolerances.min_board_edge_clearance;
var DEFAULT_SAME_NET_VIA_MARGIN = jlcMinTolerances.min_via_hole_edge_to_via_hole_edge_clearance;
var DEFAULT_DIFFERENT_NET_VIA_MARGIN = jlcMinTolerances.min_via_hole_edge_to_via_hole_edge_clearance;
var DEFAULT_PAD_PAD_CLEARANCE = jlcMinTolerances.min_pad_edge_to_pad_edge_clearance;
var EPSILON = 5e-3;
var getPcbBoard = (circuitJson) => circuitJson.find((el) => el.type === "pcb_board");
var getBoardDrcValue = (board, key) => board?.[key];

// lib/check-pad-clearance/common.ts
var getPadBounds = (pad) => {
  if (pad.type === "pcb_keepout") {
    if (pad.shape === "outline") {
      return {
        minX: Math.min(...pad.outline.map((point2) => point2.x)),
        minY: Math.min(...pad.outline.map((point2) => point2.y)),
        maxX: Math.max(...pad.outline.map((point2) => point2.x)),
        maxY: Math.max(...pad.outline.map((point2) => point2.y))
      };
    }
    if (pad.shape === "circle") {
      return {
        minX: pad.center.x - pad.radius,
        minY: pad.center.y - pad.radius,
        maxX: pad.center.x + pad.radius,
        maxY: pad.center.y + pad.radius
      };
    }
    return {
      minX: pad.center.x - pad.width / 2,
      minY: pad.center.y - pad.height / 2,
      maxX: pad.center.x + pad.width / 2,
      maxY: pad.center.y + pad.height / 2
    };
  }
  return getBoundsOfPcbElements2([pad]);
};
var getPadCenter = (pad) => {
  if (pad.type === "pcb_keepout" && pad.shape !== "outline") return pad.center;
  const bounds = getPadBounds(pad);
  return midpoint(
    { x: bounds.minX, y: bounds.minY },
    { x: bounds.maxX, y: bounds.maxY }
  );
};
var getPadRadius = (pad) => {
  if (pad.type === "pcb_keepout" && pad.shape === "circle") return pad.radius;
  const bounds = getPadBounds(pad);
  return Math.min(bounds.maxX - bounds.minX, bounds.maxY - bounds.minY) / 2;
};
var isCircularPad = (pad) => pad.type === "pcb_via" || pad.shape === "circle";
var isPillPad = (pad) => pad.type === "pcb_smtpad" && (pad.shape === "pill" || pad.shape === "rotated_pill") || pad.type === "pcb_plated_hole" && (pad.shape === "oval" || pad.shape === "pill");
var getCircleShape = (pad) => {
  const center = getPadCenter(pad);
  return {
    kind: "circle",
    x: center.x,
    y: center.y,
    radius: getPadRadius(pad)
  };
};
var getPolygonShape = (pad) => {
  if (pad.type === "pcb_keepout") {
    if (pad.shape === "outline") {
      return {
        kind: "polygon",
        points: pad.outline
      };
    }
    if (pad.shape !== "rect") {
      throw new Error(`Expected rectangular keepout, got ${pad.shape}`);
    }
    return {
      kind: "polygon",
      points: [
        {
          x: pad.center.x - pad.width / 2,
          y: pad.center.y - pad.height / 2
        },
        {
          x: pad.center.x + pad.width / 2,
          y: pad.center.y - pad.height / 2
        },
        {
          x: pad.center.x + pad.width / 2,
          y: pad.center.y + pad.height / 2
        },
        {
          x: pad.center.x - pad.width / 2,
          y: pad.center.y + pad.height / 2
        }
      ]
    };
  }
  if (pad.type === "pcb_smtpad" && (pad.shape === "polygon" || pad.shape === "rotated_rect")) {
    return {
      kind: "polygon",
      points: getPolygonPointsForPad(pad)
    };
  }
  if (pad.type === "pcb_plated_hole" && "rect_pad_width" in pad && "rect_pad_height" in pad) {
    return {
      kind: "polygon",
      points: getPolygonPointsForPad(pad)
    };
  }
  const bounds = getPadBounds(pad);
  return {
    kind: "polygon",
    points: [
      { x: bounds.minX, y: bounds.minY },
      { x: bounds.maxX, y: bounds.minY },
      { x: bounds.maxX, y: bounds.maxY },
      { x: bounds.minX, y: bounds.maxY }
    ]
  };
};
var getRoundedPadCore = (pad) => {
  if (pad.type !== "pcb_smtpad" || pad.shape !== "rect" && pad.shape !== "rotated_rect" || !pad.corner_radius || pad.corner_radius <= 0)
    return null;
  const radius = Math.min(pad.corner_radius, pad.width / 2, pad.height / 2);
  if (radius === Math.min(pad.width, pad.height) / 2) {
    const core = {
      ...pad,
      shape: "rotated_pill",
      radius,
      ccw_rotation: pad.shape === "rotated_rect" ? pad.ccw_rotation : 0
    };
    return { core, radius: 0 };
  }
  return {
    core: {
      ...pad,
      width: pad.width - 2 * radius,
      height: pad.height - 2 * radius,
      corner_radius: 0
    },
    radius
  };
};
var getPadToPadGap = (padA, padB) => {
  const roundedA = getRoundedPadCore(padA);
  const roundedB = getRoundedPadCore(padB);
  if (roundedA || roundedB) {
    return getPadToPadGap(roundedA?.core ?? padA, roundedB?.core ?? padB) - (roundedA?.radius ?? 0) - (roundedB?.radius ?? 0);
  }
  if (isPillPad(padA) && isPillPad(padB)) {
    const pillA = getPillCenterLineForPad(padA);
    const pillB = getPillCenterLineForPad(padB);
    return segmentToSegmentMinDistance2(
      pillA.start,
      pillA.end,
      pillB.start,
      pillB.end
    ) - pillA.radius - pillB.radius;
  }
  if (isPillPad(padA) && isCircularPad(padB)) {
    const pill = getPillCenterLineForPad(padA);
    return segmentToCircleMinDistance(pill.start, pill.end, getCircleShape(padB)) - pill.radius;
  }
  if (isCircularPad(padA) && isPillPad(padB)) {
    const pill = getPillCenterLineForPad(padB);
    return segmentToCircleMinDistance(pill.start, pill.end, getCircleShape(padA)) - pill.radius;
  }
  if (isPillPad(padA)) {
    const pill = getPillCenterLineForPad(padA);
    return getSegmentToPolygonClearanceFromPoints(
      pill.start,
      pill.end,
      getPolygonShape(padB).points
    ).distance - pill.radius;
  }
  if (isPillPad(padB)) {
    const pill = getPillCenterLineForPad(padB);
    return getSegmentToPolygonClearanceFromPoints(
      pill.start,
      pill.end,
      getPolygonShape(padA).points
    ).distance - pill.radius;
  }
  if (isCircularPad(padA) && isCircularPad(padB)) {
    return distanceBetweenCircleAndCircle(
      getCircleShape(padA),
      getCircleShape(padB)
    );
  }
  if (isCircularPad(padA)) {
    return distanceBetweenCircleAndPolygon(
      getCircleShape(padA),
      getPolygonShape(padB)
    );
  }
  if (isCircularPad(padB)) {
    return distanceBetweenCircleAndPolygon(
      getCircleShape(padB),
      getPolygonShape(padA)
    );
  }
  return distanceBetweenPolygonAndPolygon(
    getPolygonShape(padA),
    getPolygonShape(padB)
  );
};
var getPads = (circuitJson) => [
  ...cju(circuitJson).pcb_smtpad.list(),
  ...cju(circuitJson).pcb_plated_hole.list()
];
var getTraceSegments = (circuitJson) => {
  const pcbTraces = cju(circuitJson).pcb_trace.list();
  return pcbTraces.flatMap((pcbTrace) => {
    const segments = [];
    for (let i = 0; i < pcbTrace.route.length - 1; i++) {
      const p1 = pcbTrace.route[i];
      const p2 = pcbTrace.route[i + 1];
      if (p1.route_type !== "wire") continue;
      if (p2.route_type !== "wire") continue;
      if (p1.layer !== p2.layer) continue;
      segments.push({
        type: "pcb_trace_segment",
        pcb_trace_id: pcbTrace.pcb_trace_id,
        _pcbTrace: pcbTrace,
        thickness: "width" in p1 ? p1.width : "width" in p2 ? p2.width : DEFAULT_TRACE_THICKNESS,
        layer: p1.layer,
        x1: p1.x,
        y1: p1.y,
        x2: p2.x,
        y2: p2.y
      });
    }
    return segments;
  });
};
var getCenterBetweenCopperEdges = ({
  tracePoint,
  obstaclePoint,
  traceRadius,
  obstacleRadius
}) => {
  const dx = obstaclePoint.x - tracePoint.x;
  const dy = obstaclePoint.y - tracePoint.y;
  const distance6 = Math.hypot(dx, dy);
  if (distance6 === 0) return midpoint(tracePoint, obstaclePoint);
  const unitX = dx / distance6;
  const unitY = dy / distance6;
  if (distance6 <= traceRadius + obstacleRadius) {
    const overlapStart = Math.max(-traceRadius, distance6 - obstacleRadius);
    const overlapEnd = Math.min(traceRadius, distance6 + obstacleRadius);
    const offset = (overlapStart + overlapEnd) / 2;
    return {
      x: tracePoint.x + unitX * offset,
      y: tracePoint.y + unitY * offset
    };
  }
  const traceEdge = {
    x: tracePoint.x + unitX * traceRadius,
    y: tracePoint.y + unitY * traceRadius
  };
  const obstacleEdge = {
    x: obstaclePoint.x - unitX * obstacleRadius,
    y: obstaclePoint.y - unitY * obstacleRadius
  };
  return midpoint(traceEdge, obstacleEdge);
};
var getTraceObstacleClearance = (segment, obstacle) => {
  const rounded = getRoundedPadCore(obstacle);
  if (rounded) obstacle = rounded.core;
  const obstacleRadius = rounded?.radius ?? 0;
  const start = { x: segment.x1, y: segment.y1 };
  const end = { x: segment.x2, y: segment.y2 };
  const traceRadius = segment.thickness / 2;
  if (obstacle.type === "pcb_via" || isCircularPad(obstacle)) {
    const circle2 = obstacle.type === "pcb_via" ? {
      x: obstacle.x,
      y: obstacle.y,
      radius: obstacle.outer_diameter / 2
    } : getCircleShape(obstacle);
    const closestPoint = pointToSegmentClosestPoint2(circle2, start, end);
    return {
      gap: segmentToCircleMinDistance(start, end, circle2) - traceRadius,
      center: getCenterBetweenCopperEdges({
        tracePoint: closestPoint,
        obstaclePoint: circle2,
        traceRadius,
        obstacleRadius: circle2.radius
      })
    };
  }
  if (isPillPad(obstacle)) {
    const clearance2 = getSegmentToPillClearance(segment, obstacle);
    return {
      gap: clearance2.distance - traceRadius - clearance2.radius,
      center: getCenterBetweenCopperEdges({
        tracePoint: clearance2.tracePoint,
        obstaclePoint: clearance2.obstaclePoint,
        traceRadius,
        obstacleRadius: clearance2.radius
      })
    };
  }
  const clearance = getSegmentToPolygonClearanceFromPoints(
    start,
    end,
    getPolygonShape(obstacle).points
  );
  return {
    gap: clearance.distance - traceRadius - obstacleRadius,
    center: getCenterBetweenCopperEdges({
      tracePoint: clearance.tracePoint,
      obstaclePoint: clearance.obstaclePoint,
      traceRadius,
      obstacleRadius
    })
  };
};
var isTraceObstacleOverlap = (gap) => gap <= 0;
var getViaPadClearanceCenter = (via, pad) => getTraceObstacleClearance(
  {
    x1: via.x,
    y1: via.y,
    x2: via.x,
    y2: via.y,
    thickness: via.outer_diameter
  },
  pad
).center;

// lib/check-dangling-traces/via-contact-index.ts
function getBoardLayerStack(circuitJson) {
  const layerCount = circuitJson.find(
    (element) => element.type === "pcb_board"
  )?.num_layers;
  let innerLayers = all_layers2.filter((layer) => layer.startsWith("inner"));
  if (layerCount !== void 0) {
    innerLayers = innerLayers.slice(0, Math.max(0, layerCount - 2));
  }
  const boardLayerStack = ["top", ...innerLayers];
  if (layerCount !== 1) boardLayerStack.push("bottom");
  return boardLayerStack;
}
function getPcbViaCoppers(vias) {
  return vias.filter(
    (via) => Number.isFinite(via.outer_diameter) && via.outer_diameter > 0
  ).map((via) => ({
    id: via.pcb_via_id,
    layers: getLayersOfPcbElement(via),
    x: via.x,
    y: via.y,
    radius: via.outer_diameter / 2,
    holeRadius: via.hole_diameter / 2
  }));
}
function getRouteViaCoppers({ traces, vias }, { circuitJson, connMap }) {
  const boardLayerStack = getBoardLayerStack(circuitJson);
  const viaCoppers = [];
  for (const trace of traces) {
    for (const point2 of trace.route) {
      if (point2.route_type !== "via") continue;
      const hasPcbVia = vias.some(
        (via) => Math.hypot(via.x - point2.x, via.y - point2.y) <= CONTACT_EPSILON_MM && (via.pcb_trace_id === trace.pcb_trace_id || !via.pcb_trace_id && connMap.areIdsConnected(via.pcb_via_id, trace.pcb_trace_id))
      );
      if (hasPcbVia) continue;
      const fromLayerIndex = boardLayerStack.indexOf(point2.from_layer);
      const toLayerIndex = boardLayerStack.indexOf(point2.to_layer);
      if (fromLayerIndex < 0 || toLayerIndex < 0) continue;
      const diameter = point2.outer_diameter;
      let radius;
      if (diameter !== void 0) {
        if (!Number.isFinite(diameter) || diameter <= 0) continue;
        radius = diameter / 2;
      }
      viaCoppers.push({
        id: trace.pcb_trace_id,
        layers: boardLayerStack.slice(
          Math.min(fromLayerIndex, toLayerIndex),
          Math.max(fromLayerIndex, toLayerIndex) + 1
        ),
        x: point2.x,
        y: point2.y,
        radius
      });
    }
  }
  return viaCoppers;
}
function viaTouchesPad({
  viaCopper,
  pad
}) {
  if (viaCopper.radius === void 0) return isPointInPad(viaCopper, pad);
  const viaGeometry = {
    type: "pcb_via",
    pcb_via_id: viaCopper.id,
    x: viaCopper.x,
    y: viaCopper.y,
    outer_diameter: viaCopper.radius * 2,
    hole_diameter: 0,
    layers: all_layers2.filter((layer) => viaCopper.layers.includes(layer))
  };
  return getPadToPadGap(viaGeometry, pad) <= CONTACT_EPSILON_MM;
}
function traceTouchesVia({
  trace,
  viaCopper
}) {
  if (trace.route_thickness_mode === "interpolated") return false;
  for (let i = 1; i < trace.route.length; i++) {
    const segmentStart = trace.route[i - 1];
    const segmentEnd = trace.route[i];
    if (segmentStart.route_type !== "wire" || segmentEnd.route_type !== "wire" || segmentStart.layer !== segmentEnd.layer || !viaCopper.layers.includes(segmentStart.layer) || !Number.isFinite(segmentStart.width) || segmentStart.width <= 0 || Math.hypot(
      segmentStart.x - segmentEnd.x,
      segmentStart.y - segmentEnd.y
    ) <= CONTACT_EPSILON_MM) {
      continue;
    }
    let contactDistance = 0;
    if (viaCopper.radius !== void 0) {
      contactDistance = viaCopper.radius + segmentStart.width / 2;
    }
    if (pointToSegmentDistance2(viaCopper, segmentStart, segmentEnd) <= contactDistance + CONTACT_EPSILON_MM) {
      return true;
    }
  }
  return false;
}
function getViaContactIndex(ctx) {
  const { circuitJson, connMap, touchesPour: touchesPour2 } = ctx;
  const pads = getPads(circuitJson);
  const traces = circuitJson.filter((element) => element.type === "pcb_trace");
  const vias = circuitJson.filter((element) => element.type === "pcb_via");
  const viaCoppers = [
    ...getPcbViaCoppers(vias),
    ...getRouteViaCoppers({ traces, vias }, ctx)
  ];
  const viaContactIndex = /* @__PURE__ */ new Map();
  for (const viaCopper of viaCoppers) {
    if (!Number.isFinite(viaCopper.x) || !Number.isFinite(viaCopper.y)) continue;
    const netId = connMap.getNetConnectedToId(viaCopper.id);
    if (!netId) continue;
    const touchesPadOrPour = touchesPour2({
      netId,
      layers: viaCopper.layers,
      center: viaCopper,
      radius: viaCopper.radius ?? 0,
      holeRadius: viaCopper.holeRadius
    }) || pads.some(
      (pad) => connMap.getNetConnectedToId(getPrimaryId3(pad)) === netId && getLayersOfPcbElement(pad).some(
        (layer) => viaCopper.layers.includes(layer)
      ) && viaTouchesPad({ viaCopper, pad })
    );
    const touchingTraceIds = /* @__PURE__ */ new Set();
    for (const trace of traces) {
      if (connMap.getNetConnectedToId(trace.pcb_trace_id) === netId && traceTouchesVia({ trace, viaCopper })) {
        touchingTraceIds.add(trace.pcb_trace_id);
      }
    }
    const viaContact = {
      viaCopper,
      touchesPadOrPour,
      touchingTraceIds
    };
    const contactsByLayer = viaContactIndex.get(netId) ?? /* @__PURE__ */ new Map();
    for (const layer of viaCopper.layers) {
      const contacts = contactsByLayer.get(layer) ?? [];
      contacts.push(viaContact);
      contactsByLayer.set(layer, contacts);
    }
    viaContactIndex.set(netId, contactsByLayer);
  }
  return viaContactIndex;
}
function endpointTouchesVia({
  trace,
  point: point2,
  width
}, {
  connMap,
  viaContactIndex
}) {
  if (!Number.isFinite(width) || width <= 0) return false;
  const netId = connMap.getNetConnectedToId(trace.pcb_trace_id);
  if (!netId) return false;
  const viaContacts = viaContactIndex.get(netId)?.get(point2.layer) ?? [];
  return viaContacts.some(
    ({ viaCopper, touchesPadOrPour, touchingTraceIds }) => {
      const hasOnwardConnection = touchesPadOrPour || [...touchingTraceIds].some((traceId) => traceId !== trace.pcb_trace_id);
      if (!hasOnwardConnection) return false;
      let contactDistance = 0;
      if (viaCopper.radius !== void 0) {
        contactDistance = viaCopper.radius + width / 2;
      }
      return Math.hypot(point2.x - viaCopper.x, point2.y - viaCopper.y) <= contactDistance + CONTACT_EPSILON_MM;
    }
  );
}

// lib/check-dangling-traces/endpoint-contact.ts
function getStraightRunEnd({
  route,
  anchorPoint,
  fromIndex,
  step
}) {
  let runEnd = anchorPoint;
  for (let i = fromIndex; i >= 0 && i < route.length; i += step) {
    const nextPoint = route[i];
    if (nextPoint.route_type !== "wire" || nextPoint.layer !== anchorPoint.layer || pointToSegmentDistance3(runEnd, anchorPoint, nextPoint) > CONTACT_EPSILON_MM) {
      break;
    }
    runEnd = nextPoint;
  }
  return runEnd;
}
function getTerminalWireSegment(trace, endpoint) {
  if (trace.route_thickness_mode === "interpolated") return void 0;
  const { route } = trace;
  let outerIndex = 0;
  let step = 1;
  if (endpoint === "end") {
    outerIndex = route.length - 1;
    step = -1;
  }
  let innerIndex = outerIndex + step;
  while (innerIndex >= 0 && innerIndex < route.length) {
    const outerPoint = route[outerIndex];
    const innerPoint = route[innerIndex];
    if (outerPoint.route_type !== "wire" || innerPoint.route_type !== "wire" || outerPoint.layer !== innerPoint.layer) {
      return void 0;
    }
    const isDuplicatePoint = Math.hypot(outerPoint.x - innerPoint.x, outerPoint.y - innerPoint.y) <= CONTACT_EPSILON_MM;
    if (!isDuplicatePoint) {
      let width = outerPoint.width;
      if (endpoint === "end") width = innerPoint.width;
      const inwardPoint = getStraightRunEnd({
        route,
        anchorPoint: outerPoint,
        fromIndex: innerIndex,
        step
      });
      return { width, inwardPoint };
    }
    outerIndex = innerIndex;
    innerIndex += step;
  }
  return void 0;
}
function getStraightRunStart({
  route,
  startIndex,
  start,
  end
}) {
  let runStart = start;
  for (let i = startIndex - 1; i >= 0; i--) {
    const previousPoint = route[i];
    if (previousPoint.route_type !== "wire" || previousPoint.layer !== end.layer || pointToSegmentDistance3(runStart, previousPoint, end) > CONTACT_EPSILON_MM) {
      break;
    }
    runStart = previousPoint;
  }
  return runStart;
}
function getTraceWireSegmentsByNetAndLayer(circuitJson, connMap) {
  const segmentsByNetAndLayer = /* @__PURE__ */ new Map();
  for (const trace of circuitJson) {
    if (trace.type !== "pcb_trace") continue;
    if (trace.route_thickness_mode === "interpolated") continue;
    const netId = connMap.getNetConnectedToId(trace.pcb_trace_id);
    if (!netId) continue;
    for (let i = 0; i < trace.route.length - 1; i++) {
      const start = trace.route[i];
      const end = trace.route[i + 1];
      if (start.route_type !== "wire" || end.route_type !== "wire") continue;
      if (start.layer !== end.layer) continue;
      if (Math.hypot(start.x - end.x, start.y - end.y) <= CONTACT_EPSILON_MM) {
        continue;
      }
      const centerlineStart = getStraightRunStart({
        route: trace.route,
        startIndex: i,
        start,
        end
      });
      const centerlineEnd = getStraightRunEnd({
        route: trace.route,
        anchorPoint: centerlineStart,
        fromIndex: i + 1,
        step: 1
      });
      const segmentsByLayer = segmentsByNetAndLayer.get(netId) ?? /* @__PURE__ */ new Map();
      const segments = segmentsByLayer.get(start.layer) ?? [];
      segments.push({ trace, start, end, centerlineStart, centerlineEnd });
      segmentsByLayer.set(start.layer, segments);
      segmentsByNetAndLayer.set(netId, segmentsByLayer);
    }
  }
  return segmentsByNetAndLayer;
}
function endpointTouchesTraceSegment({
  point: point2,
  terminalSegment,
  segment
}) {
  const distance6 = pointToSegmentDistance3(point2, segment.start, segment.end);
  const endpointRadius = terminalSegment.width / 2;
  const segmentRadius = segment.start.width / 2;
  if (distance6 + endpointRadius <= segmentRadius + CONTACT_EPSILON_MM) {
    return true;
  }
  const branchesFromSegment = pointToSegmentDistance3(
    terminalSegment.inwardPoint,
    segment.centerlineStart,
    segment.centerlineEnd
  ) <= CONTACT_EPSILON_MM && pointToSegmentDistance3(
    point2,
    segment.centerlineStart,
    segment.centerlineEnd
  ) > CONTACT_EPSILON_MM;
  if (branchesFromSegment) return false;
  return distance6 <= endpointRadius + segmentRadius + CONTACT_EPSILON_MM;
}
function createEndpointContactContext(circuitJson, connMap) {
  const portPads = circuitJson.filter(
    (element) => element.type === "pcb_smtpad" || element.type === "pcb_plated_hole"
  ).filter((pad) => pad.pcb_port_id);
  return { circuitJson, portPads, connMap };
}
function getCachedConnMap(ctx) {
  ctx.connMap ??= getFullConnectivityMapFromCircuitJson2(ctx.circuitJson);
  return ctx.connMap;
}
function getCachedPourContactTester(ctx) {
  ctx.touchesPour ??= getPourContactTester(
    ctx.circuitJson,
    getCachedConnMap(ctx)
  );
  return ctx.touchesPour;
}
function getCachedTraceWireSegments(ctx) {
  ctx.traceWireSegmentsByNetAndLayer ??= getTraceWireSegmentsByNetAndLayer(
    ctx.circuitJson,
    getCachedConnMap(ctx)
  );
  return ctx.traceWireSegmentsByNetAndLayer;
}
function getCachedViaContactIndex(ctx) {
  ctx.viaContactIndex ??= getViaContactIndex({
    circuitJson: ctx.circuitJson,
    connMap: getCachedConnMap(ctx),
    touchesPour: getCachedPourContactTester(ctx)
  });
  return ctx.viaContactIndex;
}
function endpointTouchesNetCopper({
  trace,
  point: point2,
  terminalSegment
}, ctx) {
  const connMap = getCachedConnMap(ctx);
  const netId = connMap.getNetConnectedToId(trace.pcb_trace_id);
  const touchesPour2 = getCachedPourContactTester(ctx);
  if (netId && touchesPour2({
    netId,
    layers: [point2.layer],
    center: point2,
    radius: terminalSegment.width / 2
  })) {
    return true;
  }
  const traceWireSegments = getCachedTraceWireSegments(ctx);
  if (netId) {
    const segments = traceWireSegments.get(netId)?.get(point2.layer) ?? [];
    const touchesTrace = segments.some(
      (segment) => segment.trace.pcb_trace_id !== trace.pcb_trace_id && endpointTouchesTraceSegment({ point: point2, terminalSegment, segment })
    );
    if (touchesTrace) return true;
  }
  return endpointTouchesVia(
    { trace, point: point2, width: terminalSegment.width },
    { connMap, viaContactIndex: getCachedViaContactIndex(ctx) }
  );
}

// lib/check-dangling-traces/check-dangling-traces.ts
function isEndpointDangling({
  trace,
  endpoint,
  point: point2,
  hasExpectedPorts
}, ctx) {
  if (ctx.portPads.some((pad) => routePointTouchesPad(point2, pad))) {
    return false;
  }
  const terminalSegment = getTerminalWireSegment(trace, endpoint);
  if (!terminalSegment) {
    return !hasExpectedPorts;
  }
  return !endpointTouchesNetCopper({ trace, point: point2, terminalSegment }, ctx);
}
function getDanglingEndpoints({ trace, hasExpectedPorts }, ctx) {
  const routeEndpoints = [
    { endpoint: "start", point: trace.route[0] },
    { endpoint: "end", point: trace.route[trace.route.length - 1] }
  ];
  const danglingEndpoints = [];
  for (const { endpoint, point: point2 } of routeEndpoints) {
    if (point2.route_type !== "wire") continue;
    if (isEndpointDangling({ trace, endpoint, point: point2, hasExpectedPorts }, ctx)) {
      danglingEndpoints.push({ endpoint, point: point2 });
    }
  }
  const [start, end] = danglingEndpoints;
  if (start && end && start.point.layer === end.point.layer && Math.hypot(start.point.x - end.point.x, start.point.y - end.point.y) <= CONTACT_EPSILON_MM) {
    danglingEndpoints.pop();
  }
  return danglingEndpoints;
}
function checkDanglingTraces(circuitJson, options = {}) {
  const ctx = createEndpointContactContext(circuitJson, options.connMap);
  const sourceTracesById = /* @__PURE__ */ new Map();
  const sourcePortIdsWithPcbPorts = /* @__PURE__ */ new Set();
  for (const element of circuitJson) {
    if (element.type === "source_trace") {
      sourceTracesById.set(element.source_trace_id, element);
    }
    if (element.type === "pcb_port") {
      sourcePortIdsWithPcbPorts.add(element.source_port_id);
    }
  }
  const errors = [];
  for (const trace of circuitJson) {
    if (trace.type !== "pcb_trace" || trace.route.length === 0) continue;
    if (trace.is_antenna_trace === true) continue;
    let hasExpectedPorts = false;
    if (trace.source_trace_id) {
      const sourceTrace = sourceTracesById.get(trace.source_trace_id);
      hasExpectedPorts = Boolean(
        sourceTrace?.connected_source_port_ids.some(
          (sourcePortId) => sourcePortIdsWithPcbPorts.has(sourcePortId)
        )
      );
    }
    for (const { endpoint, point: point2 } of getDanglingEndpoints(
      { trace, hasExpectedPorts },
      ctx
    )) {
      const traceName = getReadableNameForTrace(
        circuitJson,
        trace.pcb_trace_id
      );
      errors.push({
        type: "pcb_trace_error",
        error_type: "pcb_trace_error",
        pcb_trace_error_id: `disconnected_endpoint_${trace.pcb_trace_id}_${endpoint}`,
        message: `Trace [${traceName}] has dangling endpoint at (${point2.x.toFixed(2)}, ${point2.y.toFixed(2)})`,
        source_trace_id: trace.source_trace_id || `!${trace.pcb_trace_id}`,
        pcb_trace_id: trace.pcb_trace_id,
        center: { x: point2.x, y: point2.y },
        pcb_component_ids: [],
        pcb_port_ids: []
      });
    }
  }
  return errors;
}

// lib/check-pcb-trace-self-shorts.ts
import { cju as cju2 } from "@tscircuit/circuit-json-util";
import { segmentToSegmentMinDistance as segmentToSegmentMinDistance3 } from "@tscircuit/math-utils";
import {
  all_layers as all_layers3
} from "circuit-json";

// lib/check-each-pcb-trace-non-overlapping/getClosestPointBetweenSegments.ts
var getClosestPointBetweenSegments = (segmentA, segmentB) => {
  const a1 = { x: segmentA.x1, y: segmentA.y1 };
  const a2 = { x: segmentA.x2, y: segmentA.y2 };
  const b1 = { x: segmentB.x1, y: segmentB.y1 };
  const b2 = { x: segmentB.x2, y: segmentB.y2 };
  const va = { x: a2.x - a1.x, y: a2.y - a1.y };
  const vb = { x: b2.x - b1.x, y: b2.y - b1.y };
  const lenSqrA = va.x * va.x + va.y * va.y;
  const lenSqrB = vb.x * vb.x + vb.y * vb.y;
  if (lenSqrA === 0 || lenSqrB === 0) {
    if (lenSqrA === 0 && lenSqrB === 0) {
      return {
        x: (a1.x + b1.x) / 2,
        y: (a1.y + b1.y) / 2
      };
    }
    if (lenSqrA === 0) {
      const t2 = clamp(
        ((a1.x - b1.x) * vb.x + (a1.y - b1.y) * vb.y) / lenSqrB,
        0,
        1
      );
      const closestOnB2 = {
        x: b1.x + t2 * vb.x,
        y: b1.y + t2 * vb.y
      };
      return {
        x: (a1.x + closestOnB2.x) / 2,
        y: (a1.y + closestOnB2.y) / 2
      };
    }
    const t = clamp(
      ((b1.x - a1.x) * va.x + (b1.y - a1.y) * va.y) / lenSqrA,
      0,
      1
    );
    const closestOnA2 = {
      x: a1.x + t * va.x,
      y: a1.y + t * va.y
    };
    return {
      x: (closestOnA2.x + b1.x) / 2,
      y: (closestOnA2.y + b1.y) / 2
    };
  }
  const w = { x: a1.x - b1.x, y: a1.y - b1.y };
  const dotAA = va.x * va.x + va.y * va.y;
  const dotAB = va.x * vb.x + va.y * vb.y;
  const dotAW = va.x * w.x + va.y * w.y;
  const dotBB = vb.x * vb.x + vb.y * vb.y;
  const dotBW = vb.x * w.x + vb.y * w.y;
  const denominator = dotAA * dotBB - dotAB * dotAB;
  if (denominator < 1e-10) {
    return closestPointsParallelSegments(
      a1,
      a2,
      b1,
      b2,
      va,
      vb,
      lenSqrA,
      lenSqrB
    );
  }
  let tA = (dotAB * dotBW - dotBB * dotAW) / denominator;
  let tB = (dotAA * dotBW - dotAB * dotAW) / denominator;
  tA = clamp(tA, 0, 1);
  tB = clamp(tB, 0, 1);
  tB = (tA * dotAB + dotBW) / dotBB;
  tB = clamp(tB, 0, 1);
  tA = (tB * dotAB - dotAW) / dotAA;
  tA = clamp(tA, 0, 1);
  const closestOnA = {
    x: a1.x + tA * va.x,
    y: a1.y + tA * va.y
  };
  const closestOnB = {
    x: b1.x + tB * vb.x,
    y: b1.y + tB * vb.y
  };
  const dx = closestOnA.x - closestOnB.x;
  const dy = closestOnA.y - closestOnB.y;
  const distance6 = Math.sqrt(dx * dx + dy * dy);
  const averagePoint = {
    x: (closestOnA.x + closestOnB.x) / 2,
    y: (closestOnA.y + closestOnB.y) / 2
  };
  return averagePoint;
};
var closestPointsParallelSegments = (a1, a2, b1, b2, va, vb, lenSqrA, lenSqrB) => {
  let tA = ((b1.x - a1.x) * va.x + (b1.y - a1.y) * va.y) / lenSqrA;
  tA = clamp(tA, 0, 1);
  const pointOnA1 = { x: a1.x + tA * va.x, y: a1.y + tA * va.y };
  let tA2 = ((b2.x - a1.x) * va.x + (b2.y - a1.y) * va.y) / lenSqrA;
  tA2 = clamp(tA2, 0, 1);
  const pointOnA2 = { x: a1.x + tA2 * va.x, y: a1.y + tA2 * va.y };
  let tB = ((a1.x - b1.x) * vb.x + (a1.y - b1.y) * vb.y) / lenSqrB;
  tB = clamp(tB, 0, 1);
  const pointOnB1 = { x: b1.x + tB * vb.x, y: b1.y + tB * vb.y };
  let tB2 = ((a2.x - b1.x) * vb.x + (a2.y - b1.y) * vb.y) / lenSqrB;
  tB2 = clamp(tB2, 0, 1);
  const pointOnB2 = { x: b1.x + tB2 * vb.x, y: b1.y + tB2 * vb.y };
  const distances = [
    {
      pointA: pointOnA1,
      pointB: b1,
      distance: Math.sqrt(
        (pointOnA1.x - b1.x) ** 2 + (pointOnA1.y - b1.y) ** 2
      )
    },
    {
      pointA: pointOnA2,
      pointB: b2,
      distance: Math.sqrt(
        (pointOnA2.x - b2.x) ** 2 + (pointOnA2.y - b2.y) ** 2
      )
    },
    {
      pointA: a1,
      pointB: pointOnB1,
      distance: Math.sqrt(
        (a1.x - pointOnB1.x) ** 2 + (a1.y - pointOnB1.y) ** 2
      )
    },
    {
      pointA: a2,
      pointB: pointOnB2,
      distance: Math.sqrt(
        (a2.x - pointOnB2.x) ** 2 + (a2.y - pointOnB2.y) ** 2
      )
    }
  ];
  const closestPair = distances.reduce(
    (closest, current) => current.distance < closest.distance ? current : closest
  );
  return {
    x: (closestPair.pointA.x + closestPair.pointB.x) / 2,
    y: (closestPair.pointA.y + closestPair.pointB.y) / 2
  };
};
var clamp = (value, min, max) => {
  return Math.max(min, Math.min(max, value));
};

// lib/check-each-pcb-trace-non-overlapping/getPcbPortIdsConnectedToTraces.ts
function getPcbPortIdsConnectedToRoutePoint(routePoint) {
  if (routePoint.route_type !== "wire") return [];
  return [routePoint.start_pcb_port_id, routePoint.end_pcb_port_id].filter(
    (portId) => Boolean(portId)
  );
}
function getPcbPortIdsConnectedToTrace(trace) {
  const connectedPcbPorts = /* @__PURE__ */ new Set();
  for (const segment of trace.route) {
    for (const portId of getPcbPortIdsConnectedToRoutePoint(segment)) {
      connectedPcbPorts.add(portId);
    }
  }
  return Array.from(connectedPcbPorts);
}
function getPcbPortIdsConnectedToTraces(traces) {
  const connectedPorts = /* @__PURE__ */ new Set();
  for (const trace of traces) {
    for (const portId of getPcbPortIdsConnectedToTrace(trace)) {
      connectedPorts.add(portId);
    }
  }
  return Array.from(connectedPorts);
}

// lib/check-pcb-trace-self-shorts.ts
function checkPcbTraceSelfShorts(circuitJson) {
  const matchedSourceTraceIds = new Set(
    circuitJson.flatMap(
      (element) => element.type === "source_bus" && element.max_length_skew !== void 0 ? element.source_trace_ids : []
    )
  );
  const db = cju2(circuitJson);
  const errors = [];
  for (const trace of circuitJson) {
    if (trace.type !== "pcb_trace") continue;
    if (!trace.source_trace_id || !matchedSourceTraceIds.has(trace.source_trace_id))
      continue;
    const segments = [];
    const routeDistances = [];
    let distance6 = 0;
    let run = 0;
    for (let i = 0; i < trace.route.length - 1; i++) {
      routeDistances[i] = distance6;
      const a = trace.route[i];
      const b = trace.route[i + 1];
      if (a.route_type !== "wire" || b.route_type !== "wire" || a.layer !== b.layer) {
        run++;
        continue;
      }
      const length = Math.hypot(b.x - a.x, b.y - a.y);
      if (length === 0) continue;
      segments.push({
        type: "pcb_trace_segment",
        _pcbTrace: trace,
        pcb_trace_id: trace.pcb_trace_id,
        thickness: a.width,
        layer: a.layer,
        x1: a.x,
        y1: a.y,
        x2: b.x,
        y2: b.y,
        run,
        startDistance: distance6,
        endDistance: distance6 + length
      });
      distance6 += length;
    }
    routeDistances[trace.route.length - 1] = distance6;
    let shortCenter;
    pairs: for (let i = 0; i < segments.length; i++) {
      const a = segments[i];
      for (let j = i + 1; j < segments.length; j++) {
        const b = segments[j];
        if (a.layer !== b.layer) continue;
        const contactDistance = (a.thickness + b.thickness) / 2;
        const dot3 = (a.x2 - a.x1) * (b.x2 - b.x1) + (a.y2 - a.y1) * (b.y2 - b.y1);
        const cross = (a.x2 - a.x1) * (b.y2 - b.y1) - (a.y2 - a.y1) * (b.x2 - b.x1);
        const directionLengthProduct = Math.hypot(a.x2 - a.x1, a.y2 - a.y1) * Math.hypot(b.x2 - b.x1, b.y2 - b.y1);
        const isForwardOrRightAngle = dot3 >= -1e-9 * directionLengthProduct;
        const adjacent = a.run === b.run && b.startDistance === a.endDistance;
        if (adjacent && !(dot3 < 0 && Math.abs(cross) < 1e-9)) continue;
        if (!adjacent && a.run === b.run && // A right-angle connector can have sqrt(2) times the straight-line
        // distance. Its local copper overlap is still part of the same bend.
        b.startDistance - a.endDistance <= Math.SQRT2 * contactDistance && isForwardOrRightAngle)
          continue;
        const gap = segmentToSegmentMinDistance3(
          { x: a.x1, y: a.y1 },
          { x: a.x2, y: a.y2 },
          { x: b.x1, y: b.y1 },
          { x: b.x2, y: b.y2 }
        ) - contactDistance;
        if (gap > 1e-9) continue;
        shortCenter = getClosestPointBetweenSegments(a, b);
        break pairs;
      }
    }
    if (!shortCenter) {
      const board = circuitJson.find((e) => e.type === "pcb_board");
      const stack = [
        "top",
        ...all_layers3.filter((layer) => layer.startsWith("inner")).slice(0, board ? Math.max(0, board.num_layers - 2) : void 0),
        ...board?.num_layers === 1 ? [] : ["bottom"]
      ];
      vias: for (let i = 0; i < trace.route.length; i++) {
        const point2 = trace.route[i];
        if (point2.route_type !== "via") continue;
        const materialized = db.pcb_via.list().find(
          (via) => (via.pcb_trace_id === trace.pcb_trace_id || !via.pcb_trace_id && via.source_trace_id === trace.source_trace_id) && Math.hypot(via.x - point2.x, via.y - point2.y) <= 1e-9
        );
        const diameter = materialized?.outer_diameter ?? point2.outer_diameter;
        if (diameter === void 0 || !Number.isFinite(diameter) || diameter <= 0)
          continue;
        const from = stack.indexOf(point2.from_layer);
        const to = stack.indexOf(point2.to_layer);
        const layers = materialized?.layers ?? (from >= 0 && to >= 0 ? stack.slice(Math.min(from, to), Math.max(from, to) + 1) : []);
        for (const segment of segments) {
          if (!layers.includes(segment.layer)) continue;
          const reach = (diameter + segment.thickness) / 2;
          const alongRouteGap = Math.max(
            segment.startDistance - routeDistances[i],
            routeDistances[i] - segment.endDistance,
            0
          );
          if (alongRouteGap <= reach + 1e-9) continue;
          const viaSegment = {
            ...segment,
            x1: point2.x,
            y1: point2.y,
            x2: point2.x,
            y2: point2.y
          };
          const gap = segmentToSegmentMinDistance3(
            point2,
            point2,
            { x: segment.x1, y: segment.y1 },
            { x: segment.x2, y: segment.y2 }
          ) - reach;
          if (gap > 1e-9) continue;
          shortCenter = getClosestPointBetweenSegments(segment, viaSegment);
          break vias;
        }
      }
    }
    if (shortCenter) {
      const sourceTrace = db.source_trace.get(trace.source_trace_id);
      const endpointNames = (sourceTrace?.connected_source_port_ids ?? []).map((id) => {
        const port = db.source_port.get(id);
        const component = port?.source_component_id ? db.source_component.get(port.source_component_id) : void 0;
        return component?.name && port?.name ? `${component.name}.${port.name}` : void 0;
      }).filter((name) => Boolean(name));
      const traceName = sourceTrace?.name || sourceTrace?.display_name || endpointNames.join(" \u2192 ") || "unnamed";
      errors.push({
        type: "pcb_trace_error",
        error_type: "pcb_trace_error",
        pcb_trace_error_id: `self_short_${trace.pcb_trace_id}`,
        pcb_trace_id: trace.pcb_trace_id,
        source_trace_id: trace.source_trace_id,
        message: `PCB trace "${traceName}" shorts to itself, bypassing part of its length-matched route`,
        center: shortCenter,
        pcb_component_ids: [],
        pcb_port_ids: getPcbPortIdsConnectedToTraces([trace]),
        subcircuit_id: trace.subcircuit_id
      });
    }
  }
  return errors;
}

// lib/check-copper-pour-shorts.ts
import Flatbush from "flatbush";
import * as Flatten2 from "@flatten-js/core";

// lib/util/polygon-contains-point.ts
import * as Flatten from "@flatten-js/core";
function polygonContainsPoint(polygon, point2) {
  const tolerance = Flatten.Utils.getTolerance();
  const edges = polygon.edges.search(
    new Flatten.Box(
      point2.x - tolerance,
      point2.y - tolerance,
      Infinity,
      point2.y + tolerance
    )
  );
  let inside = false;
  for (const edge of edges) {
    if (!(edge instanceof Flatten.Edge)) {
      throw new Error("Expected a polygon edge in the spatial index");
    }
    const shape = edge.shape;
    if (!(shape instanceof Flatten.Segment || shape instanceof Flatten.Arc)) {
      throw new Error("Expected a segment or arc in the polygon");
    }
    if (shape.contains(point2)) return true;
    if (shape instanceof Flatten.Segment) {
      const { start, end } = shape;
      if (start.y > point2.y === end.y > point2.y) continue;
      const x = start.x + (point2.y - start.y) * (end.x - start.x) / (end.y - start.y);
      if (x > point2.x) inside = !inside;
    } else {
      const turn = 2 * Math.PI;
      const startAngle = (shape.startAngle % turn + turn) % turn;
      const arcs = new Flatten.Arc(
        shape.pc,
        shape.r,
        startAngle,
        startAngle + (shape.counterClockwise ? shape.sweep : -shape.sweep),
        shape.counterClockwise
      ).breakToFunctional();
      const startY = edge.prev.shape instanceof Flatten.Segment ? edge.prev.end.y : shape.start.y;
      const endY = edge.next.start.y;
      for (const [index, arc] of arcs.entries()) {
        const fromY = index === 0 ? startY : arc.start.y;
        const toY = index === arcs.length - 1 ? endY : arc.end.y;
        if (fromY > point2.y === toY > point2.y) continue;
        const dy = point2.y - arc.pc.y;
        if (Math.abs(dy) > arc.r) continue;
        const dx = Math.sqrt((arc.r - dy) * (arc.r + dy));
        const x = arc.pc.x + (arc.middle().x >= arc.pc.x ? dx : -dx);
        if (x > point2.x) inside = !inside;
      }
    }
  }
  return inside;
}

// node_modules/@tscircuit/circuit-json-to-flattenjs/dist/index.js
import * as F from "@flatten-js/core";
import { Vector as Vector2 } from "@flatten-js/core";
import { BooleanOperations, Matrix } from "@flatten-js/core";
import { Arc as Arc22 } from "@flatten-js/core";
var EPS = 1e-9;
var point = (p) => new F.Point(p.x, p.y);
function positive(value, name) {
  if (!Number.isFinite(value) || value <= 0)
    throw new Error(`${name} must be finite and positive`);
  return value;
}
function circle(center, radius) {
  positive(radius, "radius");
  return new F.Polygon(new F.Circle(point(center), radius));
}
function ring(vertices) {
  const clean = vertices.filter(
    (p, i) => i === 0 || point(p).distanceTo(point(vertices[i - 1]))[0] > EPS
  );
  if (clean.length > 1 && point(clean[0]).distanceTo(point(clean.at(-1)))[0] <= EPS)
    clean.pop();
  if (clean.length < 2)
    throw new Error("A ring needs at least two distinct vertices");
  const edges = clean.map((a, i) => {
    const b = clean[(i + 1) % clean.length];
    if (![a.x, a.y, a.bulge ?? 0].every(Number.isFinite))
      throw new Error("Non-finite ring vertex");
    const bulge = a.bulge ?? 0;
    if (Math.abs(bulge) <= EPS) return new F.Segment(point(a), point(b));
    const dx = b.x - a.x, dy = b.y - a.y;
    const length = Math.hypot(dx, dy);
    const offset = length * (1 - bulge * bulge) / (4 * bulge);
    const center = new F.Point(
      (a.x + b.x) / 2 - dy / length * offset,
      (a.y + b.y) / 2 + dx / length * offset
    );
    return new F.Arc(
      center,
      length * (1 + bulge * bulge) / (4 * Math.abs(bulge)),
      Math.atan2(a.y - center.y, a.x - center.x),
      Math.atan2(b.y - center.y, b.x - center.x),
      bulge > 0
    );
  });
  const polygon = new F.Polygon();
  polygon.addFace(edges);
  if (polygon.area() <= EPS)
    throw new Error("A ring must enclose a non-zero area");
  return polygon;
}
function rectangle(center, width, height, rotation = 0, radius = 0) {
  positive(width, "width");
  positive(height, "height");
  if (!Number.isFinite(rotation) || !Number.isFinite(radius) || radius < 0)
    throw new Error("Invalid rectangle rotation or corner radius");
  const r = Math.min(radius, width / 2, height / 2);
  const x = width / 2, y = height / 2;
  let polygon;
  if (r <= EPS)
    polygon = ring([
      { x: -x, y: -y },
      { x, y: -y },
      { x, y },
      { x: -x, y }
    ]);
  else {
    const corners = [
      new F.Point(x - r, -y + r),
      new F.Point(x - r, y - r),
      new F.Point(-x + r, y - r),
      new F.Point(-x + r, -y + r)
    ];
    const edges = [];
    for (let i = 0; i < 4; i++) {
      const angle = -Math.PI / 2 + i * Math.PI / 2;
      const arc = new F.Arc(corners[i], r, angle, angle + Math.PI / 2, true);
      const next = corners[(i + 1) % 4];
      const nextStart = new F.Point(
        next.x + r * Math.cos(angle + Math.PI / 2),
        next.y + r * Math.sin(angle + Math.PI / 2)
      );
      edges.push(arc);
      if (arc.end.distanceTo(nextStart)[0] > EPS)
        edges.push(new F.Segment(arc.end, nextStart));
    }
    polygon = new F.Polygon();
    polygon.addFace(edges);
  }
  return polygon.rotate(rotation * Math.PI / 180).translate(new F.Vector(center.x, center.y));
}
function stroke(a, b, widthA, widthB = widthA) {
  const r1 = positive(widthA, "trace width") / 2, r2 = positive(widthB, "trace width") / 2;
  const d = point(a).distanceTo(point(b))[0];
  if (d <= Math.abs(r1 - r2) + EPS)
    return circle(r1 >= r2 ? a : b, Math.max(r1, r2));
  const theta = Math.atan2(b.y - a.y, b.x - a.x);
  const alpha = Math.acos((r1 - r2) / d);
  const low = theta - alpha, high = theta + alpha;
  const p = (c, r, angle) => new F.Point(c.x + r * Math.cos(angle), c.y + r * Math.sin(angle));
  const polygon = new F.Polygon();
  polygon.addFace([
    new F.Segment(p(a, r1, low), p(b, r2, low)),
    new F.Arc(point(b), r2, low, high, true),
    new F.Segment(p(b, r2, high), p(a, r1, high)),
    new F.Arc(point(a), r1, high, low, true)
  ]);
  return polygon;
}
function withHoles(outer, holes) {
  const result = outer.clone();
  const orientation = [...result.faces][0].orientation();
  for (const hole of holes) {
    const copy = hole.clone();
    if ([...copy.faces][0].orientation() === orientation) copy.reverse();
    for (const face of copy.faces) result.addFace(face.shapes);
  }
  return result;
}
function ellipse(center, width, height, rotation = 0, tolerance = 1e-3) {
  positive(width, "ellipse width");
  positive(height, "ellipse height");
  positive(tolerance, "curveTolerance");
  if (Math.abs(width - height) < EPS) return circle(center, width / 2);
  const radius = Math.max(width, height) / 2;
  const count = Math.max(
    16,
    Math.ceil(Math.PI / Math.acos(Math.max(-1, 1 - tolerance / radius)))
  );
  if (count > 1e5)
    throw new Error("curveTolerance requires more than 100000 ellipse segments");
  return ring(
    Array.from({ length: count }, (_, i) => ({
      x: width / 2 * Math.cos(i * 2 * Math.PI / count),
      y: height / 2 * Math.sin(i * 2 * Math.PI / count)
    }))
  ).rotate(rotation * Math.PI / 180).translate(new F.Vector(center.x, center.y));
}
function getCopperLayers(json, options) {
  if (options.copperLayers) {
    if (!options.copperLayers.length || new Set(options.copperLayers).size !== options.copperLayers.length)
      throw new Error(
        "copperLayers must be a non-empty list without duplicates"
      );
    return [...options.copperLayers];
  }
  const board = json.find((e) => e.type === "pcb_board");
  let count = board?.num_layers ?? 2;
  for (const element of json) {
    const layers = "layers" in element ? element.layers : "layer" in element ? [element.layer] : [];
    if (Array.isArray(layers))
      for (const layer of layers) {
        const match = typeof layer === "string" && /^inner(\d+)$/.exec(layer);
        if (match) count = Math.max(count, Number(match[1]) + 2);
      }
    if (element.type === "pcb_trace")
      for (const p of element.route) {
        for (const layer of p.route_type === "wire" ? [p.layer] : p.route_type === "via" ? [p.from_layer, p.to_layer] : [p.start_layer, p.end_layer]) {
          const match = /^inner(\d+)$/.exec(layer);
          if (match) count = Math.max(count, Number(match[1]) + 2);
        }
      }
  }
  if (!Number.isInteger(count) || count < 1 || count > 10)
    throw new Error("Supported copper layer count is 1\u201310");
  return count === 1 ? ["top"] : [
    "top",
    ...Array.from(
      { length: count - 2 },
      (_, i) => `inner${i + 1}`
    ),
    "bottom"
  ];
}
function spanLayers(layers, stack) {
  if (!layers.length) return [];
  const indices = layers.map((layer) => stack.indexOf(layer));
  if (indices.some((i) => i < 0))
    throw new Error(`Layer is missing from copperLayers: ${layers.join(", ")}`);
  return stack.slice(Math.min(...indices), Math.max(...indices) + 1);
}
function smtPad(pad) {
  switch (pad.shape) {
    case "circle":
      return circle(pad, pad.radius);
    case "polygon":
      return ring(pad.points);
    case "rect":
    case "rotated_rect":
      return rectangle(
        pad,
        pad.width,
        pad.height,
        "ccw_rotation" in pad ? pad.ccw_rotation : 0,
        pad.rect_border_radius ?? pad.corner_radius ?? 0
      );
    case "pill":
    case "rotated_pill":
      return rectangle(
        pad,
        pad.width,
        pad.height,
        "ccw_rotation" in pad ? pad.ccw_rotation : 0,
        pad.radius
      );
  }
}
function nonPlatedHole(hole, tolerance) {
  switch (hole.hole_shape) {
    case "circle":
      return circle(hole, hole.hole_diameter / 2);
    case "square":
      return rectangle(hole, hole.hole_diameter, hole.hole_diameter);
    case "rect":
      return rectangle(hole, hole.hole_width, hole.hole_height);
    case "oval":
      return ellipse(hole, hole.hole_width, hole.hole_height, 0, tolerance);
    case "pill":
    case "rotated_pill":
      return rectangle(
        hole,
        hole.hole_width,
        hole.hole_height,
        "ccw_rotation" in hole ? hole.ccw_rotation : 0,
        Math.min(hole.hole_width, hole.hole_height) / 2
      );
  }
}
function platedHole(hole, componentRotation, includeDrill, tolerance) {
  let outer;
  let drill;
  const drillCenter = {
    x: hole.x + ("hole_offset_x" in hole ? hole.hole_offset_x ?? 0 : 0),
    y: hole.y + ("hole_offset_y" in hole ? hole.hole_offset_y ?? 0 : 0)
  };
  switch (hole.shape) {
    case "circle":
      outer = circle(hole, hole.outer_diameter / 2);
      drill = circle(hole, hole.hole_diameter / 2);
      break;
    case "oval":
      outer = ellipse(
        hole,
        hole.outer_width,
        hole.outer_height,
        hole.ccw_rotation,
        tolerance
      );
      drill = ellipse(
        hole,
        hole.hole_width,
        hole.hole_height,
        hole.ccw_rotation,
        tolerance
      );
      break;
    case "pill":
      outer = rectangle(
        hole,
        hole.outer_width,
        hole.outer_height,
        hole.ccw_rotation,
        Math.min(hole.outer_width, hole.outer_height) / 2
      );
      drill = rectangle(
        hole,
        hole.hole_width,
        hole.hole_height,
        hole.ccw_rotation,
        Math.min(hole.hole_width, hole.hole_height) / 2
      );
      break;
    case "circular_hole_with_rect_pad":
    case "pill_hole_with_rect_pad":
    case "rotated_pill_hole_with_rect_pad":
      outer = rectangle(
        hole,
        hole.rect_pad_width,
        hole.rect_pad_height,
        "rect_ccw_rotation" in hole ? hole.rect_ccw_rotation : 0,
        hole.rect_border_radius ?? 0
      );
      drill = hole.shape === "circular_hole_with_rect_pad" ? circle(drillCenter, hole.hole_diameter / 2) : rectangle(
        drillCenter,
        hole.hole_width,
        hole.hole_height,
        "hole_ccw_rotation" in hole ? hole.hole_ccw_rotation : 0,
        Math.min(hole.hole_width, hole.hole_height) / 2
      );
      break;
    case "hole_with_polygon_pad": {
      const rotation = hole.ccw_rotation ?? componentRotation;
      outer = ring(hole.pad_outline).rotate(rotation * Math.PI / 180).translate(new Vector2(hole.x, hole.y));
      drill = hole.hole_shape === "circle" ? circle(drillCenter, hole.hole_diameter / 2) : hole.hole_shape === "oval" ? ellipse(
        drillCenter,
        hole.hole_width,
        hole.hole_height,
        rotation,
        tolerance
      ) : rectangle(
        drillCenter,
        hole.hole_width,
        hole.hole_height,
        rotation,
        Math.min(hole.hole_width, hole.hole_height) / 2
      );
      break;
    }
  }
  return includeDrill ? withHoles(outer, [drill]) : outer;
}
var samePoint = (a, b) => a.x === b.x && a.y === b.y;
var unit = (x, y) => {
  const length = Math.hypot(x, y);
  return length ? { x: x / length, y: y / length } : { x: 1, y: 0 };
};
function interpolatedPolygon(segments) {
  const points = [
    { ...segments[0].start, width: segments[0].startWidth },
    ...segments.map((s) => ({ ...s.end, width: s.endWidth }))
  ];
  const directions2 = segments.map(
    (s) => unit(s.end.x - s.start.x, s.end.y - s.start.y)
  );
  const left = [], right = [];
  for (let i = 0; i < points.length; i++) {
    const p = points[i];
    positive(p.width, "interpolated trace width");
    const before = directions2[Math.max(0, i - 1)], after = directions2[Math.min(i, directions2.length - 1)];
    const d = unit(before.x + after.x, before.y + after.y);
    const nx = -d.y * p.width / 2, ny = d.x * p.width / 2;
    left.push({ x: p.x + nx, y: p.y + ny });
    right.push({ x: p.x - nx, y: p.y - ny });
  }
  return ring([...left, ...right.reverse()]);
}
function subtractDrill(shape, hole) {
  try {
    return BooleanOperations.subtract(shape, hole);
  } catch (error) {
    if (!(error instanceof Error) || error.message !== "Unresolved boundary conflict in boolean operation")
      throw error;
    const toMicrometers = new Matrix(1e3, 0, 0, 1e3, 0, 0);
    const toMillimeters = new Matrix(1e-3, 0, 0, 1e-3, 0, 0);
    return BooleanOperations.subtract(
      shape.transform(toMicrometers),
      hole.transform(toMicrometers)
    ).transform(toMillimeters);
  }
}
function traceGeometry(trace, stack, includeDrill) {
  const result = /* @__PURE__ */ new Map();
  const drills = /* @__PURE__ */ new Map();
  const segments = [];
  const add = (layer, shape) => result.set(layer, [...result.get(layer) ?? [], shape]);
  for (const p of trace.route) {
    if (p.route_type === "via") {
      const legacy = p;
      const outerDiameter = p.outer_diameter ?? legacy.via_diameter;
      if (outerDiameter === void 0) continue;
      const holeDiameter = p.hole_diameter ?? legacy.via_hole_diameter;
      const shape = circle(p, outerDiameter / 2);
      const drill = includeDrill && holeDiameter ? circle(p, holeDiameter / 2) : void 0;
      for (const layer of spanLayers([p.from_layer, p.to_layer], stack)) {
        add(layer, drill ? withHoles(shape, [drill]) : shape);
        if (drill) drills.set(layer, [...drills.get(layer) ?? [], drill]);
      }
    }
    if (p.route_type === "through_pad") {
      for (const layer of /* @__PURE__ */ new Set([p.start_layer, p.end_layer]))
        add(layer, stroke(p.start, p.end, p.width));
    }
  }
  for (let i = 0; i < trace.route.length - 1; i++) {
    const a = trace.route[i], b = trace.route[i + 1];
    const start = a.route_type === "through_pad" ? a.end : a;
    const end = b.route_type === "through_pad" ? b.start : b;
    if (samePoint(start, end)) continue;
    const startLayers = a.route_type === "wire" ? [a.layer] : a.route_type === "via" ? spanLayers([a.from_layer, a.to_layer], stack) : [a.end_layer];
    const endLayers = b.route_type === "wire" ? [b.layer] : b.route_type === "via" ? spanLayers([b.from_layer, b.to_layer], stack) : [b.start_layer];
    const sharedLayers = startLayers.filter(
      (layer) => endLayers.includes(layer)
    );
    if (sharedLayers.length !== 1)
      throw new Error(
        `Cannot determine one wire layer between route points ${i} and ${i + 1}`
      );
    const startLayer = sharedLayers[0];
    const width = "width" in a ? a.width : "width" in b ? b.width : void 0;
    if (width === void 0 || samePoint(start, end)) continue;
    segments.push({
      start,
      end,
      layer: startLayer,
      startWidth: width,
      endWidth: "width" in b ? b.width : width
    });
  }
  if (trace.route_thickness_mode === "interpolated") {
    let group = [];
    const flush = () => {
      if (group.length) {
        add(group[0].layer, interpolatedPolygon(group));
        group = [];
      }
    };
    for (const segment of segments) {
      const last = group.at(-1);
      if (last && (last.layer !== segment.layer || !samePoint(last.end, segment.start) || last.endWidth !== segment.startWidth))
        flush();
      group.push(segment);
    }
    flush();
  } else
    for (const s of segments) add(s.layer, stroke(s.start, s.end, s.startWidth));
  for (const [layer, holes] of drills) {
    result.set(
      layer,
      result.get(layer).map(
        (shape) => holes.reduce((shape2, hole) => subtractDrill(shape2, hole), shape)
      ).filter((shape) => shape.faces.size > 0)
    );
  }
  return result;
}
var supportedElementTypes = [
  "pcb_board",
  "pcb_smtpad",
  "pcb_plated_hole",
  "pcb_hole",
  "pcb_via",
  "pcb_trace",
  "pcb_copper_pour",
  "pcb_cutout",
  "pcb_keepout",
  "pcb_courtyard_rect",
  "pcb_courtyard_circle",
  "pcb_courtyard_pill",
  "pcb_courtyard_polygon",
  "pcb_courtyard_outline"
];
function cutoutGeometry(cutout) {
  switch (cutout.shape) {
    case "circle":
      return [circle(cutout.center, cutout.radius)];
    case "rect":
      return [
        rectangle(
          cutout.center,
          cutout.width,
          cutout.height,
          cutout.rotation,
          cutout.corner_radius
        )
      ];
    case "polygon":
      return [ring(cutout.points)];
    case "path": {
      if (cutout.slot_length !== void 0 || cutout.space_between_slots !== void 0 || cutout.slot_corner_radius !== void 0) {
        throw new Error(
          "Patterned/custom-corner path cutouts are not supported; use explicit rect/polygon cutouts"
        );
      }
      return cutout.route.slice(1).map((p, i) => stroke(cutout.route[i], p, cutout.slot_width));
    }
  }
}
function convertCircuitJsonToFlattenJs(json, options = {}) {
  if (options.layer && options.layers)
    throw new Error("Specify layer or layers, not both");
  const selectedLayers = options.layer ? [options.layer] : options.layers;
  const stack = getCopperLayers(json, options);
  const result = {
    elements: [],
    warnings: [],
    bounds: void 0,
    copperLayers: stack
  };
  const rotations = new Map(
    json.filter((e) => e.type === "pcb_component").map((e) => [e.pcb_component_id, e.rotation])
  );
  const tolerance = options.curveTolerance ?? 1e-3;
  if (!Number.isFinite(tolerance) || tolerance <= 0)
    throw new Error("curveTolerance must be finite and positive");
  const includeDrill = options.includeDrillHoles !== false;
  for (const element of json) {
    if (!supportedElementTypes.includes(element.type))
      continue;
    const elementId = element[`${element.type}_id`];
    if (options.elementTypes && !options.elementTypes.includes(element.type))
      continue;
    if (options.elementIds && !options.elementIds.includes(elementId)) continue;
    let role = "copper";
    let layers = [null];
    let shapes = [];
    let byLayer;
    try {
      switch (element.type) {
        case "pcb_smtpad":
          layers = [element.layer];
          shapes = [smtPad(element)];
          break;
        case "pcb_plated_hole":
          layers = spanLayers(element.layers, stack);
          shapes = [
            platedHole(
              element,
              rotations.get(element.pcb_component_id ?? "") ?? 0,
              includeDrill,
              tolerance
            )
          ];
          break;
        case "pcb_via": {
          layers = spanLayers(element.layers, stack);
          const outer = circle(element, element.outer_diameter / 2);
          shapes = [
            includeDrill ? withHoles(outer, [circle(element, element.hole_diameter / 2)]) : outer
          ];
          break;
        }
        case "pcb_trace":
          byLayer = traceGeometry(element, stack, includeDrill);
          layers = [...byLayer.keys()];
          break;
        case "pcb_copper_pour":
          layers = [element.layer];
          shapes = [
            element.shape === "rect" ? rectangle(
              element.center,
              element.width,
              element.height,
              element.rotation
            ) : element.shape === "polygon" ? ring(element.points) : withHoles(
              ring(element.brep_shape.outer_ring.vertices),
              element.brep_shape.inner_rings.map(
                (h) => ring(h.vertices)
              )
            )
          ];
          break;
        case "pcb_board":
          role = "board";
          shapes = [
            element.outline?.length ? ring(element.outline) : rectangle(element.center, element.width, element.height)
          ];
          break;
        case "pcb_hole":
          role = "drill";
          shapes = [nonPlatedHole(element, tolerance)];
          break;
        case "pcb_cutout":
          role = "cutout";
          shapes = cutoutGeometry(element);
          break;
        case "pcb_keepout":
          role = "keepout";
          layers = element.layers;
          shapes = [
            element.shape === "circle" ? circle(element.center, element.radius) : element.shape === "rect" ? rectangle(element.center, element.width, element.height) : ring(element.outline)
          ];
          break;
        case "pcb_courtyard_rect":
          role = "courtyard";
          layers = [element.layer];
          shapes = [
            rectangle(
              element.center,
              element.width,
              element.height,
              element.ccw_rotation
            )
          ];
          break;
        case "pcb_courtyard_circle":
          role = "courtyard";
          layers = [element.layer];
          shapes = [circle(element.center, element.radius)];
          break;
        case "pcb_courtyard_pill":
          role = "courtyard";
          layers = [element.layer];
          shapes = [
            rectangle(
              element.center,
              element.width,
              element.height,
              0,
              element.radius
            )
          ];
          break;
        case "pcb_courtyard_polygon":
          role = "courtyard";
          layers = [element.layer];
          shapes = [ring(element.points)];
          break;
        case "pcb_courtyard_outline":
          role = "courtyard";
          layers = [element.layer];
          shapes = [ring(element.outline)];
          break;
      }
      if (options.roles && !options.roles.includes(role)) continue;
      const convertedElements = [];
      for (const layer of new Set(layers)) {
        if (layer === null ? options.includeLayerless === false : selectedLayers && !selectedLayers.includes(layer))
          continue;
        const layerShapes = byLayer?.get(layer) ?? shapes;
        if (!layerShapes.length) continue;
        const bounds = layerShapes.reduce(
          (box, shape) => box.merge(shape.box),
          layerShapes[0].box
        );
        if (![bounds.xmin, bounds.ymin, bounds.xmax, bounds.ymax].every(
          Number.isFinite
        ))
          throw new Error("Non-finite geometry bounds");
        const converted = {
          elementId,
          elementType: element.type,
          sourceElement: element,
          role,
          layer,
          shapes: layerShapes,
          bounds
        };
        convertedElements.push(converted);
      }
      for (const converted of convertedElements) {
        result.elements.push(converted);
        result.bounds = result.bounds ? result.bounds.merge(converted.bounds) : converted.bounds;
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      if (options.strict) throw new Error(`${elementId}: ${message}`);
      result.warnings.push({ elementId, elementType: element.type, message });
    }
  }
  return result;
}
function convertCircuitJsonElementToFlattenJs(element, options = {}) {
  const { circuitJson = [], ...conversionOptions } = options;
  const id = element[`${element.type}_id`];
  const context = circuitJson.filter(
    (e) => e !== element && e[`${e.type}_id`] !== id
  );
  return convertCircuitJsonToFlattenJs([...context, element], {
    ...conversionOptions,
    elementIds: [id]
  });
}

// lib/check-copper-pour-shorts.ts
import {
  getFullConnectivityMapFromCircuitJson as getFullConnectivityMapFromCircuitJson3
} from "circuit-json-to-connectivity-map";
function touchesPour(pour, geometry) {
  if (!pour.box.intersect(geometry.box)) return false;
  const boundariesIntersect = pour.intersect(geometry).some(
    (intersection) => hasBoundaryAtPoint(pour, intersection) && hasBoundaryAtPoint(geometry, intersection)
  );
  return boundariesIntersect || [...geometry.faces].some(
    (face) => polygonContainsPoint(pour, face.first.start)
  ) || [...pour.faces].some(
    (face) => polygonContainsPoint(geometry, face.first.start)
  );
}
function hasBoundaryAtPoint(polygon, point2) {
  const tolerance = Flatten2.Utils.getTolerance();
  return polygon.edges.search(
    new Flatten2.Box(
      point2.x - tolerance,
      point2.y - tolerance,
      point2.x + tolerance,
      point2.y + tolerance
    )
  ).length > 0;
}
function checkCopperPourShorts(circuitJson, { connMap } = {}) {
  if (!circuitJson.some((e) => e.type === "pcb_copper_pour")) return [];
  connMap ??= getFullConnectivityMapFromCircuitJson3(circuitJson);
  const { elements: copper } = convertCircuitJsonToFlattenJs(circuitJson, {
    elementTypes: [
      "pcb_smtpad",
      "pcb_plated_hole",
      "pcb_via",
      "pcb_trace",
      "pcb_copper_pour"
    ],
    strict: true
  });
  const layers = /* @__PURE__ */ new Map();
  for (const element of copper) {
    const entries = layers.get(element.layer) ?? [];
    for (const shape of element.shapes) entries.push({ element, shape });
    layers.set(element.layer, entries);
  }
  const indexes = new Map(
    [...layers].map(([layer, entries]) => {
      const index = new Flatbush(entries.length);
      for (const { shape } of entries) {
        const b = shape.box;
        index.add(b.xmin, b.ymin, b.xmax, b.ymax);
      }
      index.finish();
      return [layer, { index, entries }];
    })
  );
  const errors = /* @__PURE__ */ new Map();
  for (const pour of copper) {
    const element = pour.sourceElement;
    if (element.type !== "pcb_copper_pour") continue;
    const netId = element.source_net_id;
    const { index, entries } = indexes.get(pour.layer);
    const candidates = /* @__PURE__ */ new Set();
    for (const shape of pour.shapes) {
      const b = shape.box;
      for (const i of index.search(b.xmin, b.ymin, b.xmax, b.ymax))
        candidates.add(i);
    }
    for (const i of [...candidates].sort((a, b) => a - b)) {
      const { element: other, shape: otherShape } = entries[i];
      if (pour.elementId === other.elementId) continue;
      const otherNetId = other.sourceElement.type === "pcb_copper_pour" ? other.sourceElement.source_net_id : other.elementId;
      if (netId && otherNetId && (netId === otherNetId || connMap.areIdsConnected(netId, otherNetId)))
        continue;
      const id = `copper_pour_short_${[pour.elementId, other.elementId].sort().join("_")}`;
      if (errors.has(id) || !pour.shapes.some((shape) => touchesPour(shape, otherShape)))
        continue;
      errors.set(id, {
        type: "pcb_placement_error",
        pcb_placement_error_id: id,
        error_type: "pcb_placement_error",
        message: `Copper pour ${getReadableNameForElementId(circuitJson, pour.elementId)} (${netId ? getReadableNameForElementId(circuitJson, netId) : "unassigned net"}) shorts to ${getReadableNameForElementId(circuitJson, other.elementId)} on ${pour.layer} (accidental copper contact)`,
        subcircuit_id: element.subcircuit_id
      });
    }
  }
  return [...errors.values()];
}

// lib/util/trace-port-layer-connectivity.ts
import {
  all_layers as all_layers4
} from "circuit-json";
var EPSILON2 = 1e-9;
function createTracePortLayerConnectivity(circuit) {
  const ports = new Map(
    circuit.filter((e) => e.type === "pcb_port").map((p) => [p.pcb_port_id, p])
  );
  const pads = circuit.filter(
    (e) => e.type === "pcb_smtpad" || e.type === "pcb_plated_hole"
  );
  const padsByPort = /* @__PURE__ */ new Map();
  for (const pad of pads) {
    if (!pad.pcb_port_id) continue;
    const entries = padsByPort.get(pad.pcb_port_id) ?? [];
    entries.push(pad);
    padsByPort.set(pad.pcb_port_id, entries);
  }
  const emittedVias = circuit.filter((e) => e.type === "pcb_via");
  let bridges;
  const getBridges = () => {
    if (bridges) return bridges;
    bridges = emittedVias.map((v) => ({ ...v, diameter: v.outer_diameter }));
    const board = circuit.find((e) => e.type === "pcb_board");
    const stack = [
      "top",
      ...all_layers4.filter((l) => l.startsWith("inner")).slice(0, board ? Math.max(0, board.num_layers - 2) : void 0),
      ...board?.num_layers === 1 ? [] : ["bottom"]
    ];
    for (const trace of circuit) {
      if (trace.type !== "pcb_trace") continue;
      for (const point2 of trace.route) {
        if (point2.route_type !== "via") continue;
        if (emittedVias.some(
          (v) => Math.hypot(v.x - point2.x, v.y - point2.y) <= EPSILON2
        ))
          continue;
        const from = stack.indexOf(point2.from_layer), to = stack.indexOf(point2.to_layer);
        if (from < 0 || to < 0) continue;
        bridges.push({
          ...point2,
          layers: stack.slice(Math.min(from, to), Math.max(from, to) + 1),
          diameter: point2.outer_diameter
        });
      }
    }
    return bridges;
  };
  const layersForPort = (port) => {
    const portPads = padsByPort.get(port.pcb_port_id);
    return portPads?.length ? [...new Set(portPads.flatMap(getLayersOfPcbElement))] : port.layers;
  };
  const canConnect = (point2, portId) => {
    const port = ports.get(portId);
    if (!port) return true;
    const layers = layersForPort(port);
    if (layers.includes(point2.layer)) return true;
    const portPads = padsByPort.get(portId) ?? [];
    return getBridges().some((via) => {
      if (!via.layers.includes(point2.layer) || !layers.some((l) => via.layers.includes(l)))
        return false;
      if (via.diameter !== void 0 && (!Number.isFinite(via.diameter) || via.diameter <= 0))
        return false;
      const reach = via.diameter === void 0 ? 0 : via.diameter / 2 + point2.width / 2;
      if (Math.hypot(point2.x - via.x, point2.y - via.y) > reach + EPSILON2)
        return false;
      if (portPads.length === 0)
        return Math.hypot(port.x - via.x, port.y - via.y) <= EPSILON2;
      return portPads.some((pad) => {
        if (!getLayersOfPcbElement(pad).some((l) => via.layers.includes(l)))
          return false;
        if (via.diameter === void 0) return isPointInPad(via, pad);
        return getPadToPadGap(
          {
            type: "pcb_via",
            pcb_via_id: "layer-contact",
            x: via.x,
            y: via.y,
            outer_diameter: via.diameter,
            hole_diameter: 0,
            layers: via.layers
          },
          pad
        ) <= EPSILON2;
      });
    });
  };
  return { ports, layersForPort, canConnect };
}
function getTracePortLayerMismatches(circuit) {
  const contact = createTracePortLayerConnectivity(circuit);
  return circuit.flatMap((trace) => {
    if (trace.type !== "pcb_trace") return [];
    return trace.route.flatMap((point2, index) => {
      if (point2.route_type !== "wire") return [];
      return [
        .../* @__PURE__ */ new Set([point2.start_pcb_port_id, point2.end_pcb_port_id])
      ].flatMap((portId) => {
        if (!portId || contact.canConnect(point2, portId)) return [];
        const port = contact.ports.get(portId);
        return [
          { trace, point: point2, index, port, padLayers: contact.layersForPort(port) }
        ];
      });
    });
  });
}

// lib/util/create-indexed-pcb-connectivity-map.ts
import {
  ConnectivityMap,
  findConnectedNetworks,
  PcbConnectivityMap
} from "circuit-json-to-connectivity-map";
import Flatbush4 from "flatbush";

// lib/util/get-via-and-pour-connections.ts
import {
  all_layers as all_layers5
} from "circuit-json";
import {
  circlePolygon,
  getPlatedHolePolygon as getPlatedHolePolygon2,
  getPourPolygon as getPourPolygon4,
  getTraceSegmentPolygon as getTraceSegmentPolygon2
} from "@tscircuit/circuit-json-util";
import Flatbush2 from "flatbush";
function getViaAndPourConnections(circuit) {
  if (!circuit.some(
    (e) => e.type === "pcb_via" || e.type === "pcb_plated_hole" || e.type === "pcb_copper_pour" || e.type === "pcb_trace" && e.route.some((p) => p.route_type === "via")
  ))
    return [];
  const conductors = [];
  const connections = [];
  const scale = 1e6;
  const tolerance = 1e-7 * scale;
  const touches = createCopperPolygonContactTester(tolerance);
  const add = (id, layers, polygon, bridges = false, platedPort = false) => {
    if (!polygon.isEmpty()) {
      const scaledPolygon = polygon.scale(scale, scale);
      conductors.push({
        id,
        layers,
        geometry: { polygon: scaledPolygon },
        box: scaledPolygon.box,
        bridges,
        platedPort
      });
    }
  };
  const polygonCache = /* @__PURE__ */ new Map();
  const getPolygon = (conductor) => {
    if ("polygon" in conductor.geometry) return conductor.geometry.polygon;
    let polygon = polygonCache.get(conductor);
    if (!polygon) {
      const { start, end } = conductor.geometry;
      polygon = getTraceSegmentPolygon2(start, end, start.width).scale(
        scale,
        scale
      );
      polygonCache.set(conductor, polygon);
    }
    return polygon;
  };
  const vias = circuit.filter((e) => e.type === "pcb_via");
  const components = new Map(
    circuit.filter((e) => e.type === "pcb_component").map((e) => [e.pcb_component_id, e])
  );
  const board = circuit.find((e) => e.type === "pcb_board");
  const stack = [
    "top",
    ...all_layers5.filter((l) => l.startsWith("inner")).slice(0, board ? Math.max(0, board.num_layers - 2) : void 0),
    ...board?.num_layers === 1 ? [] : ["bottom"]
  ];
  for (const copper of circuit) {
    if (copper.type === "pcb_via") {
      add(
        copper.pcb_via_id,
        copper.layers,
        circlePolygon(copper, copper.outer_diameter / 2),
        true
      );
      if (copper.pcb_trace_id)
        connections.push([copper.pcb_via_id, copper.pcb_trace_id]);
    } else if (copper.type === "pcb_plated_hole") {
      if (!copper.pcb_port_id) continue;
      const pad = {
        ...copper,
        hole_offset_x: "hole_offset_x" in copper ? copper.hole_offset_x ?? 0 : 0,
        hole_offset_y: "hole_offset_y" in copper ? copper.hole_offset_y ?? 0 : 0
      };
      add(
        copper.pcb_port_id,
        copper.layers,
        getPlatedHolePolygon2(
          pad,
          copper.pcb_component_id ? components.get(copper.pcb_component_id)?.rotation : 0
        ),
        true,
        true
      );
    } else if (copper.type === "pcb_copper_pour") {
      add(
        copper.pcb_copper_pour_id,
        [copper.layer],
        getPourPolygon4(copper),
        true
      );
    } else if (copper.type === "pcb_trace") {
      if (copper.route_thickness_mode === "interpolated") continue;
      for (let i = 0; i < copper.route.length; i++) {
        const a = copper.route[i], b = copper.route[i + 1];
        if (a.route_type === "wire" && b?.route_type === "wire" && a.layer === b.layer && (a.x !== b.x || a.y !== b.y)) {
          if (a.width > 0) {
            const radius = a.width / 2;
            conductors.push({
              id: copper.pcb_trace_id,
              layers: [a.layer],
              geometry: { start: a, end: b },
              box: {
                xmin: (Math.min(a.x, b.x) - radius) * scale,
                ymin: (Math.min(a.y, b.y) - radius) * scale,
                xmax: (Math.max(a.x, b.x) + radius) * scale,
                ymax: (Math.max(a.y, b.y) + radius) * scale
              },
              bridges: false,
              platedPort: false
            });
          } else {
            add(
              copper.pcb_trace_id,
              [a.layer],
              getTraceSegmentPolygon2(a, b, a.width)
            );
          }
        } else if (a.route_type === "via") {
          if (vias.some(
            (v) => v.pcb_trace_id === copper.pcb_trace_id && Math.hypot(v.x - a.x, v.y - a.y) < 1e-9
          ))
            continue;
          const from = stack.indexOf(a.from_layer), to = stack.indexOf(a.to_layer);
          if (from < 0 || to < 0 || !a.outer_diameter) continue;
          const via = {
            type: "pcb_via",
            pcb_via_id: `${copper.pcb_trace_id}_via_${i}`,
            x: a.x,
            y: a.y,
            outer_diameter: a.outer_diameter,
            hole_diameter: 0,
            layers: stack.slice(Math.min(from, to), Math.max(from, to) + 1)
          };
          add(
            copper.pcb_trace_id,
            via.layers,
            circlePolygon(via, via.outer_diameter / 2),
            true
          );
        }
      }
    }
  }
  if (!conductors.length) return connections;
  const index = new Flatbush2(conductors.length);
  for (const { box: b } of conductors) {
    index.add(b.xmin, b.ymin, b.xmax, b.ymax);
  }
  index.finish();
  for (const [i, a] of conductors.entries()) {
    if (!a.bridges) continue;
    const box = a.box;
    for (const j of index.search(
      box.xmin - tolerance,
      box.ymin - tolerance,
      box.xmax + tolerance,
      box.ymax + tolerance
    )) {
      const b = conductors[j];
      if (a.platedPort && b.bridges || b.platedPort && a.bridges || i === j || a.id === b.id || b.bridges && j < i || !a.layers.some((l) => b.layers.includes(l)))
        continue;
      if (touches(getPolygon(a), getPolygon(b))) connections.push([a.id, b.id]);
    }
  }
  return connections;
}

// lib/util/get-touching-smt-pad-connections.ts
import Flatbush3 from "flatbush";
function getTouchingSmtPadConnections(circuitJson) {
  const pads = circuitJson.filter(
    (element) => element.type === "pcb_smtpad" && Boolean(element.pcb_port_id)
  );
  if (pads.length < 2) return [];
  const epsilon = 1e-9;
  const bounds = pads.map(getPadBounds);
  const index = new Flatbush3(pads.length);
  for (const box of bounds) index.add(box.minX, box.minY, box.maxX, box.maxY);
  index.finish();
  const connections = [];
  for (const [i, pad] of pads.entries()) {
    const box = bounds[i];
    for (const j of index.search(
      box.minX - epsilon,
      box.minY - epsilon,
      box.maxX + epsilon,
      box.maxY + epsilon
    )) {
      const other = pads[j];
      if (j <= i || pad.layer !== other.layer || pad.pcb_port_id === other.pcb_port_id)
        continue;
      if (getPadToPadGap(pad, other) <= epsilon) {
        connections.push([pad.pcb_port_id, other.pcb_port_id]);
      }
    }
  }
  return connections;
}

// lib/util/create-indexed-pcb-connectivity-map.ts
function createIndexedPcbConnectivityMap(circuitJson) {
  const map = new PcbConnectivityMap();
  map.circuitJson = circuitJson;
  for (const element of circuitJson) {
    if (element.type === "pcb_trace") {
      map.traceIdToElm.set(element.pcb_trace_id, element);
    } else if (element.type === "pcb_port") {
      map.portIdToElm.set(element.pcb_port_id, element);
    }
  }
  const traces = [...map.traceIdToElm.values()];
  const boundsByLayer = /* @__PURE__ */ new Map();
  for (const [traceIndex, trace] of traces.entries()) {
    for (let i = 0; i < trace.route.length - 1; i++) {
      const a = trace.route[i];
      const b = trace.route[i + 1];
      if (a.route_type !== "wire" || b.route_type !== "wire" || a.layer !== b.layer)
        continue;
      const radius = a.width / 2 + 1e-9;
      const entries = boundsByLayer.get(a.layer) ?? [];
      entries.push({
        traceIndex,
        segmentTrace: { ...trace, route: [a, b] },
        minX: Math.min(a.x, b.x) - radius,
        minY: Math.min(a.y, b.y) - radius,
        maxX: Math.max(a.x, b.x) + radius,
        maxY: Math.max(a.y, b.y) + radius
      });
      boundsByLayer.set(a.layer, entries);
    }
  }
  const candidates = traces.map(() => /* @__PURE__ */ new Set());
  for (const bounds of boundsByLayer.values()) {
    const index = new Flatbush4(bounds.length);
    for (const box of bounds) index.add(box.minX, box.minY, box.maxX, box.maxY);
    index.finish();
    for (const box of bounds) {
      for (const hit of index.search(box.minX, box.minY, box.maxX, box.maxY)) {
        const otherBox = bounds[hit];
        const other = otherBox.traceIndex;
        const connected = candidates[box.traceIndex];
        if (other > box.traceIndex && !connected.has(other) && map._arePcbTracesConnected(box.segmentTrace, otherBox.segmentTrace)) {
          connected.add(other);
        }
      }
    }
  }
  const connections = [];
  for (const [i, neighbors] of candidates.entries()) {
    for (const j of [...neighbors].sort((a, b) => a - b)) {
      connections.push([traces[i].pcb_trace_id, traces[j].pcb_trace_id]);
    }
  }
  const layerConnectivity = createTracePortLayerConnectivity(circuitJson);
  const connectionsByPort = /* @__PURE__ */ new Map();
  for (const trace of traces) {
    for (const point2 of trace.route) {
      if (point2.route_type !== "wire") continue;
      for (const portId of /* @__PURE__ */ new Set([
        point2.start_pcb_port_id,
        point2.end_pcb_port_id
      ])) {
        if (!portId || !map.portIdToElm.has(portId)) continue;
        if (!layerConnectivity.canConnect(point2, portId)) continue;
        const entries = connectionsByPort.get(portId) ?? [];
        entries.push(
          point2.start_pcb_port_id === portId ? [portId, trace.pcb_trace_id] : [trace.pcb_trace_id, portId]
        );
        connectionsByPort.set(portId, entries);
      }
    }
  }
  for (const portId of map.portIdToElm.keys()) {
    for (const connection of connectionsByPort.get(portId) ?? [])
      connections.push(connection);
  }
  connections.push(...getViaAndPourConnections(circuitJson));
  connections.push(...getTouchingSmtPadConnections(circuitJson));
  map.connMap = new ConnectivityMap(findConnectedNetworks(connections));
  return map;
}

// lib/add-start-and-end-port-ids-if-missing.ts
function distance(x1, y1, x2, y2) {
  return Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
}
var addStartAndEndPortIdsIfMissing = (soup) => {
  const pcbPorts = soup.filter((item) => item.type === "pcb_port");
  const pcbSmtPads = soup.filter(
    (item) => item.type === "pcb_smtpad"
  );
  const pcbTraces = soup.filter((item) => item.type === "pcb_trace");
  function findPortIdOverlappingPoint(point2, options = {}) {
    const traceWidth = options.traceWidth || 0;
    const directPort = pcbPorts.find(
      (port) => port.layers.includes(point2.layer) && distance(port.x, port.y, point2.x, point2.y) < 0.01
    );
    if (directPort) return directPort.pcb_port_id;
    if (options.isFirstOrLastPoint) {
      const smtPad2 = pcbSmtPads.find((pad) => {
        if (pad.layer !== point2.layer) return false;
        if (pad.shape === "rect") {
          return Math.abs(point2.x - pad.x) < pad.width / 2 + traceWidth / 2 && Math.abs(point2.y - pad.y) < pad.height / 2 + traceWidth / 2;
        } else if (pad.shape === "circle") {
          return distance(point2.x, point2.y, pad.x, pad.y) < pad.radius;
        } else if (pad.shape === "pill" || pad.shape === "rotated_pill") {
          return isPointInPad(point2, pad);
        }
      });
      if (smtPad2) return smtPad2.pcb_port_id ?? null;
    }
    return null;
  }
  for (const trace of pcbTraces) {
    for (let index = 0; index < trace.route.length; index++) {
      const segment = trace.route[index];
      const isFirstOrLastPoint = index === 0 || index === trace.route.length - 1;
      if (segment.route_type === "wire") {
        if (!segment.start_pcb_port_id && index === 0) {
          const startPortId = findPortIdOverlappingPoint(segment, {
            isFirstOrLastPoint,
            traceWidth: segment.width
          });
          if (startPortId) {
            segment.start_pcb_port_id = startPortId;
          }
        }
        if (!segment.end_pcb_port_id && index === trace.route.length - 1) {
          const endPortId = findPortIdOverlappingPoint(segment, {
            isFirstOrLastPoint,
            traceWidth: segment.width
          });
          if (endPortId) {
            segment.end_pcb_port_id = endPortId;
          }
        }
      }
    }
  }
};

// lib/check-each-pcb-port-connected-to-pcb-trace.ts
import {
  getFullConnectivityMapFromCircuitJson as getFullConnectivityMapFromCircuitJson4
} from "circuit-json-to-connectivity-map";
function checkEachPcbPortConnectedToPcbTraces(circuitJson, {
  connMap,
  pcbConnectivityMap
} = {}) {
  addStartAndEndPortIdsIfMissing(circuitJson);
  const sourceTraces = circuitJson.filter(
    (item) => item.type === "source_trace"
  );
  const pcbPorts = circuitJson.filter(
    (item) => item.type === "pcb_port"
  );
  const sourceNets = circuitJson.filter(
    (item) => item.type === "source_net"
  );
  const errors = getTracePortLayerMismatches(
    circuitJson
  ).map(({ trace, point: point2, index, port, padLayers }) => ({
    type: "pcb_port_not_connected_error",
    error_type: "pcb_port_not_connected_error",
    pcb_port_not_connected_error_id: `missing_layer_connection_${trace.pcb_trace_id}_${index}_${port.pcb_port_id}`,
    pcb_port_ids: [port.pcb_port_id],
    pcb_component_ids: port.pcb_component_id ? [port.pcb_component_id] : [],
    center: { x: point2.x, y: point2.y },
    message: `Port [${getReadableNameForPort(circuitJson, port.pcb_port_id)}] on ${padLayers.join(", ")} is not connected to trace [${getReadableNameForTrace(circuitJson, trace.pcb_trace_id)}] on ${point2.layer}: missing via connection.`
  }));
  const connectivityMap = connMap ?? getFullConnectivityMapFromCircuitJson4(circuitJson);
  pcbConnectivityMap ??= createIndexedPcbConnectivityMap(circuitJson);
  let pourConnectivity;
  const getPourConnectivity = () => pourConnectivity ??= getCopperPourConnectivity(
    circuitJson,
    connectivityMap
  );
  const sourcePortToPcbPort = /* @__PURE__ */ new Map();
  for (const pcbPort of pcbPorts) {
    sourcePortToPcbPort.set(pcbPort.source_port_id, pcbPort);
  }
  const sourceNetNameById = new Map(
    sourceNets.map((sourceNet) => [sourceNet.source_net_id, sourceNet.name])
  );
  for (const sourceTrace of sourceTraces) {
    const connectedSourcePortIds = sourceTrace.connected_source_port_ids;
    if (connectedSourcePortIds.length === 1 && sourceTrace.connected_source_net_ids.length > 0) {
      const pcbPort = sourcePortToPcbPort.get(connectedSourcePortIds[0]);
      if (!pcbPort) continue;
      const connectedPcbTraces = pcbConnectivityMap.getAllTracesConnectedToPort(
        pcbPort.pcb_port_id
      );
      if (connectedPcbTraces.length === 0 && !getPourConnectivity().isPortConnectedToNet(
        pcbPort.pcb_port_id,
        sourceTrace.connected_source_net_ids
      )) {
        const connectedNetNames = sourceTrace.connected_source_net_ids.map((sourceNetId) => sourceNetNameById.get(sourceNetId)).filter((name) => Boolean(name));
        const netDescription = connectedNetNames.length > 0 ? `net [${connectedNetNames.join(", ")}]` : "its connected net";
        errors.push({
          type: "pcb_port_not_connected_error",
          message: `Port [${getReadableNameForPort(circuitJson, pcbPort.pcb_port_id)}] is not connected to ${netDescription} by a PCB trace.`,
          error_type: "pcb_port_not_connected_error",
          pcb_port_ids: [pcbPort.pcb_port_id],
          pcb_component_ids: pcbPort.pcb_component_id ? [pcbPort.pcb_component_id] : [],
          pcb_port_not_connected_error_id: `pcb_port_not_connected_error_trace_${sourceTrace.source_trace_id}`
        });
      }
      continue;
    }
    if (connectedSourcePortIds.length < 2) {
      continue;
    }
    const pcbPortsInTrace = [];
    const missingPcbPorts = [];
    for (const sourcePortId of connectedSourcePortIds) {
      const pcbPort = sourcePortToPcbPort.get(sourcePortId);
      if (pcbPort) {
        pcbPortsInTrace.push(pcbPort);
      } else {
        missingPcbPorts.push(sourcePortId);
      }
    }
    if (pcbPortsInTrace.length < 2) {
      continue;
    }
    const firstPcbPort = pcbPortsInTrace[0];
    const referenceNetId = connectivityMap.getNetConnectedToId(
      firstPcbPort.pcb_port_id
    );
    const netElementIds = connectivityMap.getIdsConnectedToNet(referenceNetId);
    const pcbTraceIds = netElementIds.filter(
      (id) => circuitJson.some(
        (element) => element.type === "pcb_trace" && ("pcb_trace_id" in element && element.pcb_trace_id === id || "route_id" in element && element.route_id === id)
      )
    );
    if (pcbTraceIds.length === 0 && !getPourConnectivity().arePortsConnected(
      pcbPortsInTrace.map((port) => port.pcb_port_id)
    )) {
      const uniqueComponentIds = new Set(
        pcbPortsInTrace.map((p) => p.pcb_component_id)
      );
      if (uniqueComponentIds.size > 1) {
        errors.push({
          type: "pcb_port_not_connected_error",
          message: `Ports [${pcbPortsInTrace.map((p) => getReadableNameForPort(circuitJson, p.pcb_port_id)).join(", ")}] are not connected together through the same net.`,
          error_type: "pcb_port_not_connected_error",
          pcb_port_ids: pcbPortsInTrace.map((p) => p.pcb_port_id),
          pcb_component_ids: pcbPortsInTrace.map((p) => p.pcb_component_id).filter((id) => id !== void 0),
          pcb_port_not_connected_error_id: `pcb_port_not_connected_error_trace_${sourceTrace.source_trace_id}`
        });
      }
    }
  }
  return errors;
}

// lib/check-hole-clearance/common.ts
import { Point as Point3, Segment as Segment3 } from "@flatten-js/core";
import {
  pointToSegmentClosestPoint as pointToSegmentClosestPoint3,
  pointToSegmentDistance as pointToSegmentDistance4
} from "@tscircuit/math-utils";
var getHoleGeometries = (circuitJson) => convertCircuitJsonToFlattenJs(
  circuitJson.filter((e) => e.type === "pcb_hole"),
  {
    elementTypes: ["pcb_hole"],
    strict: true,
    curveTolerance: 1e-6
  }
).elements;
var getTraceHoleClearance = (trace, geometry) => {
  const hole = geometry.sourceElement;
  if (hole.type !== "pcb_hole") {
    throw new Error(`Expected hole geometry`);
  }
  const a = new Point3(trace.x1, trace.y1);
  const b = new Point3(trace.x2, trace.y2);
  let distance6 = Infinity;
  let center = pointToSegmentClosestPoint3(hole, a, b);
  if (hole.hole_shape === "circle") {
    distance6 = pointToSegmentDistance4(hole, a, b) - hole.hole_diameter / 2;
  } else {
    const segment = new Segment3(a, b);
    for (const shape of geometry.shapes) {
      const [boundaryDistance, shortest] = shape.distanceTo(segment);
      const shapeDistance = shape.contains(a) || shape.contains(b) ? 0 : boundaryDistance;
      if (shapeDistance < distance6) {
        distance6 = shapeDistance;
        center = shortest.end;
      }
    }
  }
  return { gap: distance6 - trace.thickness / 2, center };
};

// lib/check-each-pcb-trace-non-overlapping/check-each-pcb-trace-non-overlapping.ts
import { cju as cju3 } from "@tscircuit/circuit-json-util";
import { getPrimaryId as getPrimaryId4 } from "@tscircuit/circuit-json-util";
import { segmentToBoundsMinDistance } from "@tscircuit/math-utils";
import { segmentToSegmentMinDistance as segmentToSegmentMinDistance4 } from "@tscircuit/math-utils";
import {
  getFullConnectivityMapFromCircuitJson as getFullConnectivityMapFromCircuitJson5
} from "circuit-json-to-connectivity-map";

// lib/data-structures/SpatialIndex.ts
var SpatialObjectIndex = class {
  buckets;
  objectsById;
  getBounds;
  getId;
  CELL_SIZE = 0.4;
  constructor({
    objects,
    getBounds,
    getId,
    CELL_SIZE
  }) {
    this.buckets = /* @__PURE__ */ new Map();
    this.objectsById = /* @__PURE__ */ new Map();
    this.getBounds = getBounds;
    this.getId = getId ?? (() => this._getNextId());
    this.CELL_SIZE = CELL_SIZE ?? this.CELL_SIZE;
    for (const obj of objects) {
      this.addObject(obj);
    }
  }
  _idCounter = 0;
  _getNextId() {
    return `${this._idCounter++}`;
  }
  addObject(obj) {
    const bounds = this.getBounds(obj);
    const spatialIndexId = this.getId(obj);
    const objWithId = { ...obj, spatialIndexId };
    this.objectsById.set(spatialIndexId, objWithId);
    const minBucketX = Math.floor(bounds.minX / this.CELL_SIZE);
    const minBucketY = Math.floor(bounds.minY / this.CELL_SIZE);
    const maxBucketX = Math.floor(bounds.maxX / this.CELL_SIZE);
    const maxBucketY = Math.floor(bounds.maxY / this.CELL_SIZE);
    for (let bx = minBucketX; bx <= maxBucketX; bx++) {
      for (let by = minBucketY; by <= maxBucketY; by++) {
        const bucketKey = `${bx}x${by}`;
        const bucket = this.buckets.get(bucketKey);
        if (!bucket) {
          this.buckets.set(bucketKey, [objWithId]);
        } else {
          bucket.push(objWithId);
        }
      }
    }
  }
  removeObject(id) {
    const obj = this.objectsById.get(id);
    if (!obj) return false;
    this.objectsById.delete(id);
    const bounds = this.getBounds(obj);
    const minBucketX = Math.floor(bounds.minX / this.CELL_SIZE);
    const minBucketY = Math.floor(bounds.minY / this.CELL_SIZE);
    const maxBucketX = Math.floor(bounds.maxX / this.CELL_SIZE);
    const maxBucketY = Math.floor(bounds.maxY / this.CELL_SIZE);
    for (let bx = minBucketX; bx <= maxBucketX; bx++) {
      for (let by = minBucketY; by <= maxBucketY; by++) {
        const bucketKey = `${bx}x${by}`;
        const bucket = this.buckets.get(bucketKey);
        if (bucket) {
          const index = bucket.findIndex((item) => item.spatialIndexId === id);
          if (index !== -1) {
            bucket.splice(index, 1);
            if (bucket.length === 0) {
              this.buckets.delete(bucketKey);
            }
          }
        }
      }
    }
    return true;
  }
  getBucketKey(x, y) {
    return `${Math.floor(x / this.CELL_SIZE)}x${Math.floor(y / this.CELL_SIZE)}`;
  }
  getObjectsInBounds(bounds, margin = 0) {
    const objects = [];
    const addedIds = /* @__PURE__ */ new Set();
    const minBucketX = Math.floor((bounds.minX - margin) / this.CELL_SIZE);
    const minBucketY = Math.floor((bounds.minY - margin) / this.CELL_SIZE);
    const maxBucketX = Math.floor((bounds.maxX + margin) / this.CELL_SIZE);
    const maxBucketY = Math.floor((bounds.maxY + margin) / this.CELL_SIZE);
    for (let bx = minBucketX; bx <= maxBucketX; bx++) {
      for (let by = minBucketY; by <= maxBucketY; by++) {
        const bucketKey = `${bx}x${by}`;
        const bucket = this.buckets.get(bucketKey) || [];
        for (const obj of bucket) {
          const id = obj.spatialIndexId;
          if (addedIds.has(id)) continue;
          addedIds.add(id);
          objects.push(obj);
        }
      }
    }
    return objects;
  }
};

// lib/check-each-pcb-trace-non-overlapping/getClosestPointBetweenSegmentAndBounds.ts
var getClosestPointBetweenSegmentAndBounds = (segment, bounds) => {
  const p1 = { x: segment.x1, y: segment.y1 };
  const p2 = { x: segment.x2, y: segment.y2 };
  const minX = bounds.minX;
  const minY = bounds.minY;
  const maxX = bounds.maxX;
  const maxY = bounds.maxY;
  if (p1.x === p2.x && p1.y === p2.y) {
    const closestX = Math.max(minX, Math.min(maxX, p1.x));
    const closestY = Math.max(minY, Math.min(maxY, p1.y));
    if (closestX === p1.x && closestY === p1.y) {
      return { x: p1.x, y: p1.y };
    }
    return { x: closestX, y: closestY };
  }
  const dx = p2.x - p1.x;
  const dy = p2.y - p1.y;
  const tMinX = dx !== 0 ? (minX - p1.x) / dx : Number.NEGATIVE_INFINITY;
  const tMaxX = dx !== 0 ? (maxX - p1.x) / dx : Number.POSITIVE_INFINITY;
  const tMinY = dy !== 0 ? (minY - p1.y) / dy : Number.NEGATIVE_INFINITY;
  const tMaxY = dy !== 0 ? (maxY - p1.y) / dy : Number.POSITIVE_INFINITY;
  const tEnter = Math.max(Math.min(tMinX, tMaxX), Math.min(tMinY, tMaxY));
  const tExit = Math.min(Math.max(tMinX, tMaxX), Math.max(tMinY, tMaxY));
  if (tEnter <= tExit && tExit >= 0 && tEnter <= 1) {
    const t = Math.max(0, Math.min(1, tEnter));
    return {
      x: p1.x + t * dx,
      y: p1.y + t * dy
    };
  }
  const closestToP1 = {
    x: Math.max(minX, Math.min(maxX, p1.x)),
    y: Math.max(minY, Math.min(maxY, p1.y))
  };
  const closestToP2 = {
    x: Math.max(minX, Math.min(maxX, p2.x)),
    y: Math.max(minY, Math.min(maxY, p2.y))
  };
  const distToP1Squared = (closestToP1.x - p1.x) ** 2 + (closestToP1.y - p1.y) ** 2;
  const distToP2Squared = (closestToP2.x - p2.x) ** 2 + (closestToP2.y - p2.y) ** 2;
  const edges = [
    { start: { x: minX, y: minY }, end: { x: maxX, y: minY } },
    // Bottom edge
    { start: { x: maxX, y: minY }, end: { x: maxX, y: maxY } },
    // Right edge
    { start: { x: maxX, y: maxY }, end: { x: minX, y: maxY } },
    // Top edge
    { start: { x: minX, y: maxY }, end: { x: minX, y: minY } }
    // Left edge
  ];
  let minDistance = Math.min(distToP1Squared, distToP2Squared);
  let closestPoint = distToP1Squared <= distToP2Squared ? closestToP1 : closestToP2;
  const clamp2 = (value, min, max) => {
    return Math.max(min, Math.min(max, value));
  };
  for (const edge of edges) {
    const va = { x: p2.x - p1.x, y: p2.y - p1.y };
    const vb = { x: edge.end.x - edge.start.x, y: edge.end.y - edge.start.y };
    const w = { x: p1.x - edge.start.x, y: p1.y - edge.start.y };
    const dotAA = va.x * va.x + va.y * va.y;
    const dotAB = va.x * vb.x + va.y * vb.y;
    const dotAW = va.x * w.x + va.y * w.y;
    const dotBB = vb.x * vb.x + vb.y * vb.y;
    const dotBW = vb.x * w.x + vb.y * w.y;
    const denominator = dotAA * dotBB - dotAB * dotAB;
    if (Math.abs(denominator) < 1e-10) continue;
    let tA = (dotAB * dotBW - dotBB * dotAW) / denominator;
    let tB = (dotAA * dotBW - dotAB * dotAW) / denominator;
    tA = clamp2(tA, 0, 1);
    tB = clamp2(tB, 0, 1);
    const closestOnSegment = {
      x: p1.x + tA * va.x,
      y: p1.y + tA * va.y
    };
    const closestOnEdge = {
      x: edge.start.x + tB * vb.x,
      y: edge.start.y + tB * vb.y
    };
    const dx2 = closestOnSegment.x - closestOnEdge.x;
    const dy2 = closestOnSegment.y - closestOnEdge.y;
    const distSquared = dx2 * dx2 + dy2 * dy2;
    if (distSquared < minDistance) {
      minDistance = distSquared;
      closestPoint = {
        x: (closestOnSegment.x + closestOnEdge.x) / 2,
        y: (closestOnSegment.y + closestOnEdge.y) / 2
      };
    }
  }
  return closestPoint;
};

// lib/check-each-pcb-trace-non-overlapping/getCollidableBounds.ts
import { getBoundsOfPcbElements as getBoundsOfPcbElements3 } from "@tscircuit/circuit-json-util";
var getCollidableBounds = (collidable) => {
  if (collidable.type === "pcb_hole" && (collidable.hole_shape === "pill" || collidable.hole_shape === "rotated_pill") || collidable.type === "pcb_smtpad" && collidable.shape === "rotated_pill") {
    const pill = getPillCenterLineForPad(collidable);
    return {
      minX: Math.min(pill.start.x, pill.end.x) - pill.radius,
      minY: Math.min(pill.start.y, pill.end.y) - pill.radius,
      maxX: Math.max(pill.start.x, pill.end.x) + pill.radius,
      maxY: Math.max(pill.start.y, pill.end.y) + pill.radius
    };
  }
  if (collidable.type === "pcb_trace_segment") {
    return {
      minX: Math.min(collidable.x1, collidable.x2),
      minY: Math.min(collidable.y1, collidable.y2),
      maxX: Math.max(collidable.x1, collidable.x2),
      maxY: Math.max(collidable.y1, collidable.y2)
    };
  }
  if (collidable.type === "pcb_smtpad" || collidable.type === "pcb_plated_hole") {
    const isPolygon = collidable.type === "pcb_smtpad" && (collidable.shape === "rotated_rect" || collidable.shape === "polygon") || collidable.type === "pcb_plated_hole" && "rect_pad_width" in collidable && "rect_pad_height" in collidable;
    if (isPolygon) {
      const polygonPoints = getPolygonPointsForPad(collidable);
      return {
        minX: Math.min(...polygonPoints.map((point2) => point2.x)),
        minY: Math.min(...polygonPoints.map((point2) => point2.y)),
        maxX: Math.max(...polygonPoints.map((point2) => point2.x)),
        maxY: Math.max(...polygonPoints.map((point2) => point2.y))
      };
    }
  }
  return getBoundsOfPcbElements3([collidable]);
};

// lib/check-each-pcb-trace-non-overlapping/check-each-pcb-trace-non-overlapping.ts
var getPcbComponentConnectionElementId = (element) => {
  if (element.type === "pcb_port") return element.pcb_port_id;
  if (element.type === "pcb_smtpad") return element.pcb_smtpad_id;
  return element.pcb_plated_hole_id;
};
function checkEachPcbTraceNonOverlapping(circuitJson, {
  connMap,
  minClearance
} = {}) {
  const errors = checkPcbTraceSelfShorts(circuitJson);
  addStartAndEndPortIdsIfMissing(circuitJson);
  connMap ??= getFullConnectivityMapFromCircuitJson5(circuitJson);
  const board = getPcbBoard(circuitJson);
  minClearance ??= getBoardDrcValue(board, "min_trace_to_pad_edge_clearance") ?? DEFAULT_TRACE_MARGIN;
  const pcbTraces = cju3(circuitJson).pcb_trace.list();
  const pcbTraceSegments = pcbTraces.flatMap((pcbTrace) => {
    const segments = [];
    for (let i = 0; i < pcbTrace.route.length - 1; i++) {
      const p1 = pcbTrace.route[i];
      const p2 = pcbTrace.route[i + 1];
      if (p1.route_type !== "wire" && p1.route_type !== "via" || p2.route_type !== "wire" && p2.route_type !== "via")
        continue;
      const wire = p1.route_type === "wire" ? p1 : p2;
      if (wire.route_type !== "wire") continue;
      if (p1.route_type === "wire" && p2.route_type === "wire" && p1.layer !== p2.layer)
        continue;
      segments.push({
        type: "pcb_trace_segment",
        pcb_trace_id: pcbTrace.pcb_trace_id,
        _pcbTrace: pcbTrace,
        // A wire owns the outgoing segment; the next wire can start a wider
        // segment without widening this one. Keep this segment's taper bounds.
        thickness: Math.max(
          wire.width ?? DEFAULT_TRACE_THICKNESS,
          wire.start_width ?? 0,
          wire.end_width ?? 0
        ),
        layer: wire.layer,
        x1: p1.x,
        y1: p1.y,
        x2: p2.x,
        y2: p2.y
      });
    }
    return segments;
  });
  const pcbSmtPads = cju3(circuitJson).pcb_smtpad.list();
  const pcbPlatedHoles = cju3(circuitJson).pcb_plated_hole.list();
  const pcbPorts = cju3(circuitJson).pcb_port.list();
  const pcbHoles = cju3(circuitJson).pcb_hole.list();
  const holeGeometryById = new Map(
    getHoleGeometries(circuitJson).map((geometry) => [
      geometry.elementId,
      geometry
    ])
  );
  const pcbVias = cju3(circuitJson).pcb_via.list();
  const pcbKeepouts = cju3(circuitJson).pcb_keepout.list().filter((keepout) => !keepout.allow_traces);
  const pcbComponentConnectionElements = [
    ...pcbPorts,
    ...pcbSmtPads,
    ...pcbPlatedHoles
  ];
  const excludedConnectionIdsByKeepoutId = /* @__PURE__ */ new Map();
  for (const keepout of pcbKeepouts) {
    const excludedPcbComponentIds = new Set(
      keepout.excluded_pcb_component_ids ?? []
    );
    if (excludedPcbComponentIds.size === 0) continue;
    excludedConnectionIdsByKeepoutId.set(
      keepout.pcb_keepout_id,
      pcbComponentConnectionElements.filter(
        (element) => element.pcb_component_id && excludedPcbComponentIds.has(element.pcb_component_id)
      ).map(getPcbComponentConnectionElementId)
    );
  }
  const allObjects = [
    ...pcbTraceSegments,
    ...pcbSmtPads,
    ...pcbPlatedHoles,
    ...pcbHoles,
    ...pcbVias,
    ...pcbKeepouts
  ];
  const spatialIndex = new SpatialObjectIndex({
    objects: allObjects,
    getBounds: getCollidableBounds
  });
  const getReadableName = (id) => getReadableNameForElementId(circuitJson, id);
  const constructErrorMessage = (traceName, otherName, gap) => {
    if (isTraceObstacleOverlap(gap)) {
      return `PCB trace ${traceName} overlaps with ${otherName} (accidental contact)`;
    }
    return `PCB trace ${traceName} is too close to ${otherName} (gap: ${gap.toFixed(3)}mm)`;
  };
  const errorIds = /* @__PURE__ */ new Set();
  for (const segmentA of pcbTraceSegments) {
    const requiredMargin = minClearance;
    const bounds = getCollidableBounds(segmentA);
    const nearbyObjects = spatialIndex.getObjectsInBounds(
      bounds,
      requiredMargin + segmentA.thickness / 2
    );
    if (segmentA.x1 === segmentA.x2 && segmentA.y1 === segmentA.y2) continue;
    for (const obj of nearbyObjects) {
      if (!getLayersOfPcbElement(obj).includes(segmentA.layer)) {
        continue;
      }
      if (obj.type === "pcb_keepout" && (excludedConnectionIdsByKeepoutId.get(obj.pcb_keepout_id) ?? []).some(
        (connectionId) => connMap.areIdsConnected(segmentA.pcb_trace_id, connectionId)
      )) {
        continue;
      }
      if (obj.type === "pcb_trace_segment") {
        const segmentB = obj;
        if (segmentA.layer !== segmentB.layer) continue;
        if (connMap.areIdsConnected(segmentA.pcb_trace_id, segmentB.pcb_trace_id))
          continue;
        const gap2 = segmentToSegmentMinDistance4(
          { x: segmentA.x1, y: segmentA.y1 },
          { x: segmentA.x2, y: segmentA.y2 },
          { x: segmentB.x1, y: segmentB.y1 },
          { x: segmentB.x2, y: segmentB.y2 }
        ) - segmentA.thickness / 2 - segmentB.thickness / 2;
        if (gap2 > minClearance - EPSILON) continue;
        const pcb_trace_error_id = `overlap_${segmentA.pcb_trace_id}_${segmentB.pcb_trace_id}`;
        const pcb_trace_error_id_reverse = `overlap_${segmentB.pcb_trace_id}_${segmentA.pcb_trace_id}`;
        if (errorIds.has(pcb_trace_error_id)) continue;
        if (errorIds.has(pcb_trace_error_id_reverse)) continue;
        errorIds.add(pcb_trace_error_id);
        errors.push({
          type: "pcb_trace_error",
          error_type: "pcb_trace_error",
          message: constructErrorMessage(
            getReadableName(segmentA.pcb_trace_id),
            getReadableName(segmentB.pcb_trace_id),
            gap2
          ),
          pcb_trace_id: segmentA.pcb_trace_id,
          source_trace_id: "",
          pcb_trace_error_id,
          pcb_component_ids: [],
          center: getClosestPointBetweenSegments(segmentA, segmentB),
          pcb_port_ids: getPcbPortIdsConnectedToTraces([
            segmentA._pcbTrace,
            segmentB._pcbTrace
          ])
        });
        continue;
      }
      const primaryObjId = getPrimaryId4(obj);
      if (connMap.areIdsConnected(
        segmentA.pcb_trace_id,
        "pcb_trace_id" in obj ? obj.pcb_trace_id : primaryObjId
      ))
        continue;
      if (obj.type === "pcb_smtpad" || obj.type === "pcb_plated_hole" || obj.type === "pcb_via") {
        const { gap: gap2, center } = getTraceObstacleClearance(segmentA, obj);
        if (!isTraceObstacleOverlap(gap2)) continue;
        const pcb_trace_error_id = `overlap_${segmentA.pcb_trace_id}_${primaryObjId}`;
        if (errorIds.has(pcb_trace_error_id)) continue;
        errorIds.add(pcb_trace_error_id);
        errors.push({
          type: "pcb_trace_error",
          error_type: "pcb_trace_error",
          message: constructErrorMessage(
            getReadableName(segmentA.pcb_trace_id),
            `${obj.type} "${getReadableName(primaryObjId)}"`,
            gap2
          ),
          pcb_trace_id: segmentA.pcb_trace_id,
          center,
          source_trace_id: "",
          pcb_trace_error_id,
          pcb_component_ids: [
            "pcb_component_id" in obj ? obj.pcb_component_id : void 0
          ].filter(Boolean),
          pcb_port_ids: [
            ...getPcbPortIdsConnectedToTraces([segmentA._pcbTrace]),
            "pcb_port_id" in obj ? obj.pcb_port_id : void 0
          ].filter(Boolean)
        });
        continue;
      }
      if (obj.type === "pcb_hole") {
        const { gap: gap2, center } = getTraceHoleClearance(
          segmentA,
          holeGeometryById.get(obj.pcb_hole_id)
        );
        if (!isTraceObstacleOverlap(gap2)) continue;
        const pcb_trace_error_id = `overlap_${segmentA.pcb_trace_id}_${primaryObjId}`;
        if (errorIds.has(pcb_trace_error_id)) continue;
        errorIds.add(pcb_trace_error_id);
        errors.push({
          type: "pcb_trace_error",
          error_type: "pcb_trace_error",
          message: constructErrorMessage(
            getReadableName(segmentA.pcb_trace_id),
            `${obj.type} "${getReadableName(primaryObjId)}"`,
            gap2
          ),
          pcb_trace_id: segmentA.pcb_trace_id,
          source_trace_id: segmentA._pcbTrace.source_trace_id ?? "",
          pcb_trace_error_id,
          pcb_component_ids: obj.pcb_component_id ? [obj.pcb_component_id] : [],
          pcb_port_ids: getPcbPortIdsConnectedToTraces([segmentA._pcbTrace]),
          center
        });
        continue;
      }
      const gap = segmentToBoundsMinDistance(
        { x: segmentA.x1, y: segmentA.y1 },
        { x: segmentA.x2, y: segmentA.y2 },
        getCollidableBounds(obj)
      ) - segmentA.thickness / 2;
      if (gap + EPSILON < requiredMargin) {
        const pcb_trace_error_id = `overlap_${segmentA.pcb_trace_id}_${primaryObjId}`;
        if (errorIds.has(pcb_trace_error_id)) continue;
        errorIds.add(pcb_trace_error_id);
        if (obj.type === "pcb_keepout" && obj.warning_only) {
          errors.push({
            type: "pcb_keepout_overlap_warning",
            warning_type: "pcb_keepout_overlap_warning",
            pcb_keepout_overlap_warning_id: `pcb_keepout_overlap_warning_${pcb_trace_error_id}`,
            pcb_keepout_id: obj.pcb_keepout_id,
            pcb_trace_ids: [segmentA.pcb_trace_id],
            message: `PCB trace ${getReadableName(segmentA.pcb_trace_id)} violates advisory PCB keepout "${getReadableNameForElementId(circuitJson, obj.pcb_keepout_id)}"`,
            center: getClosestPointBetweenSegmentAndBounds(
              segmentA,
              getCollidableBounds(obj)
            ),
            subcircuit_id: segmentA._pcbTrace.subcircuit_id ?? obj.subcircuit_id
          });
          continue;
        }
        errors.push({
          type: "pcb_trace_error",
          error_type: "pcb_trace_error",
          message: constructErrorMessage(
            getReadableName(segmentA.pcb_trace_id),
            `${obj.type} "${getReadableName(getPrimaryId4(obj))}"`,
            gap
          ),
          pcb_trace_id: segmentA.pcb_trace_id,
          source_trace_id: "",
          pcb_trace_error_id,
          pcb_component_ids: [
            "pcb_component_id" in obj ? obj.pcb_component_id : void 0
          ].filter(Boolean),
          center: getClosestPointBetweenSegmentAndBounds(
            segmentA,
            getCollidableBounds(obj)
          ),
          pcb_port_ids: [
            ...getPcbPortIdsConnectedToTraces([segmentA._pcbTrace]),
            "pcb_port_id" in obj ? obj.pcb_port_id : void 0
          ].filter(Boolean)
        });
      }
    }
  }
  return errors;
}

// lib/net-manager.ts
var NetManager = class {
  networks = /* @__PURE__ */ new Set();
  setConnected(nodes) {
    if (nodes.length < 2) return;
    let targetNetwork = null;
    for (const network of this.networks) {
      for (const node of nodes) {
        if (network.has(node)) {
          if (targetNetwork === null) {
            targetNetwork = network;
          } else if (targetNetwork !== network) {
            for (const mergeNode of network) {
              targetNetwork.add(mergeNode);
            }
            this.networks.delete(network);
          }
          break;
        }
      }
      if (targetNetwork !== null && targetNetwork !== network) break;
    }
    if (targetNetwork === null) {
      targetNetwork = new Set(nodes);
      this.networks.add(targetNetwork);
    } else {
      for (const node of nodes) {
        targetNetwork.add(node);
      }
    }
  }
  isConnected(nodes) {
    if (nodes.length < 2) return true;
    for (const network of this.networks) {
      if (nodes.every((node) => network.has(node))) {
        return true;
      }
    }
    return false;
  }
};

// lib/check-copper-to-board-edge-clearance.ts
var GEOMETRY_EPSILON = 1e-9;
var getCopperElementLabel = (element) => {
  if (element.type === "pcb_via") return "Via";
  if (element.type === "pcb_smtpad") return "SMT pad";
  if (element.type === "pcb_plated_hole") return "Plated hole";
  return "Copper pour";
};
function checkCopperToBoardEdgeClearance(circuitJson) {
  const board = getPcbBoard(circuitJson);
  if (!board) return [];
  if (!circuitJson.some(
    (element) => element.type === "pcb_via" || element.type === "pcb_smtpad" || element.type === "pcb_plated_hole" || element.type === "pcb_copper_pour"
  ))
    return [];
  const boardPolygon = convertCircuitJsonToFlattenJs([board], { strict: true }).elements[0]?.shapes[0];
  if (!boardPolygon) return [];
  const requiredClearance = getBoardDrcValue(board, "min_board_edge_clearance") ?? jlcMinTolerances.min_board_edge_clearance;
  if (requiredClearance === void 0) return [];
  const allowedOffBoardComponentIds = new Set(
    circuitJson.filter(
      (element) => element.type === "pcb_component"
    ).filter((component) => component.is_allowed_to_be_off_board).map((component) => component.pcb_component_id)
  );
  const { elements: copperElements } = convertCircuitJsonToFlattenJs(
    circuitJson,
    {
      elementTypes: [
        "pcb_via",
        "pcb_smtpad",
        "pcb_plated_hole",
        "pcb_copper_pour"
      ],
      includeDrillHoles: false,
      strict: true
    }
  );
  const errors = [];
  const seen = /* @__PURE__ */ new Set();
  for (const geometry of copperElements) {
    if (seen.has(geometry.elementId)) continue;
    seen.add(geometry.elementId);
    const element = geometry.sourceElement;
    if ((element.type === "pcb_smtpad" || element.type === "pcb_plated_hole") && element.pcb_component_id && allowedOffBoardComponentIds.has(element.pcb_component_id)) {
      continue;
    }
    const isInside = geometry.shapes.every(
      (shape) => boardPolygon.contains(shape)
    );
    const clearance = isInside ? Math.min(
      ...geometry.shapes.map((shape) => boardPolygon.distanceTo(shape)[0])
    ) : 0;
    if (isInside && clearance + GEOMETRY_EPSILON >= requiredClearance) {
      continue;
    }
    const id = geometry.elementId;
    const label = getCopperElementLabel(element);
    errors.push({
      type: "pcb_placement_error",
      pcb_placement_error_id: `copper_too_close_to_board_edge_${id}`,
      error_type: "pcb_placement_error",
      message: `${label} ${getReadableNameForElementId(circuitJson, id)} violates copper-to-board-edge clearance (measured ${clearance.toFixed(3)}mm, required ${requiredClearance.toFixed(3)}mm)`
    });
  }
  return errors;
}

// lib/check-pcb-components-out-of-board/checkViasOffBoard.ts
function checkViasOffBoard(circuitJson) {
  const vias = circuitJson.filter((element) => element.type === "pcb_via");
  const violationsById = new Map(
    checkCopperToBoardEdgeClearance(
      circuitJson.filter(
        (element) => element.type === "pcb_board" || element.type === "pcb_via"
      )
    ).map((error) => [
      error.pcb_placement_error_id.replace(
        "copper_too_close_to_board_edge_",
        ""
      ),
      error
    ])
  );
  return vias.flatMap((via) => {
    const violation = violationsById.get(via.pcb_via_id);
    if (!violation) return [];
    const viaName = getReadableNameForElementId(circuitJson, via.pcb_via_id);
    return [
      {
        ...violation,
        pcb_placement_error_id: `out_of_board_${via.pcb_via_id}`,
        message: `Via ${viaName} is outside or crossing the board boundary`
      }
    ];
  });
}

// lib/check-copper-to-cutout-clearance.ts
import { Relations } from "@flatten-js/core";
import { getPrimaryId as getPrimaryId5 } from "@tscircuit/circuit-json-util";

// lib/util/get-conservative-cutout-clearance-bounds.ts
import { Box as Box4 } from "@flatten-js/core";
function encloseCopperPoints(points) {
  if (points.length === 0 || points.some(
    (point2) => !Number.isFinite(point2.x) || !Number.isFinite(point2.y) || !Number.isFinite(point2.radius) || point2.radius <= 0
  ))
    return void 0;
  const radius = points.reduce(
    (largest, point2) => Math.max(largest, point2.radius),
    0
  );
  let bounds;
  for (const point2 of points) {
    const pointBounds = new Box4(
      point2.x - radius,
      point2.y - radius,
      point2.x + radius,
      point2.y + radius
    );
    bounds = bounds ? bounds.merge(pointBounds) : pointBounds;
  }
  return bounds && [bounds.xmin, bounds.ymin, bounds.xmax, bounds.ymax].every(Number.isFinite) ? bounds : void 0;
}
function getConservativeCutoutClearanceBounds(element, circuitJson) {
  const envelope = convertCircuitJsonElementToFlattenJs(element, {
    circuitJson,
    includeDrillHoles: false
  }).bounds;
  if (envelope) return envelope;
  if (element.type === "pcb_cutout" && element.shape === "path") {
    if (element.slot_corner_radius !== void 0) return void 0;
    return convertCircuitJsonElementToFlattenJs(
      {
        ...element,
        slot_length: void 0,
        space_between_slots: void 0
      },
      { circuitJson }
    ).bounds;
  }
  if (element.type === "pcb_trace") {
    const points = element.route.flatMap((point2) => {
      if (point2.route_type === "through_pad") {
        return [point2.start, point2.end].map((endpoint) => ({
          ...endpoint,
          radius: point2.width / 2
        }));
      }
      return [
        {
          x: point2.x,
          y: point2.y,
          radius: point2.route_type === "via" ? (point2.outer_diameter ?? NaN) / 2 : Math.max(
            point2.width,
            point2.start_width ?? 0,
            point2.end_width ?? 0
          ) / 2
        }
      ];
    });
    return encloseCopperPoints(points);
  }
  return void 0;
}

// lib/check-copper-to-cutout-clearance.ts
function checkCopperToCutoutClearance(circuitJson, {
  elementTypes = [
    "pcb_trace",
    "pcb_via",
    "pcb_smtpad",
    "pcb_plated_hole",
    "pcb_copper_pour"
  ]
} = {}) {
  if (!circuitJson.some((element) => element.type === "pcb_cutout")) return [];
  if (!circuitJson.some(
    (element) => elementTypes.some((type) => type === element.type)
  ))
    return [];
  const requiredClearance = getBoardDrcValue(getPcbBoard(circuitJson), "min_board_edge_clearance") ?? jlcMinTolerances.min_board_edge_clearance ?? 0;
  const { elements, warnings } = convertCircuitJsonToFlattenJs(circuitJson, {
    elementTypes: [...elementTypes, "pcb_cutout"]
  });
  const cutouts = elements.filter((element) => element.role === "cutout");
  const copper = elements.filter((element) => element.role === "copper");
  const unconverted = warnings.map((warning) => {
    const element = circuitJson.find(
      (candidate) => getPrimaryId5(candidate) === warning.elementId
    );
    return {
      warning,
      bounds: element ? getConservativeCutoutClearanceBounds(element, circuitJson) : void 0
    };
  });
  const cutoutBounds = [
    ...cutouts.map((cutout) => cutout.bounds),
    ...unconverted.filter(({ warning }) => warning.elementType === "pcb_cutout").map(({ bounds }) => bounds)
  ];
  const copperBounds = [
    ...copper.map((geometry) => geometry.bounds),
    ...unconverted.filter(({ warning }) => warning.elementType !== "pcb_cutout").map(({ bounds }) => bounds)
  ];
  const relevantWarnings = unconverted.filter(({ warning, bounds }) => {
    const counterparts = warning.elementType === "pcb_cutout" ? copperBounds : cutoutBounds;
    return counterparts.some(
      (counterpart) => !bounds || !counterpart || bounds.clone().extend(requiredClearance).intersect(counterpart)
    );
  });
  const errors = relevantWarnings.map(({ warning }) => ({
    type: "pcb_placement_error",
    error_type: "pcb_placement_error",
    pcb_placement_error_id: `unverified_cutout_clearance_${warning.elementId}`,
    message: `Cannot verify copper-to-cutout clearance for ${getReadableNameForElementId(circuitJson, warning.elementId)} because its PCB geometry is unsupported or invalid`
  }));
  for (const cutout of cutouts) {
    const reportedCopperIds = /* @__PURE__ */ new Set();
    const clearanceBounds = cutout.bounds.clone().extend(requiredClearance);
    for (const copperGeometry of copper) {
      if (reportedCopperIds.has(copperGeometry.elementId)) continue;
      if (!copperGeometry.bounds.intersect(clearanceBounds)) continue;
      let clearance = Infinity;
      let intersects = false;
      let center = copperGeometry.bounds.center;
      for (const copperPolygon of copperGeometry.shapes) {
        for (const cutoutPolygon of cutout.shapes) {
          const overlaps = Relations.intersect(copperPolygon, cutoutPolygon);
          const [distance6, shortestSegment] = copperPolygon.distanceTo(cutoutPolygon);
          const measuredClearance = overlaps ? 0 : distance6;
          intersects ||= overlaps;
          if (measuredClearance < clearance) {
            clearance = measuredClearance;
            center = overlaps ? copperPolygon.intersect(cutoutPolygon)[0] ?? copperPolygon.box.center : shortestSegment.middle();
          }
        }
      }
      if (!intersects && clearance + 1e-9 >= requiredClearance) continue;
      reportedCopperIds.add(copperGeometry.elementId);
      const error = {
        type: "pcb_placement_error",
        error_type: "pcb_placement_error",
        pcb_placement_error_id: `copper_to_cutout_${copperGeometry.elementId}_${cutout.elementId}`,
        pcb_cutout_id: cutout.elementId,
        pcb_element_id: copperGeometry.elementId,
        actual_clearance: clearance,
        minimum_clearance: requiredClearance,
        center: { x: center.x, y: center.y },
        message: `Copper for ${getReadableNameForElementId(circuitJson, copperGeometry.elementId)} violates clearance to cutout ${getReadableNameForElementId(circuitJson, cutout.elementId)} (measured ${clearance.toFixed(3)}mm, required ${requiredClearance.toFixed(3)}mm)`,
        ..."subcircuit_id" in copperGeometry.sourceElement ? { subcircuit_id: copperGeometry.sourceElement.subcircuit_id } : {}
      };
      errors.push(error);
    }
  }
  return errors;
}

// lib/util/get-board-owner-resolver.ts
function getBoardOwnerResolver(circuitJson) {
  const boardsBySubcircuit = new Map(
    circuitJson.flatMap(
      (element) => element.type === "pcb_board" && element.subcircuit_id ? [[element.subcircuit_id, element.pcb_board_id]] : []
    )
  );
  const parentSubcircuits = new Map(
    circuitJson.flatMap(
      (element) => element.type === "source_group" && element.is_subcircuit && element.subcircuit_id ? [[element.subcircuit_id, element.parent_subcircuit_id]] : []
    )
  );
  const components = new Map(
    circuitJson.flatMap(
      (element) => element.type === "pcb_component" ? [[element.pcb_component_id, element]] : []
    )
  );
  return (element) => {
    if ("pcb_board_id" in element && element.pcb_board_id)
      return element.pcb_board_id;
    if ("positioned_relative_to_pcb_board_id" in element && element.positioned_relative_to_pcb_board_id)
      return element.positioned_relative_to_pcb_board_id;
    const component = "pcb_component_id" in element && element.pcb_component_id ? components.get(element.pcb_component_id) : void 0;
    if (component?.positioned_relative_to_pcb_board_id)
      return component.positioned_relative_to_pcb_board_id;
    let subcircuitId = ("subcircuit_id" in element ? element.subcircuit_id : void 0) ?? component?.subcircuit_id;
    const visited = /* @__PURE__ */ new Set();
    while (subcircuitId && !visited.has(subcircuitId)) {
      const boardId = boardsBySubcircuit.get(subcircuitId);
      if (boardId) return boardId;
      visited.add(subcircuitId);
      subcircuitId = parentSubcircuits.get(subcircuitId);
    }
  };
}

// lib/check-pcb-components-out-of-board/checkPcbComponentsOutOfBoard.ts
import * as Flatten3 from "@flatten-js/core";
import { rotateDEG, applyToPoint } from "transformation-matrix";
function isPolygonCCW(poly) {
  return poly.area() >= 0;
}
function rectanglePolygon({
  center,
  size,
  rotationDeg = 0
}) {
  const cx = center.x;
  const cy = center.y;
  const hw = size.width / 2;
  const hh = size.height / 2;
  const corners = [
    new Flatten3.Point(cx - hw, cy - hh),
    new Flatten3.Point(cx + hw, cy - hh),
    new Flatten3.Point(cx + hw, cy + hh),
    new Flatten3.Point(cx - hw, cy + hh)
  ];
  let poly = new Flatten3.Polygon(corners);
  if (rotationDeg) {
    const matrix = rotateDEG(rotationDeg, cx, cy);
    const rotatedCorners = corners.map((pt2) => {
      const p = applyToPoint(matrix, { x: pt2.x, y: pt2.y });
      return new Flatten3.Point(p.x, p.y);
    });
    poly = new Flatten3.Polygon(rotatedCorners);
  }
  if (!isPolygonCCW(poly)) poly.reverse();
  return poly;
}
function boardToPolygon({
  board
}) {
  if (board.outline && board.outline.length > 0) {
    const points = board.outline.map((p) => new Flatten3.Point(p.x, p.y));
    const poly = new Flatten3.Polygon(points);
    if (!isPolygonCCW(poly)) {
      poly.reverse();
    }
    return poly;
  }
  if (board.center && typeof board.width === "number" && typeof board.height === "number") {
    return rectanglePolygon({
      center: board.center,
      size: { width: board.width, height: board.height },
      rotationDeg: 0
    });
  }
  return null;
}
function getComponentName({
  circuitJson,
  component
}) {
  if (component.source_component_id) {
    const sourceComponent = circuitJson.find(
      (el) => el.type === "source_component" && el.source_component_id === component.source_component_id
    );
    if (sourceComponent && "name" in sourceComponent && sourceComponent.name) {
      return sourceComponent.name;
    }
  }
  return getReadableNameForComponent(circuitJson, component.pcb_component_id);
}
function computeOverlapDistance(componentPoly, boardPoly) {
  const edges = [...componentPoly.edges];
  const boundary = edges[0]?.shape;
  if (edges.length === 1 && boundary instanceof Flatten3.Arc && Flatten3.Utils.EQ(boundary.sweep, 2 * Math.PI)) {
    const [distance6] = boardPoly.distanceTo(boundary.pc);
    return boardPoly.contains(boundary.pc) ? boundary.r - distance6 : boundary.r + distance6;
  }
  let maxDistance = 0;
  for (const edge of edges) {
    const samples = edge.shape instanceof Flatten3.Arc ? Math.ceil(edge.shape.sweep / (Math.PI / 32)) : 2;
    for (let i = 0; i <= samples; i++) {
      const point2 = edge.pointAtLength(edge.length * i / samples);
      if (!boardPoly.contains(point2)) {
        maxDistance = Math.max(maxDistance, boardPoly.distanceTo(point2)[0]);
      }
    }
  }
  return maxDistance || 0.1;
}
function getRepositionSuggestion({
  componentBox,
  boardPoly
}) {
  const boardBox = boardPoly.box;
  let deltaX = 0;
  let deltaY = 0;
  if (componentBox.xmin < boardBox.xmin) {
    deltaX = boardBox.xmin - componentBox.xmin;
  } else if (componentBox.xmax > boardBox.xmax) {
    deltaX = boardBox.xmax - componentBox.xmax;
  }
  if (componentBox.ymin < boardBox.ymin) {
    deltaY = boardBox.ymin - componentBox.ymin;
  } else if (componentBox.ymax > boardBox.ymax) {
    deltaY = boardBox.ymax - componentBox.ymax;
  }
  if (deltaX === 0 && deltaY === 0) {
    return null;
  }
  const xDir = deltaX >= 0 ? "right" : "left";
  const yDir = deltaY >= 0 ? "up" : "down";
  const absDx = Math.abs(Math.round(deltaX * 100) / 100);
  const absDy = Math.abs(Math.round(deltaY * 100) / 100);
  if (absDx > 0 && absDy > 0) {
    return `Try moving it ${absDx}mm ${xDir} and ${absDy}mm ${yDir} to fit within the board edge.`;
  }
  if (absDx > 0) {
    return `Try moving it ${absDx}mm ${xDir} to fit within the board edge.`;
  }
  return `Try moving it ${absDy}mm ${yDir} to fit within the board edge.`;
}
function checkPcbComponentsOutOfBoard(circuitJson) {
  const boards = circuitJson.filter(
    (el) => el.type === "pcb_board"
  );
  if (boards.length === 0) return [];
  const boardsById = new Map(boards.map((board) => [board.pcb_board_id, board]));
  const boardPolygons = /* @__PURE__ */ new Map();
  const getBoardOwner = getBoardOwnerResolver(circuitJson);
  const components = circuitJson.filter(
    (el) => el.type === "pcb_component"
  );
  if (components.length === 0) return [];
  const footprintGeometry = convertCircuitJsonToFlattenJs(circuitJson, {
    elementTypes: [
      "pcb_smtpad",
      "pcb_plated_hole",
      "pcb_hole",
      "pcb_courtyard_circle",
      "pcb_courtyard_rect",
      "pcb_courtyard_pill",
      "pcb_courtyard_polygon",
      "pcb_courtyard_outline"
    ],
    includeDrillHoles: false,
    strict: true
  }).elements;
  const errors = [];
  for (const c of components) {
    if (c.is_allowed_to_be_off_board) continue;
    const boardId = getBoardOwner(c);
    const board = boardId ? boardsById.get(boardId) : boards.length === 1 ? boards[0] : void 0;
    if (!board) continue;
    if (!boardPolygons.has(board.pcb_board_id)) {
      boardPolygons.set(board.pcb_board_id, boardToPolygon({ board }));
    }
    const boardPoly = boardPolygons.get(board.pcb_board_id);
    if (!boardPoly) continue;
    if (!c.center || typeof c.width !== "number" || typeof c.height !== "number")
      continue;
    if (c.width <= 0 || c.height <= 0) continue;
    const componentRect = rectanglePolygon({
      center: c.center,
      size: { width: c.width, height: c.height },
      rotationDeg: 0
    });
    const componentGeometry = footprintGeometry.filter(
      ({ sourceElement }) => "pcb_component_id" in sourceElement && sourceElement.pcb_component_id === c.pcb_component_id
    );
    const physicalBounds = componentGeometry.filter(({ role }) => role !== "courtyard").reduce(
      (bounds, geometry) => bounds ? bounds.merge(geometry.bounds) : geometry.bounds,
      void 0
    );
    const componentPolygons = componentGeometry.flatMap(({ shapes }) => shapes);
    if (!physicalBounds || !Flatten3.Utils.EQ(physicalBounds.xmin, componentRect.box.xmin) || !Flatten3.Utils.EQ(physicalBounds.xmax, componentRect.box.xmax) || !Flatten3.Utils.EQ(physicalBounds.ymin, componentRect.box.ymin) || !Flatten3.Utils.EQ(physicalBounds.ymax, componentRect.box.ymax)) {
      componentPolygons.push(componentRect);
    }
    const outsidePolygons = componentPolygons.filter(
      (polygon) => polygon.area() > 0 && !boardPoly.contains(polygon)
    );
    if (outsidePolygons.length === 0) continue;
    const componentBox = componentPolygons.reduce(
      (bounds, polygon) => bounds.merge(polygon.box),
      componentPolygons[0].box
    );
    const overlapDistance = Math.max(
      ...outsidePolygons.map(
        (polygon) => computeOverlapDistance(polygon, boardPoly)
      )
    );
    const compName = getComponentName({ circuitJson, component: c });
    const overlapDistanceMm = Math.round(overlapDistance * 100) / 100;
    const repositionSuggestion = getRepositionSuggestion({
      componentBox,
      boardPoly
    });
    errors.push({
      type: "pcb_component_outside_board_error",
      error_type: "pcb_component_outside_board_error",
      pcb_component_outside_board_error_id: `pcb_component_outside_board_${c.pcb_component_id}`,
      message: `Component ${compName} extends outside board boundaries by ${overlapDistanceMm}mm.${repositionSuggestion ? ` ${repositionSuggestion}` : ""}`,
      pcb_component_id: c.pcb_component_id,
      pcb_board_id: board.pcb_board_id,
      component_center: c.center,
      component_bounds: {
        min_x: componentBox.xmin,
        max_x: componentBox.xmax,
        min_y: componentBox.ymin,
        max_y: componentBox.ymax
      },
      subcircuit_id: c.subcircuit_id,
      source_component_id: c.source_component_id
    });
  }
  return errors;
}

// lib/check-pcb-component-over-cutout.ts
import { doBoundsOverlap } from "@tscircuit/math-utils";
import * as Flatten4 from "@flatten-js/core";
import { applyToPoint as applyToPoint2, rotateDEG as rotateDEG2 } from "transformation-matrix";
var CUTOUT_CIRCLE_SEGMENTS = 32;
function rectanglePolygon2({
  center,
  width,
  height,
  rotation = 0
}) {
  const halfWidth = width / 2;
  const halfHeight = height / 2;
  const corners = [
    { x: center.x - halfWidth, y: center.y - halfHeight },
    { x: center.x + halfWidth, y: center.y - halfHeight },
    { x: center.x + halfWidth, y: center.y + halfHeight },
    { x: center.x - halfWidth, y: center.y + halfHeight }
  ];
  const matrix = rotateDEG2(rotation, center.x, center.y);
  return new Flatten4.Polygon(
    corners.map((corner) => {
      const rotated = rotation ? applyToPoint2(matrix, corner) : corner;
      return new Flatten4.Point(rotated.x, rotated.y);
    })
  );
}
function circlePolygon2({
  center,
  radius
}) {
  return new Flatten4.Polygon(
    Array.from({ length: CUTOUT_CIRCLE_SEGMENTS }, (_, index) => {
      const angle = 2 * Math.PI * index / CUTOUT_CIRCLE_SEGMENTS;
      return new Flatten4.Point(
        center.x + Math.cos(angle) * radius,
        center.y + Math.sin(angle) * radius
      );
    })
  );
}
function cutoutToPolygon(cutout) {
  if (cutout.shape === "rect") {
    return rectanglePolygon2({
      center: cutout.center,
      width: cutout.width,
      height: cutout.height,
      rotation: cutout.rotation ?? 0
    });
  }
  if (cutout.shape === "circle") {
    return circlePolygon2({ center: cutout.center, radius: cutout.radius });
  }
  if (cutout.shape === "polygon") {
    return new Flatten4.Polygon(
      cutout.points.map((point2) => new Flatten4.Point(point2.x, point2.y))
    );
  }
  return null;
}
function polygonBoxToBounds(polygon) {
  return {
    minX: polygon.box.xmin,
    minY: polygon.box.ymin,
    maxX: polygon.box.xmax,
    maxY: polygon.box.ymax
  };
}
function doPolygonsOverlap(polygonA, polygonB) {
  if (!doBoundsOverlap(polygonBoxToBounds(polygonA), polygonBoxToBounds(polygonB))) {
    return false;
  }
  if (polygonA.contains(polygonB) || polygonB.contains(polygonA)) return true;
  try {
    const intersections = Flatten4.BooleanOperations.intersect(
      polygonA,
      polygonB
    );
    if (Array.isArray(intersections)) {
      return intersections.some((polygon) => polygon.area() > 0);
    }
    return intersections.area() > 0;
  } catch {
    return false;
  }
}
function checkPcbComponentOverCutout(circuitJson) {
  const cutouts = circuitJson.filter(
    (element) => element.type === "pcb_cutout"
  );
  const components = circuitJson.filter(
    (element) => element.type === "pcb_component"
  );
  if (cutouts.length === 0 || components.length === 0) return [];
  const cutoutPolygons = cutouts.map((cutout) => ({ cutout, polygon: cutoutToPolygon(cutout) })).filter(
    (entry) => entry.polygon !== null && entry.polygon.area() > 0
  );
  const errors = [];
  for (const component of components) {
    if (component.do_not_place) continue;
    if (!component.center || component.width <= 0 || component.height <= 0) {
      continue;
    }
    const componentPolygon = rectanglePolygon2({
      center: component.center,
      width: component.width,
      height: component.height
    });
    for (const { cutout, polygon: cutoutPolygon } of cutoutPolygons) {
      if (cutout.pcb_component_id === component.pcb_component_id) continue;
      if (!doPolygonsOverlap(componentPolygon, cutoutPolygon)) continue;
      const componentName = getReadableNameForComponent(
        circuitJson,
        component.pcb_component_id
      );
      const cutoutId = cutout.pcb_cutout_id;
      errors.push({
        type: "pcb_placement_error",
        pcb_placement_error_id: `component_over_cutout_${component.pcb_component_id}_${cutoutId}`,
        error_type: "pcb_placement_error",
        message: `Component ${componentName} overlaps with cutout [${getReadableNameForElementId(circuitJson, cutoutId)}]`,
        subcircuit_id: component.subcircuit_id
      });
    }
  }
  return errors;
}

// lib/util/courtyard-to-keepout.ts
var getCourtyardId = (courtyard) => {
  switch (courtyard.type) {
    case "pcb_courtyard_circle":
      return courtyard.pcb_courtyard_circle_id;
    case "pcb_courtyard_outline":
      return courtyard.pcb_courtyard_outline_id;
    case "pcb_courtyard_polygon":
      return courtyard.pcb_courtyard_polygon_id;
    case "pcb_courtyard_rect":
      return courtyard.pcb_courtyard_rect_id;
  }
};
var courtyardToKeepout = (courtyard) => {
  const common = {
    type: "pcb_keepout",
    pcb_keepout_id: getCourtyardId(courtyard),
    layers: [courtyard.layer]
  };
  if (courtyard.type === "pcb_courtyard_circle") {
    return {
      ...common,
      shape: "circle",
      center: courtyard.center,
      radius: courtyard.radius
    };
  }
  const outline = courtyard.type === "pcb_courtyard_rect" ? getRotatedRectPoints({
    x: courtyard.center.x,
    y: courtyard.center.y,
    width: courtyard.width,
    height: courtyard.height,
    ccwRotation: courtyard.ccw_rotation ?? 0
  }) : courtyard.type === "pcb_courtyard_polygon" ? courtyard.points : courtyard.outline;
  return {
    ...common,
    shape: "outline",
    outline,
    stroke_width: 0
  };
};

// lib/check-pcb-courtyard-over-keepout.ts
function checkPcbCourtyardOverKeepout(circuitJson) {
  const keepouts = circuitJson.filter(
    (el) => el.type === "pcb_keepout" && !el.allow_placements
  );
  const components = new Map(
    circuitJson.flatMap(
      (el) => el.type === "pcb_component" ? [[el.pcb_component_id, el]] : []
    )
  );
  const courtyards = circuitJson.filter(
    (el) => el.type === "pcb_courtyard_rect" || el.type === "pcb_courtyard_circle" || el.type === "pcb_courtyard_outline" || el.type === "pcb_courtyard_polygon"
  );
  const errors = /* @__PURE__ */ new Map();
  for (const courtyard of courtyards) {
    const componentId = courtyard.pcb_component_id;
    const component = components.get(componentId);
    if (component?.do_not_place) continue;
    const geometry = courtyardToKeepout(courtyard);
    for (const keepout of keepouts) {
      if (!keepout.layers.includes(courtyard.layer)) continue;
      if (keepout.excluded_pcb_component_ids?.includes(componentId)) continue;
      const id = `courtyard_over_keepout_${componentId}_${keepout.pcb_keepout_id}`;
      if (errors.has(id)) continue;
      if (getPadToPadGap(geometry, keepout) > EPSILON) continue;
      const name = getReadableNameForElementId(circuitJson, componentId);
      const description = getReadableNameForElementId(
        circuitJson,
        keepout.pcb_keepout_id
      );
      const subcircuit_id = component?.subcircuit_id ?? keepout.subcircuit_id;
      if (keepout.warning_only) {
        errors.set(id, {
          type: "pcb_keepout_overlap_warning",
          warning_type: "pcb_keepout_overlap_warning",
          pcb_keepout_overlap_warning_id: `pcb_keepout_overlap_warning_${id}`,
          pcb_keepout_id: keepout.pcb_keepout_id,
          pcb_component_ids: [componentId],
          message: `Courtyard of ${name} overlaps advisory PCB keepout "${description}"`,
          subcircuit_id
        });
      } else {
        errors.set(id, {
          type: "pcb_placement_error",
          error_type: "pcb_placement_error",
          pcb_placement_error_id: id,
          message: `Courtyard of ${name} overlaps PCB keepout "${description}"`,
          subcircuit_id
        });
      }
    }
  }
  return [...errors.values()];
}

// lib/check-pcb-copper-over-keepout.ts
import { cju as cju4, getPrimaryId as getPrimaryId6 } from "@tscircuit/circuit-json-util";
var getErrorOwnerId = (copper) => "pcb_component_id" in copper && copper.pcb_component_id ? copper.pcb_component_id : getPrimaryId6(copper);
var getReadableCopperName = (circuitJson, copper) => {
  if ("pcb_component_id" in copper && copper.pcb_component_id) {
    const pcbComponent = circuitJson.find(
      (element) => element.type === "pcb_component" && element.pcb_component_id === copper.pcb_component_id
    );
    const sourceComponent = pcbComponent?.type === "pcb_component" ? circuitJson.find(
      (element) => element.type === "source_component" && element.source_component_id === pcbComponent.source_component_id
    ) : void 0;
    const componentName = sourceComponent?.type === "source_component" && sourceComponent.name ? sourceComponent.name : getReadableNameForComponent(circuitJson, copper.pcb_component_id);
    return `component ${componentName}`;
  }
  return copper.type === "pcb_via" ? `via ${getReadableNameForElementId(circuitJson, copper.pcb_via_id)}` : getReadableNameForElementId(circuitJson, getPrimaryId6(copper));
};
function checkPcbCopperOverKeepout(circuitJson) {
  const keepouts = cju4(circuitJson).pcb_keepout.list();
  if (keepouts.length === 0) return [];
  const copper = [
    ...getPads(circuitJson),
    ...cju4(circuitJson).pcb_via.list()
  ];
  const errors = /* @__PURE__ */ new Map();
  for (const keepout of keepouts) {
    const excludedComponentIds = new Set(
      keepout.excluded_pcb_component_ids ?? []
    );
    for (const copperElement of copper) {
      if (keepout.allow_placements && copperElement.type !== "pcb_via") continue;
      const copperComponentId = "pcb_component_id" in copperElement ? copperElement.pcb_component_id : void 0;
      if (copperComponentId && excludedComponentIds.has(copperComponentId)) {
        continue;
      }
      const copperLayers = getLayersOfPcbElement(copperElement);
      if (!copperLayers.some((layer) => keepout.layers.includes(layer))) {
        continue;
      }
      if (getPadToPadGap(copperElement, keepout) > EPSILON) continue;
      const ownerId = getErrorOwnerId(copperElement);
      const errorId = `copper_over_keepout_${ownerId}_${keepout.pcb_keepout_id}`;
      if (keepout.warning_only) {
        const copperIdField = copperElement.type === "pcb_smtpad" ? "pcb_smtpad_ids" : copperElement.type === "pcb_plated_hole" ? "pcb_plated_hole_ids" : "pcb_via_ids";
        const existing = errors.get(errorId);
        if (existing?.type === "pcb_keepout_overlap_warning") {
          existing[copperIdField] = Array.from(
            /* @__PURE__ */ new Set([
              ...existing[copperIdField] ?? [],
              getPrimaryId6(copperElement)
            ])
          );
        } else {
          errors.set(errorId, {
            type: "pcb_keepout_overlap_warning",
            warning_type: "pcb_keepout_overlap_warning",
            pcb_keepout_overlap_warning_id: `pcb_keepout_overlap_warning_${errorId}`,
            pcb_keepout_id: keepout.pcb_keepout_id,
            message: `Copper for ${getReadableCopperName(circuitJson, copperElement)} overlaps advisory PCB keepout "${getReadableNameForElementId(circuitJson, keepout.pcb_keepout_id)}"`,
            ...copperComponentId ? { pcb_component_ids: [copperComponentId] } : {},
            [copperIdField]: [getPrimaryId6(copperElement)],
            subcircuit_id: copperElement.subcircuit_id ?? keepout.subcircuit_id
          });
        }
        continue;
      }
      if (errors.has(errorId)) continue;
      errors.set(errorId, {
        type: "pcb_placement_error",
        pcb_placement_error_id: errorId,
        error_type: "pcb_placement_error",
        message: `Copper for ${getReadableCopperName(
          circuitJson,
          copperElement
        )} overlaps ${keepout.description ? `PCB keepout "${keepout.description}"` : "a PCB keepout"}`,
        subcircuit_id: copperElement.subcircuit_id ?? keepout.subcircuit_id
      });
    }
  }
  return [...errors.values()];
}

// lib/check-pcb-bend-zones.ts
import { getPrimaryId as getPrimaryId7 } from "@tscircuit/circuit-json-util";
var GEOMETRY_EPSILON2 = 1e-9;
function getBendZones(circuitJson) {
  const boards = new Map(
    circuitJson.filter((element) => element.type === "pcb_board").map((board) => [board.pcb_board_id, board])
  );
  return circuitJson.flatMap((bend) => {
    if (bend.type !== "pcb_bend") return [];
    const board = boards.get(bend.pcb_board_id);
    if (!board) return [];
    const dx = bend.end.x - bend.start.x;
    const dy = bend.end.y - bend.start.y;
    const length = Math.hypot(dx, dy);
    const width = bend.bend_radius * Math.abs(bend.bend_angle * Math.PI / 180);
    if (!Number.isFinite(length) || !Number.isFinite(width) || length <= GEOMETRY_EPSILON2 || width <= GEOMETRY_EPSILON2)
      return [];
    const tangent = { x: dx / length, y: dy / length };
    const offset = { x: -tangent.y * width / 2, y: tangent.x * width / 2 };
    const start = {
      x: board.center.x + bend.start.x,
      y: board.center.y + bend.start.y
    };
    const end = {
      x: board.center.x + bend.end.x,
      y: board.center.y + bend.end.y
    };
    const outline = [
      { x: start.x + offset.x, y: start.y + offset.y },
      { x: end.x + offset.x, y: end.y + offset.y },
      { x: end.x - offset.x, y: end.y - offset.y },
      { x: start.x - offset.x, y: start.y - offset.y }
    ];
    const keepout = {
      type: "pcb_keepout",
      pcb_keepout_id: bend.pcb_bend_id,
      shape: "outline",
      outline,
      stroke_width: 0,
      layers: ["top", "bottom"]
    };
    return [{ bend, board, tangent, keepout }];
  });
}
function getStiffenerOutline(stiffener, board) {
  const points = stiffener.shape === "polygon" ? stiffener.outline : getRotatedRectPoints({
    x: stiffener.center.x,
    y: stiffener.center.y,
    width: stiffener.width,
    height: stiffener.height,
    ccwRotation: stiffener.rotation ?? 0
  });
  return points.map((point2) => ({
    x: point2.x + board.center.x,
    y: point2.y + board.center.y
  }));
}
function checkPcbBendZonePlacement(circuitJson) {
  const zones = getBendZones(circuitJson);
  if (zones.length === 0) return [];
  const getBoardOwner = getBoardOwnerResolver(circuitJson);
  const copper = [
    ...getPads(circuitJson),
    ...circuitJson.filter((element) => element.type === "pcb_via")
  ].map((element) => ({ element, boardId: getBoardOwner(element) }));
  for (const trace of circuitJson) {
    if (trace.type !== "pcb_trace") continue;
    const boardId = getBoardOwner(trace);
    for (const [index, point2] of trace.route.entries()) {
      if (point2.route_type !== "via") continue;
      const outerDiameter = point2.outer_diameter ?? point2.hole_diameter ?? 0;
      const alreadyMaterialized = copper.some(
        ({ element: element2, boardId: viaBoardId }) => element2.type === "pcb_via" && !(boardId && viaBoardId && boardId !== viaBoardId) && Math.hypot(element2.x - point2.x, element2.y - point2.y) <= GEOMETRY_EPSILON2 && element2.layers.includes(point2.from_layer) && element2.layers.includes(point2.to_layer) && (point2.outer_diameter === void 0 || Math.abs(element2.outer_diameter - outerDiameter) <= GEOMETRY_EPSILON2) && (point2.hole_diameter === void 0 || Math.abs(element2.hole_diameter - point2.hole_diameter) <= GEOMETRY_EPSILON2)
      );
      if (alreadyMaterialized) continue;
      const element = {
        type: "pcb_via",
        pcb_via_id: `${trace.pcb_trace_id}_route_via_${index}`,
        pcb_trace_id: trace.pcb_trace_id,
        x: point2.x,
        y: point2.y,
        outer_diameter: outerDiameter,
        hole_diameter: point2.hole_diameter ?? 0,
        layers: [point2.from_layer, point2.to_layer],
        subcircuit_id: trace.subcircuit_id
      };
      copper.push({ element, boardId });
    }
  }
  const stiffeners = circuitJson.filter(
    (element) => element.type === "pcb_stiffener"
  );
  const errors = [];
  const report = (elementId, bend, subcircuitId) => {
    errors.push({
      type: "pcb_placement_error",
      pcb_placement_error_id: `bend_zone_${bend.pcb_bend_id}_${elementId}`,
      error_type: "pcb_placement_error",
      message: `${getReadableNameForElementId(circuitJson, elementId)} overlaps PCB bend zone ${getReadableNameForElementId(circuitJson, bend.pcb_bend_id)}`,
      subcircuit_id: subcircuitId ?? bend.subcircuit_id
    });
  };
  for (const { bend, board, keepout } of zones) {
    for (const { element, boardId } of copper) {
      if (boardId && boardId !== board.pcb_board_id) continue;
      if (getPadToPadGap(element, keepout) <= GEOMETRY_EPSILON2) {
        report(getPrimaryId7(element), bend, element.subcircuit_id);
      }
    }
    for (const stiffener of stiffeners) {
      if (stiffener.pcb_board_id !== board.pcb_board_id) continue;
      const outline = getStiffenerOutline(stiffener, board);
      if (outline.length < 3) continue;
      if (getPadToPadGap(
        { ...keepout, outline, pcb_keepout_id: stiffener.pcb_stiffener_id },
        keepout
      ) <= GEOMETRY_EPSILON2) {
        report(stiffener.pcb_stiffener_id, bend, stiffener.subcircuit_id);
      }
    }
  }
  return errors;
}
function checkPcbBendZoneTraces(circuitJson) {
  const zones = getBendZones(circuitJson);
  if (zones.length === 0) return [];
  const getBoardOwner = getBoardOwnerResolver(circuitJson);
  const errors = [];
  for (const trace of circuitJson) {
    if (trace.type !== "pcb_trace") continue;
    const boardId = getBoardOwner(trace);
    for (const { bend, tangent, keepout } of zones) {
      if (boardId && boardId !== bend.pcb_board_id) continue;
      let violation;
      for (let i = 1; i < trace.route.length; i++) {
        const a = trace.route[i - 1];
        const b = trace.route[i];
        const wire = a.route_type === "wire" ? a : b.route_type === "wire" ? b : void 0;
        if (!wire) continue;
        const aPoint = a.route_type === "through_pad" ? a.end_layer === wire.layer ? a.end : a.start_layer === wire.layer ? a.start : void 0 : a.route_type === "wire" ? a.layer === wire.layer ? a : void 0 : a.to_layer === wire.layer ? a : void 0;
        const bPoint = b.route_type === "through_pad" ? b.start_layer === wire.layer ? b.start : b.end_layer === wire.layer ? b.end : void 0 : b.route_type === "wire" ? b.layer === wire.layer ? b : void 0 : b.from_layer === wire.layer ? b : void 0;
        if (!aPoint || !bPoint) continue;
        const dx = bPoint.x - aPoint.x;
        const dy = bPoint.y - aPoint.y;
        const length = Math.hypot(dx, dy);
        if (length <= GEOMETRY_EPSILON2) continue;
        const alongBend = Math.abs(dx * tangent.x + dy * tangent.y) / length;
        if (alongBend <= GEOMETRY_EPSILON2) continue;
        const radius = Math.max(wire.width, wire.start_width ?? 0, wire.end_width ?? 0) / 2;
        const clearance = getSegmentToPolygonClearanceFromPoints(
          aPoint,
          bPoint,
          keepout.outline
        );
        if (clearance.distance > radius + GEOMETRY_EPSILON2) continue;
        violation = {
          center: clearance.center,
          reason: "Non-perpendicular trace copper"
        };
        break;
      }
      for (let i = 1; !violation && i < trace.route.length - 1; i++) {
        const point2 = trace.route[i];
        if (point2.route_type !== "wire") continue;
        let previousIndex = i - 1;
        let nextIndex = i + 1;
        while (previousIndex >= 0) {
          const previous2 = trace.route[previousIndex];
          if (previous2.route_type !== "wire" || previous2.layer !== point2.layer || Math.hypot(previous2.x - point2.x, previous2.y - point2.y) > GEOMETRY_EPSILON2)
            break;
          previousIndex--;
        }
        while (nextIndex < trace.route.length) {
          const next2 = trace.route[nextIndex];
          if (next2.route_type !== "wire" || next2.layer !== point2.layer || Math.hypot(next2.x - point2.x, next2.y - point2.y) > GEOMETRY_EPSILON2)
            break;
          nextIndex++;
        }
        const previous = trace.route[previousIndex];
        const next = trace.route[nextIndex];
        if (previous?.route_type !== "wire" || next?.route_type !== "wire" || previous.layer !== point2.layer || next.layer !== point2.layer)
          continue;
        const incoming = { x: point2.x - previous.x, y: point2.y - previous.y };
        const outgoing = { x: next.x - point2.x, y: next.y - point2.y };
        const lengths = Math.hypot(incoming.x, incoming.y) * Math.hypot(outgoing.x, outgoing.y);
        if (lengths <= GEOMETRY_EPSILON2) continue;
        const dot3 = (incoming.x * outgoing.x + incoming.y * outgoing.y) / lengths;
        const cross = (incoming.x * outgoing.y - incoming.y * outgoing.x) / lengths;
        if (dot3 > 0 && Math.abs(cross) <= GEOMETRY_EPSILON2) continue;
        const radius = Math.max(
          previous.width,
          previous.end_width ?? 0,
          point2.width,
          point2.start_width ?? 0
        ) / 2;
        const clearance = getSegmentToPolygonClearanceFromPoints(
          point2,
          point2,
          keepout.outline
        );
        if (clearance.distance > radius + GEOMETRY_EPSILON2) continue;
        violation = { center: point2, reason: "Trace corner" };
      }
      if (!violation) continue;
      errors.push({
        type: "pcb_trace_error",
        pcb_trace_error_id: `bend_zone_${bend.pcb_bend_id}_${trace.pcb_trace_id}`,
        error_type: "pcb_trace_error",
        message: `${violation.reason} for ${getReadableNameForTrace(circuitJson, trace.pcb_trace_id)} overlaps PCB bend zone ${getReadableNameForElementId(circuitJson, bend.pcb_bend_id)}`,
        center: violation.center,
        pcb_trace_id: trace.pcb_trace_id,
        source_trace_id: trace.source_trace_id ?? "",
        pcb_component_ids: trace.pcb_component_id ? [trace.pcb_component_id] : [],
        pcb_port_ids: [],
        subcircuit_id: trace.subcircuit_id ?? bend.subcircuit_id
      });
    }
  }
  return errors;
}

// lib/check-same-net-via-spacing.ts
import {
  getFullConnectivityMapFromCircuitJson as getFullConnectivityMapFromCircuitJson6
} from "circuit-json-to-connectivity-map";

// lib/util/distance.ts
function distance2(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

// lib/util/viasAreAtSameLocation.ts
function viasAreAtSameLocation(a, b) {
  return distance2(a, b) <= EPSILON;
}

// lib/check-same-net-via-spacing.ts
function checkSameNetViaSpacing(circuitJson, {
  connMap,
  minClearance
} = {}) {
  const vias = circuitJson.filter((el) => el.type === "pcb_via");
  if (vias.length < 2) return [];
  const board = getPcbBoard(circuitJson);
  minClearance ??= getBoardDrcValue(board, "min_via_hole_edge_to_via_hole_edge_clearance") ?? jlcMinTolerances.min_via_hole_edge_to_via_hole_edge_clearance;
  connMap ??= getFullConnectivityMapFromCircuitJson6(circuitJson);
  const errors = [];
  const reported = /* @__PURE__ */ new Set();
  for (let i = 0; i < vias.length; i++) {
    for (let j = i + 1; j < vias.length; j++) {
      const viaA = vias[i];
      const viaB = vias[j];
      if (viasAreAtSameLocation(viaA, viaB)) continue;
      if (!connMap.areIdsConnected(viaA.pcb_via_id, viaB.pcb_via_id)) continue;
      const gap = distance2(viaA, viaB) - viaA.hole_diameter / 2 - viaB.hole_diameter / 2;
      if (gap + EPSILON >= minClearance) continue;
      const pairId = [viaA.pcb_via_id, viaB.pcb_via_id].sort().join("_");
      if (reported.has(pairId)) continue;
      reported.add(pairId);
      errors.push({
        type: "pcb_via_clearance_error",
        pcb_error_id: `same_net_vias_close_${pairId}`,
        message: `Vias ${getReadableNameForElementId(
          circuitJson,
          viaA.pcb_via_id
        )} and ${getReadableNameForElementId(
          circuitJson,
          viaB.pcb_via_id
        )} are too close together (gap: ${gap.toFixed(3)}mm)`,
        error_type: "pcb_via_clearance_error",
        pcb_via_ids: [viaA.pcb_via_id, viaB.pcb_via_id],
        minimum_clearance: minClearance,
        actual_clearance: gap,
        pcb_center: {
          x: (viaA.x + viaB.x) / 2,
          y: (viaA.y + viaB.y) / 2
        }
      });
    }
  }
  return errors;
}

// lib/check-different-net-via-spacing.ts
import {
  getFullConnectivityMapFromCircuitJson as getFullConnectivityMapFromCircuitJson7
} from "circuit-json-to-connectivity-map";
function checkDifferentNetViaSpacing(circuitJson, {
  connMap,
  minClearance
} = {}) {
  const vias = circuitJson.filter((el) => el.type === "pcb_via");
  if (vias.length < 2) return [];
  const board = getPcbBoard(circuitJson);
  minClearance ??= getBoardDrcValue(board, "min_via_hole_edge_to_via_hole_edge_clearance") ?? jlcMinTolerances.min_via_hole_edge_to_via_hole_edge_clearance;
  const minCopperClearance = getBoardDrcValue(board, "min_pad_edge_to_pad_edge_clearance") ?? jlcMinTolerances.min_pad_edge_to_pad_edge_clearance;
  connMap ??= getFullConnectivityMapFromCircuitJson7(circuitJson);
  const errors = [];
  const reported = /* @__PURE__ */ new Set();
  for (let i = 0; i < vias.length; i++) {
    for (let j = i + 1; j < vias.length; j++) {
      const viaA = vias[i];
      const viaB = vias[j];
      if (connMap.areIdsConnected(viaA.pcb_via_id, viaB.pcb_via_id)) continue;
      const centerDistance = distance2(viaA, viaB);
      let gap = centerDistance - viaA.hole_diameter / 2 - viaB.hole_diameter / 2;
      let minimumClearance = minClearance;
      if (gap + EPSILON >= minimumClearance) {
        if (!viaA.layers.some((layer) => viaB.layers.includes(layer))) continue;
        gap = centerDistance - viaA.outer_diameter / 2 - viaB.outer_diameter / 2;
        minimumClearance = minCopperClearance;
        if (gap >= 0 && gap + EPSILON >= minimumClearance) continue;
      }
      const pairId = [viaA.pcb_via_id, viaB.pcb_via_id].sort().join("_");
      if (reported.has(pairId)) continue;
      reported.add(pairId);
      errors.push({
        type: "pcb_via_clearance_error",
        pcb_error_id: `different_net_vias_close_${pairId}`,
        message: `Vias ${getReadableNameForElementId(
          circuitJson,
          viaA.pcb_via_id
        )} and ${getReadableNameForElementId(
          circuitJson,
          viaB.pcb_via_id
        )} from different nets are too close together (gap: ${gap.toFixed(
          3
        )}mm)`,
        error_type: "pcb_via_clearance_error",
        pcb_via_ids: [viaA.pcb_via_id, viaB.pcb_via_id],
        minimum_clearance: minimumClearance,
        actual_clearance: gap,
        pcb_center: {
          x: (viaA.x + viaB.x) / 2,
          y: (viaA.y + viaB.y) / 2
        }
      });
    }
  }
  return errors;
}

// lib/util/get-trace-endpoint-neckdown-lengths.ts
import { Point as Point6, Segment as Segment4 } from "@flatten-js/core";
function getTraceEndpointNeckdownLengths(trace, circuitJson, maxEscapeLength) {
  const fromStart = /* @__PURE__ */ new Map();
  const fromEnd = /* @__PURE__ */ new Map();
  for (const reverse of [false, true]) {
    const endpoint = trace.route[reverse ? trace.route.length - 1 : 0];
    if (endpoint?.route_type !== "wire") continue;
    const portId = reverse ? endpoint.end_pcb_port_id : endpoint.start_pcb_port_id;
    if (!portId) continue;
    const pads = circuitJson.filter(
      (element) => (element.type === "pcb_smtpad" || element.type === "pcb_plated_hole") && element.pcb_port_id === portId
    );
    if (!pads.length) continue;
    const geometry = convertCircuitJsonToFlattenJs(circuitJson, {
      elementIds: pads.map(
        (pad) => pad.type === "pcb_smtpad" ? pad.pcb_smtpad_id : pad.pcb_plated_hole_id
      ),
      layers: [endpoint.layer],
      roles: ["copper"],
      includeDrillHoles: false
    });
    if (geometry.warnings.length) continue;
    const shapes = geometry.elements.flatMap((element) => element.shapes);
    const contains = (point2) => shapes.some((shape) => shape.contains(point2));
    if (!contains(new Point6(endpoint.x, endpoint.y))) continue;
    let insidePad = true;
    let remainingEscape = maxEscapeLength;
    const lengths = reverse ? fromEnd : fromStart;
    for (let i = reverse ? trace.route.length - 2 : 0; i >= 0 && i < trace.route.length - 1; i += reverse ? -1 : 1) {
      const a = trace.route[reverse ? i + 1 : i];
      const b = trace.route[reverse ? i : i + 1];
      if (a.route_type !== "wire" || b.route_type !== "wire" || a.layer !== endpoint.layer || b.layer !== endpoint.layer)
        break;
      const start = new Point6(a.x, a.y);
      const end = new Point6(b.x, b.y);
      const segment = new Segment4(start, end);
      const length = segment.length;
      if (length === 0) continue;
      let covered = 0;
      if (insidePad) {
        const cuts = [
          0,
          length,
          ...shapes.flatMap(
            (shape) => shape.intersect(segment).map((point2) => start.distanceTo(point2)[0])
          )
        ].sort((a2, b2) => a2 - b2);
        for (let j = 0; j < cuts.length - 1; j++) {
          if (cuts[j + 1] - cuts[j] < 1e-9) continue;
          const fraction = (cuts[j] + cuts[j + 1]) / (2 * length);
          if (!contains(
            new Point6(
              a.x + (b.x - a.x) * fraction,
              a.y + (b.y - a.y) * fraction
            )
          )) {
            insidePad = false;
            break;
          }
          covered = cuts[j + 1];
        }
      }
      const escape = Math.min(length - covered, remainingEscape);
      covered += escape;
      remainingEscape -= escape;
      lengths.set(i, covered);
      if (covered < length) break;
    }
  }
  return { fromStart, fromEnd };
}

// lib/check-source-traces-match-pcb-trace-thickness.ts
import { cju as cju5 } from "@tscircuit/circuit-json-util";
function checkSourceTracesMatchPcbTraceThickness(circuitJson, {
  maxPadNeckdownLength
} = {}) {
  if (maxPadNeckdownLength !== void 0 && (!Number.isFinite(maxPadNeckdownLength) || maxPadNeckdownLength < 0)) {
    throw new Error("maxPadNeckdownLength must be finite and nonnegative");
  }
  const warnings = [];
  const db = cju5(circuitJson);
  const sourceTraces = db.source_trace.list();
  const pcbTraces = db.pcb_trace.list();
  const pcbPorts = db.pcb_port.list();
  for (const sourceTrace of sourceTraces) {
    const requestedThickness = sourceTrace.min_trace_thickness;
    if (requestedThickness === void 0) continue;
    const connectedPcbPorts = pcbPorts.filter(
      (pcbPort) => sourceTrace.connected_source_port_ids?.includes(pcbPort.source_port_id)
    );
    if (connectedPcbPorts.length < 2) continue;
    const relatedPcbTraces = pcbTraces.filter(
      (pcbTrace) => pcbTrace.source_trace_id === sourceTrace.source_trace_id
    );
    if (relatedPcbTraces.length === 0) continue;
    let undersizedSegment;
    for (const relatedPcbTrace of relatedPcbTraces) {
      const neckdowns = getTraceEndpointNeckdownLengths(
        relatedPcbTrace,
        circuitJson,
        maxPadNeckdownLength ?? requestedThickness
      );
      for (let i = 0; i < relatedPcbTrace.route.length - 1; i++) {
        const point2 = relatedPcbTrace.route[i];
        const nextPoint = relatedPcbTrace.route[i + 1];
        if (point2.route_type !== "wire" || nextPoint.route_type !== "wire") {
          continue;
        }
        if (point2.layer !== nextPoint.layer) continue;
        if (point2.x === nextPoint.x && point2.y === nextPoint.y) continue;
        const interpolated = relatedPcbTrace.route_thickness_mode === "interpolated";
        if (Math.min(point2.width, interpolated ? nextPoint.width : point2.width) >= requestedThickness)
          continue;
        let startFraction = 0;
        let endFraction = 1;
        if (interpolated && point2.width !== nextPoint.width) {
          const crossing = (requestedThickness - point2.width) / (nextPoint.width - point2.width);
          if (point2.width >= requestedThickness) startFraction = crossing;
          if (nextPoint.width >= requestedThickness) endFraction = crossing;
        }
        const length = Math.hypot(nextPoint.x - point2.x, nextPoint.y - point2.y);
        startFraction = Math.max(
          startFraction,
          (neckdowns.fromStart.get(i) ?? 0) / length
        );
        endFraction = Math.min(
          endFraction,
          1 - (neckdowns.fromEnd.get(i) ?? 0) / length
        );
        if (endFraction - startFraction < 1e-9) continue;
        const width = interpolated ? Math.min(
          point2.width + (nextPoint.width - point2.width) * startFraction,
          point2.width + (nextPoint.width - point2.width) * endFraction
        ) : point2.width;
        if (undersizedSegment && width >= undersizedSegment.width) continue;
        const fraction = (startFraction + endFraction) / 2;
        undersizedSegment = {
          pcb_trace_id: relatedPcbTrace.pcb_trace_id,
          center: {
            x: point2.x + (nextPoint.x - point2.x) * fraction,
            y: point2.y + (nextPoint.y - point2.y) * fraction
          },
          width
        };
      }
    }
    if (!undersizedSegment) continue;
    warnings.push({
      type: "pcb_trace_warning",
      pcb_trace_warning_id: `pcb_trace_warning_${sourceTrace.source_trace_id}`,
      warning_type: "pcb_trace_warning",
      message: `Trace [${getReadableNameForSourceTrace(circuitJson, sourceTrace)}] is routed thinner than requested (requested: ${requestedThickness}mm, actual: ${undersizedSegment.width}mm).`,
      center: undersizedSegment.center,
      source_trace_id: sourceTrace.source_trace_id,
      pcb_trace_id: undersizedSegment.pcb_trace_id,
      pcb_component_ids: Array.from(
        new Set(
          connectedPcbPorts.map((pcbPort) => pcbPort.pcb_component_id).filter((id) => id !== void 0)
        )
      ),
      pcb_port_ids: connectedPcbPorts.map((pcbPort) => pcbPort.pcb_port_id)
    });
  }
  return warnings;
}

// lib/check-source-traces-have-pcb-traces.ts
import {
  getFullConnectivityMapFromCircuitJson as getFullConnectivityMapFromCircuitJson8
} from "circuit-json-to-connectivity-map";
function checkSourceTracesHavePcbTraces(circuitJson, { connMap } = {}) {
  const errors = [];
  const sourceTraces = circuitJson.filter(
    (el) => el.type === "source_trace"
  );
  const pcbTraces = circuitJson.filter(
    (el) => el.type === "pcb_trace"
  );
  const pcbPorts = circuitJson.filter(
    (el) => el.type === "pcb_port"
  );
  const sourcePortToPcbPort = new Map(
    pcbPorts.map((pcbPort) => [pcbPort.source_port_id, pcbPort])
  );
  const connectivityMap = connMap ?? getFullConnectivityMapFromCircuitJson8(circuitJson);
  let pourConnectivity;
  const getPourConnectivity = () => pourConnectivity ??= getCopperPourConnectivity(
    circuitJson,
    connectivityMap
  );
  for (const sourceTrace of sourceTraces) {
    if (!sourceTrace.connected_source_port_ids?.length) continue;
    if ((sourceTrace.connected_source_net_ids?.length ?? 0) > 0) continue;
    if (sourceTrace.connected_source_port_ids.length < 2) continue;
    const hasPcbTrace = pcbTraces.some(
      (pcbTrace) => connectivityMap.areIdsConnected(
        sourceTrace.source_trace_id,
        pcbTrace.pcb_trace_id
      )
    );
    if (!hasPcbTrace) {
      const connectedPcbPorts = sourceTrace.connected_source_port_ids.map((sourcePortId) => sourcePortToPcbPort.get(sourcePortId)).filter((pcbPort) => pcbPort !== void 0);
      if (connectedPcbPorts.length === sourceTrace.connected_source_port_ids.length && getPourConnectivity().arePortsConnected(
        connectedPcbPorts.map((port) => port.pcb_port_id)
      ))
        continue;
      const connectedPcbComponentIds = Array.from(
        new Set(
          connectedPcbPorts.map((port) => port.pcb_component_id).filter((id) => id !== void 0)
        )
      );
      errors.push({
        type: "pcb_trace_missing_error",
        pcb_trace_missing_error_id: `pcb_trace_missing_${sourceTrace.source_trace_id}`,
        error_type: "pcb_trace_missing_error",
        message: `Trace [${getReadableNameForSourceTrace(circuitJson, sourceTrace)}] is not connected (it has no PCB trace)`,
        source_trace_id: sourceTrace.source_trace_id,
        pcb_component_ids: connectedPcbComponentIds,
        pcb_port_ids: connectedPcbPorts.map((port) => port.pcb_port_id)
      });
    }
  }
  return errors;
}

// lib/check-traces-are-contiguous/check-traces-are-contiguous.ts
import { pointToSegmentDistance as pointToSegmentDistance6 } from "@tscircuit/math-utils";
import {
  getFullConnectivityMapFromCircuitJson as getFullConnectivityMapFromCircuitJson9
} from "circuit-json-to-connectivity-map";

// lib/check-traces-are-contiguous/via-contact-index.ts
import {
  all_layers as all_layers6
} from "circuit-json";
import { getPrimaryId as getPrimaryId8 } from "@tscircuit/circuit-json-util";
import { pointToSegmentDistance as pointToSegmentDistance5 } from "@tscircuit/math-utils";
var CONTACT_EPSILON = 1e-9;
function getViaContactIndex2(circuitJson, connectivity) {
  const index = /* @__PURE__ */ new Map();
  const pads = getPads(circuitJson);
  const traces = circuitJson.filter((element) => element.type === "pcb_trace");
  const vias = circuitJson.filter((element) => element.type === "pcb_via");
  const board = circuitJson.find((element) => element.type === "pcb_board");
  const layerCount = board?.num_layers;
  const innerLayers = all_layers6.filter((layer) => layer.startsWith("inner"));
  const stack = [
    "top",
    ...innerLayers.slice(
      0,
      layerCount === void 0 ? void 0 : Math.max(0, layerCount - 2)
    ),
    ...layerCount === 1 ? [] : ["bottom"]
  ];
  const add = (id, layers, contact) => {
    if (![contact.x, contact.y].every(Number.isFinite)) return;
    const net = connectivity.getNetConnectedToId(id);
    if (!net) return;
    const touchesPad = pads.some((pad) => {
      if (connectivity.getNetConnectedToId(getPrimaryId8(pad)) !== net || !getLayersOfPcbElement(pad).some((layer) => layers.includes(layer)))
        return false;
      if (contact.radius === void 0) return isPointInPad(contact, pad);
      const viaGeometry = {
        type: "pcb_via",
        pcb_via_id: id,
        x: contact.x,
        y: contact.y,
        outer_diameter: contact.radius * 2,
        hole_diameter: 0,
        layers
      };
      return getPadToPadGap(viaGeometry, pad) <= CONTACT_EPSILON;
    });
    const touchingTraceIds = /* @__PURE__ */ new Set();
    for (const trace of traces) {
      if (trace.route_thickness_mode === "interpolated" || connectivity.getNetConnectedToId(trace.pcb_trace_id) !== net)
        continue;
      for (let i = 1; i < trace.route.length; i++) {
        const a = trace.route[i - 1], b = trace.route[i];
        if (a.route_type !== "wire" || b.route_type !== "wire" || a.layer !== b.layer || !layers.includes(a.layer) || !Number.isFinite(a.width) || a.width <= 0 || Math.hypot(a.x - b.x, a.y - b.y) <= CONTACT_EPSILON)
          continue;
        const reach = contact.radius === void 0 ? 0 : contact.radius + a.width / 2;
        if (pointToSegmentDistance5(contact, a, b) <= reach + CONTACT_EPSILON) {
          touchingTraceIds.add(trace.pcb_trace_id);
          break;
        }
      }
    }
    const copper = { ...contact, touchesPad, touchingTraceIds };
    const byLayer = index.get(net) ?? /* @__PURE__ */ new Map();
    for (const layer of layers) {
      const contacts = byLayer.get(layer) ?? [];
      contacts.push(copper);
      byLayer.set(layer, contacts);
    }
    index.set(net, byLayer);
  };
  for (const via of vias) {
    if (!Number.isFinite(via.outer_diameter) || via.outer_diameter <= 0)
      continue;
    add(via.pcb_via_id, getLayersOfPcbElement(via), {
      x: via.x,
      y: via.y,
      ownerTraceId: via.pcb_trace_id,
      radius: via.outer_diameter / 2
    });
  }
  for (const trace of circuitJson) {
    if (trace.type !== "pcb_trace") continue;
    for (const point2 of trace.route) {
      if (point2.route_type !== "via") continue;
      if (vias.some(
        (via) => Math.hypot(via.x - point2.x, via.y - point2.y) <= CONTACT_EPSILON && (via.pcb_trace_id === trace.pcb_trace_id || !via.pcb_trace_id && connectivity.areIdsConnected(
          via.pcb_via_id,
          trace.pcb_trace_id
        ))
      ))
        continue;
      const from = stack.indexOf(point2.from_layer);
      const to = stack.indexOf(point2.to_layer);
      if (from < 0 || to < 0) continue;
      const diameter = point2.outer_diameter;
      if (diameter !== void 0 && (!Number.isFinite(diameter) || diameter <= 0))
        continue;
      add(
        trace.pcb_trace_id,
        stack.slice(Math.min(from, to), Math.max(from, to) + 1),
        {
          x: point2.x,
          y: point2.y,
          ownerTraceId: trace.pcb_trace_id,
          radius: diameter === void 0 ? void 0 : diameter / 2
        }
      );
    }
  }
  return index;
}
function endpointTouchesVia2({
  point: point2,
  width,
  ownerTrace,
  index,
  connectivity
}) {
  if (point2.route_type !== "wire" || !Number.isFinite(width) || width <= 0)
    return false;
  const net = connectivity.getNetConnectedToId(ownerTrace.pcb_trace_id);
  if (!net) return false;
  return (index.get(net)?.get(point2.layer) ?? []).some((via) => {
    if (via.ownerTraceId === ownerTrace.pcb_trace_id) return false;
    if (!via.touchesPad && ![...via.touchingTraceIds].some((id) => id !== ownerTrace.pcb_trace_id))
      return false;
    const contactDistance = via.radius === void 0 ? 0 : via.radius + width / 2;
    return Math.hypot(point2.x - via.x, point2.y - via.y) <= contactDistance + CONTACT_EPSILON;
  });
}

// lib/check-traces-are-contiguous/route-via-connects-adjacent-wires.ts
import {
  all_layers as all_layers7
} from "circuit-json";
var CONTACT_EPSILON2 = 0.01;
function createRouteViaContactContext(circuitJson) {
  const board = circuitJson.find((element) => element.type === "pcb_board");
  const innerLayers = all_layers7.filter((layer) => layer.startsWith("inner"));
  const stack = [
    "top",
    ...innerLayers.slice(
      0,
      board ? Math.max(0, board.num_layers - 2) : void 0
    ),
    ...board?.num_layers === 1 ? [] : ["bottom"]
  ];
  const ownedViasByTrace = /* @__PURE__ */ new Map();
  for (const element of circuitJson) {
    if (element.type !== "pcb_via" || !element.pcb_trace_id) continue;
    const ownedVias = ownedViasByTrace.get(element.pcb_trace_id);
    if (ownedVias) ownedVias.push(element);
    else ownedViasByTrace.set(element.pcb_trace_id, [element]);
  }
  return { stack, ownedViasByTrace };
}
function routeViaConnectsAdjacentWires({
  via,
  incoming,
  outgoing,
  traceId,
  context: { stack, ownedViasByTrace }
}) {
  const fromIndex = stack.indexOf(via.from_layer);
  const toIndex = stack.indexOf(via.to_layer);
  if (fromIndex < 0 || toIndex < 0) return false;
  const emitted = ownedViasByTrace.get(traceId)?.filter(
    (element) => Math.abs(element.x - via.x) < CONTACT_EPSILON2 && Math.abs(element.y - via.y) < CONTACT_EPSILON2
  ) ?? [];
  const spans = emitted.length > 0 ? emitted.map((element) => element.layers) : [
    stack.slice(
      Math.min(fromIndex, toIndex),
      Math.max(fromIndex, toIndex) + 1
    )
  ];
  const incomingAtVia = Math.abs(incoming.x - via.x) < CONTACT_EPSILON2 && Math.abs(incoming.y - via.y) < CONTACT_EPSILON2;
  const outgoingAtVia = Math.abs(outgoing.x - via.x) < CONTACT_EPSILON2 && Math.abs(outgoing.y - via.y) < CONTACT_EPSILON2;
  return stack.includes(incoming.layer) && stack.includes(outgoing.layer) && spans.some(
    (layers) => layers.includes(incoming.layer) && layers.includes(outgoing.layer)
  ) && (incomingAtVia || incoming.layer === via.from_layer) && (outgoingAtVia || outgoing.layer === via.to_layer);
}

// lib/check-traces-are-contiguous/check-traces-are-contiguous.ts
var ENDPOINT_CONTACT_EPSILON = 1e-9;
var TRACE_SEGMENT_GEOMETRY_EPSILON = 1e-9;
function routePointTouchesPad2({
  point: point2,
  pad,
  endpointCopperWidth,
  bounds
}) {
  if (point2.route_type !== "wire" || !getLayersOfPcbElement(pad).includes(point2.layer))
    return false;
  if (isPointInPad(point2, pad)) return true;
  if (endpointCopperWidth === void 0 || !Number.isFinite(endpointCopperWidth) || endpointCopperWidth <= 0 || !bounds)
    return false;
  const radius = endpointCopperWidth / 2;
  if (point2.x + radius <= bounds.minX || point2.x - radius >= bounds.maxX || point2.y + radius <= bounds.minY || point2.y - radius >= bounds.maxY)
    return false;
  const { gap } = getTraceObstacleClearance(
    {
      x1: point2.x,
      y1: point2.y,
      x2: point2.x,
      y2: point2.y,
      thickness: endpointCopperWidth
    },
    pad
  );
  return gap < -ENDPOINT_CONTACT_EPSILON;
}
function getTraceWireSegmentsByNetAndLayer2(pcbTraces, fullConnectivityMap) {
  const segmentsByNetAndLayer = /* @__PURE__ */ new Map();
  for (const trace of pcbTraces) {
    if (trace.route_thickness_mode === "interpolated") continue;
    const netId = fullConnectivityMap.getNetConnectedToId(trace.pcb_trace_id);
    if (!netId) continue;
    for (let i = 0; i < trace.route.length - 1; i++) {
      const start = trace.route[i];
      const end = trace.route[i + 1];
      if (start.route_type !== "wire" || end.route_type !== "wire") continue;
      if (start.layer !== end.layer) continue;
      if (Math.hypot(start.x - end.x, start.y - end.y) <= TRACE_SEGMENT_GEOMETRY_EPSILON) {
        continue;
      }
      const segmentsByLayer = segmentsByNetAndLayer.get(netId) ?? /* @__PURE__ */ new Map();
      const segments = segmentsByLayer.get(start.layer) ?? [];
      segments.push({ trace, start, end });
      segmentsByLayer.set(start.layer, segments);
      segmentsByNetAndLayer.set(netId, segmentsByLayer);
    }
  }
  return segmentsByNetAndLayer;
}
function getEndpointTraceCopperWidth(trace, endpoint) {
  if (trace.route_thickness_mode === "interpolated") return void 0;
  let segmentStartIndex = endpoint === "start" ? 0 : trace.route.length - 2;
  const indexStep = endpoint === "start" ? 1 : -1;
  while (segmentStartIndex >= 0 && segmentStartIndex < trace.route.length - 1) {
    const segmentStart = trace.route[segmentStartIndex];
    const segmentEnd = trace.route[segmentStartIndex + 1];
    if (segmentStart?.route_type !== "wire" || segmentEnd?.route_type !== "wire" || segmentStart.layer !== segmentEnd.layer) {
      return void 0;
    }
    if (Math.hypot(segmentStart.x - segmentEnd.x, segmentStart.y - segmentEnd.y) > TRACE_SEGMENT_GEOMETRY_EPSILON) {
      return segmentStart.width;
    }
    segmentStartIndex += indexStep;
  }
  return void 0;
}
function routePointTouchesLogicallyConnectedTraceCopper({
  point: point2,
  endpointTraceCopperWidth,
  ownerTrace,
  traceWireSegmentsByNetAndLayer,
  fullConnectivityMap
}) {
  if (point2.route_type !== "wire") return false;
  const ownerNetId = fullConnectivityMap.getNetConnectedToId(
    ownerTrace.pcb_trace_id
  );
  if (!ownerNetId) return false;
  const candidateSegments = traceWireSegmentsByNetAndLayer.get(ownerNetId)?.get(point2.layer) ?? [];
  for (const segment of candidateSegments) {
    if (segment.trace.pcb_trace_id === ownerTrace.pcb_trace_id) continue;
    const maximumContactDistance = endpointTraceCopperWidth / 2 + segment.start.width / 2 + ENDPOINT_CONTACT_EPSILON;
    if (pointToSegmentDistance6(point2, segment.start, segment.end) <= maximumContactDistance) {
      return true;
    }
  }
  return false;
}
function getRoutePointCenter(point2) {
  if (point2.route_type === "through_pad") {
    return {
      x: (point2.start.x + point2.end.x) / 2,
      y: (point2.start.y + point2.end.y) / 2
    };
  }
  return { x: point2.x, y: point2.y };
}
function routePointConnectsToAnotherExpectedPort(point2, expectedPorts, missingPcbPortId, padMap) {
  return expectedPorts.some((expectedPort) => {
    if (!expectedPort.pcb_port_id || expectedPort.pcb_port_id === missingPcbPortId) {
      return false;
    }
    const expectedPads = padMap.get(expectedPort.pcb_port_id);
    return expectedPads?.some((pad) => routePointTouchesPad2({ point: point2, pad })) ?? false;
  });
}
function getMissingConnectionErrorCenter({
  firstPoint,
  lastPoint,
  port,
  expectedPorts,
  padMap
}) {
  let errorLocation;
  const firstWirePoint = firstPoint.route_type === "wire" ? firstPoint : void 0;
  const lastWirePoint = lastPoint.route_type === "wire" ? lastPoint : void 0;
  const firstWirePointReferencesPort = getPcbPortIdsConnectedToRoutePoint(
    firstPoint
  ).includes(port.pcb_port_id);
  const lastWirePointReferencesPort = getPcbPortIdsConnectedToRoutePoint(
    lastPoint
  ).includes(port.pcb_port_id);
  if (firstWirePointReferencesPort && firstWirePoint) {
    errorLocation = firstWirePoint;
  } else if (lastWirePointReferencesPort && lastWirePoint) {
    errorLocation = lastWirePoint;
  } else if (routePointConnectsToAnotherExpectedPort(
    firstPoint,
    expectedPorts,
    port.pcb_port_id,
    padMap
  ) && lastWirePoint) {
    errorLocation = lastWirePoint;
  } else if (routePointConnectsToAnotherExpectedPort(
    lastPoint,
    expectedPorts,
    port.pcb_port_id,
    padMap
  ) && firstWirePoint) {
    errorLocation = firstWirePoint;
  } else if (firstWirePoint && lastWirePoint) {
    errorLocation = distance2(firstWirePoint, port) <= distance2(lastWirePoint, port) ? firstWirePoint : lastWirePoint;
  } else if (firstWirePoint) {
    errorLocation = firstWirePoint;
  } else if (lastWirePoint) {
    errorLocation = lastWirePoint;
  }
  const firstPointCenter = getRoutePointCenter(firstPoint);
  const lastPointCenter = getRoutePointCenter(lastPoint);
  return errorLocation ? { x: errorLocation.x, y: errorLocation.y } : {
    x: (firstPointCenter.x + lastPointCenter.x) / 2,
    y: (firstPointCenter.y + lastPointCenter.y) / 2
  };
}
function checkTracesAreContiguous(circuitJson, {
  connMap,
  pcbConnectivityMap
} = {}) {
  const routeViaContext = createRouteViaContactContext(circuitJson);
  const errors = getTracePortLayerMismatches(circuitJson).map(
    ({ trace, point: point2, index, port, padLayers }) => ({
      type: "pcb_trace_error",
      error_type: "pcb_trace_error",
      pcb_trace_error_id: `missing_layer_connection_${trace.pcb_trace_id}_${index}_${port.pcb_port_id}`,
      pcb_trace_id: trace.pcb_trace_id,
      source_trace_id: trace.source_trace_id ?? `!${trace.pcb_trace_id}`,
      pcb_port_ids: [port.pcb_port_id],
      pcb_component_ids: port.pcb_component_id ? [port.pcb_component_id] : [],
      center: { x: point2.x, y: point2.y },
      message: `Trace [${getReadableNameForTrace(circuitJson, trace.pcb_trace_id)}] on ${point2.layer} is missing a via connection to port [${getReadableNameForPort(circuitJson, port.pcb_port_id)}] on ${padLayers.join(", ")}.`
    })
  );
  const pcbPorts = circuitJson.filter(
    (el) => el.type === "pcb_port"
  );
  const pcbTraces = circuitJson.filter(
    (el) => el.type === "pcb_trace"
  );
  const sourceTraces = circuitJson.filter(
    (el) => el.type === "source_trace"
  );
  const pcbSmtPads = circuitJson.filter(
    (el) => el.type === "pcb_smtpad"
  );
  const pcbPlatedHoles = circuitJson.filter(
    (el) => el.type === "pcb_plated_hole"
  );
  const padMap = /* @__PURE__ */ new Map();
  let fullConnectivityMap = connMap;
  let traceWireSegmentsByNetAndLayer;
  const getFullConnectivityMap = () => {
    fullConnectivityMap ??= getFullConnectivityMapFromCircuitJson9(circuitJson);
    return fullConnectivityMap;
  };
  const getTraceWireSegmentIndex = () => {
    traceWireSegmentsByNetAndLayer ??= getTraceWireSegmentsByNetAndLayer2(
      pcbTraces,
      getFullConnectivityMap()
    );
    return traceWireSegmentsByNetAndLayer;
  };
  let viaContactIndex;
  const getViaIndex = () => {
    viaContactIndex ??= getViaContactIndex2(
      circuitJson,
      getFullConnectivityMap()
    );
    return viaContactIndex;
  };
  const checkedSourceTraceIds = /* @__PURE__ */ new Set();
  for (const pad of pcbSmtPads) {
    if (pad.pcb_port_id) {
      padMap.set(pad.pcb_port_id, [...padMap.get(pad.pcb_port_id) ?? [], pad]);
    }
  }
  for (const hole of pcbPlatedHoles) {
    if (hole.pcb_port_id) {
      padMap.set(hole.pcb_port_id, [
        ...padMap.get(hole.pcb_port_id) ?? [],
        hole
      ]);
    }
  }
  const touchedPortIdsByTraceId = /* @__PURE__ */ new Map();
  const traceIdsByTouchedPortId = /* @__PURE__ */ new Map();
  const padBounds = new Map(
    [...padMap.values()].flat().map((pad) => [pad, getPadBounds(pad)])
  );
  for (const trace of pcbTraces) {
    const touchedPortIds = /* @__PURE__ */ new Set();
    const firstPoint = trace.route[0];
    const lastPoint = trace.route.at(-1);
    for (const [endpoint, point2] of [
      ["start", firstPoint],
      ["end", lastPoint]
    ]) {
      if (!point2) continue;
      const copperWidth = getEndpointTraceCopperWidth(trace, endpoint);
      for (const [pcbPortId, pads] of padMap) {
        if (pads.some(
          (pad) => routePointTouchesPad2({
            point: point2,
            pad,
            endpointCopperWidth: copperWidth,
            bounds: padBounds.get(pad)
          })
        )) {
          touchedPortIds.add(pcbPortId);
        }
      }
    }
    touchedPortIdsByTraceId.set(trace.pcb_trace_id, touchedPortIds);
    for (const pcbPortId of touchedPortIds) {
      const traceIds = traceIdsByTouchedPortId.get(pcbPortId) ?? /* @__PURE__ */ new Set();
      traceIds.add(trace.pcb_trace_id);
      traceIdsByTouchedPortId.set(pcbPortId, traceIds);
    }
  }
  const physicallyConnectedTracesByTraceId = /* @__PURE__ */ new Map();
  const getPhysicallyConnectedTraces = (startTrace) => {
    const cached = physicallyConnectedTracesByTraceId.get(
      startTrace.pcb_trace_id
    );
    if (cached) return cached;
    pcbConnectivityMap ??= createIndexedPcbConnectivityMap(circuitJson);
    const connectedTraceIds = /* @__PURE__ */ new Set();
    const pendingTraceIds = [startTrace.pcb_trace_id];
    while (pendingTraceIds.length > 0) {
      const traceId = pendingTraceIds.pop();
      if (connectedTraceIds.has(traceId)) continue;
      connectedTraceIds.add(traceId);
      for (const connectedTrace of pcbConnectivityMap.getAllTracesConnectedToTrace(
        traceId
      )) {
        if (!connectedTraceIds.has(connectedTrace.pcb_trace_id)) {
          pendingTraceIds.push(connectedTrace.pcb_trace_id);
        }
      }
      for (const pcbPortId of touchedPortIdsByTraceId.get(traceId) ?? []) {
        for (const touchingTraceId of traceIdsByTouchedPortId.get(pcbPortId) ?? []) {
          if (!connectedTraceIds.has(touchingTraceId)) {
            pendingTraceIds.push(touchingTraceId);
          }
        }
      }
    }
    const connectedTraces = pcbTraces.filter(
      (trace) => connectedTraceIds.has(trace.pcb_trace_id)
    );
    for (const trace of connectedTraces) {
      physicallyConnectedTracesByTraceId.set(
        trace.pcb_trace_id,
        connectedTraces
      );
    }
    return connectedTraces;
  };
  for (const trace of pcbTraces) {
    if (trace.route.length === 0) continue;
    const firstPoint = trace.route[0];
    const lastPoint = trace.route[trace.route.length - 1];
    const startCopperWidth = getEndpointTraceCopperWidth(trace, "start");
    const endCopperWidth = getEndpointTraceCopperWidth(trace, "end");
    const sourceTrace = sourceTraces.find(
      (st2) => st2.source_trace_id === trace.source_trace_id
    );
    const expectedPorts = sourceTrace ? pcbPorts.filter(
      (port) => sourceTrace.connected_source_port_ids?.includes(port.source_port_id)
    ) : [];
    let traceName;
    for (let i = 1; i < trace.route.length - 1; i++) {
      const prevPoint = trace.route[i - 1];
      const currentPoint = trace.route[i];
      const nextPoint = trace.route[i + 1];
      if (currentPoint.route_type === "via") {
        const prevIsWire = prevPoint.route_type === "wire";
        const nextIsWire = nextPoint.route_type === "wire";
        if (prevIsWire && nextIsWire) {
          if (!routeViaConnectsAdjacentWires({
            via: currentPoint,
            incoming: prevPoint,
            outgoing: nextPoint,
            traceId: trace.pcb_trace_id,
            context: routeViaContext
          })) {
            traceName ??= getReadableNameForTrace(
              circuitJson,
              trace.pcb_trace_id
            );
            errors.push({
              type: "pcb_trace_error",
              message: `Via in trace [${traceName}] does not connect its adjacent wire layers at position {x: ${currentPoint.x}, y: ${currentPoint.y}}.`,
              source_trace_id: sourceTrace?.source_trace_id || trace.source_trace_id || `!${trace.pcb_trace_id}`,
              error_type: "pcb_trace_error",
              pcb_trace_id: trace.pcb_trace_id,
              pcb_trace_error_id: `misaligned_via_${trace.pcb_trace_id}_${i}`,
              pcb_component_ids: [],
              pcb_port_ids: []
            });
          }
        }
      }
    }
    if (sourceTrace && expectedPorts.length > 0) {
      if (checkedSourceTraceIds.has(sourceTrace.source_trace_id)) continue;
      checkedSourceTraceIds.add(sourceTrace.source_trace_id);
    }
    for (const port of expectedPorts) {
      if (!port.pcb_port_id) continue;
      const pads = padMap.get(port.pcb_port_id);
      if (!pads?.length) continue;
      const isFirstPointConnected = pads.some(
        (pad) => routePointTouchesPad2({
          point: firstPoint,
          pad,
          endpointCopperWidth: startCopperWidth,
          bounds: padBounds.get(pad)
        })
      );
      const isLastPointConnected = pads.some(
        (pad) => routePointTouchesPad2({
          point: lastPoint,
          pad,
          endpointCopperWidth: endCopperWidth,
          bounds: padBounds.get(pad)
        })
      );
      if (isFirstPointConnected || isLastPointConnected) continue;
      const isConnectedByRoutedSourceTrace = getPhysicallyConnectedTraces(
        trace
      ).some(
        (candidateTrace) => touchedPortIdsByTraceId.get(candidateTrace.pcb_trace_id)?.has(port.pcb_port_id)
      );
      if (isConnectedByRoutedSourceTrace) continue;
      if (!isFirstPointConnected && !isLastPointConnected) {
        traceName ??= getReadableNameForTrace(
          circuitJson,
          trace.pcb_trace_id
        );
        const portName = getReadableNameForPort(
          circuitJson,
          port.pcb_port_id
        );
        const padType = pads[0].type === "pcb_smtpad" ? "SMD pad" : "through-hole pad";
        const errorCenter = getMissingConnectionErrorCenter({
          firstPoint,
          lastPoint,
          port,
          expectedPorts,
          padMap
        });
        errors.push({
          type: "pcb_trace_error",
          message: `Trace [${traceName}] is missing a connection to ${padType} ${portName}`,
          source_trace_id: sourceTrace?.source_trace_id || trace.source_trace_id || `!${trace.pcb_trace_id}`,
          error_type: "pcb_trace_error",
          pcb_trace_id: trace.pcb_trace_id,
          pcb_trace_error_id: `missing_connection_${trace.pcb_trace_id}_${port.pcb_port_id}`,
          center: errorCenter,
          pcb_component_ids: [],
          pcb_port_ids: [port.pcb_port_id]
        });
      }
    }
    if (expectedPorts.length === 0) {
      let firstConnectsToAnyPad = false;
      let lastConnectsToAnyPad = false;
      for (const pads of padMap.values()) {
        if (pads.some(
          (pad) => routePointTouchesPad2({
            point: firstPoint,
            pad,
            endpointCopperWidth: startCopperWidth,
            bounds: padBounds.get(pad)
          })
        )) {
          firstConnectsToAnyPad = true;
        }
        if (pads.some(
          (pad) => routePointTouchesPad2({
            point: lastPoint,
            pad,
            endpointCopperWidth: endCopperWidth,
            bounds: padBounds.get(pad)
          })
        )) {
          lastConnectsToAnyPad = true;
        }
      }
      const firstEndpointTraceCopperWidth = !firstConnectsToAnyPad ? getEndpointTraceCopperWidth(trace, "start") : void 0;
      const lastEndpointTraceCopperWidth = !lastConnectsToAnyPad ? getEndpointTraceCopperWidth(trace, "end") : void 0;
      const firstConnectsToLogicallyConnectedTraceCopper = firstEndpointTraceCopperWidth !== void 0 && routePointTouchesLogicallyConnectedTraceCopper({
        point: firstPoint,
        endpointTraceCopperWidth: firstEndpointTraceCopperWidth,
        ownerTrace: trace,
        traceWireSegmentsByNetAndLayer: getTraceWireSegmentIndex(),
        fullConnectivityMap: getFullConnectivityMap()
      });
      const lastConnectsToLogicallyConnectedTraceCopper = lastEndpointTraceCopperWidth !== void 0 && routePointTouchesLogicallyConnectedTraceCopper({
        point: lastPoint,
        endpointTraceCopperWidth: lastEndpointTraceCopperWidth,
        ownerTrace: trace,
        traceWireSegmentsByNetAndLayer: getTraceWireSegmentIndex(),
        fullConnectivityMap: getFullConnectivityMap()
      });
      const firstIsConnected = firstConnectsToAnyPad || firstConnectsToLogicallyConnectedTraceCopper || firstEndpointTraceCopperWidth !== void 0 && endpointTouchesVia2({
        point: firstPoint,
        width: firstEndpointTraceCopperWidth,
        ownerTrace: trace,
        index: getViaIndex(),
        connectivity: getFullConnectivityMap()
      });
      const lastIsConnected = lastConnectsToAnyPad || lastConnectsToLogicallyConnectedTraceCopper || lastEndpointTraceCopperWidth !== void 0 && endpointTouchesVia2({
        point: lastPoint,
        width: lastEndpointTraceCopperWidth,
        ownerTrace: trace,
        index: getViaIndex(),
        connectivity: getFullConnectivityMap()
      });
      const endpointsAreSame = firstPoint.route_type === "wire" && lastPoint.route_type === "wire" && firstPoint.layer === lastPoint.layer && Math.hypot(firstPoint.x - lastPoint.x, firstPoint.y - lastPoint.y) <= ENDPOINT_CONTACT_EPSILON;
      if (!firstIsConnected && firstPoint.route_type === "wire") {
        traceName ??= getReadableNameForTrace(
          circuitJson,
          trace.pcb_trace_id
        );
        errors.push({
          type: "pcb_trace_error",
          message: `Trace [${traceName}] has disconnected endpoint at (${firstPoint.x.toFixed(2)}, ${firstPoint.y.toFixed(2)})`,
          source_trace_id: sourceTrace?.source_trace_id || trace.source_trace_id || `!${trace.pcb_trace_id}`,
          error_type: "pcb_trace_error",
          pcb_trace_id: trace.pcb_trace_id,
          pcb_trace_error_id: `disconnected_endpoint_${trace.pcb_trace_id}_start`,
          center: { x: firstPoint.x, y: firstPoint.y },
          pcb_component_ids: [],
          pcb_port_ids: []
        });
      }
      if (!lastIsConnected && lastPoint.route_type === "wire" && !(endpointsAreSame && !firstIsConnected)) {
        traceName ??= getReadableNameForTrace(
          circuitJson,
          trace.pcb_trace_id
        );
        errors.push({
          type: "pcb_trace_error",
          message: `Trace [${traceName}] has disconnected endpoint at (${lastPoint.x.toFixed(2)}, ${lastPoint.y.toFixed(2)})`,
          source_trace_id: sourceTrace?.source_trace_id || trace.source_trace_id || `!${trace.pcb_trace_id}`,
          error_type: "pcb_trace_error",
          pcb_trace_id: trace.pcb_trace_id,
          pcb_trace_error_id: `disconnected_endpoint_${trace.pcb_trace_id}_end`,
          center: { x: lastPoint.x, y: lastPoint.y },
          pcb_component_ids: [],
          pcb_port_ids: []
        });
      }
    }
  }
  return errors;
}

// lib/check-trace-out-of-board/checkTraceOutOfBoard.ts
import { cju as cju6 } from "@tscircuit/circuit-json-util";
import { segmentToSegmentMinDistance as segmentToSegmentMinDistance5 } from "@tscircuit/math-utils";
function getBoardPolygonPoints(board) {
  if (board.outline && board.outline.length > 0) {
    return board.outline.map((p) => ({ x: p.x, y: p.y }));
  }
  if (board.center && typeof board.width === "number" && typeof board.height === "number") {
    const cx = board.center.x;
    const cy = board.center.y;
    const hw = board.width / 2;
    const hh = board.height / 2;
    return [
      { x: cx - hw, y: cy - hh },
      // bottom-left
      { x: cx + hw, y: cy - hh },
      // bottom-right
      { x: cx + hw, y: cy + hh },
      // top-right
      { x: cx - hw, y: cy + hh }
      // top-left
    ];
  }
  return null;
}
function checkPcbTracesOutOfBoard(circuitJson, config = {}) {
  const errors = [];
  const board = getPcbBoard(circuitJson);
  if (!board) return errors;
  const margin = config.margin ?? getBoardDrcValue(board, "min_board_edge_clearance") ?? jlcMinTolerances.min_board_edge_clearance;
  const boardPoints = getBoardPolygonPoints(board);
  if (!boardPoints) return errors;
  const pcbTraces = cju6(circuitJson).pcb_trace.list();
  for (const trace of pcbTraces) {
    if (trace.route.length < 2) continue;
    for (let i = 0; i < trace.route.length - 1; i++) {
      const p1 = trace.route[i];
      const p2 = trace.route[i + 1];
      if (p1.route_type !== "wire" || p2.route_type !== "wire") continue;
      const traceWidth = "width" in p1 ? p1.width : "width" in p2 ? p2.width : 0.1;
      const segmentStart = { x: p1.x, y: p1.y };
      const segmentEnd = { x: p2.x, y: p2.y };
      let minDistance = Number.POSITIVE_INFINITY;
      for (let j = 0; j < boardPoints.length; j++) {
        const edgeStart = boardPoints[j];
        const edgeEnd = boardPoints[(j + 1) % boardPoints.length];
        const distance6 = segmentToSegmentMinDistance5(
          segmentStart,
          segmentEnd,
          edgeStart,
          edgeEnd
        );
        if (distance6 < minDistance) {
          minDistance = distance6;
        }
      }
      const minimumDistance = traceWidth / 2 + margin;
      if (minDistance < minimumDistance) {
        const error = {
          type: "pcb_trace_error",
          error_type: "pcb_trace_error",
          pcb_trace_error_id: `trace_too_close_to_board_${trace.pcb_trace_id}_segment_${i}`,
          message: `Trace too close to board edge (${minDistance.toFixed(3)}mm < ${minimumDistance.toFixed(3)}mm required, margin: ${margin}mm)`,
          pcb_trace_id: trace.pcb_trace_id,
          source_trace_id: trace.source_trace_id || "",
          center: {
            x: (segmentStart.x + segmentEnd.x) / 2,
            y: (segmentStart.y + segmentEnd.y) / 2
          },
          pcb_component_ids: [],
          pcb_port_ids: []
        };
        errors.push(error);
      }
    }
  }
  return errors;
}

// lib/check-pcb-components-overlap/checkPcbComponentOverlap.ts
import {
  cju as cju7,
  getBoundsOfPcbElements as getBoundsOfPcbElements5,
  getPrimaryId as getPrimaryId9
} from "@tscircuit/circuit-json-util";
import { doBoundsOverlap as doBoundsOverlap3 } from "@tscircuit/math-utils";
import { getFullConnectivityMapFromCircuitJson as getFullConnectivityMapFromCircuitJson10 } from "circuit-json-to-connectivity-map";

// lib/check-pcb-components-overlap/doPcbElementsOverlap.ts
import { getBoundsOfPcbElements as getBoundsOfPcbElements4 } from "@tscircuit/circuit-json-util";
import { doBoundsOverlap as doBoundsOverlap2 } from "@tscircuit/math-utils";
var isCourtyardElement = (element) => element.type === "pcb_courtyard_circle" || element.type === "pcb_courtyard_outline" || element.type === "pcb_courtyard_polygon" || element.type === "pcb_courtyard_rect";
function getElementLayers(elem) {
  if (isCourtyardElement(elem)) {
    return [elem.layer];
  }
  return getLayersOfPcbElement(elem);
}
function doLayersOverlap(layers1, layers2) {
  if (layers1.length === 0 || layers2.length === 0) return true;
  return layers1.some((l) => layers2.includes(l));
}
function doPcbElementsOverlap(elem1, elem2) {
  const layers1 = getElementLayers(elem1);
  const layers2 = getElementLayers(elem2);
  if (!doLayersOverlap(layers1, layers2)) return false;
  if (elem1.type === "pcb_smtpad" && elem2.type === "pcb_smtpad") {
    return getPadToPadGap(elem1, elem2) <= 0;
  }
  if (elem1.type === "pcb_plated_hole" && isCourtyardElement(elem2)) {
    return getPadToPadGap(elem1, courtyardToKeepout(elem2)) <= 0;
  }
  if (isCourtyardElement(elem1) && elem2.type === "pcb_plated_hole") {
    return getPadToPadGap(elem2, courtyardToKeepout(elem1)) <= 0;
  }
  const bounds1 = getBoundsOfPcbElements4([elem1]);
  const bounds2 = getBoundsOfPcbElements4([elem2]);
  return doBoundsOverlap2(bounds1, bounds2);
}

// lib/check-pcb-components-overlap/checkPcbComponentOverlap.ts
var isCourtyardElement2 = (element) => element.type === "pcb_courtyard_circle" || element.type === "pcb_courtyard_outline" || element.type === "pcb_courtyard_polygon" || element.type === "pcb_courtyard_rect";
var isHoleElement = (element) => element.type === "pcb_hole" || element.type === "pcb_plated_hole";
var formatOverlapElementDescription = (circuitJson, element) => {
  if ("pcb_port_id" in element && element.pcb_port_id) {
    return getReadableNameForPort(circuitJson, element.pcb_port_id);
  }
  const id = getPrimaryId9(element);
  const readableName = getReadableNameForElementId(circuitJson, id);
  return readableName;
};
function checkPcbComponentOverlap(circuitJson) {
  const errors = [];
  const doNotPlaceComponentIds = new Set(
    circuitJson.flatMap(
      (element) => element.type === "pcb_component" && element.do_not_place ? [element.pcb_component_id] : []
    )
  );
  const connMap = getFullConnectivityMapFromCircuitJson10(circuitJson);
  const smtPads = cju7(circuitJson).pcb_smtpad.list();
  const platedHoles = cju7(circuitJson).pcb_plated_hole.list();
  const holes = cju7(circuitJson).pcb_hole.list();
  const courtyards = circuitJson.filter(isCourtyardElement2);
  const componentMap = /* @__PURE__ */ new Map();
  for (const pad of smtPads) {
    const componentId = pad.pcb_component_id || `standalone_pad_${getPrimaryId9(pad)}`;
    if (!componentMap.has(componentId)) {
      componentMap.set(componentId, {
        component_id: componentId,
        elements: []
      });
    }
    componentMap.get(componentId).elements.push(pad);
  }
  for (const hole of platedHoles) {
    const componentId = hole.pcb_component_id || `standalone_plated_hole_${getPrimaryId9(hole)}`;
    if (!componentMap.has(componentId)) {
      componentMap.set(componentId, {
        component_id: componentId,
        elements: []
      });
    }
    componentMap.get(componentId).elements.push(hole);
  }
  for (const hole of holes) {
    const componentId = hole.pcb_component_id || `standalone_hole_${getPrimaryId9(hole)}`;
    if (!componentMap.has(componentId)) {
      componentMap.set(componentId, {
        component_id: componentId,
        elements: [hole]
      });
    }
  }
  for (const courtyard of courtyards) {
    const componentId = courtyard.pcb_component_id;
    if (!componentMap.has(componentId)) {
      componentMap.set(componentId, {
        component_id: componentId,
        elements: []
      });
    }
    componentMap.get(componentId).elements.push(courtyard);
  }
  for (const [componentId, componentData] of componentMap) {
    if (componentData.elements.length > 0) {
      componentData.bounds = getBoundsOfPcbElements5(componentData.elements);
    }
  }
  const componentsWithElements = Array.from(componentMap.values());
  for (let i = 0; i < componentsWithElements.length; i++) {
    for (let j = i + 1; j < componentsWithElements.length; j++) {
      const comp1 = componentsWithElements[i];
      const comp2 = componentsWithElements[j];
      const pairIncludesDoNotPlaceComponent = doNotPlaceComponentIds.has(comp1.component_id) || doNotPlaceComponentIds.has(comp2.component_id);
      if (!comp1.bounds || !comp2.bounds) {
        continue;
      }
      if (!doBoundsOverlap3(comp1.bounds, comp2.bounds)) {
        continue;
      }
      for (const elem1 of comp1.elements) {
        for (const elem2 of comp2.elements) {
          const id1 = getPrimaryId9(elem1);
          const id2 = getPrimaryId9(elem2);
          if (pairIncludesDoNotPlaceComponent && (isCourtyardElement2(elem1) || isCourtyardElement2(elem2))) {
            continue;
          }
          if ((isCourtyardElement2(elem1) || isCourtyardElement2(elem2)) && !isHoleElement(elem1) && !isHoleElement(elem2)) {
            continue;
          }
          if (elem1.type === "pcb_smtpad" && elem2.type === "pcb_smtpad" && connMap.areIdsConnected(id1, id2)) {
            continue;
          }
          if (doPcbElementsOverlap(elem1, elem2)) {
            const elem1Description = formatOverlapElementDescription(
              circuitJson,
              elem1
            );
            const elem2Description = formatOverlapElementDescription(
              circuitJson,
              elem2
            );
            const error = {
              type: "pcb_footprint_overlap_error",
              pcb_error_id: `pcb_footprint_overlap_${id1}_${id2}`,
              error_type: "pcb_footprint_overlap_error",
              message: `${elem1.type} ${elem1Description} overlaps with ${elem2.type} ${elem2Description}`,
              pcb_component_ids: [
                elem1.pcb_component_id,
                elem2.pcb_component_id
              ].filter((id) => Boolean(id))
            };
            if (elem1.type === "pcb_smtpad" || elem2.type === "pcb_smtpad") {
              error.pcb_smtpad_ids = [];
              if (elem1.type === "pcb_smtpad") error.pcb_smtpad_ids.push(id1);
              if (elem2.type === "pcb_smtpad") error.pcb_smtpad_ids.push(id2);
            }
            if (elem1.type === "pcb_plated_hole" || elem2.type === "pcb_plated_hole") {
              error.pcb_plated_hole_ids = [];
              if (elem1.type === "pcb_plated_hole")
                error.pcb_plated_hole_ids.push(id1);
              if (elem2.type === "pcb_plated_hole")
                error.pcb_plated_hole_ids.push(id2);
            }
            if (elem1.type === "pcb_hole" || elem2.type === "pcb_hole") {
              error.pcb_hole_ids = [];
              if (elem1.type === "pcb_hole") error.pcb_hole_ids.push(id1);
              if (elem2.type === "pcb_hole") error.pcb_hole_ids.push(id2);
            }
            errors.push(error);
          }
        }
      }
    }
  }
  return errors;
}

// lib/check-pcb-components-missing-courtyard.ts
var courtyardTypes = /* @__PURE__ */ new Set([
  "pcb_courtyard_circle",
  "pcb_courtyard_outline",
  "pcb_courtyard_polygon",
  "pcb_courtyard_pill",
  "pcb_courtyard_rect"
]);
function checkPcbComponentsMissingCourtyard(circuitJson) {
  const courtyardExemptSourceIds = new Set(
    circuitJson.flatMap((element) => {
      if (element.type === "source_manually_placed_via") {
        return [element.source_manually_placed_via_id];
      }
      if (element.type === "source_component" && element.ftype === "simple_test_point") {
        return [element.source_component_id];
      }
      return [];
    })
  );
  const componentIdsWithCourtyards = new Set(
    circuitJson.filter((element) => courtyardTypes.has(element.type)).flatMap(
      (element) => "pcb_component_id" in element && element.pcb_component_id ? [element.pcb_component_id] : []
    )
  );
  return circuitJson.filter(
    (element) => element.type === "pcb_component"
  ).filter(
    (component) => !componentIdsWithCourtyards.has(component.pcb_component_id) && (!component.source_component_id || !courtyardExemptSourceIds.has(component.source_component_id))
  ).map((component) => {
    const sourceComponent = component.source_component_id ? circuitJson.find(
      (element) => element.type === "source_component" && element.source_component_id === component.source_component_id
    ) : void 0;
    const componentName = sourceComponent?.type === "source_component" ? sourceComponent.name : getReadableNameForComponent(circuitJson, component.pcb_component_id);
    return {
      type: "pcb_component_missing_courtyard_warning",
      pcb_component_missing_courtyard_warning_id: `pcb_component_missing_courtyard_warning_${component.pcb_component_id}`,
      warning_type: "pcb_component_missing_courtyard_warning",
      message: `${componentName} has no courtyard`,
      pcb_component_id: component.pcb_component_id,
      source_component_id: component.source_component_id,
      subcircuit_id: component.subcircuit_id
    };
  });
}

// lib/util/get-pcb-trace-length.ts
var getPcbTraceLength = (trace) => {
  if (trace.trace_length !== void 0) return trace.trace_length;
  let length = 0;
  let previousEnd;
  for (const point2 of trace.route) {
    const start = point2.route_type === "through_pad" ? point2.start : point2;
    if (previousEnd)
      length += Math.hypot(start.x - previousEnd.x, start.y - previousEnd.y);
    if (point2.route_type === "via") length += 1.6;
    if (point2.route_type === "through_pad") {
      length += Math.hypot(
        point2.end.x - point2.start.x,
        point2.end.y - point2.start.y
      );
      previousEnd = point2.end;
    } else {
      previousEnd = point2;
    }
  }
  return length;
};

// lib/check-pcb-trace-lengths.ts
var getReferencedPcbPortIds = (pcbTrace) => {
  const pcbPortIds = /* @__PURE__ */ new Set();
  for (const routePoint of pcbTrace.route) {
    if (routePoint.route_type !== "wire") continue;
    if (routePoint.start_pcb_port_id) {
      pcbPortIds.add(routePoint.start_pcb_port_id);
    }
    if (routePoint.end_pcb_port_id) {
      pcbPortIds.add(routePoint.end_pcb_port_id);
    }
  }
  return pcbPortIds;
};
var getPcbTracesBySourceTraceId = (circuitJson) => {
  const sourceTraces = circuitJson.filter(
    (element) => element.type === "source_trace"
  );
  const pcbTraces = circuitJson.filter(
    (element) => element.type === "pcb_trace"
  );
  const pcbPorts = circuitJson.filter(
    (element) => element.type === "pcb_port"
  );
  const pcbPortIdsBySourcePortId = /* @__PURE__ */ new Map();
  for (const pcbPort of pcbPorts) {
    if (!pcbPort.source_port_id) continue;
    const pcbPortIds = pcbPortIdsBySourcePortId.get(pcbPort.source_port_id) ?? /* @__PURE__ */ new Set();
    pcbPortIds.add(pcbPort.pcb_port_id);
    pcbPortIdsBySourcePortId.set(pcbPort.source_port_id, pcbPortIds);
  }
  const pcbTracesBySourceTraceId = /* @__PURE__ */ new Map();
  for (const pcbTrace of pcbTraces) {
    if (!pcbTrace.source_trace_id) continue;
    const matchingPcbTraces = pcbTracesBySourceTraceId.get(pcbTrace.source_trace_id) ?? [];
    matchingPcbTraces.push(pcbTrace);
    pcbTracesBySourceTraceId.set(pcbTrace.source_trace_id, matchingPcbTraces);
  }
  const exactEndpointPcbTraceIdsBySourceTraceId = /* @__PURE__ */ new Map();
  for (const sourceTrace of sourceTraces) {
    if (sourceTrace.connected_source_port_ids.length !== 2) continue;
    const endpointPcbPortIds = sourceTrace.connected_source_port_ids.map(
      (sourcePortId) => pcbPortIdsBySourcePortId.get(sourcePortId)
    );
    if (endpointPcbPortIds.some((pcbPortIds) => !pcbPortIds?.size)) continue;
    const exactEndpointPcbTraceIds = new Set(
      (pcbTracesBySourceTraceId.get(sourceTrace.source_trace_id) ?? []).filter((pcbTrace) => {
        const referencedPcbPortIds = getReferencedPcbPortIds(pcbTrace);
        return endpointPcbPortIds.every(
          (pcbPortIds) => [...pcbPortIds].some(
            (pcbPortId) => referencedPcbPortIds.has(pcbPortId)
          )
        );
      }).map((pcbTrace) => pcbTrace.pcb_trace_id)
    );
    if (exactEndpointPcbTraceIds.size > 0) {
      exactEndpointPcbTraceIdsBySourceTraceId.set(
        sourceTrace.source_trace_id,
        exactEndpointPcbTraceIds
      );
    }
  }
  for (const [id, exactIds] of exactEndpointPcbTraceIdsBySourceTraceId) {
    pcbTracesBySourceTraceId.set(
      id,
      pcbTracesBySourceTraceId.get(id).filter((trace) => exactIds.has(trace.pcb_trace_id))
    );
  }
  return pcbTracesBySourceTraceId;
};
var checkPcbTraceLengths = (circuitJson) => {
  const sourceTracesById = new Map(
    circuitJson.filter((e) => e.type === "source_trace").map((e) => [e.source_trace_id, e])
  );
  const pcbTracesBySourceTraceId = getPcbTracesBySourceTraceId(circuitJson);
  const errors = [];
  for (const [sourceTraceId, pcbTraces] of pcbTracesBySourceTraceId) {
    const pcbTrace = pcbTraces[0];
    const sourceTrace = sourceTracesById.get(sourceTraceId);
    if (!sourceTrace) continue;
    const maximumTraceLength = sourceTrace.max_length;
    if (typeof maximumTraceLength !== "number") continue;
    const actualTraceLength = pcbTraces.reduce(
      (sum, trace) => sum + getPcbTraceLength(trace),
      0
    );
    if (actualTraceLength <= maximumTraceLength + 1e-9) continue;
    errors.push({
      type: "pcb_trace_too_long_error",
      pcb_trace_too_long_error_id: `pcb_trace_too_long_error_${pcbTrace.pcb_trace_id}`,
      error_type: "pcb_trace_too_long_error",
      message: `PCB trace is ${actualTraceLength.toFixed(2)}mm long, exceeding the ${maximumTraceLength}mm maximum`,
      pcb_trace_id: pcbTrace.pcb_trace_id,
      source_trace_id: sourceTrace.source_trace_id,
      source_net_id: sourceTrace.connected_source_net_ids[0],
      actual_trace_length: actualTraceLength,
      maximum_trace_length: maximumTraceLength,
      subcircuit_id: pcbTrace.subcircuit_id ?? sourceTrace.subcircuit_id
    });
  }
  return errors;
};

// lib/check-pcb-trace-via-counts.ts
var checkPcbTraceViaCounts = (circuitJson) => {
  const sourceTraces = circuitJson.filter(
    (element) => element.type === "source_trace"
  );
  const pcbTraces = circuitJson.filter(
    (element) => element.type === "pcb_trace"
  );
  const pcbPorts = circuitJson.filter(
    (element) => element.type === "pcb_port"
  );
  const errors = [];
  for (const sourceTrace of sourceTraces) {
    const maximumViaCount = sourceTrace.max_via_count;
    if (typeof maximumViaCount !== "number") continue;
    const routedPcbTraces = pcbTraces.filter(
      (pcbTrace) => pcbTrace.source_trace_id === sourceTrace.source_trace_id
    );
    if (routedPcbTraces.length === 0) continue;
    const actualViaCount = routedPcbTraces.reduce(
      (viaCount, pcbTrace) => viaCount + pcbTrace.route.filter((routePoint) => routePoint.route_type === "via").length,
      0
    );
    if (actualViaCount <= maximumViaCount) continue;
    const connectedPcbPorts = pcbPorts.filter(
      (pcbPort) => pcbPort.source_port_id !== void 0 && sourceTrace.connected_source_port_ids.includes(pcbPort.source_port_id)
    );
    errors.push({
      type: "pcb_trace_error",
      pcb_trace_error_id: `max_via_count_exceeded_${sourceTrace.source_trace_id}`,
      error_type: "pcb_trace_error",
      message: `PCB trace uses ${actualViaCount} vias, exceeding the ${maximumViaCount} maximum`,
      pcb_trace_id: routedPcbTraces[0].pcb_trace_id,
      source_trace_id: sourceTrace.source_trace_id,
      pcb_component_ids: [
        ...new Set(
          connectedPcbPorts.map((pcbPort) => pcbPort.pcb_component_id).filter(
            (pcbComponentId) => pcbComponentId !== void 0
          )
        )
      ],
      pcb_port_ids: connectedPcbPorts.map((pcbPort) => pcbPort.pcb_port_id),
      subcircuit_id: routedPcbTraces[0].subcircuit_id ?? sourceTrace.subcircuit_id
    });
  }
  return errors;
};

// lib/check-pad-pad-clearance.ts
import { getPrimaryId as getPrimaryId10 } from "@tscircuit/circuit-json-util";
import { formatMm } from "format-si-unit";
import {
  getFullConnectivityMapFromCircuitJson as getFullConnectivityMapFromCircuitJson11
} from "circuit-json-to-connectivity-map";
function checkPadPadClearance(circuitJson, {
  connMap,
  minClearance
} = {}) {
  const pads = getPads(circuitJson);
  if (pads.length < 2) return [];
  const board = getPcbBoard(circuitJson);
  minClearance ??= getBoardDrcValue(board, "min_pad_edge_to_pad_edge_clearance") ?? jlcMinTolerances.min_pad_edge_to_pad_edge_clearance;
  connMap ??= getFullConnectivityMapFromCircuitJson11(circuitJson);
  const spatialIndex = new SpatialObjectIndex({
    objects: pads,
    getBounds: getPadBounds,
    getId: (pad) => getPrimaryId10(pad)
  });
  const errors = /* @__PURE__ */ new Map();
  for (const padA of pads) {
    const padAId = getPrimaryId10(padA);
    const nearbyPads = spatialIndex.getObjectsInBounds(
      getPadBounds(padA),
      minClearance
    );
    for (const padB of nearbyPads) {
      const padBId = getPrimaryId10(padB);
      if (padAId === padBId) continue;
      if (!getLayersOfPcbElement(padA).some(
        (layer) => getLayersOfPcbElement(padB).includes(layer)
      )) {
        continue;
      }
      if (connMap.areIdsConnected(padAId, padBId)) continue;
      const pairId = [padAId, padBId].sort().join("_");
      const gap = getPadToPadGap(padA, padB);
      if (gap + EPSILON >= minClearance) continue;
      const centerA = getPadCenter(padA);
      const centerB = getPadCenter(padB);
      const nextError = {
        type: "pcb_pad_pad_clearance_error",
        pcb_pad_pad_clearance_error_id: `pad_pad_clearance_${pairId}`,
        error_type: "pcb_pad_pad_clearance_error",
        message: `Pads ${getReadableNameForElementId(circuitJson, padAId)} and ${getReadableNameForElementId(circuitJson, padBId)} are too close (clearance: ${formatMm(gap)}, minimum: ${formatMm(minClearance)})`,
        pcb_pad_ids: [padAId, padBId],
        minimum_clearance: minClearance,
        actual_clearance: gap,
        center: {
          x: (centerA.x + centerB.x) / 2,
          y: (centerA.y + centerB.y) / 2
        }
      };
      if (!errors.has(pairId)) {
        errors.set(pairId, nextError);
      }
    }
  }
  return Array.from(errors.values());
}

// lib/check-pad-trace-clearance.ts
import { getPrimaryId as getPrimaryId11 } from "@tscircuit/circuit-json-util";
import { formatMm as formatMm2 } from "format-si-unit";
import {
  getFullConnectivityMapFromCircuitJson as getFullConnectivityMapFromCircuitJson12
} from "circuit-json-to-connectivity-map";
function checkPadTraceClearance(circuitJson, {
  connMap,
  minClearance
} = {}) {
  const pads = getPads(circuitJson);
  const segments = getTraceSegments(circuitJson);
  if (pads.length === 0 || segments.length === 0) return [];
  const board = getPcbBoard(circuitJson);
  minClearance ??= getBoardDrcValue(board, "min_trace_to_pad_edge_clearance") ?? jlcMinTolerances.min_trace_to_pad_edge_clearance;
  connMap ??= getFullConnectivityMapFromCircuitJson12(circuitJson);
  const spatialIndex = new SpatialObjectIndex({
    objects: pads,
    getBounds: getPadBounds,
    getId: (pad) => getPrimaryId11(pad)
  });
  const errors = /* @__PURE__ */ new Map();
  const overlappingPairIds = /* @__PURE__ */ new Set();
  for (const segment of segments) {
    const nearbyPads = spatialIndex.getObjectsInBounds(
      getCollidableBounds(segment),
      minClearance + segment.thickness / 2
    );
    for (const pad of nearbyPads) {
      const padId = getPrimaryId11(pad);
      if (!getLayersOfPcbElement(pad).includes(segment.layer)) continue;
      if (connMap.areIdsConnected(segment.pcb_trace_id, padId)) continue;
      const pairId = `${padId}_${segment.pcb_trace_id}`;
      const { gap, center } = getTraceObstacleClearance(segment, pad);
      if (isTraceObstacleOverlap(gap)) {
        errors.delete(pairId);
        overlappingPairIds.add(pairId);
        continue;
      }
      if (overlappingPairIds.has(pairId)) continue;
      if (gap + EPSILON >= minClearance) continue;
      const nextError = {
        type: "pcb_pad_trace_clearance_error",
        pcb_pad_trace_clearance_error_id: `pad_trace_clearance_${pairId}`,
        error_type: "pcb_pad_trace_clearance_error",
        message: `Pad ${getReadableNameForElementId(circuitJson, padId)} and trace ${getReadableNameForElementId(circuitJson, segment.pcb_trace_id)} are too close (clearance: ${formatMm2(gap)}, minimum: ${formatMm2(minClearance)})`,
        pcb_pad_id: padId,
        pcb_trace_id: segment.pcb_trace_id,
        minimum_clearance: minClearance,
        actual_clearance: gap,
        center
      };
      const current = errors.get(pairId);
      if (!current || gap < current.gap) {
        errors.set(pairId, { error: nextError, gap });
      }
    }
  }
  return Array.from(errors.values()).map(({ error }) => error);
}

// lib/check-via-trace-clearance.ts
import { formatMm as formatMm3 } from "format-si-unit";
import {
  getFullConnectivityMapFromCircuitJson as getFullConnectivityMapFromCircuitJson13
} from "circuit-json-to-connectivity-map";
function checkViaTraceClearance(circuitJson, {
  connMap,
  minClearance
} = {}) {
  const vias = circuitJson.filter((el) => el.type === "pcb_via");
  const segments = getTraceSegments(circuitJson).map((segment) => ({
    ...segment,
    minX: Math.min(segment.x1, segment.x2),
    maxX: Math.max(segment.x1, segment.x2),
    minY: Math.min(segment.y1, segment.y2),
    maxY: Math.max(segment.y1, segment.y2),
    radius: Math.max(0, segment.thickness / 2),
    finiteBounds: Number.isFinite(segment.x1) && Number.isFinite(segment.x2) && Number.isFinite(segment.y1) && Number.isFinite(segment.y2) && Number.isFinite(segment.thickness)
  }));
  if (vias.length === 0 || segments.length === 0) return [];
  const board = getPcbBoard(circuitJson);
  minClearance ??= getBoardDrcValue(board, "min_trace_to_pad_edge_clearance") ?? jlcMinTolerances.min_trace_to_pad_edge_clearance;
  connMap ??= getFullConnectivityMapFromCircuitJson13(circuitJson);
  const errors = /* @__PURE__ */ new Map();
  const overlappingPairIds = /* @__PURE__ */ new Set();
  for (const via of vias) {
    const layers = getLayersOfPcbElement(via);
    const finiteBounds = Number.isFinite(via.x) && Number.isFinite(via.y) && Number.isFinite(via.outer_diameter) && Number.isFinite(minClearance);
    const radius = Math.max(0, via.outer_diameter / 2) + Math.max(0, minClearance) + EPSILON;
    for (const segment of segments) {
      const expansion = radius + segment.radius;
      if (finiteBounds && segment.finiteBounds && (via.x < segment.minX - expansion || via.x > segment.maxX + expansion || via.y < segment.minY - expansion || via.y > segment.maxY + expansion))
        continue;
      if (!layers.includes(segment.layer)) continue;
      if (connMap.areIdsConnected(segment.pcb_trace_id, via.pcb_via_id))
        continue;
      const pairId = `${via.pcb_via_id}_${segment.pcb_trace_id}`;
      const { gap, center } = getTraceObstacleClearance(segment, via);
      if (isTraceObstacleOverlap(gap)) {
        errors.delete(pairId);
        overlappingPairIds.add(pairId);
        continue;
      }
      if (overlappingPairIds.has(pairId)) continue;
      if (gap + EPSILON >= minClearance) continue;
      const nextError = {
        type: "pcb_via_trace_clearance_error",
        pcb_via_trace_clearance_error_id: `via_trace_clearance_${pairId}`,
        error_type: "pcb_via_trace_clearance_error",
        message: `Via ${getReadableNameForElementId(circuitJson, via.pcb_via_id)} and trace ${getReadableNameForElementId(circuitJson, segment.pcb_trace_id)} are too close (clearance: ${formatMm3(gap)}, minimum: ${formatMm3(minClearance)})`,
        pcb_via_id: via.pcb_via_id,
        pcb_trace_id: segment.pcb_trace_id,
        minimum_clearance: minClearance,
        actual_clearance: gap,
        center
      };
      const current = errors.get(pairId);
      if (!current || gap < current.gap) {
        errors.set(pairId, { error: nextError, gap });
      }
    }
  }
  return Array.from(errors.values()).map(({ error }) => error);
}

// lib/check-via-pad-clearance.ts
import { getPrimaryId as getPrimaryId12 } from "@tscircuit/circuit-json-util";
import { formatMm as formatMm4 } from "format-si-unit";
import {
  getFullConnectivityMapFromCircuitJson as getFullConnectivityMapFromCircuitJson14
} from "circuit-json-to-connectivity-map";
function checkViaPadClearance(circuitJson, {
  connMap,
  minClearance
} = {}) {
  const vias = circuitJson.filter(
    (element) => element.type === "pcb_via"
  );
  const pads = getPads(circuitJson);
  if (vias.length === 0 || pads.length === 0) return [];
  const board = getPcbBoard(circuitJson);
  const requiredClearance = minClearance ?? getBoardDrcValue(board, "min_pad_edge_to_pad_edge_clearance") ?? jlcMinTolerances.min_pad_edge_to_pad_edge_clearance;
  connMap ??= getFullConnectivityMapFromCircuitJson14(circuitJson);
  const padIndex = new SpatialObjectIndex({
    objects: pads,
    getBounds: getPadBounds,
    getId: getPrimaryId12
  });
  const errors = [];
  for (const via of vias) {
    const nearbyPads = padIndex.getObjectsInBounds(
      getPadBounds(via),
      requiredClearance
    );
    for (const pad of nearbyPads) {
      const padId = getPrimaryId12(pad);
      if (!getLayersOfPcbElement(via).some(
        (layer) => getLayersOfPcbElement(pad).includes(layer)
      )) {
        continue;
      }
      if (connMap.areIdsConnected(via.pcb_via_id, padId)) continue;
      const gap = getPadToPadGap(via, pad);
      if (gap + EPSILON >= requiredClearance) continue;
      errors.push({
        type: "pcb_pad_pad_clearance_error",
        pcb_pad_pad_clearance_error_id: `via_pad_clearance_${via.pcb_via_id}_${padId}`,
        error_type: "pcb_pad_pad_clearance_error",
        message: `Via ${getReadableNameForElementId(circuitJson, via.pcb_via_id)} and pad ${getReadableNameForElementId(circuitJson, padId)} are too close (clearance: ${formatMm4(gap)}, minimum: ${formatMm4(requiredClearance)})`,
        pcb_pad_ids: [via.pcb_via_id, padId],
        minimum_clearance: requiredClearance,
        actual_clearance: gap,
        center: getViaPadClearanceCenter(via, pad)
      });
    }
  }
  return errors;
}

// lib/check-vias-in-pads.ts
import { getPrimaryId as getPrimaryId13 } from "@tscircuit/circuit-json-util";

// lib/check-vias-in-pads/does-via-hole-overlap-pad.ts
var GEOMETRY_EPSILON_MM = 1e-9;
function doesViaHoleOverlapPad(via, pad) {
  const { gap } = getTraceObstacleClearance(
    {
      x1: via.x,
      y1: via.y,
      x2: via.x,
      y2: via.y,
      thickness: via.hole_diameter
    },
    pad
  );
  return gap < -GEOMETRY_EPSILON_MM;
}

// lib/check-vias-in-pads.ts
function checkViasInPads(circuitJson) {
  const board = getPcbBoard(circuitJson);
  if (board && "is_via_in_pad_allowed" in board && board.is_via_in_pad_allowed === true) {
    return [];
  }
  const vias = circuitJson.filter(
    (element) => element.type === "pcb_via"
  );
  const pads = getPads(circuitJson);
  if (vias.length === 0 || pads.length === 0) return [];
  const padOrdinals = new Map(
    pads.map((pad, index) => [getPrimaryId13(pad), index])
  );
  const padIndex = new SpatialObjectIndex({
    objects: pads,
    getBounds: getPadBounds,
    getId: getPrimaryId13
  });
  const errors = [];
  for (const via of vias) {
    const nearbyPads = padIndex.getObjectsInBounds(getPadBounds(via));
    for (const pad of nearbyPads) {
      const padId = getPrimaryId13(pad);
      const viaLayers = getLayersOfPcbElement(via);
      const padLayers = getLayersOfPcbElement(pad);
      if (!viaLayers.some((layer) => padLayers.includes(layer))) continue;
      if (!doesViaHoleOverlapPad(via, pad)) continue;
      const padOrdinal = padOrdinals.get(padId) ?? 0;
      const padName = getReadableNameForFootprintPad(
        circuitJson,
        pad,
        padOrdinal
      );
      errors.push({
        type: "pcb_placement_error",
        pcb_placement_error_id: `via_in_pad_${via.pcb_via_id}_${padId}`,
        error_type: "pcb_placement_error",
        message: `Via hole at (${via.x.toFixed(2)}mm, ${via.y.toFixed(2)}mm) overlaps ${padName}`,
        subcircuit_id: via.subcircuit_id ?? pad.subcircuit_id
      });
    }
  }
  return errors;
}

// lib/dedupe-pcb-drc-errors.ts
var dedupePcbDrcErrors = (errors) => {
  const specificallyReportedPairIds = /* @__PURE__ */ new Set();
  for (const error of errors) {
    if (error.type === "pcb_pad_trace_clearance_error" && typeof error.pcb_trace_id === "string" && typeof error.pcb_pad_id === "string") {
      specificallyReportedPairIds.add(
        `overlap_${error.pcb_trace_id}_${error.pcb_pad_id}`
      );
    }
    if (error.type === "pcb_via_trace_clearance_error" && typeof error.pcb_trace_id === "string" && typeof error.pcb_via_id === "string") {
      specificallyReportedPairIds.add(
        `overlap_${error.pcb_trace_id}_${error.pcb_via_id}`
      );
    }
  }
  return errors.filter((element) => {
    const error = element;
    return !(error.type === "pcb_trace_error" && typeof error.pcb_trace_error_id === "string" && specificallyReportedPairIds.has(error.pcb_trace_error_id));
  });
};

// lib/check-pin-must-be-connected.ts
function checkPinMustBeConnected(circuitJson) {
  const errors = [];
  const sourceComponents = circuitJson.filter(
    (el) => "source_component_id" in el && (el.type === "source_component" || el.type.startsWith("source_simple_"))
  );
  const sourcePorts = circuitJson.filter(
    (el) => el.type === "source_port"
  );
  const sourceTraces = circuitJson.filter(
    (el) => el.type === "source_trace"
  );
  const connectedPortIds = /* @__PURE__ */ new Set();
  for (const trace of sourceTraces) {
    for (const portId of trace.connected_source_port_ids ?? []) {
      connectedPortIds.add(portId);
    }
  }
  const componentInternalConnections = /* @__PURE__ */ new Map();
  for (const component of sourceComponents) {
    if ("internally_connected_source_port_ids" in component && component.internally_connected_source_port_ids) {
      componentInternalConnections.set(
        component.source_component_id,
        component.internally_connected_source_port_ids
      );
    }
  }
  for (const internalGroups of componentInternalConnections.values()) {
    for (const group of internalGroups) {
      if (group.some((portId) => connectedPortIds.has(portId))) {
        for (const portId of group) {
          connectedPortIds.add(portId);
        }
      }
    }
  }
  for (const port of sourcePorts) {
    if (port.must_be_connected === true) {
      if (!connectedPortIds.has(port.source_port_id)) {
        const component = sourceComponents.find(
          (c) => c.source_component_id === port.source_component_id
        );
        const componentName = component?.name ?? "Unknown";
        errors.push({
          type: "source_pin_must_be_connected_error",
          source_pin_must_be_connected_error_id: `source_pin_must_be_connected_error_${port.source_port_id}`,
          error_type: "source_pin_must_be_connected_error",
          message: `Port ${port.name} on ${componentName} must be connected but is floating`,
          source_component_id: port.source_component_id ?? "",
          source_port_id: port.source_port_id,
          subcircuit_id: port.subcircuit_id
        });
      }
    }
  }
  return errors;
}

// lib/check-source-pin-voltage-compatibility.ts
import {
  source_component_misconfigured_error,
  voltage
} from "circuit-json";
import { getSourcePortConnectivityMapFromCircuitJson } from "circuit-json-to-connectivity-map";
var parseScalarVoltage = (value) => {
  if (value === void 0) return void 0;
  if (typeof value === "string" && !/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?\s*(?:[pnumkKMGTµμ]?V)?$/i.test(
    value.trim()
  ))
    return void 0;
  try {
    const volts = voltage.parse(value);
    return Number.isFinite(volts) ? volts : void 0;
  } catch {
    return void 0;
  }
};
function checkSourcePinVoltageCompatibility(circuitJson) {
  const connectivity = getSourcePortConnectivityMapFromCircuitJson(circuitJson);
  const sourcePorts = circuitJson.filter(
    (element) => element.type === "source_port"
  );
  const suppliesByNet = /* @__PURE__ */ new Map();
  for (const sourcePort of sourcePorts) {
    const volts = parseScalarVoltage(sourcePort.provides_voltage);
    if (volts === void 0) continue;
    const net = connectivity.getNetConnectedToId(sourcePort.source_port_id);
    if (net === void 0) continue;
    const supplies = suppliesByNet.get(net) ?? [];
    supplies.push({ sourcePort, volts });
    suppliesByNet.set(net, supplies);
  }
  const errors = [];
  for (const consumerPort of sourcePorts) {
    const requiredVolts = parseScalarVoltage(consumerPort.requires_voltage);
    if (requiredVolts === void 0) continue;
    const net = connectivity.getNetConnectedToId(consumerPort.source_port_id);
    if (net === void 0) continue;
    for (const supply of suppliesByNet.get(net) ?? []) {
      if (supply.sourcePort.source_port_id === consumerPort.source_port_id)
        continue;
      if (Math.abs(supply.volts - requiredVolts) <= 1e-9 * Math.max(1, Math.abs(supply.volts), Math.abs(requiredVolts)))
        continue;
      errors.push(
        source_component_misconfigured_error.parse({
          type: "source_component_misconfigured_error",
          message: `${getReadableNameForSourcePort(circuitJson, consumerPort)} requires ${requiredVolts} V, but is connected to ${getReadableNameForSourcePort(circuitJson, supply.sourcePort)}, which provides ${supply.volts} V.`,
          source_component_ids: [
            ...new Set(
              [
                consumerPort.source_component_id,
                supply.sourcePort.source_component_id
              ].filter((id) => id !== void 0)
            )
          ],
          source_port_ids: [
            consumerPort.source_port_id,
            supply.sourcePort.source_port_id
          ],
          is_fatal: true
        })
      );
    }
  }
  return errors;
}

// lib/check-two-terminal-switch-contacts-on-different-nets.ts
import {
  source_component_misconfigured_error as source_component_misconfigured_error2
} from "circuit-json";
function checkTwoTerminalSwitchContactsOnDifferentNets(circuitJson) {
  const switchingComponents = circuitJson.filter(
    (element) => element.type === "source_component" && (element.ftype === "simple_push_button" || element.ftype === "simple_switch")
  );
  const sourcePorts = circuitJson.filter(
    (element) => element.type === "source_port"
  );
  const schematicPorts = circuitJson.filter(
    (element) => element.type === "schematic_port"
  );
  const errors = [];
  for (const switchingComponent of switchingComponents) {
    const schematicContactSourcePorts = schematicPorts.flatMap(
      (schematicPort) => {
        const sourcePort = sourcePorts.find(
          (sourcePort2) => sourcePort2.source_port_id === schematicPort.source_port_id && sourcePort2.source_component_id === switchingComponent.source_component_id
        );
        if (!sourcePort) return [];
        return [sourcePort];
      }
    );
    if (schematicContactSourcePorts.length !== 2) continue;
    const firstContactConnectivityKey = schematicContactSourcePorts[0].subcircuit_connectivity_map_key;
    const secondContactConnectivityKey = schematicContactSourcePorts[1].subcircuit_connectivity_map_key;
    if (!firstContactConnectivityKey) continue;
    if (firstContactConnectivityKey !== secondContactConnectivityKey) continue;
    errors.push(
      source_component_misconfigured_error2.parse({
        type: "source_component_misconfigured_error",
        message: `Switch ${switchingComponent.name} has both schematic contacts connected to the same net. Check internallyConnectedPins and the footprint pin mapping.`,
        source_component_ids: [switchingComponent.source_component_id],
        source_port_ids: schematicContactSourcePorts.map(
          (sourcePort) => sourcePort.source_port_id
        ),
        is_fatal: true
      })
    );
  }
  return errors;
}

// lib/check-all-pins-in-component-are-underspecified.ts
import { cju as cju8 } from "@tscircuit/circuit-json-util";
var PIN_ATTRIBUTE_KEYS = [
  "is_input",
  "is_output",
  "is_bidirectional",
  "is_passive",
  "must_be_connected",
  "provides_power",
  "requires_power",
  "provides_ground",
  "requires_ground",
  "provides_voltage",
  "requires_voltage",
  "do_not_connect",
  "include_in_board_pinout",
  "can_use_internal_pullup",
  "is_using_internal_pullup",
  "needs_external_pullup",
  "can_use_internal_pulldown",
  "is_using_internal_pulldown",
  "needs_external_pulldown",
  "can_use_open_drain",
  "is_using_open_drain",
  "can_use_push_pull",
  "is_using_push_pull",
  "should_have_decoupling_capacitor",
  "recommended_decoupling_capacitor_capacitance",
  "is_configured_for_i2c_sda",
  "is_configured_for_i2c_scl",
  "is_configured_for_spi_mosi",
  "is_configured_for_spi_miso",
  "is_configured_for_spi_sck",
  "is_configured_for_spi_cs",
  "is_configured_for_uart_tx",
  "is_configured_for_uart_rx",
  "supports_i2c_sda",
  "supports_i2c_scl",
  "supports_spi_mosi",
  "supports_spi_miso",
  "supports_spi_sck",
  "supports_spi_cs",
  "supports_uart_tx",
  "supports_uart_rx"
];
function hasAnyPinAttribute(port) {
  return PIN_ATTRIBUTE_KEYS.some((key) => port[key] !== void 0);
}
function checkAllPinsInComponentAreUnderspecified(circuitJson) {
  const warnings = [];
  const db = cju8(circuitJson);
  const sourceComponents = db.source_component.list();
  const sourcePorts = db.source_port.list();
  const portsByComponent = /* @__PURE__ */ new Map();
  for (const port of sourcePorts) {
    if (!port.source_component_id) continue;
    const existing = portsByComponent.get(port.source_component_id) ?? [];
    existing.push(port);
    portsByComponent.set(port.source_component_id, existing);
  }
  for (const component of sourceComponents) {
    if (component.ftype !== "simple_chip") continue;
    const componentPorts = portsByComponent.get(component.source_component_id) ?? [];
    if (componentPorts.length === 0) continue;
    const hasAnySpecifiedAttributes = componentPorts.some(
      (port) => hasAnyPinAttribute(port)
    );
    if (hasAnySpecifiedAttributes) continue;
    warnings.push({
      type: "source_component_pins_underspecified_warning",
      source_component_pins_underspecified_warning_id: `source_component_pins_underspecified_warning_${component.source_component_id}`,
      warning_type: "source_component_pins_underspecified_warning",
      message: `All pins on ${component.name} are underspecified (no pinAttributes set)`,
      source_component_id: component.source_component_id,
      source_port_ids: componentPorts.map((port) => port.source_port_id),
      subcircuit_id: componentPorts[0]?.subcircuit_id
    });
  }
  return warnings;
}

// lib/check-no-power-pin-defined.ts
import { cju as cju9 } from "@tscircuit/circuit-json-util";

// lib/util/should-check-chip-power-ground-pins.ts
var shouldCheckChipPowerGroundPins = (component, ports) => component.ftype === "simple_chip" && ports.filter((port) => port.do_not_connect !== true).length >= 2;

// lib/check-no-power-pin-defined.ts
function checkNoPowerPinDefined(circuitJson) {
  const warnings = [];
  const db = cju9(circuitJson);
  const sourceComponents = db.source_component.list();
  const sourcePorts = db.source_port.list();
  const portsByComponent = /* @__PURE__ */ new Map();
  for (const port of sourcePorts) {
    if (!port.source_component_id) continue;
    const existing = portsByComponent.get(port.source_component_id) ?? [];
    existing.push(port);
    portsByComponent.set(port.source_component_id, existing);
  }
  for (const component of sourceComponents) {
    const componentPorts = portsByComponent.get(component.source_component_id) ?? [];
    if (!shouldCheckChipPowerGroundPins(component, componentPorts)) continue;
    const allConnectablePinsPassive = componentPorts.filter((port) => port.do_not_connect !== true).every((port) => port.is_passive === true);
    if (allConnectablePinsPassive) continue;
    const hasRequiredPowerPin = componentPorts.some(
      (port) => port.requires_power === true
    );
    if (hasRequiredPowerPin) continue;
    warnings.push({
      type: "source_no_power_pin_defined_warning",
      source_no_power_pin_defined_warning_id: `source_no_power_pin_defined_warning_${component.source_component_id}`,
      warning_type: "source_no_power_pin_defined_warning",
      message: `${component.name} has no pin with requires_power=true`,
      source_component_id: component.source_component_id,
      source_port_ids: componentPorts.map((port) => port.source_port_id),
      subcircuit_id: componentPorts[0]?.subcircuit_id
    });
  }
  return warnings;
}

// lib/check-no-ground-pin-defined.ts
import { cju as cju10 } from "@tscircuit/circuit-json-util";
function checkNoGroundPinDefined(circuitJson) {
  const warnings = [];
  const db = cju10(circuitJson);
  const sourceComponents = db.source_component.list();
  const sourcePorts = db.source_port.list();
  const portsByComponent = /* @__PURE__ */ new Map();
  for (const port of sourcePorts) {
    if (!port.source_component_id) continue;
    const existing = portsByComponent.get(port.source_component_id) ?? [];
    existing.push(port);
    portsByComponent.set(port.source_component_id, existing);
  }
  for (const component of sourceComponents) {
    const componentPorts = portsByComponent.get(component.source_component_id) ?? [];
    if (!shouldCheckChipPowerGroundPins(component, componentPorts)) continue;
    const allConnectablePinsPassive = componentPorts.filter((port) => port.do_not_connect !== true).every((port) => port.is_passive === true);
    if (allConnectablePinsPassive) continue;
    const hasRequiredGroundPin = componentPorts.some(
      (port) => port.requires_ground === true
    );
    if (hasRequiredGroundPin) continue;
    warnings.push({
      type: "source_no_ground_pin_defined_warning",
      source_no_ground_pin_defined_warning_id: `source_no_ground_pin_defined_warning_${component.source_component_id}`,
      warning_type: "source_no_ground_pin_defined_warning",
      message: `${component.name} has no pin with requires_ground=true`,
      source_component_id: component.source_component_id,
      source_port_ids: componentPorts.map((port) => port.source_port_id),
      subcircuit_id: componentPorts[0]?.subcircuit_id
    });
  }
  return warnings;
}

// lib/check-schematic-component-excessive-vertical-padding.ts
var DEFAULT_PIN_SPACING = 0.2;
var MAX_VERTICAL_PADDING_IN_PIN_SPACINGS = 3;
var FLOATING_POINT_TOLERANCE = 1e-9;
function checkSchematicComponentExcessiveVerticalPadding(circuitJson) {
  const schematicComponents = circuitJson.filter(
    (element) => element.type === "schematic_component"
  );
  const schematicPorts = circuitJson.filter(
    (element) => element.type === "schematic_port"
  );
  const portsByComponentId = /* @__PURE__ */ new Map();
  for (const port of schematicPorts) {
    if (!port.schematic_component_id) continue;
    const componentPorts = portsByComponentId.get(port.schematic_component_id) ?? [];
    componentPorts.push(port);
    portsByComponentId.set(port.schematic_component_id, componentPorts);
  }
  const warnings = [];
  for (const component of schematicComponents) {
    if (!component.is_box_with_pins || component.size.height <= 0) continue;
    const sidePorts = (portsByComponentId.get(component.schematic_component_id) ?? []).filter(
      (port) => port.side_of_component === "left" || port.side_of_component === "right"
    );
    if (sidePorts.length < 2) continue;
    const pinYs = sidePorts.map((port) => port.center.y);
    const highestPinY = Math.max(...pinYs);
    const lowestPinY = Math.min(...pinYs);
    const componentTopY = component.center.y + component.size.height / 2;
    const componentBottomY = component.center.y - component.size.height / 2;
    const pinSpacing = component.pin_spacing ?? DEFAULT_PIN_SPACING;
    const maximumPadding = pinSpacing * MAX_VERTICAL_PADDING_IN_PIN_SPACINGS;
    const paddingBySide = {
      top: componentTopY - highestPinY,
      bottom: lowestPinY - componentBottomY
    };
    const componentName = getReadableNameForElementId(
      circuitJson,
      component.schematic_component_id
    );
    for (const side of ["top", "bottom"]) {
      const padding = paddingBySide[side];
      if (padding <= maximumPadding + FLOATING_POINT_TOLERANCE || padding <= 0) {
        continue;
      }
      const relativePosition = side === "top" ? "above" : "below";
      const stylingIssueType = `excessive_${side}_padding`;
      warnings.push({
        type: "schematic_component_styling_warning",
        schematic_component_styling_warning_id: `schematic_component_styling_warning_${component.schematic_component_id}_${stylingIssueType}`,
        warning_type: "schematic_component_styling_warning",
        message: `${componentName} has excessive empty space ${relativePosition} its pins (${padding.toFixed(2)}mm, more than ${MAX_VERTICAL_PADDING_IN_PIN_SPACINGS} pin spacings)`,
        schematic_component_id: component.schematic_component_id,
        styling_issue_type: stylingIssueType,
        schematic_port_ids: sidePorts.map((port) => port.schematic_port_id),
        source_component_id: component.source_component_id,
        schematic_sheet_id: component.schematic_sheet_id,
        subcircuit_id: component.subcircuit_id
      });
    }
  }
  return warnings;
}

// lib/check-schematic-component-missing-reference-designator-text.ts
var isFallbackReferenceDesignator = (name) => /^unnamed_[a-z0-9_-]+\d+$/i.test(name);
var isTextWithinComponentBounds = (schematicText, schematicComponent) => {
  const { center, size } = schematicComponent;
  const tolerance = 1e-9;
  return schematicText.position.x >= center.x - size.width / 2 - tolerance && schematicText.position.x <= center.x + size.width / 2 + tolerance && schematicText.position.y >= center.y - size.height / 2 - tolerance && schematicText.position.y <= center.y + size.height / 2 + tolerance;
};
function checkSchematicComponentMissingReferenceDesignatorText(circuitJson) {
  const schematicComponents = circuitJson.filter(
    (element) => element.type === "schematic_component"
  );
  const sourceComponents = circuitJson.filter(
    (element) => element.type === "source_component"
  );
  const schematicTexts = circuitJson.filter(
    (element) => element.type === "schematic_text"
  );
  const sourceComponentById = new Map(
    sourceComponents.map((component) => [
      component.source_component_id,
      component
    ])
  );
  const textBySchematicComponentId = /* @__PURE__ */ new Map();
  const customSymbolTexts = [];
  for (const schematicText of schematicTexts) {
    if (!schematicText.schematic_component_id) {
      if (schematicText.schematic_symbol_id) {
        customSymbolTexts.push(schematicText);
      }
      continue;
    }
    const componentTexts = textBySchematicComponentId.get(schematicText.schematic_component_id) ?? /* @__PURE__ */ new Set();
    componentTexts.add(schematicText.text.trim());
    textBySchematicComponentId.set(
      schematicText.schematic_component_id,
      componentTexts
    );
  }
  const warnings = [];
  for (const schematicComponent of schematicComponents) {
    if (schematicComponent.symbol_name) continue;
    if (schematicComponent.is_box_with_pins) continue;
    if (!schematicComponent.source_component_id) continue;
    const sourceComponent = sourceComponentById.get(
      schematicComponent.source_component_id
    );
    if (!sourceComponent) continue;
    const referenceDesignators = new Set(
      [sourceComponent.name, sourceComponent.display_name].map((name) => name?.trim()).filter((name) => Boolean(name))
    );
    const nonFallbackReferenceDesignator = [...referenceDesignators].find(
      (referenceDesignator) => !isFallbackReferenceDesignator(referenceDesignator)
    );
    const componentTexts = textBySchematicComponentId.get(
      schematicComponent.schematic_component_id
    );
    const hasReferenceDesignatorText = [...referenceDesignators].some(
      (referenceDesignator) => componentTexts?.has(referenceDesignator)
    ) || customSymbolTexts.some(
      (schematicText) => referenceDesignators.has(schematicText.text.trim()) && isTextWithinComponentBounds(schematicText, schematicComponent)
    );
    if (nonFallbackReferenceDesignator && hasReferenceDesignatorText) {
      continue;
    }
    const readableComponentName = nonFallbackReferenceDesignator ?? "Schematic component";
    warnings.push({
      type: "schematic_component_styling_warning",
      schematic_component_styling_warning_id: `schematic_component_styling_warning_${schematicComponent.schematic_component_id}_missing_reference_designator_text`,
      warning_type: "schematic_component_styling_warning",
      message: `${readableComponentName} is missing schematic reference designator text. For a custom symbol, add name="{REFDES}" inside the symbol.`,
      schematic_component_id: schematicComponent.schematic_component_id,
      styling_issue_type: "missing_reference_designator_text",
      source_component_id: schematicComponent.source_component_id,
      schematic_sheet_id: schematicComponent.schematic_sheet_id,
      subcircuit_id: schematicComponent.subcircuit_id
    });
  }
  return warnings;
}

// lib/check-schematic-component-ports-outside-body.ts
var FLOATING_POINT_TOLERANCE2 = 1e-9;
var getPortLabel = (port) => port.display_pin_label ?? `pin ${port.pin_number}`;
function checkSchematicComponentPortsOutsideBody(circuitJson) {
  const schematicComponents = circuitJson.filter(
    (element) => element.type === "schematic_component"
  );
  const schematicPorts = circuitJson.filter(
    (element) => element.type === "schematic_port"
  );
  const portsByComponentId = /* @__PURE__ */ new Map();
  for (const port of schematicPorts) {
    if (!port.schematic_component_id) continue;
    const componentPorts = portsByComponentId.get(port.schematic_component_id) ?? [];
    componentPorts.push(port);
    portsByComponentId.set(port.schematic_component_id, componentPorts);
  }
  const warnings = [];
  for (const component of schematicComponents) {
    if (component.is_box_with_pins === false || component.size.width <= 0 || component.size.height <= 0) {
      continue;
    }
    const componentLeftX = component.center.x - component.size.width / 2;
    const componentRightX = component.center.x + component.size.width / 2;
    const componentBottomY = component.center.y - component.size.height / 2;
    const componentTopY = component.center.y + component.size.height / 2;
    const componentPorts = portsByComponentId.get(component.schematic_component_id) ?? [];
    const portsOutsideBody = componentPorts.filter((port) => {
      if (port.side_of_component === "left" || port.side_of_component === "right") {
        return port.center.y < componentBottomY - FLOATING_POINT_TOLERANCE2 || port.center.y > componentTopY + FLOATING_POINT_TOLERANCE2;
      }
      if (port.side_of_component === "top" || port.side_of_component === "bottom") {
        return port.center.x < componentLeftX - FLOATING_POINT_TOLERANCE2 || port.center.x > componentRightX + FLOATING_POINT_TOLERANCE2;
      }
      return false;
    }).sort((portA, portB) => {
      const portAIsVertical = portA.side_of_component === "left" || portA.side_of_component === "right";
      const portBIsVertical = portB.side_of_component === "left" || portB.side_of_component === "right";
      if (portAIsVertical && portBIsVertical) {
        return portB.center.y - portA.center.y;
      }
      if (!portAIsVertical && !portBIsVertical) {
        return portA.center.x - portB.center.x;
      }
      return portAIsVertical ? -1 : 1;
    });
    if (portsOutsideBody.length === 0) continue;
    const requiredHeight = Math.max(
      component.size.height,
      ...portsOutsideBody.filter(
        (port) => port.side_of_component === "left" || port.side_of_component === "right"
      ).map((port) => 2 * Math.abs(port.center.y - component.center.y))
    );
    const requiredWidth = Math.max(
      component.size.width,
      ...portsOutsideBody.filter(
        (port) => port.side_of_component === "top" || port.side_of_component === "bottom"
      ).map((port) => 2 * Math.abs(port.center.x - component.center.x))
    );
    const suggestedDimensionChanges = [];
    if (requiredHeight > component.size.height + FLOATING_POINT_TOLERANCE2) {
      suggestedDimensionChanges.push(
        `increase schHeight to at least ${requiredHeight.toFixed(2)}mm`
      );
    }
    if (requiredWidth > component.size.width + FLOATING_POINT_TOLERANCE2) {
      suggestedDimensionChanges.push(
        `increase schWidth to at least ${requiredWidth.toFixed(2)}mm`
      );
    }
    const componentName = getReadableNameForElementId(
      circuitJson,
      component.schematic_component_id
    );
    const portLabels = portsOutsideBody.map(getPortLabel).join(", ");
    warnings.push({
      type: "schematic_component_styling_warning",
      schematic_component_styling_warning_id: `schematic_component_styling_warning_${component.schematic_component_id}_ports_outside_body`,
      warning_type: "schematic_component_styling_warning",
      message: `${componentName} has schematic pins outside its body (${portLabels}); ${suggestedDimensionChanges.join(" and ")}`,
      schematic_component_id: component.schematic_component_id,
      styling_issue_type: "ports_outside_body",
      schematic_port_ids: portsOutsideBody.map(
        (port) => port.schematic_port_id
      ),
      source_component_id: component.source_component_id,
      schematic_sheet_id: component.schematic_sheet_id,
      subcircuit_id: component.subcircuit_id
    });
  }
  return warnings;
}

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/DiodeCapacitorStagePlacementSolver/DiodeCapacitorStagePlacementSolver.ts
import { BaseSolver } from "@tscircuit/solver-utils";

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/utils/format.ts
var fmtNumber = (value) => {
  if (Number.isInteger(value)) return String(value);
  return value.toFixed(3).replace(/\.0+$/, "").replace(/(\.\d*?)0+$/, "$1");
};
var fmtDelta = (value) => {
  const formatted = fmtNumber(value);
  return value > 0 ? `+${formatted}` : formatted;
};
var escapeAttr = (value) => value.replaceAll("&", "&amp;").replaceAll('"', "&quot;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
var addAttr = (attrs, key, value, options) => {
  if (value === void 0) return;
  const stringValue = typeof value === "number" ? options?.formatDelta ? fmtDelta(value) : fmtNumber(value) : escapeAttr(value);
  attrs.push(`${key}="${stringValue}"`);
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/utils/source-connectivity.ts
function getSourceConnectivity(circuitJson) {
  const parent = /* @__PURE__ */ new Map();
  const find = (id) => {
    const next = parent.get(id);
    if (next === void 0 || next === id) return id;
    const root = find(next);
    parent.set(id, root);
    return root;
  };
  const join = (ids) => {
    const first = ids[0];
    if (!first) return;
    const root = find(first);
    for (const id of ids.slice(1)) parent.set(find(id), root);
  };
  for (const element of circuitJson) {
    if (element.type === "source_port" || element.type === "source_net") {
      const id = element.type === "source_port" ? element.source_port_id : element.source_net_id;
      if (element.subcircuit_connectivity_map_key)
        join([id, `connectivity:${element.subcircuit_connectivity_map_key}`]);
    }
    if (element.type === "source_trace") {
      join([
        ...element.connected_source_port_ids,
        ...element.connected_source_net_ids,
        ...element.subcircuit_connectivity_map_key ? [`connectivity:${element.subcircuit_connectivity_map_key}`] : []
      ]);
    }
    if (element.type === "source_component_internal_connection")
      join(element.source_port_ids);
    if (element.type === "source_component") {
      for (const ids of element.internally_connected_source_port_ids ?? [])
        join(ids);
    }
  }
  return find;
}

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/utils/placement-network-index.ts
var PlacementNetworkIndex = class {
  connected;
  components = /* @__PURE__ */ new Map();
  portsByComponent = /* @__PURE__ */ new Map();
  portsByNet = /* @__PURE__ */ new Map();
  powerNets = /* @__PURE__ */ new Set();
  groundNets = /* @__PURE__ */ new Set();
  placements = /* @__PURE__ */ new Map();
  schematicComponents = /* @__PURE__ */ new Map();
  schematicPorts = /* @__PURE__ */ new Map();
  constructor(ctx) {
    this.connected = getSourceConnectivity(ctx.circuitJson);
    for (const placement of ctx.componentPlacements) {
      if (placement.sourceComponentId)
        append(this.placements, placement.sourceComponentId, placement);
    }
    for (const element of ctx.circuitJson) {
      if (element.type === "source_component")
        this.components.set(element.source_component_id, element);
      if (element.type === "source_port" && element.source_component_id) {
        append(
          this.portsByComponent,
          element.source_component_id,
          element
        );
        append(
          this.portsByNet,
          this.connected(element.source_port_id),
          element
        );
      }
      if (element.type === "source_net") {
        const net = this.connected(element.source_net_id);
        if (element.is_power || element.is_positive_voltage_source)
          this.powerNets.add(net);
        if (element.is_ground) this.groundNets.add(net);
      }
      if (element.type === "schematic_component")
        this.schematicComponents.set(element.schematic_component_id, element);
      if (element.type === "schematic_port" && element.source_port_id)
        append(this.schematicPorts, element.source_port_id, element);
    }
  }
  placement(componentId) {
    const placements = this.placements.get(componentId);
    return placements?.length === 1 ? placements[0] : void 0;
  }
  port(sourcePort) {
    const placement = this.placement(sourcePort.source_component_id);
    const ports = this.schematicPorts.get(sourcePort.source_port_id)?.filter(
      (port) => port.schematic_component_id === placement?.schematicComponentId
    );
    return ports?.length === 1 ? ports[0] : void 0;
  }
  namedPort(componentId, name) {
    const ports = this.portsByComponent.get(componentId)?.filter((port) => port.name === name || port.port_hints?.includes(name));
    return ports?.length === 1 ? ports[0] : void 0;
  }
  twoTerminalNets(componentId) {
    const ports = this.portsByComponent.get(componentId);
    if (ports?.length !== 2) return;
    const first = this.connected(ports[0].source_port_id);
    const second = this.connected(ports[1].source_port_id);
    if (first !== second) return [first, second];
  }
  isRail(net) {
    return this.powerNets.has(net) || this.groundNets.has(net);
  }
  /** Direct feedback may return to either input; grounded output loads do not count. */
  isDirectOpAmpFeedback(componentId) {
    const nets = this.twoTerminalNets(componentId);
    if (!nets || nets.some((net) => this.isRail(net))) return false;
    return nets.some(
      (net) => (this.portsByNet.get(net) ?? []).some((port) => {
        const hostId = port.source_component_id;
        if (this.components.get(hostId)?.ftype !== "simple_op_amp") return false;
        const output = this.namedPort(hostId, "output");
        if (output?.source_port_id !== port.source_port_id) return false;
        return ["inverting_input", "non_inverting_input"].some((name) => {
          const input = this.namedPort(hostId, name);
          if (!input) return false;
          const inputNet = this.connected(input.source_port_id);
          return inputNet !== net && nets.includes(inputNet);
        });
      })
    );
  }
  sameLocalScope(first, second) {
    if (first.schematicSheetId !== second.schematicSheetId || first.subcircuitId !== second.subcircuitId)
      return false;
    const a = this.schematicComponents.get(first.schematicComponentId ?? "");
    const b = this.schematicComponents.get(second.schematicComponentId ?? "");
    if (!a || !b || a.schematic_group_id !== b.schematic_group_id) return false;
    const firstSource = this.components.get(first.sourceComponentId ?? "");
    const secondSource = this.components.get(second.sourceComponentId ?? "");
    return firstSource?.source_group_id === secondSource?.source_group_id && firstSource?.subcircuit_id === secondSource?.subcircuit_id;
  }
};
function append(map, key, value) {
  const values = map.get(key);
  if (values) values.push(value);
  else map.set(key, [value]);
}

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/DiodeCapacitorStagePlacementSolver/DiodeCapacitorStagePlacementSolver.ts
var DiodeCapacitorStagePlacementSolver = class extends BaseSolver {
  constructor(params) {
    super();
    this.params = params;
    this.index = new PlacementNetworkIndex(params.ctx);
    for (const e of params.ctx.circuitJson) {
      if (e.type === "pcb_component" && e.do_not_place)
        this.unpopulated.add(e.source_component_id);
      if (e.type === "source_port") {
        const net = this.index.connected(e.source_port_id);
        if (e.requires_ground || e.provides_ground)
          this.index.groundNets.add(net);
        if (e.requires_power || e.provides_power) this.index.powerNets.add(net);
      }
    }
    this.nets = [...this.index.portsByNet.keys()];
    this.solved = this.nets.length === 0;
  }
  params;
  index;
  nets;
  unpopulated = /* @__PURE__ */ new Set();
  currentIndex = 0;
  _step() {
    const net = this.nets[this.currentIndex++];
    this.solved = this.currentIndex >= this.nets.length;
    if (!net || this.index.isRail(net)) return;
    const index = this.index;
    const junction = index.portsByNet.get(net);
    if (junction.length !== 3 || new Set(junction.map((p) => p.source_component_id)).size !== 3)
      return;
    const parts = junction.map((p) => this.localPart(p.source_component_id));
    if (parts.some((p) => !p)) return;
    const diodes = parts.filter((p) => p.component.ftype === "simple_diode");
    const capacitors = parts.filter(
      (p) => p.component.ftype === "simple_capacitor"
    );
    if (diodes.length !== 2 || capacitors.length !== 1) return;
    const capacitor = capacitors[0];
    const first = diodes[0];
    const second = diodes[1];
    if (![first, second].every(
      (p) => index.sameLocalScope(capacitor.placement, p.placement)
    ))
      return;
    const otherNet = (part) => part.nets.find((n) => n !== net);
    const diodeNets = [otherNet(first), otherNet(second)];
    const grounds = diodeNets.filter((n) => index.groundNets.has(n));
    if (grounds.length !== 1) return;
    const ground = grounds[0];
    const branchNet = diodeNets.find((n) => n !== ground);
    const capacitorNet = otherNet(capacitor);
    if (capacitorNet === branchNet || capacitorNet === ground || index.isRail(capacitorNet))
      return;
    const bankIds = new Set(
      (index.portsByNet.get(branchNet) ?? []).filter(
        (p) => index.components.get(p.source_component_id)?.ftype === "simple_capacitor"
      ).map((p) => p.source_component_id)
    );
    const groundedBank = [...bankIds].filter(
      (id) => index.twoTerminalNets(id)?.includes(ground)
    );
    if (!groundedBank.length || groundedBank.some((id) => {
      const part = this.localPart(id);
      return !part || !index.sameLocalScope(capacitor.placement, part.placement);
    }))
      return;
    const placements = [capacitor.placement, first.placement, second.placement];
    const pins = junction.map((p) => index.port(p));
    const maxJunctionPinDistance = Math.max(
      ...pins.flatMap(
        (a, i) => pins.slice(i + 1).map(
          (b) => Math.hypot(a.center.x - b.center.x, a.center.y - b.center.y)
        )
      )
    );
    const maxRecommendedJunctionPinDistance = Math.max(
      4,
      ...placements.map((p) => 3 * Math.max(p.width, p.height))
    );
    if (maxJunctionPinDistance <= maxRecommendedJunctionPinDistance) return;
    const names = placements.map((p) => p.sourceComponentName || "component");
    this.params.issues.push({
      lineItemType: "DiodeCapacitorJunctionTooSpreadOut",
      capacitorSchematicBox: capacitor.placement,
      diodeSchematicBoxes: [first.placement, second.placement],
      maxJunctionPinDistance,
      maxRecommendedJunctionPinDistance,
      message: `Bring ${names.join(", ")} closer together so their shared junction can be read as one local diode-capacitor stage. Preserve pin connections, leave room for labels, and reroute affected traces.`
    });
  }
  localPart(id) {
    const component = this.index.components.get(id);
    const placement = this.index.placement(id);
    const ports = this.index.portsByComponent.get(id);
    const nets = this.index.twoTerminalNets(id);
    if (!component || !placement || !nets || this.unpopulated.has(id) || ports?.length !== 2 || ![placement.width, placement.height].every(
      (n) => Number.isFinite(n) && n > 0
    ) || component.ftype === "simple_capacitor" && (!Number.isFinite(component.capacitance) || component.capacitance <= 0) || ports.some((p) => {
      const pin = this.index.port(p);
      return p.do_not_connect || !pin || pin.schematic_sheet_id !== placement.schematicSheetId || !Number.isFinite(pin.center.x) || !Number.isFinite(pin.center.y);
    }))
      return;
    return { component, placement, ports, nets };
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(
      attrs,
      "capacitorName",
      issue.capacitorSchematicBox.sourceComponentName
    );
    addAttr(
      attrs,
      "diodeNames",
      issue.diodeSchematicBoxes.map((p) => p.sourceComponentName).join(",")
    );
    addAttr(attrs, "maxJunctionPinDistance", issue.maxJunctionPinDistance);
    addAttr(
      attrs,
      "maxRecommendedJunctionPinDistance",
      issue.maxRecommendedJunctionPinDistance
    );
    addAttr(attrs, "message", issue.message);
    return `<DiodeCapacitorJunctionTooSpreadOut ${attrs.join(" ")} />`;
  }
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/SeriesLedChainPlacementSolver/SeriesLedChainPlacementSolver.ts
import { BaseSolver as BaseSolver2 } from "@tscircuit/solver-utils";
var SeriesLedChainPlacementSolver = class extends BaseSolver2 {
  constructor(params) {
    super();
    this.params = params;
    this.index = new PlacementNetworkIndex(params.ctx);
    this.ledIds = new Set(
      [...this.index.components.values()].filter((c) => c.ftype === "simple_led").map((c) => c.source_component_id)
    );
    for (const e of params.ctx.circuitJson)
      if (e.type === "pcb_component" && e.do_not_place)
        this.unpopulated.add(e.source_component_id);
    this.solved = this.ledIds.size === 0;
  }
  params;
  index;
  ledIds;
  visited = /* @__PURE__ */ new Set();
  unpopulated = /* @__PURE__ */ new Set();
  _step() {
    const start = [...this.ledIds].find((id) => !this.visited.has(id));
    if (!start) {
      this.solved = true;
      return;
    }
    const group = [start];
    this.visited.add(start);
    const neighbors = /* @__PURE__ */ new Map();
    for (let i = 0; i < group.length; i++) {
      const id = group[i];
      const adjacent = /* @__PURE__ */ new Set();
      for (const port of this.index.portsByComponent.get(id) ?? []) {
        for (const other of this.index.portsByNet.get(
          this.index.connected(port.source_port_id)
        ) ?? []) {
          const otherId = other.source_component_id;
          if (otherId === id || !this.ledIds.has(otherId)) continue;
          adjacent.add(otherId);
          if (!this.visited.has(otherId)) {
            this.visited.add(otherId);
            group.push(otherId);
          }
        }
      }
      neighbors.set(id, adjacent);
    }
    this.solved = this.visited.size === this.ledIds.size;
    if (group.length < 3) return;
    const ends = group.filter((id) => neighbors.get(id).size === 1);
    if (ends.length !== 2 || group.some((id) => neighbors.get(id).size > 2))
      return;
    const ordered = [ends.sort()[0]];
    while (ordered.length < group.length) {
      const last = ordered.at(-1);
      const previous = ordered.at(-2);
      const next = [...neighbors.get(last)].find((id) => id !== previous);
      if (!next || ordered.includes(next)) return;
      ordered.push(next);
    }
    const boxes = ordered.map((id) => this.index.placement(id));
    if (boxes.some((box) => !box)) return;
    const placements = boxes.filter((box) => box !== void 0);
    if (placements.some(
      (box) => !this.index.sameLocalScope(placements[0], box) || ![box.schX, box.schY, box.width, box.height].every(Number.isFinite) || box.width <= 0 || box.height <= 0
    ))
      return;
    for (const id of ordered) {
      const ports = this.index.portsByComponent.get(id) ?? [];
      if (this.unpopulated.has(id) || !this.index.twoTerminalNets(id) || ports.some((p) => p.do_not_connect))
        return;
      const placement = this.index.placement(id);
      for (const port of ports) {
        const pin = this.index.port(port);
        if (!pin || pin.schematic_sheet_id !== placement.schematicSheetId || !Number.isFinite(pin.center.x) || !Number.isFinite(pin.center.y) || !pin.facing_direction)
          return;
      }
    }
    const backtrackingConnections = [];
    for (let i = 1; i < ordered.length; i++) {
      const aId = ordered[i - 1], bId = ordered[i];
      const aNets = this.index.twoTerminalNets(aId);
      const common = this.index.twoTerminalNets(bId).filter((net) => aNets.includes(net));
      if (common.length !== 1 || this.index.isRail(common[0])) return;
      const ports = this.index.portsByNet.get(common[0]) ?? [];
      if (ports.length !== 2) return;
      const aSource = ports.find((p) => p.source_component_id === aId);
      const bSource = ports.find((p) => p.source_component_id === bId);
      const a = this.index.port(aSource), b = this.index.port(bSource);
      const dx = b.center.x - a.center.x, dy = b.center.y - a.center.y;
      const pinDistance = Math.hypot(dx, dy);
      const span = Math.max(
        placements[i - 1].width,
        placements[i - 1].height,
        placements[i].width,
        placements[i].height
      );
      if (pinDistance > Math.max(4, 3 * span) && (outwardDistance(a, dx, dy) < -span || outwardDistance(b, -dx, -dy) < -span)) {
        backtrackingConnections.push({
          firstSourcePortId: aSource.source_port_id,
          secondSourcePortId: bSource.source_port_id,
          pinDistance
        });
      }
    }
    if (!backtrackingConnections.length) return;
    const names = placements.map((box) => box.sourceComponentName || "LED").join(", ");
    this.params.issues.push({
      lineItemType: "SeriesLedChainNotOrdered",
      ledSchematicBoxes: placements,
      backtrackingConnections,
      message: `Arrange ${names} in their connected series order so adjacent LEDs do not require long connections behind their pins. Move or rotate the symbols while preserving anode/cathode connections; allow space for labels and reroute affected traces. A horizontal, vertical, or clearly connected folded chain is acceptable.`
    });
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(
      attrs,
      "ledComponents",
      issue.ledSchematicBoxes.map((box) => box.sourceComponentName).join(",")
    );
    addAttr(
      attrs,
      "backtrackingConnections",
      issue.backtrackingConnections.length
    );
    addAttr(
      attrs,
      "maxPinDistance",
      Math.max(
        ...issue.backtrackingConnections.map((link) => link.pinDistance)
      )
    );
    addAttr(attrs, "message", issue.message);
    return `<SeriesLedChainNotOrdered ${attrs.join(" ")} />`;
  }
};
function outwardDistance(pin, dx, dy) {
  switch (pin.facing_direction) {
    case "left":
      return -dx;
    case "right":
      return dx;
    case "up":
      return dy;
    case "down":
      return -dy;
    default:
      return 0;
  }
}

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/ParallelRcPlacementSolver/ParallelRcPlacementSolver.ts
import { BaseSolver as BaseSolver3 } from "@tscircuit/solver-utils";
var ParallelRcPlacementSolver = class extends BaseSolver3 {
  constructor(params) {
    super();
    this.params = params;
    this.index = new PlacementNetworkIndex(params.ctx);
    for (const element of params.ctx.circuitJson) {
      if (element.type === "pcb_component" && element.do_not_place)
        this.unpopulated.add(element.source_component_id);
      if (element.type === "source_port") {
        const net = this.index.connected(element.source_port_id);
        if (element.requires_ground || element.provides_ground)
          this.index.groundNets.add(net);
        if (element.requires_power || element.provides_power || element.requires_voltage !== void 0 || element.provides_voltage !== void 0)
          this.index.powerNets.add(net);
      }
    }
    this.resistorIds = [...this.index.components.values()].filter((c) => c.ftype === "simple_resistor").map((c) => c.source_component_id);
    this.solved = this.resistorIds.length === 0;
  }
  params;
  index;
  resistorIds;
  unpopulated = /* @__PURE__ */ new Set();
  currentIndex = 0;
  _step() {
    const resistorId = this.resistorIds[this.currentIndex++];
    this.solved = this.currentIndex >= this.resistorIds.length;
    const index = this.index;
    const resistor = index.components.get(resistorId);
    const nets = index.twoTerminalNets(resistorId);
    if (resistor?.ftype !== "simple_resistor" || !Number.isFinite(resistor.resistance) || resistor.resistance <= 0 || !nets)
      return;
    const grounds = nets.filter(
      (net) => index.groundNets.has(net) && !index.powerNets.has(net)
    );
    if (grounds.length !== 1) return;
    const ground = grounds[0];
    const signal = nets.find((net) => net !== ground);
    if (index.isRail(signal)) return;
    const members = index.portsByNet.get(signal) ?? [];
    if (members.length !== 3 || members.some((p) => p.do_not_connect)) return;
    const capPort = members.find(
      (p) => index.components.get(p.source_component_id)?.ftype === "simple_capacitor"
    );
    const chipPort = members.find(
      (p) => index.components.get(p.source_component_id)?.ftype === "simple_chip"
    );
    if (!capPort || !chipPort) return;
    const capacitorId = capPort.source_component_id;
    const capacitor = index.components.get(capacitorId);
    if (capacitor?.ftype !== "simple_capacitor" || !Number.isFinite(capacitor.capacitance) || capacitor.capacitance <= 0 || !index.twoTerminalNets(capacitorId)?.includes(ground))
      return;
    const hostId = chipPort.source_component_id;
    if ((index.portsByComponent.get(hostId)?.length ?? 0) < 3) return;
    const r = index.placement(resistorId), c = index.placement(capacitorId), host = index.placement(hostId);
    if (!r || !c || !host || [resistorId, capacitorId, hostId].some((id) => this.unpopulated.has(id)))
      return;
    if ([r, c].some(
      (box) => box.schematicSheetId !== host.schematicSheetId || box.subcircuitId !== host.subcircuitId
    ))
      return;
    if ([r, c, host].some(
      (box) => ![box.schX, box.schY, box.width, box.height].every(Number.isFinite) || box.width <= 0 || box.height <= 0
    ))
      return;
    const chipPin = index.port(chipPort);
    if (!chipPin || chipPin.schematic_sheet_id !== host.schematicSheetId) return;
    const resistorPins = this.pins(resistorId, signal, ground, r);
    const capacitorPins = this.pins(capacitorId, signal, ground, c);
    if (!resistorPins || !capacitorPins) return;
    const rAxis = pinAxis(...resistorPins), cAxis = pinAxis(...capacitorPins);
    if (!rAxis || !cAxis) return;
    if (Math.abs(r.schX - c.schX) < (r.width + c.width) / 2 && Math.abs(r.schY - c.schY) < (r.height + c.height) / 2)
      return;
    let reason;
    if (rAxis !== cAxis) reason = "different_axes";
    else {
      const axis = rAxis === "horizontal" ? "x" : "y";
      const a = resistorPins.map((p) => p.center[axis]), b = capacitorPins.map((p) => p.center[axis]);
      if ((a[1] - a[0]) * (b[1] - b[0]) < 0) reason = "crossed_connections";
      else {
        const overlap = Math.min(Math.max(...a), Math.max(...b)) - Math.max(Math.min(...a), Math.min(...b));
        if (overlap > 0.01) return;
        reason = "staggered";
      }
    }
    this.params.issues.push({
      lineItemType: "ParallelRcNotAligned",
      resistorSchematicBox: r,
      capacitorSchematicBox: c,
      chipSourcePortId: chipPort.source_port_id,
      reason,
      message: `Draw ${r.sourceComponentName || "the resistor"} and ${c.sourceComponentName || "the capacitor"} as adjacent parallel branches with their shared nets at matching ends. Preserve all pin connections and capacitor polarity, leave room for labels, and reroute affected wires.`
    });
  }
  pins(id, signal, ground, box) {
    const ports = this.index.portsByComponent.get(id) ?? [];
    if (ports.length !== 2 || ports.some((p) => p.do_not_connect)) return;
    const pins = [signal, ground].map((net) => {
      const source = ports.find(
        (p) => this.index.connected(p.source_port_id) === net
      );
      return source && this.index.port(source);
    });
    const [first, second] = pins;
    if (!first || !second || pins.some(
      (p) => p.schematic_sheet_id !== box.schematicSheetId || !Number.isFinite(p.center.x) || !Number.isFinite(p.center.y)
    ))
      return;
    return [first, second];
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(
      attrs,
      "resistorComponentName",
      issue.resistorSchematicBox.sourceComponentName
    );
    addAttr(
      attrs,
      "capacitorComponentName",
      issue.capacitorSchematicBox.sourceComponentName
    );
    addAttr(attrs, "reason", issue.reason);
    addAttr(attrs, "message", issue.message);
    return `<ParallelRcNotAligned ${attrs.join(" ")} />`;
  }
};
function pinAxis(a, b) {
  const directions2 = /* @__PURE__ */ new Set([a.facing_direction, b.facing_direction]);
  if (directions2.has("left") && directions2.has("right") && Math.abs(a.center.y - b.center.y) < 0.01 && Math.abs(a.center.x - b.center.x) > 0.01)
    return "horizontal";
  if (directions2.has("up") && directions2.has("down") && Math.abs(a.center.x - b.center.x) < 0.01 && Math.abs(a.center.y - b.center.y) > 0.01)
    return "vertical";
}

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/ChipPinResistorPlacementSolver/ChipPinResistorPlacementSolver.ts
import { BaseSolver as BaseSolver4 } from "@tscircuit/solver-utils";
var ChipPinResistorPlacementSolver = class extends BaseSolver4 {
  constructor(params) {
    super();
    this.params = params;
    this.index = new PlacementNetworkIndex(params.ctx);
    for (const element of params.ctx.circuitJson)
      if (element.type === "pcb_component" && element.do_not_place)
        this.unpopulated.add(element.source_component_id);
    this.resistorIds = [...this.index.components.values()].filter((component) => component.ftype === "simple_resistor").map((component) => component.source_component_id);
    this.solved = this.resistorIds.length === 0;
  }
  params;
  index;
  resistorIds;
  unpopulated = /* @__PURE__ */ new Set();
  currentIndex = 0;
  _step() {
    const resistorId = this.resistorIds[this.currentIndex++];
    this.solved = this.currentIndex >= this.resistorIds.length;
    if (!resistorId || this.unpopulated.has(resistorId)) return;
    const index = this.index;
    const component = index.components.get(resistorId);
    const resistor = index.placement(resistorId);
    const nets = index.twoTerminalNets(resistorId);
    const resistorPorts = index.portsByComponent.get(resistorId) ?? [];
    if (component?.ftype !== "simple_resistor" || !Number.isFinite(component.resistance) || component.resistance <= 0 || !resistor || !nets || resistorPorts.some((p) => p.do_not_connect))
      return;
    const grounds = nets.filter(
      (net) => index.groundNets.has(net) && !index.powerNets.has(net)
    );
    if (grounds.length !== 1) return;
    const signal = nets.find((net) => net !== grounds[0]);
    if (index.isRail(signal)) return;
    const members = index.portsByNet.get(signal) ?? [];
    if (members.length !== 2) return;
    const chipPort = members.find((p) => p.source_component_id !== resistorId);
    const resistorPort = members.find(
      (p) => p.source_component_id === resistorId
    );
    if (!chipPort || !resistorPort || chipPort.do_not_connect || hasSupplyRole(chipPort))
      return;
    const hostId = chipPort.source_component_id;
    const host = index.placement(hostId);
    if (index.components.get(hostId)?.ftype !== "simple_chip" || (index.portsByComponent.get(hostId)?.length ?? 0) < 3 || this.unpopulated.has(hostId) || !host || !index.sameLocalScope(host, resistor))
      return;
    const chipPin = index.port(chipPort);
    const resistorPin = index.port(resistorPort);
    if (!chipPin || !resistorPin || [chipPin, resistorPin].some(
      (pin) => pin.schematic_sheet_id !== host.schematicSheetId || !Number.isFinite(pin.center.x) || !Number.isFinite(pin.center.y)
    ) || [host, resistor].some(
      (box) => ![box.schX, box.schY, box.width, box.height].every(Number.isFinite) || box.width <= 0 || box.height <= 0
    ))
      return;
    const side = chipPin.facing_direction;
    if (!side) return;
    const horizontal = side === "left" || side === "right";
    const sign = side === "left" || side === "down" ? -1 : 1;
    const oppositeDistance = -sign * (horizontal ? resistor.schX - host.schX : resistor.schY - host.schY);
    const halfBodies = horizontal ? (host.width + resistor.width) / 2 : (host.height + resistor.height) / 2;
    if (oppositeDistance <= halfBodies + 0.2) return;
    const pinDistance = Math.hypot(
      chipPin.center.x - resistorPin.center.x,
      chipPin.center.y - resistorPin.center.y
    );
    const maxRecommendedPinDistance = Math.max(
      4,
      3 * Math.max(resistor.width, resistor.height)
    );
    if (pinDistance <= maxRecommendedPinDistance) return;
    this.params.issues.push({
      lineItemType: "ResistorSeparatedFromChipPin",
      hostSchematicBox: host,
      resistorSchematicBox: resistor,
      chipSourcePortId: chipPort.source_port_id,
      resistorSourcePortId: resistorPort.source_port_id,
      pinDistance,
      maxRecommendedPinDistance,
      message: `Place ${resistor.sourceComponentName || "resistor"} beside its connected pin on the ${side} side of ${host.sourceComponentName || "chip"} so the resistor-to-ground branch can be read together. Preserve pin connections, leave room for labels, and reroute affected traces; exact alignment is not required.`
    });
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(
      attrs,
      "hostComponentName",
      issue.hostSchematicBox.sourceComponentName
    );
    addAttr(
      attrs,
      "resistorName",
      issue.resistorSchematicBox.sourceComponentName
    );
    addAttr(attrs, "pinDistance", issue.pinDistance);
    addAttr(attrs, "maxRecommendedPinDistance", issue.maxRecommendedPinDistance);
    addAttr(attrs, "message", issue.message);
    return `<ResistorSeparatedFromChipPin ${attrs.join(" ")} />`;
  }
};
function hasSupplyRole(port) {
  return Boolean(
    port.requires_power || port.provides_power || port.requires_ground || port.provides_ground || port.requires_voltage !== void 0 || port.provides_voltage !== void 0
  );
}

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/ParallelDiodeResistorPlacementSolver/ParallelDiodeResistorPlacementSolver.ts
import { BaseSolver as BaseSolver5 } from "@tscircuit/solver-utils";
var ParallelDiodeResistorPlacementSolver = class extends BaseSolver5 {
  constructor(params) {
    super();
    this.params = params;
    const index = new PlacementNetworkIndex(params.ctx);
    const byNets = /* @__PURE__ */ new Map();
    for (const component of index.components.values()) {
      const diode = component.ftype === "simple_diode" || component.ftype === "simple_led";
      if (!diode && component.ftype !== "simple_resistor") continue;
      const id = component.source_component_id;
      const box = index.placement(id);
      const nets = index.twoTerminalNets(id)?.sort();
      const ports = index.portsByComponent.get(id);
      if (!box || !nets || !ports) continue;
      const pins = nets.map((net) => {
        const port = ports.find(
          (p) => index.connected(p.source_port_id) === net
        );
        return port && index.port(port);
      });
      const [first, second] = pins;
      const member = { diode, box };
      if (first && second && !ports.some((port) => port.do_not_connect) && pins.every((pin) => pin?.schematic_sheet_id === box.schematicSheetId)) {
        member.pins = [first, second];
        member.axis = pinAxis2(first, second);
      }
      const key = JSON.stringify(nets);
      const scopes = byNets.get(key) ?? [];
      const bank = scopes.find(
        (items) => index.sameLocalScope(items[0].box, box)
      );
      if (bank) bank.push(member);
      else {
        const items = [member];
        scopes.push(items);
        this.banks.push(items);
      }
      byNets.set(key, scopes);
    }
    this.solved = this.banks.length === 0;
  }
  params;
  banks = [];
  bankIndex = 0;
  _step() {
    const bank = this.banks[this.bankIndex++];
    this.solved = this.bankIndex >= this.banks.length;
    if (bank.length !== 2) return;
    const diode = bank.find((member) => member.diode);
    const resistor = bank.find((member) => !member.diode);
    if (!diode?.pins || !diode.axis || !resistor?.pins || !resistor.axis) return;
    const a = diode.box;
    const b = resistor.box;
    if (Math.abs(a.schX - b.schX) < (a.width + b.width) / 2 && Math.abs(a.schY - b.schY) < (a.height + b.height) / 2)
      return;
    let reason;
    if (diode.axis !== resistor.axis) reason = "different_axes";
    else {
      const coordinate = diode.axis === "horizontal" ? "x" : "y";
      const d = diode.pins.map((pin) => pin.center[coordinate]);
      const r = resistor.pins.map((pin) => pin.center[coordinate]);
      if ((d[1] - d[0]) * (r[1] - r[0]) < 0) reason = "crossed_connections";
      else {
        const overlap = Math.min(Math.max(...d), Math.max(...r)) - Math.max(Math.min(...d), Math.min(...r));
        if (overlap > 0.01) return;
        reason = "staggered";
      }
    }
    this.params.issues.push({
      lineItemType: "ParallelDiodeResistorNotAligned",
      diodeSchematicBox: a,
      resistorSchematicBox: b,
      reason,
      message: `Draw ${a.sourceComponentName || "the diode"} and ${b.sourceComponentName || "the resistor"} as adjacent parallel rows or columns with their shared nets at matching ends. Preserve every pin connection and diode polarity, leave room for labels, and reroute the affected wires.`
    });
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(
      attrs,
      "diodeComponentName",
      issue.diodeSchematicBox.sourceComponentName
    );
    addAttr(
      attrs,
      "resistorComponentName",
      issue.resistorSchematicBox.sourceComponentName
    );
    addAttr(attrs, "reason", issue.reason);
    addAttr(attrs, "message", issue.message);
    return `<ParallelDiodeResistorNotAligned ${attrs.join(" ")} />`;
  }
};
function pinAxis2(first, second) {
  const directions2 = /* @__PURE__ */ new Set([first.facing_direction, second.facing_direction]);
  if (directions2.has("left") && directions2.has("right") && Math.abs(first.center.y - second.center.y) < 0.01 && Math.abs(first.center.x - second.center.x) > 0.01)
    return "horizontal";
  if (directions2.has("up") && directions2.has("down") && Math.abs(first.center.x - second.center.x) < 0.01 && Math.abs(first.center.y - second.center.y) > 0.01)
    return "vertical";
}

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/RailPathVisibilitySolver/RailPathVisibilitySolver.ts
import { BaseSolver as BaseSolver6 } from "@tscircuit/solver-utils";
var distance3 = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
var EPS2 = 1e-3;
var RailPathVisibilitySolver = class extends BaseSolver6 {
  index;
  nodes = /* @__PURE__ */ new Map();
  starts = [];
  currentIndex = 0;
  issues;
  maxSpan;
  maxLength;
  constructor({
    ctx,
    issues,
    maxSpan = 8,
    maxLength = 16
  }) {
    super();
    this.index = new PlacementNetworkIndex(ctx);
    this.issues = issues;
    if (!Number.isFinite(maxSpan) || maxSpan < 0 || !Number.isFinite(maxLength) || maxLength < 0)
      throw new Error(
        "Rail visibility thresholds must be finite and nonnegative"
      );
    this.maxSpan = maxSpan;
    this.maxLength = maxLength;
    const index = this.index;
    const node = (point2, net, sheet) => {
      const id = JSON.stringify([
        sheet,
        net,
        Math.round(point2.x / EPS2),
        Math.round(point2.y / EPS2)
      ]);
      if (!this.nodes.has(id))
        this.nodes.set(id, { point: point2, net, sheet, links: [] });
      return id;
    };
    const link = (a, b, extra) => {
      const first = this.nodes.get(a), second = this.nodes.get(b);
      const length = distance3(first.point, second.point);
      first.links.push({ to: b, length, ...extra });
      second.links.push({ to: a, length, ...extra });
    };
    const portNodes = /* @__PURE__ */ new Map();
    for (const [componentId, ports] of index.portsByComponent) {
      for (const port of ports) {
        const placed = index.port(port);
        if (!placed) continue;
        const id = node(
          placed.center,
          index.connected(port.source_port_id),
          placed.schematic_sheet_id
        );
        portNodes.set(port.source_port_id, id);
        if (ports.length > 2)
          this.starts.push({
            portId: port.source_port_id,
            componentId,
            nodeId: id
          });
      }
    }
    for (const element of ctx.circuitJson) {
      if (element.type !== "schematic_net_label" || !element.source_net_id || !element.anchor_position)
        continue;
      const net = index.connected(element.source_net_id);
      if (!index.isRail(net) || index.powerNets.has(net) && index.groundNets.has(net))
        continue;
      const id = node(element.anchor_position, net, element.schematic_sheet_id);
      this.nodes.get(id).terminal = index.groundNets.has(net) ? "ground" : "power";
    }
    const segments = [];
    for (const element of ctx.circuitJson) {
      if (element.type !== "schematic_trace") continue;
      const net = traceNet(element, ctx.circuitJson, index);
      if (!net) continue;
      for (const edge of element.edges) {
        segments.push({
          from: node(edge.from, net, element.schematic_sheet_id),
          to: node(edge.to, net, element.schematic_sheet_id),
          traceId: element.schematic_trace_id
        });
      }
    }
    for (const segment of segments) {
      const a = this.nodes.get(segment.from), b = this.nodes.get(segment.to);
      const length = distance3(a.point, b.point);
      if (length < EPS2) continue;
      const onSegment2 = [...this.nodes].filter(
        ([, n]) => n.net === a.net && n.sheet === a.sheet && pointOnSegment(n.point, a.point, b.point)
      ).sort(
        ([, p], [, q2]) => distance3(a.point, p.point) - distance3(a.point, q2.point)
      );
      for (let i = 1; i < onSegment2.length; i++)
        link(onSegment2[i - 1][0], onSegment2[i][0], {
          traceId: segment.traceId
        });
    }
    for (const [id, component] of index.components) {
      if (!["simple_resistor", "simple_capacitor", "simple_inductor"].includes(
        component.ftype
      ))
        continue;
      const ports = index.portsByComponent.get(id);
      if (ports?.length !== 2 || !index.twoTerminalNets(id)) continue;
      const a = portNodes.get(ports[0].source_port_id), b = portNodes.get(ports[1].source_port_id);
      if (a && b) link(a, b, { componentId: id });
    }
    this.solved = this.starts.length === 0;
  }
  _step() {
    const start = this.starts[this.currentIndex++];
    this.solved = this.currentIndex >= this.starts.length;
    if (!start) return;
    const sourcePort = this.index.portsByComponent.get(start.componentId)?.find((port) => port.source_port_id === start.portId);
    const placedPort = sourcePort ? this.index.port(sourcePort) : void 0;
    const sourcePortName = placedPort?.display_pin_label || sourcePort?.name || (placedPort?.pin_number !== void 0 ? `pin${placedPort.pin_number}` : "connected pin");
    const host = this.index.placement(start.componentId);
    if (!host) return;
    const queue = [
      { id: start.nodeId, length: 0, hops: 0, path: [start.nodeId], links: [] }
    ];
    const bestLengths = /* @__PURE__ */ new Map([[`${start.nodeId}:0`, 0]]);
    while (queue.length) {
      queue.sort((a, b) => a.length - b.length);
      const state = queue.shift();
      const key = `${state.id}:${state.hops}`;
      if (state.length !== bestLengths.get(key)) continue;
      const current = this.nodes.get(state.id);
      if (current.terminal) {
        const points = state.path.map((id) => this.nodes.get(id).point);
        const xs = points.map((p) => p.x), ys = points.map((p) => p.y);
        const bounds = {
          left: Math.min(...xs),
          right: Math.max(...xs),
          bottom: Math.min(...ys),
          top: Math.max(...ys)
        };
        const span = Math.max(
          bounds.right - bounds.left,
          bounds.top - bounds.bottom
        );
        if (span <= this.maxSpan && state.length <= this.maxLength) return;
        const componentIds = [
          ...new Set(
            state.links.flatMap((l) => l.componentId ? [l.componentId] : [])
          )
        ];
        this.issues.push({
          lineItemType: "RailPathTooSpreadOut",
          hostSchematicBox: host,
          sourcePortId: start.portId,
          sourcePortName,
          railType: current.terminal,
          supportSchematicBoxes: componentIds.flatMap((id) => {
            const placement = this.index.placement(id);
            return placement ? [placement] : [];
          }),
          schematicTraceIds: [
            ...new Set(
              state.links.flatMap((l) => l.traceId ? [l.traceId] : [])
            )
          ],
          pathPoints: points,
          pathBounds: bounds,
          pathLength: state.length,
          pathSpan: span,
          maxRecommendedSpan: this.maxSpan,
          maxRecommendedPathLength: this.maxLength,
          message: `Visible path from ${host.sourceComponentName || "component"}.${sourcePortName} to ${current.terminal} spans ${span.toFixed(2)} schematic units; move the connected support elements closer together near the pin and recompute their schematic traces.`
        });
        return;
      }
      for (const edge of current.links) {
        if (state.path.includes(edge.to)) continue;
        if (edge.componentId) {
          const placement = this.index.placement(edge.componentId);
          if (state.hops >= 3 || !placement || !this.index.sameLocalScope(host, placement))
            continue;
        }
        const length = state.length + edge.length;
        const hops = state.hops + (edge.componentId ? 1 : 0);
        const nextKey = `${edge.to}:${hops}`;
        if (length >= (bestLengths.get(nextKey) ?? Infinity)) continue;
        bestLengths.set(nextKey, length);
        queue.push({
          id: edge.to,
          length,
          hops,
          path: [...state.path, edge.to],
          links: [...state.links, edge]
        });
      }
    }
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(attrs, "hostName", issue.hostSchematicBox.sourceComponentName);
    addAttr(attrs, "pinName", issue.sourcePortName);
    addAttr(attrs, "railType", issue.railType);
    addAttr(attrs, "pathSpan", issue.pathSpan);
    addAttr(attrs, "pathLength", issue.pathLength);
    addAttr(attrs, "message", issue.message);
    return `<RailPathTooSpreadOut ${attrs.join(" ")} />`;
  }
};
function traceNet(trace, circuitJson, index) {
  if (trace.subcircuit_connectivity_map_key)
    return index.connected(
      `connectivity:${trace.subcircuit_connectivity_map_key}`
    );
  const source = circuitJson.find(
    (e) => e.type === "source_trace" && e.source_trace_id === trace.source_trace_id
  );
  if (source?.type !== "source_trace") return;
  const ids = [
    ...source.connected_source_port_ids,
    ...source.connected_source_net_ids
  ];
  return ids[0] ? index.connected(ids[0]) : void 0;
}
function pointOnSegment(p, a, b) {
  const dx = b.x - a.x, dy = b.y - a.y, length = distance3(a, b);
  if (length < EPS2) return distance3(a, p) < EPS2;
  const projection = ((p.x - a.x) * dx + (p.y - a.y) * dy) / length;
  const perpendicular = Math.abs((p.x - a.x) * dy - (p.y - a.y) * dx) / length;
  return perpendicular < EPS2 && projection >= -EPS2 && projection <= length + EPS2;
}

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/ChipPinPairCapacitorPlacementSolver/ChipPinPairCapacitorPlacementSolver.ts
import { BaseSolver as BaseSolver7 } from "@tscircuit/solver-utils";
var ChipPinPairCapacitorPlacementSolver = class extends BaseSolver7 {
  constructor(params) {
    super();
    this.params = params;
    this.index = new PlacementNetworkIndex(params.ctx);
    for (const element of params.ctx.circuitJson)
      if (element.type === "pcb_component" && element.do_not_place)
        this.unpopulated.add(element.source_component_id);
    this.capacitorIds = [...this.index.components.values()].filter((component) => component.ftype === "simple_capacitor").map((component) => component.source_component_id);
    this.solved = this.capacitorIds.length === 0;
  }
  params;
  index;
  capacitorIds;
  unpopulated = /* @__PURE__ */ new Set();
  currentIndex = 0;
  _step() {
    const capacitorId = this.capacitorIds[this.currentIndex++];
    this.solved = this.currentIndex >= this.capacitorIds.length;
    if (!capacitorId || this.unpopulated.has(capacitorId)) return;
    const index = this.index;
    const component = index.components.get(capacitorId);
    const capacitor = index.placement(capacitorId);
    const capacitorPorts = index.portsByComponent.get(capacitorId) ?? [];
    const nets = index.twoTerminalNets(capacitorId);
    if (component?.ftype !== "simple_capacitor" || !Number.isFinite(component.capacitance) || component.capacitance <= 0 || !capacitor || !nets || nets.some((net) => index.isRail(net)) || capacitorPorts.some((port) => port.do_not_connect || hasSupplyRole2(port)))
      return;
    const peers = nets.map((net) => {
      const members = index.portsByNet.get(net) ?? [];
      if (members.length !== 2) return;
      return members.find((port) => port.source_component_id !== capacitorId);
    });
    const [first, second] = peers;
    if (!first || !second || first.source_component_id !== second.source_component_id || first.do_not_connect || second.do_not_connect || hasSupplyRole2(first) || hasSupplyRole2(second))
      return;
    const hostId = first.source_component_id;
    const host = index.placement(hostId);
    if (index.components.get(hostId)?.ftype !== "simple_chip" || this.unpopulated.has(hostId) || !host || !index.sameLocalScope(host, capacitor))
      return;
    const chipPorts = [first, second];
    const pins = chipPorts.map((port) => index.port(port));
    const capPins = capacitorPorts.map((port) => index.port(port));
    if ([...pins, ...capPins].some(
      (pin) => !pin || pin.schematic_sheet_id !== host.schematicSheetId || !Number.isFinite(pin.center.x) || !Number.isFinite(pin.center.y)
    ) || [host, capacitor].some(
      (box) => ![box.schX, box.schY, box.width, box.height].every(Number.isFinite) || box.width <= 0 || box.height <= 0
    ))
      return;
    const firstPin = pins[0], secondPin = pins[1];
    const side = firstPin.facing_direction;
    if (!side || side !== secondPin.facing_direction) return;
    const horizontal = side === "left" || side === "right";
    const sign = side === "left" || side === "down" ? -1 : 1;
    const pinSpan = Math.hypot(
      firstPin.center.x - secondPin.center.x,
      firstPin.center.y - secondPin.center.y
    );
    if (pinSpan < 0.01) return;
    const oppositeDistance = -sign * (horizontal ? capacitor.schX - host.schX : capacitor.schY - host.schY);
    const halfBodies = horizontal ? (host.width + capacitor.width) / 2 : (host.height + capacitor.height) / 2;
    if (oppositeDistance <= halfBodies + 0.2) return;
    const maxPinDistance = Math.max(
      ...pins.map(
        (pin, i) => Math.hypot(
          pin.center.x - capPins[i].center.x,
          pin.center.y - capPins[i].center.y
        )
      )
    );
    const maxRecommendedPinDistance = Math.max(
      4,
      3 * Math.max(capacitor.width, capacitor.height),
      2 * pinSpan
    );
    if (maxPinDistance <= maxRecommendedPinDistance) return;
    this.params.issues.push({
      lineItemType: "CapacitorSeparatedFromChipPins",
      hostSchematicBox: host,
      capacitorSchematicBox: capacitor,
      chipSourcePortIds: [
        chipPorts[0].source_port_id,
        chipPorts[1].source_port_id
      ],
      maxPinDistance,
      maxRecommendedPinDistance,
      message: `Place ${capacitor.sourceComponentName || "component"} beside its two connected pins on the ${side} side of ${host.sourceComponentName || "component"} so their connections can be read together. Preserve pin connections, leave room for labels, and reroute affected traces; exact alignment is not required.`
    });
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(
      attrs,
      "hostComponentName",
      issue.hostSchematicBox.sourceComponentName
    );
    addAttr(
      attrs,
      "capacitorName",
      issue.capacitorSchematicBox.sourceComponentName
    );
    addAttr(attrs, "maxPinDistance", issue.maxPinDistance);
    addAttr(attrs, "maxRecommendedPinDistance", issue.maxRecommendedPinDistance);
    addAttr(attrs, "message", issue.message);
    return `<CapacitorSeparatedFromChipPins ${attrs.join(" ")} />`;
  }
};
function hasSupplyRole2(port) {
  return Boolean(
    port.requires_power || port.provides_power || port.requires_ground || port.provides_ground || port.requires_voltage !== void 0 || port.provides_voltage !== void 0
  );
}

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/PiFilterPlacementSolver/PiFilterPlacementSolver.ts
import { BaseSolver as BaseSolver8 } from "@tscircuit/solver-utils";
var PiFilterPlacementSolver = class extends BaseSolver8 {
  constructor(params) {
    super();
    this.params = params;
    this.index = new PlacementNetworkIndex(params.ctx);
    for (const e of params.ctx.circuitJson)
      if (e.type === "pcb_component" && e.do_not_place)
        this.unpopulated.add(e.source_component_id);
    for (const e of params.ctx.circuitJson)
      if (e.type === "pcb_component" && !e.do_not_place)
        this.unpopulated.delete(e.source_component_id);
    this.inductorIds = [...this.index.components.values()].filter(
      (c) => c.ftype === "simple_inductor" && !this.unpopulated.has(c.source_component_id)
    ).map((c) => c.source_component_id);
    this.solved = this.inductorIds.length === 0;
  }
  params;
  index;
  inductorIds;
  unpopulated = /* @__PURE__ */ new Set();
  currentIndex = 0;
  _step() {
    const id = this.inductorIds[this.currentIndex++];
    this.solved = this.currentIndex >= this.inductorIds.length;
    if (!id) return;
    const index = this.index;
    const inductor = this.localPart(id);
    const nets = index.twoTerminalNets(id);
    if (!inductor || !nets || nets.some((net) => index.isRail(net))) return;
    const branches = nets.map((net) => {
      const peers = index.portsByNet.get(net) ?? [];
      if (peers.some(
        (p) => p.source_component_id !== id && !this.unpopulated.has(p.source_component_id) && index.components.get(p.source_component_id)?.ftype === "simple_inductor"
      ))
        return;
      const capacitors = peers.filter((p) => {
        const c = index.components.get(p.source_component_id);
        const capNets = index.twoTerminalNets(p.source_component_id);
        return c?.ftype === "simple_capacitor" && !this.unpopulated.has(p.source_component_id) && capNets?.some((n) => n !== net && index.groundNets.has(n));
      });
      if (capacitors.length !== 1) return;
      const capacitorPort = capacitors[0];
      const component = index.components.get(capacitorPort.source_component_id);
      if (component.ftype !== "simple_capacitor" || !Number.isFinite(component.capacitance) || component.capacitance <= 0)
        return;
      const capacitor = this.localPart(capacitorPort.source_component_id);
      if (!capacitor || !index.sameLocalScope(inductor.placement, capacitor.placement))
        return;
      const capPin = index.port(capacitorPort);
      const seriesPin = index.port(
        inductor.ports.find((p) => index.connected(p.source_port_id) === net)
      );
      return {
        placement: capacitor.placement,
        ground: index.twoTerminalNets(capacitorPort.source_component_id).find((n) => n !== net),
        distance: Math.hypot(
          capPin.center.x - seriesPin.center.x,
          capPin.center.y - seriesPin.center.y
        )
      };
    });
    const [first, second] = branches;
    if (!first || !second || first.ground !== second.ground) return;
    const placements = [inductor.placement, first.placement, second.placement];
    const maxRecommendedSignalPinDistance = Math.max(
      4,
      ...placements.map((p) => 3 * Math.max(p.width, p.height))
    );
    const maxSignalPinDistance = Math.max(first.distance, second.distance);
    if (maxSignalPinDistance <= maxRecommendedSignalPinDistance) return;
    const name = (p) => p.sourceComponentName || "component";
    this.params.issues.push({
      lineItemType: "PiFilterComponentsNotGrouped",
      inductorSchematicBox: inductor.placement,
      firstCapacitorSchematicBox: first.placement,
      secondCapacitorSchematicBox: second.placement,
      maxSignalPinDistance,
      maxRecommendedSignalPinDistance,
      message: `Group ${name(first.placement)} and ${name(second.placement)} beside the connected ends of ${name(inductor.placement)} so the series path and both grounded branches of the pi filter can be read together. Preserve pin connections, allow room for labels, and reroute affected traces.`
    });
  }
  localPart(id) {
    const placement = this.index.placement(id);
    const ports = this.index.portsByComponent.get(id);
    if (!placement || ports?.length !== 2 || ports.some((p) => {
      const pin = this.index.port(p);
      return p.do_not_connect || !pin || pin.schematic_sheet_id !== placement.schematicSheetId || !Number.isFinite(pin.center.x) || !Number.isFinite(pin.center.y);
    }))
      return;
    return { placement, ports };
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(
      attrs,
      "inductorName",
      issue.inductorSchematicBox.sourceComponentName
    );
    addAttr(
      attrs,
      "firstCapacitorName",
      issue.firstCapacitorSchematicBox.sourceComponentName
    );
    addAttr(
      attrs,
      "secondCapacitorName",
      issue.secondCapacitorSchematicBox.sourceComponentName
    );
    addAttr(attrs, "maxSignalPinDistance", issue.maxSignalPinDistance);
    addAttr(
      attrs,
      "maxRecommendedSignalPinDistance",
      issue.maxRecommendedSignalPinDistance
    );
    addAttr(attrs, "message", issue.message);
    return `<PiFilterComponentsNotGrouped ${attrs.join(" ")} />`;
  }
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/MosfetGateNetworkPlacementSolver/MosfetGateNetworkPlacementSolver.ts
import { BaseSolver as BaseSolver9 } from "@tscircuit/solver-utils";
var MosfetGateNetworkPlacementSolver = class extends BaseSolver9 {
  constructor(params) {
    super();
    this.params = params;
    this.index = new PlacementNetworkIndex(params.ctx);
    this.mosfetIds = [...this.index.components.keys()].filter(
      (id) => this.mosfetPorts(id)
    );
    this.solved = this.mosfetIds.length === 0;
  }
  params;
  index;
  mosfetIds;
  currentIndex = 0;
  _step() {
    const id = this.mosfetIds[this.currentIndex++];
    this.solved = this.currentIndex >= this.mosfetIds.length;
    if (!id) return;
    const index = this.index;
    const mosfet = index.placement(id);
    const roles = this.mosfetPorts(id);
    if (!mosfet) return;
    const gateNet = index.connected(roles.gate.source_port_id);
    const sourceNet = index.connected(roles.sources[0].source_port_id);
    const drainNet = index.connected(roles.drains[0].source_port_id);
    if ((/* @__PURE__ */ new Set([gateNet, sourceNet, drainNet])).size !== 3 || index.isRail(gateNet))
      return;
    if ([roles.gate, ...roles.sources, ...roles.drains].some((p) => {
      const pin = index.port(p);
      return !pin || pin.schematic_sheet_id !== mosfet.schematicSheetId;
    }))
      return;
    const peers = (index.portsByNet.get(gateNet) ?? []).filter(
      (p) => p.source_component_id !== id
    );
    if (peers.length !== 2) return;
    const resistors = peers.map((p) => {
      const resistorId = p.source_component_id;
      const component = index.components.get(resistorId);
      const placement = index.placement(resistorId);
      const nets = index.twoTerminalNets(resistorId);
      if (component?.ftype !== "simple_resistor" || !Number.isFinite(component.resistance) || component.resistance <= 0 || !placement || !nets || !index.sameLocalScope(mosfet, placement) || index.portsByComponent.get(resistorId).some((port) => {
        const pin = index.port(port);
        return port.do_not_connect || !pin || pin.schematic_sheet_id !== mosfet.schematicSheetId;
      }))
        return;
      return { placement, otherNet: nets.find((net) => net !== gateNet) };
    });
    if (resistors.some((r) => !r)) return;
    const shunts = resistors.filter((r) => r.otherNet === sourceNet);
    const series = resistors.filter((r) => r.otherNet !== sourceNet);
    if (shunts.length !== 1 || series.length !== 1) return;
    const gateSourceResistor = shunts[0].placement;
    const seriesGateResistor = series[0].placement;
    if (series[0].otherNet === drainNet || index.isRail(series[0].otherNet))
      return;
    const maxRecommendedBodyGap = Math.max(
      6,
      3 * Math.max(mosfet.width, mosfet.height)
    );
    const maxBodyGap = Math.max(
      bodyGap(mosfet, seriesGateResistor),
      bodyGap(mosfet, gateSourceResistor)
    );
    if (maxBodyGap <= maxRecommendedBodyGap) return;
    this.params.issues.push({
      lineItemType: "MosfetGateNetworkNotGrouped",
      mosfetSchematicBox: mosfet,
      seriesGateResistorSchematicBox: seriesGateResistor,
      gateSourceResistorSchematicBox: gateSourceResistor,
      maxBodyGap,
      maxRecommendedBodyGap,
      message: `Group ${seriesGateResistor.sourceComponentName || "component"} and ${gateSourceResistor.sourceComponentName || "component"} beside ${mosfet.sourceComponentName || "component"}'s gate/source pins so the gate-drive branch can be read together. Preserve all pin connections, leave room for labels, and reroute affected traces.`
    });
  }
  mosfetPorts(id) {
    const type = this.index.components.get(id)?.ftype;
    if (type !== "simple_mosfet" && type !== "simple_chip") return;
    const ports = this.index.portsByComponent.get(id) ?? [];
    const gate = ports.filter((p) => hasRole(p, /^(G|GATE)$/));
    const sources = ports.filter((p) => hasRole(p, /^(S|SOURCE)[0-9]*$/));
    const drains = ports.filter((p) => hasRole(p, /^(D|DRAIN)[0-9]*$/));
    if (gate.length !== 1 || !sources.length || !drains.length || gate.length + sources.length + drains.length !== ports.length || (/* @__PURE__ */ new Set([...gate, ...sources, ...drains])).size !== ports.length || ports.some((p) => p.do_not_connect))
      return;
    for (const group of [sources, drains])
      if (new Set(group.map((p) => this.index.connected(p.source_port_id))).size !== 1)
        return;
    return { gate: gate[0], sources, drains };
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(attrs, "mosfetName", issue.mosfetSchematicBox.sourceComponentName);
    addAttr(
      attrs,
      "seriesGateResistorName",
      issue.seriesGateResistorSchematicBox.sourceComponentName
    );
    addAttr(
      attrs,
      "gateSourceResistorName",
      issue.gateSourceResistorSchematicBox.sourceComponentName
    );
    addAttr(attrs, "maxBodyGap", issue.maxBodyGap);
    addAttr(attrs, "maxRecommendedBodyGap", issue.maxRecommendedBodyGap);
    addAttr(attrs, "message", issue.message);
    return `<MosfetGateNetworkNotGrouped ${attrs.join(" ")} />`;
  }
};
function hasRole(port, pattern) {
  return [port.name, ...port.port_hints ?? []].some(
    (hint) => pattern.test(hint.toUpperCase().replace(/[\s_]/g, ""))
  );
}
function bodyGap(a, b) {
  return Math.hypot(
    Math.max(0, Math.abs(a.schX - b.schX) - (a.width + b.width) / 2),
    Math.max(0, Math.abs(a.schY - b.schY) - (a.height + b.height) / 2)
  );
}

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/RelayFlybackDiodePlacementSolver/RelayFlybackDiodePlacementSolver.ts
import { BaseSolver as BaseSolver10 } from "@tscircuit/solver-utils";
var RelayFlybackDiodePlacementSolver = class extends BaseSolver10 {
  constructor(params) {
    super();
    this.params = params;
    this.index = new PlacementNetworkIndex(params.ctx);
    this.relayIds = [...this.index.components.keys()].filter(
      (id) => this.coilPorts(id)
    );
    this.solved = this.relayIds.length === 0;
  }
  params;
  index;
  relayIds;
  currentIndex = 0;
  _step() {
    const relayId = this.relayIds[this.currentIndex++];
    this.solved = this.currentIndex >= this.relayIds.length;
    if (!relayId) return;
    const index = this.index;
    const relay = index.placement(relayId);
    const coil = this.coilPorts(relayId);
    if (!relay || coil.some((p) => p.do_not_connect)) return;
    const nets = coil.map((p) => index.connected(p.source_port_id));
    if (nets[0] === nets[1]) return;
    if (this.relayIds.some(
      (id) => id !== relayId && this.coilPorts(id).every(
        (p) => nets.includes(index.connected(p.source_port_id))
      )
    ))
      return;
    const diodeIds = new Set(
      (index.portsByNet.get(nets[0]) ?? []).filter(
        (p) => index.components.get(p.source_component_id)?.ftype === "simple_diode"
      ).map((p) => p.source_component_id).filter((id) => index.twoTerminalNets(id)?.includes(nets[1]))
    );
    if (diodeIds.size !== 1) return;
    const diodeId = [...diodeIds][0];
    const diode = index.placement(diodeId);
    const anode = this.uniquePort(diodeId, /^(?:ANODE|A)$/);
    const cathode = this.uniquePort(diodeId, /^(?:CATHODE|K)$/);
    if (!diode || !index.sameLocalScope(relay, diode) || !anode || !cathode || anode === cathode || anode.do_not_connect || cathode.do_not_connect)
      return;
    const anodeNet = index.connected(anode.source_port_id);
    const cathodeNet = index.connected(cathode.source_port_id);
    if (index.isRail(anodeNet) || index.groundNets.has(cathodeNet) || !this.hasGroundedDriver(anodeNet, cathodeNet))
      return;
    const coilPins = coil.map((p) => index.port(p));
    const diodePins = [anode, cathode].map((p) => index.port(p));
    if ([...coilPins, ...diodePins].some(
      (p) => !p || p.schematic_sheet_id !== relay.schematicSheetId
    ))
      return;
    const [first, second] = coilPins;
    const left = Math.min(first.center.x, second.center.x);
    const right = Math.max(first.center.x, second.center.x);
    const bottom = Math.min(first.center.y, second.center.y);
    const top = Math.max(first.center.y, second.center.y);
    const gapX = Math.max(
      left - (diode.schX + diode.width / 2),
      diode.schX - diode.width / 2 - right,
      0
    );
    const gapY = Math.max(
      bottom - (diode.schY + diode.height / 2),
      diode.schY - diode.height / 2 - top,
      0
    );
    const distanceFromCoilPins = Math.hypot(gapX, gapY);
    const pinSpan = Math.hypot(right - left, top - bottom);
    if (distanceFromCoilPins <= Math.max(1.5, 2 * pinSpan) || distanceFromCoilPins > Math.max(8, 4 * Math.max(relay.width, relay.height)))
      return;
    if (!this.params.ctx.circuitJson.some(
      (e) => e.type === "schematic_net_label" && e.schematic_sheet_id === relay.schematicSheetId && e.anchor_position && diodePins.some(
        (p) => Math.hypot(
          p.center.x - e.anchor_position.x,
          p.center.y - e.anchor_position.y
        ) < 0.01 && !this.hasWireAtPin(p)
      )
    ))
      return;
    this.params.issues.push({
      lineItemType: "FlybackDiodeSeparatedFromRelayCoil",
      relaySchematicBox: relay,
      diodeSchematicBox: diode,
      coilSourcePortIds: [coil[0].source_port_id, coil[1].source_port_id],
      distanceFromCoilPins,
      message: `Place ${diode.sourceComponentName || "component"} beside ${relay.sourceComponentName || "component"}'s coil pins so the flyback protection loop can be read together. Preserve diode polarity and all pin connections; leave room for labels and reroute affected traces.`
    });
  }
  hasWireAtPin(pin) {
    return this.params.ctx.circuitJson.some(
      (e) => e.type === "schematic_trace" && e.schematic_sheet_id === pin.schematic_sheet_id && e.edges.some(({ from, to }) => {
        const dx = to.x - from.x, dy = to.y - from.y;
        const lengthSquared = dx * dx + dy * dy;
        const t = lengthSquared ? Math.max(
          0,
          Math.min(
            1,
            ((pin.center.x - from.x) * dx + (pin.center.y - from.y) * dy) / lengthSquared
          )
        ) : 0;
        return Math.hypot(
          pin.center.x - from.x - t * dx,
          pin.center.y - from.y - t * dy
        ) < 0.01;
      })
    );
  }
  uniquePort(id, pattern) {
    const ports = this.index.portsByComponent.get(id)?.filter((p) => hasHint(p, pattern));
    return ports?.length === 1 ? ports[0] : void 0;
  }
  coilPorts(id) {
    if (this.index.components.get(id)?.ftype !== "simple_chip") return;
    const ports = this.index.portsByComponent.get(id) ?? [];
    if (!this.uniquePort(id, /^(?:COM|COMMON)$/) || !ports.some((p) => hasHint(p, /^(?:NO|NC|NORMALLYOPEN|NORMALLYCLOSED)$/)))
      return;
    const coil = ports.filter((p) => hasHint(p, /^(?:COIL[A-B12]|A[12])$/));
    if (coil.length !== 2) return;
    for (const [a, b] of [
      ["COILA", "COILB"],
      ["COIL1", "COIL2"],
      ["A1", "A2"]
    ]) {
      const first = this.uniquePort(id, new RegExp(`^${a}$`));
      const second = this.uniquePort(id, new RegExp(`^${b}$`));
      if (first && second && first !== second && !hasHint(first, new RegExp(`^${b}$`)) && !hasHint(second, new RegExp(`^${a}$`)))
        return [first, second];
    }
  }
  hasGroundedDriver(anodeNet, cathodeNet) {
    return (this.index.portsByNet.get(anodeNet) ?? []).some((p) => {
      const id = p.source_component_id;
      const component = this.index.components.get(id);
      if (component?.ftype !== "simple_chip" && !(component?.ftype === "simple_transistor" && component.transistor_type === "npn"))
        return false;
      if (this.index.portsByComponent.get(id)?.length !== 3) return false;
      const c = this.uniquePort(id, /^(?:C|COLLECTOR)$/);
      const e = this.uniquePort(id, /^(?:E|EMITTER)$/);
      const b = this.uniquePort(id, /^(?:B|BASE)$/);
      if (!c || !e || !b || (/* @__PURE__ */ new Set([c, e, b])).size !== 3 || [c, e, b].some((p2) => p2.do_not_connect) || c.source_port_id !== p.source_port_id)
        return false;
      const emitterNet = this.index.connected(e.source_port_id), baseNet = this.index.connected(b.source_port_id);
      return this.index.groundNets.has(emitterNet) && !this.index.powerNets.has(emitterNet) && (/* @__PURE__ */ new Set([anodeNet, cathodeNet, emitterNet, baseNet])).size === 4;
    });
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(attrs, "relayName", issue.relaySchematicBox.sourceComponentName);
    addAttr(attrs, "diodeName", issue.diodeSchematicBox.sourceComponentName);
    addAttr(attrs, "distanceFromCoilPins", issue.distanceFromCoilPins);
    addAttr(attrs, "message", issue.message);
    return `<FlybackDiodeSeparatedFromRelayCoil ${attrs.join(" ")} />`;
  }
};
function hasHint(port, pattern) {
  return [port.name, ...port.port_hints ?? []].some(
    (hint) => pattern.test(hint.toUpperCase().replace(/[\s_]/g, ""))
  );
}

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/CurrentSenseShuntPlacementSolver/CurrentSenseShuntPlacementSolver.ts
import { BaseSolver as BaseSolver11 } from "@tscircuit/solver-utils";
var EPSILON3 = 0.01;
var CurrentSenseShuntPlacementSolver = class extends BaseSolver11 {
  constructor(params) {
    super();
    this.params = params;
    this.index = new PlacementNetworkIndex(params.ctx);
    this.hostIds = [...this.index.components.values()].filter((component) => component.ftype === "simple_chip").map((component) => component.source_component_id);
    this.traces = params.ctx.circuitJson.filter(
      (element) => element.type === "schematic_trace"
    );
    this.solved = this.hostIds.length === 0;
  }
  params;
  index;
  hostIds;
  traces;
  currentIndex = 0;
  _step() {
    const hostId = this.hostIds[this.currentIndex++];
    this.solved = this.currentIndex >= this.hostIds.length;
    if (!hostId) return;
    const index = this.index;
    const host = index.placement(hostId);
    const ports = index.portsByComponent.get(hostId) ?? [];
    const positive2 = ports.filter((port) => inputRole(port) === "positive");
    const negative = ports.filter((port) => inputRole(port) === "negative");
    const outputs = ports.filter(
      (port) => hasHint2(port, /^(?:OUT|VOUT|OUTPUT)$/)
    );
    if (!host || positive2.length !== 1 || negative.length !== 1 || outputs.length !== 1 || !ports.some((port) => hasHint2(port, /^(?:VS|VCC|VDD)$/)) || !ports.some((port) => hasHint2(port, /^(?:GND|GROUND|VSS)$/)))
      return;
    const inputs = [positive2[0], negative[0]];
    const nets = inputs.map((port) => index.connected(port.source_port_id));
    if (inputs.some((port) => port.do_not_connect) || nets[0] === nets[1] || nets.includes(index.connected(outputs[0].source_port_id)))
      return;
    const pins = inputs.map((port) => index.port(port));
    const [positivePin, negativePin] = pins;
    if (!positivePin || !negativePin || !positivePin.facing_direction || positivePin.facing_direction !== negativePin.facing_direction || pins.some((pin) => pin.schematic_sheet_id !== host.schematicSheetId))
      return;
    const resistorIds = new Set(
      (index.portsByNet.get(nets[0]) ?? []).filter(
        (port) => index.components.get(port.source_component_id)?.ftype === "simple_resistor"
      ).map((port) => port.source_component_id).filter((id) => index.twoTerminalNets(id)?.includes(nets[1]))
    );
    if (resistorIds.size !== 1) return;
    const shuntId = [...resistorIds][0];
    const component = index.components.get(shuntId);
    if (component?.ftype !== "simple_resistor" || !Number.isFinite(component.resistance) || component.resistance <= 0 || component.resistance > 1)
      return;
    if (nets.some(
      (net) => (index.portsByNet.get(net) ?? []).some(
        (port) => port.source_component_id !== hostId && inputRole(port) !== void 0 && index.components.get(port.source_component_id)?.ftype === "simple_chip"
      )
    ))
      return;
    const shunt = index.placement(shuntId);
    if (!shunt || !index.sameLocalScope(host, shunt)) return;
    const shuntPorts = index.portsByComponent.get(shuntId);
    if (shuntPorts.some((port) => port.do_not_connect)) return;
    const shuntPins = nets.map(
      (net) => index.port(
        shuntPorts.find(
          (port) => index.connected(port.source_port_id) === net
        )
      )
    );
    if (shuntPins.some(
      (pin) => !pin || pin.schematic_sheet_id !== host.schematicSheetId
    ))
      return;
    const horizontalInputs = positivePin.facing_direction === "left" || positivePin.facing_direction === "right";
    const across = (point2) => horizontalInputs ? point2.y : point2.x;
    const first = across(positivePin.center), second = across(negativePin.center);
    const span = Math.abs(first - second);
    if (span < EPSILON3) return;
    const shuntAcross = horizontalInputs ? shunt.schY : shunt.schX;
    const halfSize = (horizontalInputs ? shunt.height : shunt.width) / 2;
    const inputBandGap = Math.max(
      Math.min(first, second) - (shuntAcross + halfSize),
      shuntAcross - halfSize - Math.max(first, second)
    );
    if (inputBandGap <= Math.max(1.5, 2 * span) || Math.hypot(shunt.schX - host.schX, shunt.schY - host.schY) > Math.max(8, 4 * Math.max(host.width, host.height)))
      return;
    const visible = pins.map(
      (pin, i) => this.hasVisibleConnection(shuntPins[i], pin, nets[i])
    );
    if (visible[0] === visible[1]) return;
    const labeledIndex = visible[0] ? 1 : 0;
    const labeledNet = nets[labeledIndex];
    if (!this.params.ctx.circuitJson.some((element) => {
      if (element.type !== "schematic_net_label" || element.schematic_sheet_id !== host.schematicSheetId)
        return false;
      if (element.source_net_id && (index.connected(element.source_net_id) === labeledNet || index.connected(`connectivity:${element.source_net_id}`) === labeledNet))
        return true;
      const pin = shuntPins[labeledIndex].center;
      if (element.anchor_position && Math.hypot(
        element.anchor_position.x - pin.x,
        element.anchor_position.y - pin.y
      ) < EPSILON3)
        return true;
      return element.source_trace_id !== void 0 && this.sourceTraceTouchesNet(element.source_trace_id, labeledNet);
    }))
      return;
    this.params.issues.push({
      lineItemType: "CurrentSenseShuntSeparatedFromInputs",
      amplifierSchematicBox: host,
      shuntSchematicBox: shunt,
      positiveInputSourcePortId: inputs[0].source_port_id,
      negativeInputSourcePortId: inputs[1].source_port_id,
      inputBandGap,
      message: `Place ${shunt.sourceComponentName || "component"} near ${host.sourceComponentName || "component"}.${inputs[0].name}/${inputs[1].name}, so both sense connections can be read together. Move or rotate the shunt as needed; preserve all pin connections and leave room for labels.`
    });
  }
  hasVisibleConnection(from, to, net) {
    const edges = this.traces.filter((trace) => {
      if (trace.schematic_sheet_id !== from.schematic_sheet_id) return false;
      if (trace.subcircuit_connectivity_map_key)
        return this.index.connected(
          `connectivity:${trace.subcircuit_connectivity_map_key}`
        ) === net;
      if (this.sourceTraceTouchesNet(trace.source_trace_id, net)) return true;
      const endpoints = [trace.edges[0]?.from, trace.edges.at(-1)?.to];
      const endpointNets = new Set(
        this.params.ctx.circuitJson.flatMap(
          (element) => element.type === "schematic_port" && element.source_port_id && element.schematic_sheet_id === trace.schematic_sheet_id && endpoints.some(
            (point2) => point2 && Math.hypot(
              point2.x - element.center.x,
              point2.y - element.center.y
            ) < EPSILON3
          ) ? [this.index.connected(element.source_port_id)] : []
        )
      );
      return endpointNets.size === 1 && endpointNets.has(net);
    }).flatMap((trace) => trace.edges);
    const reached = edges.filter(
      (edge) => onSegment(from.center, edge.from, edge.to)
    );
    const visited = /* @__PURE__ */ new Set();
    for (let i = 0; i < reached.length; i++) {
      const current = reached[i];
      if (onSegment(to.center, current.from, current.to)) return true;
      for (const [edgeIndex, edge] of edges.entries()) {
        if (visited.has(edgeIndex) || ![current.from, current.to].some(
          (point2) => onSegment(point2, edge.from, edge.to)
        ) && ![edge.from, edge.to].some(
          (point2) => onSegment(point2, current.from, current.to)
        ))
          continue;
        visited.add(edgeIndex);
        reached.push(edge);
      }
    }
    return false;
  }
  sourceTraceTouchesNet(traceId, net) {
    if (!traceId) return false;
    const source = this.params.ctx.circuitJson.find(
      (element) => element.type === "source_trace" && element.source_trace_id === traceId
    );
    return source?.type === "source_trace" && source.connected_source_port_ids.some(
      (id) => this.index.connected(id) === net
    );
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(
      attrs,
      "amplifierName",
      issue.amplifierSchematicBox.sourceComponentName
    );
    addAttr(attrs, "shuntName", issue.shuntSchematicBox.sourceComponentName);
    addAttr(attrs, "inputBandGap", issue.inputBandGap);
    addAttr(attrs, "message", issue.message);
    return `<CurrentSenseShuntSeparatedFromInputs ${attrs.join(" ")} />`;
  }
};
function hasHint2(port, pattern) {
  return [port.name, ...port.port_hints ?? []].some(
    (hint) => pattern.test(hint.toUpperCase().replace(/[\s_]/g, ""))
  );
}
function inputRole(port) {
  const positive2 = hasHint2(port, /^(?:IN\+|VIN\+|INPOS|VINPOS)$/);
  const negative = hasHint2(port, /^(?:IN-|VIN-|INNEG|VINNEG)$/);
  return positive2 === negative ? void 0 : positive2 ? "positive" : "negative";
}
function onSegment(point2, from, to) {
  const dx = to.x - from.x, dy = to.y - from.y;
  const length = Math.hypot(dx, dy);
  if (length < EPSILON3)
    return Math.hypot(point2.x - from.x, point2.y - from.y) < EPSILON3;
  const projection = ((point2.x - from.x) * dx + (point2.y - from.y) * dy) / length;
  return projection >= -EPSILON3 && projection <= length + EPSILON3 && Math.abs((point2.x - from.x) * dy - (point2.y - from.y) * dx) / length < EPSILON3;
}

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/VoltageDividerPlacementSolver/VoltageDividerPlacementSolver.ts
import { BaseSolver as BaseSolver12 } from "@tscircuit/solver-utils";
var VoltageDividerPlacementSolver = class extends BaseSolver12 {
  constructor(params) {
    super();
    this.params = params;
    this.index = new PlacementNetworkIndex(params.ctx);
    this.resistorIds = [...this.index.components.values()].filter((component) => component.ftype === "simple_resistor").map((component) => component.source_component_id);
    for (const element of params.ctx.circuitJson) {
      if (element.type === "source_net" && element.is_positive_voltage_source)
        this.positiveNets.add(this.index.connected(element.source_net_id));
    }
    this.solved = this.resistorIds.length === 0;
  }
  params;
  index;
  positiveNets = /* @__PURE__ */ new Set();
  resistorIds;
  currentIndex = 0;
  _step() {
    const supplyId = this.resistorIds[this.currentIndex++];
    this.solved = this.currentIndex >= this.resistorIds.length;
    if (!supplyId || !this.isResistor(supplyId)) return;
    const index = this.index;
    const nets = index.twoTerminalNets(supplyId);
    if (!nets) return;
    const rails = nets.filter((net) => index.isRail(net));
    if (rails.length !== 1) return;
    const supplyNet = rails[0];
    if (!this.positiveNets.has(supplyNet) || index.groundNets.has(supplyNet))
      return;
    const tap = nets.find((net) => net !== supplyNet);
    const tapPorts = index.portsByNet.get(tap) ?? [];
    const resistorIds = new Set(
      tapPorts.filter(
        (port) => index.components.get(port.source_component_id)?.ftype === "simple_resistor"
      ).map((port) => port.source_component_id)
    );
    if (resistorIds.size !== 2) return;
    const groundId = [...resistorIds].find((id) => id !== supplyId);
    if (!this.isResistor(groundId)) return;
    const groundNets = index.twoTerminalNets(groundId);
    const groundNet = groundNets?.find((net) => net !== tap);
    if (!groundNets?.includes(tap) || !groundNet || !index.groundNets.has(groundNet) || index.powerNets.has(groundNet) || !tapPorts.some((port) => !resistorIds.has(port.source_component_id)))
      return;
    const supply = index.placement(supplyId);
    const ground = index.placement(groundId);
    if (!supply || !ground || !index.sameLocalScope(supply, ground)) return;
    const supplyTap = this.getDownwardResistorPorts(supplyId, supplyNet, tap);
    const groundTap = this.getDownwardResistorPorts(groundId, tap, groundNet);
    if (!supplyTap || !groundTap) return;
    const reversedBodyGap = ground.schY - ground.height / 2 - (supply.schY + supply.height / 2);
    if (reversedBodyGap <= 1.5) return;
    this.params.issues.push({
      lineItemType: "VoltageDividerSupplyResistorBelowGroundResistor",
      supplyResistorSchematicBox: supply,
      groundResistorSchematicBox: ground,
      supplyTapSourcePortId: supplyTap.bottom.source_port_id,
      groundTapSourcePortId: groundTap.top.source_port_id,
      reversedBodyGap,
      message: `Place ${supply.sourceComponentName || "component"} above ${ground.sourceComponentName || "component"}, close enough to read their shared divider tap. Preserve all connections and leave room for labels; exact alignment is not required.`
    });
  }
  isResistor(id) {
    const component = this.index.components.get(id);
    return component?.ftype === "simple_resistor" && Number.isFinite(component.resistance) && component.resistance > 0;
  }
  getDownwardResistorPorts(id, topNet, bottomNet) {
    const index = this.index;
    const placement = index.placement(id);
    const ports = index.portsByComponent.get(id);
    if (ports.some((port) => port.do_not_connect)) return;
    const top = ports.find(
      (port) => index.connected(port.source_port_id) === topNet
    );
    const bottom = ports.find(
      (port) => index.connected(port.source_port_id) === bottomNet
    );
    if (!top || !bottom) return;
    const topPin = index.port(top);
    const bottomPin = index.port(bottom);
    if (!topPin || !bottomPin || topPin.schematic_sheet_id !== placement.schematicSheetId || bottomPin.schematic_sheet_id !== placement.schematicSheetId || topPin.facing_direction !== "up" || bottomPin.facing_direction !== "down" || topPin.center.y <= bottomPin.center.y)
      return;
    return { top, bottom };
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(
      attrs,
      "supplyResistorName",
      issue.supplyResistorSchematicBox.sourceComponentName
    );
    addAttr(
      attrs,
      "groundResistorName",
      issue.groundResistorSchematicBox.sourceComponentName
    );
    addAttr(attrs, "reversedBodyGap", issue.reversedBodyGap);
    addAttr(attrs, "message", issue.message);
    return `<VoltageDividerSupplyResistorBelowGroundResistor ${attrs.join(" ")} />`;
  }
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/RegulatorInputOutputCapacitorPlacementSolver/RegulatorInputOutputCapacitorPlacementSolver.ts
import { BaseSolver as BaseSolver13 } from "@tscircuit/solver-utils";
var RegulatorInputOutputCapacitorPlacementSolver = class extends BaseSolver13 {
  constructor(params) {
    super();
    this.params = params;
    this.index = new PlacementNetworkIndex(params.ctx);
    this.hostIds = [...this.index.components.values()].filter((component) => component.ftype === "simple_chip").map((component) => component.source_component_id);
    this.solved = this.hostIds.length === 0;
  }
  params;
  index;
  hostIds;
  currentIndex = 0;
  _step() {
    const hostId = this.hostIds[this.currentIndex++];
    this.solved = this.currentIndex >= this.hostIds.length;
    if (!hostId) return;
    const index = this.index;
    const host = index.placement(hostId);
    const ports = index.portsByComponent.get(hostId) ?? [];
    if (!host || ports.some((port) => !portRole(port))) return;
    const inputs = ports.filter((port) => portRole(port) === "input");
    const outputs = ports.filter((port) => portRole(port) === "output");
    const grounds = ports.filter((port) => portRole(port) === "ground");
    if (inputs.length !== 1 || outputs.length !== 1 || !grounds.length) return;
    const input = inputs[0];
    const output = outputs[0];
    if ([input, output, ...grounds].some((port) => port.do_not_connect)) return;
    const inputNet = index.connected(input.source_port_id);
    const outputNet = index.connected(output.source_port_id);
    const groundNets = new Set(
      grounds.map((port) => index.connected(port.source_port_id))
    );
    if (groundNets.size !== 1) return;
    const groundNet = [...groundNets][0];
    if ((/* @__PURE__ */ new Set([inputNet, outputNet, groundNet])).size !== 3 || !(index.groundNets.has(groundNet) || grounds.some((port) => port.requires_ground || port.provides_ground)) || !(index.powerNets.has(inputNet) || input.requires_power) || !(index.powerNets.has(outputNet) || output.provides_power))
      return;
    const inputPin = index.port(input);
    const outputPin = index.port(output);
    if (!inputPin || !outputPin || inputPin.schematic_sheet_id !== host.schematicSheetId || outputPin.schematic_sheet_id !== host.schematicSheetId)
      return;
    const horizontal = inputPin.facing_direction === "left" && outputPin.facing_direction === "right" || inputPin.facing_direction === "right" && outputPin.facing_direction === "left";
    const vertical = inputPin.facing_direction === "up" && outputPin.facing_direction === "down" || inputPin.facing_direction === "down" && outputPin.facing_direction === "up";
    if (!horizontal && !vertical) return;
    const sign = outputPin.facing_direction === "right" || outputPin.facing_direction === "up" ? 1 : -1;
    const pinSeparation = sign * (horizontal ? outputPin.center.x - inputPin.center.x : outputPin.center.y - inputPin.center.y);
    if (pinSeparation <= 0.01) return;
    const inputCap = this.localCapacitor(host, inputNet, groundNet);
    const outputCap = this.localCapacitor(host, outputNet, groundNet);
    if (!inputCap || !outputCap) return;
    const beyondOppositeSide = (cap, side) => {
      const distance6 = side * sign * (horizontal ? cap.schX - host.schX : cap.schY - host.schY);
      const halfBodies = horizontal ? (host.width + cap.width) / 2 : (host.height + cap.height) / 2;
      return distance6 > halfBodies + 0.2;
    };
    if (!beyondOppositeSide(inputCap, 1) || !beyondOppositeSide(outputCap, -1))
      return;
    const name = host.sourceComponentName || "component";
    this.params.issues.push({
      lineItemType: "RegulatorCapacitorsOnWrongSides",
      regulatorSchematicBox: host,
      inputCapacitorSchematicBox: inputCap,
      outputCapacitorSchematicBox: outputCap,
      inputSourcePortId: input.source_port_id,
      outputSourcePortId: output.source_port_id,
      message: `Place ${inputCap.sourceComponentName} near ${name}.${input.name} on the ${inputPin.facing_direction} side and ${outputCap.sourceComponentName} near ${name}.${output.name} on the ${outputPin.facing_direction} side. Preserve all connections and leave room for labels; exact alignment is not required.`
    });
  }
  localCapacitor(host, rail, ground) {
    const index = this.index;
    const candidates = [];
    const maxDistance = Math.max(6, 4 * Math.max(host.width, host.height));
    const ids = new Set(
      (index.portsByNet.get(rail) ?? []).map(
        (port) => port.source_component_id
      )
    );
    for (const id of ids) {
      if (index.components.get(id)?.ftype !== "simple_capacitor") continue;
      const nets = index.twoTerminalNets(id);
      const cap = index.placement(id);
      if (!nets?.includes(ground) || !cap || !index.sameLocalScope(host, cap))
        continue;
      if (Math.hypot(cap.schX - host.schX, cap.schY - host.schY) > maxDistance)
        continue;
      const ports = index.portsByComponent.get(id);
      if (ports.some(
        (port) => port.do_not_connect || !index.port(port) || index.port(port).schematic_sheet_id !== host.schematicSheetId
      ))
        continue;
      candidates.push(cap);
    }
    return candidates.length === 1 ? candidates[0] : void 0;
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(
      attrs,
      "regulatorName",
      issue.regulatorSchematicBox.sourceComponentName
    );
    addAttr(
      attrs,
      "inputCapacitorName",
      issue.inputCapacitorSchematicBox.sourceComponentName
    );
    addAttr(
      attrs,
      "outputCapacitorName",
      issue.outputCapacitorSchematicBox.sourceComponentName
    );
    addAttr(attrs, "message", issue.message);
    return `<RegulatorCapacitorsOnWrongSides ${attrs.join(" ")} />`;
  }
};
function portRole(port) {
  const roles = /* @__PURE__ */ new Set();
  for (const hint of [port.name, ...port.port_hints ?? []]) {
    const name = hint.toUpperCase().replace(/[ _-]/g, "");
    if (/^(?:VIN|IN|INPUT)$/.test(name)) roles.add("input");
    else if (/^(?:VOUT|OUT|OUTPUT)$/.test(name)) roles.add("output");
    else if (/^(?:GND\d*|VSS)$/.test(name)) roles.add("ground");
    else if (/^(?:EN|ENABLE|CE|SHDN|NC\d*|EP|PAD|ADJ|FB|BYP|BYPASS|NR|PG|PGOOD)$/.test(
      name
    ))
      roles.add("control");
  }
  return roles.size === 1 ? [...roles][0] : void 0;
}

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/ConnectorPlacementSolver/ConnectorPlacementSolver.ts
import { BaseSolver as BaseSolver14 } from "@tscircuit/solver-utils";

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/utils/geometry.ts
function centeredRect(cx, cy, w, h) {
  return {
    left: cx - w / 2,
    right: cx + w / 2,
    top: cy + h / 2,
    bottom: cy - h / 2
  };
}
function rectOverlap(a, b) {
  const ow = Math.min(a.right, b.right) - Math.max(a.left, b.left);
  const oh = Math.min(a.top, b.top) - Math.max(a.bottom, b.bottom);
  return ow > 0 && oh > 0 ? { ow, oh } : null;
}

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/ConnectorPlacementSolver/ConnectorPlacementSolver.ts
var EPSILON4 = 0.01;
var directions = {
  right: { x: 1, y: 0 },
  left: { x: -1, y: 0 },
  up: { x: 0, y: 1 },
  down: { x: 0, y: -1 }
};
var dot = (a, b) => a.x * b.x + a.y * b.y;
var distance4 = (a, b) => Math.abs(a.x - b.x) + Math.abs(a.y - b.y);
var near = (a, b) => distance4(a, b) <= EPSILON4;
var round = (value) => Math.round(value * 100) / 100;
var ConnectorPlacementSolver = class extends BaseSolver14 {
  constructor(params) {
    super();
    this.params = params;
  }
  params;
  _step() {
    const { ctx, issues } = this.params;
    const index = new PlacementNetworkIndex(ctx);
    for (const ports of index.portsByComponent.values()) {
      for (const port of ports) {
        const net = index.connected(port.source_port_id);
        if (port.requires_ground || port.provides_ground)
          index.groundNets.add(net);
        if (port.requires_power || port.provides_power) index.powerNets.add(net);
      }
    }
    const allTraces = ctx.circuitJson.filter(
      (e) => e.type === "schematic_trace"
    );
    for (const [id, source] of index.components) {
      if (source.ftype !== "simple_pin_header" && source.ftype !== "simple_connector")
        continue;
      const connector = index.placement(id);
      const sourcePorts = index.portsByComponent.get(id) ?? [];
      if (!connector || sourcePorts.length < 2) continue;
      const pins = sourcePorts.map((p) => index.port(p));
      const facing = pins[0]?.facing_direction;
      if (!facing || pins.some((p) => !p || p.facing_direction !== facing))
        continue;
      const along = directions[facing];
      const across = { x: -along.y, y: along.x };
      const traces = allTraces.filter(
        (t) => t.schematic_sheet_id === connector.schematicSheetId
      );
      const railLabels = ctx.circuitJson.filter(
        (e) => e.type === "schematic_net_label" && e.schematic_sheet_id === connector.schematicSheetId
      );
      const connections = [];
      let ambiguous = false;
      for (const sourcePort of sourcePorts) {
        const pin = index.port(sourcePort);
        const net = index.connected(sourcePort.source_port_id);
        const peers = (index.portsByNet.get(net) ?? []).filter(
          (p) => p.source_port_id !== sourcePort.source_port_id
        );
        const incidentTraces = traces.filter(
          (t) => t.edges.some(
            (edge) => near(edge.from, pin.center) || near(edge.to, pin.center)
          )
        );
        if (index.isRail(net)) {
          if (incidentTraces.some(
            (t) => !railLabels.some(
              (label) => label.anchor_position && joins(t, pin.center, label.anchor_position)
            )
          ))
            ambiguous = true;
          continue;
        }
        if (peers.length === 0) {
          if (incidentTraces.length > 0) ambiguous = true;
          continue;
        }
        const peer = peers.length === 1 ? index.port(peers[0]) : void 0;
        const component = peers.length === 1 ? index.placement(peers[0].source_component_id) : void 0;
        if (!peer?.facing_direction || !component || !index.sameLocalScope(connector, component) || dot(directions[peer.facing_direction], along) !== -1) {
          ambiguous = true;
          break;
        }
        connections.push({ pin, peer, component });
      }
      if (ambiguous || connections.length < 2) continue;
      if (connections.some(
        (c) => dot(c.peer.center, along) >= dot(c.pin.center, along) - 2
      ))
        continue;
      const detouredConnections = connections.map(
        (c) => traces.filter(
          (t) => joins(t, c.pin.center, c.peer.center) && bendCount(t) >= 3
        )
      ).filter((t) => t.length > 0);
      if (detouredConnections.length < 2) continue;
      const detours = detouredConnections.flat();
      const ordered = [...connections].sort(
        (a, b) => dot(a.pin.center, across) - dot(b.pin.center, across)
      );
      if (ordered.some(
        (c, i) => i > 0 && dot(c.peer.center, across) <= dot(ordered[i - 1].peer.center, across) + EPSILON4
      ))
        continue;
      const center = { x: connector.schX, y: connector.schY };
      const pinOffset = Math.max(
        ...connections.map(
          (c) => dot(c.pin.center, along) - dot(center, along)
        )
      );
      const targetAlong = Math.min(...connections.map((c) => dot(c.peer.center, along))) - 2 - pinOffset;
      const offsets = connections.map(
        (c) => dot(c.peer.center, across) - dot(c.pin.center, across) + dot(center, across)
      ).sort((a, b) => a - b);
      const targetAcross = offsets[Math.floor(offsets.length / 2)];
      const target = {
        x: round(along.x * targetAlong + across.x * targetAcross),
        y: round(along.y * targetAlong + across.y * targetAcross)
      };
      const delta = { x: target.x - center.x, y: target.y - center.y };
      const movedPin = (pin) => ({
        x: pin.center.x + delta.x,
        y: pin.center.y + delta.y
      });
      if (connections.some(
        (c) => distance4(movedPin(c.pin), c.peer.center) > distance4(c.pin.center, c.peer.center) + EPSILON4
      ))
        continue;
      const before = connections.reduce(
        (sum, c) => sum + distance4(c.pin.center, c.peer.center),
        0
      );
      const after = connections.reduce(
        (sum, c) => sum + distance4(movedPin(c.pin), c.peer.center),
        0
      );
      if (before - after < 4 || after > before * 0.75) continue;
      const obstacles = ctx.componentPlacements.filter(
        (p) => p.schematicSheetId === connector.schematicSheetId && p.schematicComponentId !== connector.schematicComponentId
      );
      const targetBounds = centeredRect(
        target.x,
        target.y,
        connector.width + 0.4,
        connector.height + 0.4
      );
      if (obstacles.some(
        (p) => rectOverlap(
          targetBounds,
          centeredRect(p.schX, p.schY, p.width, p.height)
        )
      ))
        continue;
      if (connections.some((c) => {
        const start = movedPin(c.pin);
        const end = c.peer.center;
        const middleAlong = (dot(start, along) + dot(end, along)) / 2;
        const points = [
          start,
          {
            x: along.x * middleAlong + across.x * dot(start, across),
            y: along.y * middleAlong + across.y * dot(start, across)
          },
          {
            x: along.x * middleAlong + across.x * dot(end, across),
            y: along.y * middleAlong + across.y * dot(end, across)
          },
          end
        ];
        return obstacles.some(
          (p) => p.schematicComponentId !== c.component.schematicComponentId && points.slice(1).some((point2, i) => segmentCrossesBox(points[i], point2, p))
        );
      }))
        continue;
      const connectedComponents = [
        ...new Map(
          connections.map((c) => [
            c.component.schematicComponentId,
            c.component
          ])
        ).values()
      ];
      const name = connector.sourceComponentName || "component";
      issues.push({
        lineItemType: "ConnectorPositionCausesTraceDetours",
        connectorSchematicBox: connector,
        connectedComponents,
        schematicTraceIds: [
          ...new Set(detours.map((t) => t.schematic_trace_id))
        ],
        evaluatedSignalCount: connections.length,
        newSchX: target.x,
        newSchY: target.y,
        deltaSchX: round(delta.x),
        deltaSchY: round(delta.y),
        currentTotalSignalDistance: round(before),
        suggestedTotalSignalDistance: round(after),
        message: `Move ${name} to schX=${target.x}, schY=${target.y} so its signal pins face ${connectedComponents.map((p) => p.sourceComponentName || "component").join(", ")}. Preserve rotation and pin assignments; reroute the connections and attached rail labels.`
      });
    }
    this.solved = true;
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(
      attrs,
      "connectorComponentName",
      issue.connectorSchematicBox.sourceComponentName
    );
    addAttr(
      attrs,
      "connectedComponents",
      issue.connectedComponents.map((p) => p.sourceComponentName || "component").join(",")
    );
    for (const key of [
      "evaluatedSignalCount",
      "newSchX",
      "newSchY",
      "deltaSchX",
      "deltaSchY",
      "currentTotalSignalDistance",
      "suggestedTotalSignalDistance"
    ])
      addAttr(attrs, key, issue[key]);
    addAttr(attrs, "message", issue.message);
    return `<ConnectorPositionCausesTraceDetours ${attrs.join(" ")} />`;
  }
};
function joins(trace, a, b) {
  const first = trace.edges[0]?.from;
  const last = trace.edges.at(-1)?.to;
  return !!first && !!last && (near(first, a) && near(last, b) || near(first, b) && near(last, a));
}
function bendCount(trace) {
  let previousAxis;
  let bends = 0;
  for (let i = 0; i < trace.edges.length; i++) {
    const edge = trace.edges[i];
    if (i > 0 && !near(trace.edges[i - 1].to, edge.from)) return 0;
    if (near(edge.from, edge.to)) continue;
    const axis = Math.abs(edge.from.y - edge.to.y) < EPSILON4 ? "x" : Math.abs(edge.from.x - edge.to.x) < EPSILON4 ? "y" : void 0;
    if (!axis) return 0;
    if (previousAxis && previousAxis !== axis) bends++;
    previousAxis = axis;
  }
  return bends;
}
function segmentCrossesBox(a, b, box) {
  const bounds = centeredRect(
    box.schX,
    box.schY,
    box.width + 0.2,
    box.height + 0.2
  );
  return Math.max(a.x, b.x) > bounds.left && Math.min(a.x, b.x) < bounds.right && Math.max(a.y, b.y) > bounds.bottom && Math.min(a.y, b.y) < bounds.top;
}

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/LowSideTransistorPlacementSolver/LowSideTransistorPlacementSolver.ts
import { BaseSolver as BaseSolver15 } from "@tscircuit/solver-utils";
var LowSideTransistorPlacementSolver = class extends BaseSolver15 {
  index;
  positiveNets = /* @__PURE__ */ new Set();
  transistorIds;
  issues;
  currentIndex = 0;
  constructor({
    ctx,
    issues
  }) {
    super();
    this.issues = issues;
    this.index = new PlacementNetworkIndex(ctx);
    for (const element of ctx.circuitJson) {
      if (element.type === "source_net" && element.is_positive_voltage_source)
        this.positiveNets.add(this.index.connected(element.source_net_id));
    }
    this.transistorIds = [...this.index.components.values()].filter(
      (component) => component.ftype === "simple_transistor" && component.transistor_type === "npn"
    ).map((component) => component.source_component_id);
    this.solved = this.transistorIds.length === 0;
  }
  _step() {
    const id = this.transistorIds[this.currentIndex++];
    this.solved = this.currentIndex >= this.transistorIds.length;
    if (!id) return;
    const index = this.index;
    const transistor = index.placement(id);
    if (!transistor || index.portsByComponent.get(id)?.length !== 3) return;
    const base = index.namedPort(id, "base");
    const collector = index.namedPort(id, "collector");
    const emitter = index.namedPort(id, "emitter");
    if (!base || !collector || !emitter) return;
    const baseNet = index.connected(base.source_port_id);
    const collectorNet = index.connected(collector.source_port_id);
    const emitterNet = index.connected(emitter.source_port_id);
    if ((/* @__PURE__ */ new Set([baseNet, collectorNet, emitterNet])).size !== 3 || !index.groundNets.has(emitterNet) || index.powerNets.has(emitterNet) || index.isRail(baseNet) || index.isRail(collectorNet))
      return;
    const basePeers = (index.portsByNet.get(baseNet) ?? []).filter(
      (port) => port.source_component_id !== id
    );
    if (basePeers.length !== 1) return;
    const resistorId = basePeers[0].source_component_id;
    const resistor = index.components.get(resistorId);
    const baseResistor = index.placement(resistorId);
    const resistorNets = index.twoTerminalNets(resistorId);
    const inputNet = resistorNets?.find((net) => net !== baseNet);
    if (resistor?.ftype !== "simple_resistor" || resistor.resistance <= 0 || !baseResistor || !index.sameLocalScope(transistor, baseResistor) || !inputNet || index.isRail(inputNet) || inputNet === collectorNet)
      return;
    const collectorPeers = (index.portsByNet.get(collectorNet) ?? []).filter(
      (port) => port.source_component_id !== id
    );
    const loadPeers = collectorPeers.filter((port) => {
      const type = index.components.get(port.source_component_id)?.ftype;
      return type === "simple_chip";
    });
    if (loadPeers.length !== 1) return;
    const loadId = loadPeers[0].source_component_id;
    const load = index.placement(loadId);
    const loadNets = index.twoTerminalNets(loadId);
    const supplyNet = loadNets?.find((net) => net !== collectorNet);
    if (!load || !index.sameLocalScope(transistor, load) || !supplyNet || !this.positiveNets.has(supplyNet) || index.groundNets.has(supplyNet))
      return;
    const clampPeers = collectorPeers.filter(
      (port) => port.source_component_id !== loadId
    );
    if (clampPeers.length !== 1) return;
    const clampId = clampPeers[0].source_component_id;
    const clamp2 = index.placement(clampId);
    const anode = index.namedPort(clampId, "anode");
    const cathode = index.namedPort(clampId, "cathode");
    if (index.components.get(clampId)?.ftype !== "simple_diode" || !index.twoTerminalNets(clampId) || !anode || !cathode || index.connected(anode.source_port_id) !== collectorNet || index.connected(cathode.source_port_id) !== supplyNet || !clamp2 || !index.sameLocalScope(transistor, clamp2))
      return;
    const collectorPin = index.port(collector);
    const emitterPin = index.port(emitter);
    const basePin = index.port(base);
    if (!collectorPin || !emitterPin || !basePin) return;
    const collectorFacingDirection = collectorPin.facing_direction;
    const emitterFacingDirection = emitterPin.facing_direction;
    if (!collectorFacingDirection || !emitterFacingDirection) return;
    const placementProblems = [];
    if (transistor.schY >= load.schY)
      placementProblems.push("transistor_not_below_load");
    if (collectorFacingDirection !== "up")
      placementProblems.push("collector_not_up");
    if (emitterFacingDirection !== "down")
      placementProblems.push("emitter_not_down");
    if (placementProblems.length === 0) return;
    const name = transistor.sourceComponentName || "component";
    const loadName = load.sourceComponentName || "component";
    this.issues.push({
      lineItemType: "LowSideTransistorNotAlignedWithLoad",
      transistorSchematicBox: transistor,
      loadSchematicBox: load,
      baseResistorSchematicBox: baseResistor,
      clampDiodeSchematicBox: clamp2,
      collectorSourcePortId: collector.source_port_id,
      emitterSourcePortId: emitter.source_port_id,
      collectorFacingDirection,
      emitterFacingDirection,
      placementProblems,
      message: `Arrange ${name} below ${loadName}, with its collector facing up toward the load and emitter facing down toward ground; place ${baseResistor.sourceComponentName || "component"} beside the base. Preserve all pin connections and reroute affected traces.`
    });
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(
      attrs,
      "transistorName",
      issue.transistorSchematicBox.sourceComponentName
    );
    addAttr(attrs, "loadName", issue.loadSchematicBox.sourceComponentName);
    addAttr(
      attrs,
      "baseResistorName",
      issue.baseResistorSchematicBox.sourceComponentName
    );
    addAttr(
      attrs,
      "clampDiodeName",
      issue.clampDiodeSchematicBox.sourceComponentName
    );
    addAttr(attrs, "placementProblems", issue.placementProblems.join(","));
    addAttr(attrs, "collectorFacingDirection", issue.collectorFacingDirection);
    addAttr(attrs, "emitterFacingDirection", issue.emitterFacingDirection);
    addAttr(attrs, "message", issue.message);
    return `<LowSideTransistorNotAlignedWithLoad ${attrs.join(" ")} />`;
  }
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/UsbSeriesResistorPlacementSolver/UsbSeriesResistorPlacementSolver.ts
import { BaseSolver as BaseSolver16 } from "@tscircuit/solver-utils";
var UsbSeriesResistorPlacementSolver = class extends BaseSolver16 {
  constructor(params) {
    super();
    this.params = params;
    this.index = new PlacementNetworkIndex(params.ctx);
    this.hostIds = [...this.index.components.values()].filter((component) => component.ftype === "simple_chip").map((component) => component.source_component_id);
    this.solved = this.hostIds.length === 0;
  }
  params;
  index;
  hostIds;
  reportedPairs = /* @__PURE__ */ new Set();
  currentIndex = 0;
  _step() {
    const hostId = this.hostIds[this.currentIndex++];
    this.solved = this.currentIndex >= this.hostIds.length;
    if (!hostId) return;
    const ports = this.index.portsByComponent.get(hostId) ?? [];
    const positivePorts = ports.filter((port) => usbRole(port) === "positive");
    const negativePorts = ports.filter((port) => usbRole(port) === "negative");
    if (positivePorts.length !== 1 || negativePorts.length !== 1) return;
    const positivePort = positivePorts[0];
    const negativePort = negativePorts[0];
    const positive2 = this.seriesResistor(positivePort);
    const negative = this.seriesResistor(negativePort);
    if (!positive2 || !negative || positive2.axis !== negative.axis || !this.index.sameLocalScope(positive2.placement, negative.placement) || (/* @__PURE__ */ new Set([
      positive2.hostNet,
      negative.hostNet,
      positive2.interfaceNet,
      negative.interfaceNet
    ])).size !== 4 || !this.shareInterface(positive2, negative, hostId))
      return;
    const pairKey = [positive2.id, negative.id].sort().join("\0");
    if (this.reportedPairs.has(pairKey)) return;
    const a = positive2.placement;
    const b = negative.placement;
    const horizontal = positive2.axis === "horizontal";
    const along = Math.abs(horizontal ? a.schX - b.schX : a.schY - b.schY);
    const across = Math.abs(horizontal ? a.schY - b.schY : a.schX - b.schX);
    const alongA = horizontal ? a.width : a.height;
    const alongB = horizontal ? b.width : b.height;
    const acrossA = horizontal ? a.height : a.width;
    const acrossB = horizontal ? b.height : b.width;
    const bodyGap2 = along - (alongA + alongB) / 2;
    if (bodyGap2 < Math.max(alongA, alongB) || across >= (acrossA + acrossB) / 2 - 0.01)
      return;
    this.reportedPairs.add(pairKey);
    const positiveName = a.sourceComponentName || "component";
    const negativeName = b.sourceComponentName || "component";
    this.params.issues.push({
      lineItemType: "UsbSeriesResistorsNotAligned",
      positiveResistorSchematicBox: a,
      negativeResistorSchematicBox: b,
      hostSourceComponentId: hostId,
      positiveSourcePortId: positivePort.source_port_id,
      negativeSourcePortId: negativePort.source_port_id,
      signalAxis: positive2.axis,
      message: `Place ${positiveName} (D+) and ${negativeName} (D\u2212) near each other and draw clear traces to their corresponding USB ports. Exact alignment is not required; preserve pin assignments and leave space for labels.`
    });
  }
  seriesResistor(hostPort) {
    const index = this.index;
    const hostNet = index.connected(hostPort.source_port_id);
    if (index.isRail(hostNet)) return;
    const candidates = new Set(
      (index.portsByNet.get(hostNet) ?? []).filter(
        (port) => index.components.get(port.source_component_id)?.ftype === "simple_resistor"
      ).map((port) => port.source_component_id)
    );
    if (candidates.size !== 1) return;
    const id = [...candidates][0];
    const nets = index.twoTerminalNets(id);
    const interfaceNet = nets?.find((net) => net !== hostNet);
    const placement = index.placement(id);
    if (!interfaceNet || index.isRail(interfaceNet) || !placement) return;
    if ((index.portsByNet.get(interfaceNet) ?? []).some(
      (port) => port.source_component_id !== id && index.components.get(port.source_component_id)?.ftype === "simple_resistor"
    ))
      return;
    const pins = index.portsByComponent.get(id).map((port) => index.port(port));
    const [first, second] = pins;
    if (!first || !second) return;
    const facing = /* @__PURE__ */ new Set([first.facing_direction, second.facing_direction]);
    let axis;
    if (facing.has("left") && facing.has("right") && Math.abs(first.center.y - second.center.y) < 0.01)
      axis = "horizontal";
    else if (facing.has("up") && facing.has("down") && Math.abs(first.center.x - second.center.x) < 0.01)
      axis = "vertical";
    else return;
    return { id, placement, hostNet, interfaceNet, axis };
  }
  shareInterface(positive2, negative, hostId) {
    const peerIds = (net) => new Set(
      (this.index.portsByNet.get(net) ?? []).map((port) => port.source_component_id).filter(
        (id) => id !== hostId && id !== positive2.id && id !== negative.id && (this.index.portsByComponent.get(id)?.length ?? 0) > 2
      )
    );
    const positivePeers = peerIds(positive2.interfaceNet);
    return [...peerIds(negative.interfaceNet)].some(
      (id) => positivePeers.has(id)
    );
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(
      attrs,
      "positiveResistorName",
      issue.positiveResistorSchematicBox.sourceComponentName
    );
    addAttr(
      attrs,
      "negativeResistorName",
      issue.negativeResistorSchematicBox.sourceComponentName
    );
    addAttr(attrs, "signalAxis", issue.signalAxis);
    addAttr(attrs, "message", issue.message);
    return `<UsbSeriesResistorsNotAligned ${attrs.join(" ")} />`;
  }
};
function usbRole(port) {
  const roles = /* @__PURE__ */ new Set();
  for (const hint of [port.name, ...port.port_hints ?? []]) {
    const name = hint.toUpperCase();
    if (/^(?:USB_?)?D(?:P|\+|_POS)$/.test(name)) roles.add("positive");
    if (/^(?:USB_?)?D(?:M|N|-|_NEG)$/.test(name)) roles.add("negative");
  }
  return roles.size === 1 ? [...roles][0] : void 0;
}

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/CapacitorOrientationSolver/CapacitorOrientationSolver.ts
import { BaseSolver as BaseSolver17 } from "@tscircuit/solver-utils";

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/utils/graphics.ts
import { mergeGraphics } from "graphics-debug";
function mergeGraphicsObjects(objects) {
  return objects.filter((o) => o !== void 0).reduce((acc, o) => mergeGraphics(acc, o), {});
}
function highlightPlacement(placement, color, label) {
  return {
    rects: [
      {
        center: { x: placement.schX, y: placement.schY },
        width: placement.width,
        height: placement.height,
        stroke: color,
        fill: color.replace("0.95", "0.15"),
        label
      }
    ]
  };
}
function visualizeCircuitJson(circuitJson) {
  const rects = circuitJson.filter((el) => el.type === "schematic_box").map((el) => {
    const box = el;
    return {
      center: { x: box.x, y: box.y },
      width: box.width,
      height: box.height,
      stroke: "hsl(0,0%,60%)"
    };
  });
  return { rects };
}

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/CapacitorOrientationSolver/CapacitorOrientationSolver.ts
var CapacitorOrientationSolver = class _CapacitorOrientationSolver extends BaseSolver17 {
  static EPSILON = 0.01;
  static ORIENTATION_MESSAGE = 'Use schOrientation="vertical" on this capacitor to fix the symbol orientation';
  ctx;
  out;
  schematicComponentById;
  sourceComponentById;
  capacitorPlacements;
  feedbackCapacitorIds;
  currentPlacementIndex = 0;
  horizontalSymbolNames = /* @__PURE__ */ new Set([
    "capacitor_left",
    "capacitor_right"
  ]);
  constructor({
    ctx,
    issues: out
  }) {
    super();
    this.ctx = ctx;
    this.out = out;
    this.schematicComponentById = this.buildSchematicComponentById(
      ctx.circuitJson
    );
    this.sourceComponentById = this.buildSourceComponentById(ctx.circuitJson);
    this.capacitorPlacements = this.getCapacitorPlacements();
    const networks = new PlacementNetworkIndex(ctx);
    this.feedbackCapacitorIds = new Set(
      this.capacitorPlacements.flatMap(
        (capacitor) => capacitor.sourceComponentId && networks.isDirectOpAmpFeedback(capacitor.sourceComponentId) ? [capacitor.sourceComponentId] : []
      )
    );
    this.solved = this.capacitorPlacements.length === 0;
  }
  getCapacitorPlacements() {
    return this.ctx.componentPlacements.filter(
      (p) => p.sourceComponentId !== void 0 && this.sourceComponentById.get(p.sourceComponentId)?.ftype === "simple_capacitor"
    ).map((p) => ({
      schX: p.schX,
      schY: p.schY,
      width: p.width,
      height: p.height,
      sourceComponentId: p.sourceComponentId,
      sourceComponentName: p.sourceComponentName,
      schematicComponentId: p.schematicComponentId,
      schematicSheetId: p.schematicSheetId,
      schematicSheetName: p.schematicSheetName
    }));
  }
  _step() {
    const currentPlacement = this.capacitorPlacements[this.currentPlacementIndex];
    if (!currentPlacement) {
      this.solved = true;
      return;
    }
    this.currentPlacementIndex += 1;
    this.solved = this.currentPlacementIndex >= this.capacitorPlacements.length;
    const issue = this.getIssueForPlacement(currentPlacement);
    if (issue) this.out.push(issue);
  }
  visualize() {
    const focusedPlacement = this.getFocusedPlacement();
    return mergeGraphicsObjects([
      visualizeCircuitJson(this.ctx.circuitJson),
      focusedPlacement ? highlightPlacement(
        focusedPlacement,
        "hsl(210, 100%, 50%, 0.95)",
        "capacitorOrientation"
      ) : void 0
    ]);
  }
  getFocusedPlacement() {
    if (this.capacitorPlacements.length === 0) return void 0;
    const index = this.iterations === 0 ? this.currentPlacementIndex : Math.max(0, this.currentPlacementIndex - 1);
    return this.capacitorPlacements[index];
  }
  buildSchematicComponentById(circuitJson) {
    return new Map(
      circuitJson.filter(
        (el) => el.type === "schematic_component"
      ).map((sc) => [sc.schematic_component_id, sc])
    );
  }
  buildSourceComponentById(circuitJson) {
    return new Map(
      circuitJson.flatMap((el) => {
        if (el.type !== "source_component" || !("source_component_id" in el) || typeof el.source_component_id !== "string")
          return [];
        return [
          {
            type: "source_component",
            source_component_id: el.source_component_id,
            ftype: "ftype" in el && typeof el.ftype === "string" ? el.ftype : void 0
          }
        ];
      }).map((sc) => [sc.source_component_id, sc])
    );
  }
  createIssuePlacement(placement) {
    return {
      positionAnchor: "center",
      schX: placement.schX,
      schY: placement.schY,
      width: placement.width,
      height: placement.height,
      sourceComponentId: placement.sourceComponentId,
      sourceComponentName: placement.sourceComponentName,
      schematicComponentId: placement.schematicComponentId,
      schematicSheetId: placement.schematicSheetId,
      schematicSheetName: placement.schematicSheetName
    };
  }
  getIssueForPlacement(placement) {
    if (!placement.schematicComponentId || !placement.sourceComponentId) return;
    const schematicComponent = this.schematicComponentById.get(
      placement.schematicComponentId
    );
    if (!schematicComponent) return;
    if (!this.horizontalSymbolNames.has(schematicComponent.symbol_name ?? ""))
      return;
    if (this.feedbackCapacitorIds.has(placement.sourceComponentId)) return;
    if (this.isInlineWithHorizontalTraces(placement.schematicComponentId))
      return;
    return {
      lineItemType: "CapacitorSymbolHorizontal",
      schematicBox: this.createIssuePlacement(placement),
      message: _CapacitorOrientationSolver.ORIENTATION_MESSAGE
    };
  }
  isInlineWithHorizontalTraces(schematicComponentId) {
    const ports = this.ctx.circuitJson.filter(
      (element) => element.type === "schematic_port" && element.schematic_component_id === schematicComponentId
    );
    if (ports.length !== 2) return false;
    const traces = ports.map((port) => this.getOutwardHorizontalTrace(port));
    return traces.every((trace) => trace !== void 0) && traces.some(
      (trace) => trace !== void 0 && trace.edges.every(
        (edge) => Math.abs(edge.from.y - edge.to.y) <= _CapacitorOrientationSolver.EPSILON
      )
    );
  }
  getOutwardHorizontalTrace(port) {
    if (port.facing_direction !== "left" && port.facing_direction !== "right")
      return;
    return this.ctx.circuitJson.find(
      (element) => element.type === "schematic_trace" && element.schematic_sheet_id === port.schematic_sheet_id && element.edges.some((edge) => {
        const other = this.pointsEqual(edge.from, port.center) ? edge.to : this.pointsEqual(edge.to, port.center) ? edge.from : void 0;
        return other !== void 0 && Math.abs(other.y - port.center.y) <= _CapacitorOrientationSolver.EPSILON && (port.facing_direction === "left" ? other.x < port.center.x - _CapacitorOrientationSolver.EPSILON : other.x > port.center.x + _CapacitorOrientationSolver.EPSILON);
      })
    );
  }
  pointsEqual(first, second) {
    return Math.abs(first.x - second.x) <= _CapacitorOrientationSolver.EPSILON && Math.abs(first.y - second.y) <= _CapacitorOrientationSolver.EPSILON;
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(attrs, "componentName", issue.schematicBox.sourceComponentName);
    addAttr(attrs, "schX", issue.schematicBox.schX);
    addAttr(attrs, "schY", issue.schematicBox.schY);
    addAttr(attrs, "width", issue.schematicBox.width);
    addAttr(attrs, "height", issue.schematicBox.height);
    addAttr(attrs, "message", issue.message);
    return `<CapacitorSymbolHorizontal ${attrs.join(" ")} />`;
  }
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/DecouplingCapacitorGroupingSolver/DecouplingCapacitorGroupingSolver.ts
import { BaseSolver as BaseSolver18 } from "@tscircuit/solver-utils";
var DecouplingCapacitorGroupingSolver = class _DecouplingCapacitorGroupingSolver extends BaseSolver18 {
  constructor(params) {
    super();
    this.params = params;
    const index = new PlacementNetworkIndex(params.ctx);
    const powerNets = new Set(index.powerNets);
    const groundNets = new Set(index.groundNets);
    for (const element of params.ctx.circuitJson) {
      if (element.type === "source_net") {
        const net = index.connected(element.source_net_id);
        if (!this.netNames.has(net)) this.netNames.set(net, element.name);
      }
    }
    for (const ports of index.portsByComponent.values()) {
      for (const port of ports) {
        if (port.do_not_connect) continue;
        const net = index.connected(port.source_port_id);
        if (port.provides_power || port.requires_power) powerNets.add(net);
        if (port.provides_ground || port.requires_ground) groundNets.add(net);
        if ((powerNets.has(net) || groundNets.has(net)) && !this.netNames.has(net))
          this.netNames.set(net, port.name);
      }
    }
    for (const component of index.components.values()) {
      if (component.ftype !== "simple_capacitor") continue;
      const id = component.source_component_id;
      const placement = index.placement(id);
      const nets = index.twoTerminalNets(id);
      const ports = index.portsByComponent.get(id);
      if (!placement || !nets || !ports || ports.some((port) => {
        const schematicPort = index.port(port);
        return port.do_not_connect || !schematicPort || schematicPort.schematic_sheet_id !== placement.schematicSheetId;
      }))
        continue;
      const power = nets.find(
        (net) => powerNets.has(net) && !groundNets.has(net)
      );
      const ground = nets.find(
        (net) => groundNets.has(net) && !powerNets.has(net)
      );
      if (!power || !ground) continue;
      const bank = this.banks.find(
        (candidate) => candidate.power === power && candidate.ground === ground && index.sameLocalScope(candidate.capacitors[0], placement)
      );
      if (bank) bank.capacitors.push(placement);
      else this.banks.push({ power, ground, capacitors: [placement] });
    }
    this.solved = this.banks.length === 0;
  }
  params;
  // Schematic readability heuristic, not a PCB distance or an industry limit.
  // TI SLUUCB5E Fig. 4-5 C18-C23 use ~3.12 plate widths between centres:
  // ~1.0 centre pitch / 0.1 bounds gap for the standard tscircuit capacitor.
  // Allow extra label room, but do not reuse the old four-unit bank-diameter
  // budget for EVERY neighbour. See the published-reference TSX regression.
  static MIN_BODY_GAP = 1;
  banks = [];
  netNames = /* @__PURE__ */ new Map();
  bankIndex = 0;
  _step() {
    const bank = this.banks[this.bankIndex++];
    this.solved = this.bankIndex >= this.banks.length;
    if (bank.capacitors.length < 2) return;
    const maxRecommendedBodyGap = Math.max(
      _DecouplingCapacitorGroupingSolver.MIN_BODY_GAP,
      ...bank.capacitors.map((box) => Math.max(box.width, box.height))
    );
    let maxBodyGap = 0;
    const pending = bank.capacitors.slice(1).map((box) => ({
      box,
      gap: _DecouplingCapacitorGroupingSolver.bodyGap(bank.capacitors[0], box)
    }));
    while (pending.length > 0) {
      let closest = 0;
      for (let i = 1; i < pending.length; i++) {
        if (pending[i].gap < pending[closest].gap) closest = i;
      }
      const next = pending.splice(closest, 1)[0];
      maxBodyGap = Math.max(maxBodyGap, next.gap);
      for (const candidate of pending) {
        candidate.gap = Math.min(
          candidate.gap,
          _DecouplingCapacitorGroupingSolver.bodyGap(next.box, candidate.box)
        );
      }
    }
    if (maxBodyGap <= maxRecommendedBodyGap + 1e-6) return;
    const railName = this.netNames.get(bank.power) ?? "power";
    const groundName = this.netNames.get(bank.ground) ?? "ground";
    this.params.issues.push({
      lineItemType: "DecouplingCapacitorsNotCloseTogether",
      railName,
      groundName,
      capacitorSchematicBoxes: bank.capacitors,
      maxBodyGap,
      maxRecommendedBodyGap,
      message: `Group the decoupling capacitors between ${railName} and ${groundName} closer together in this schematic block. Preserve their net connections.`
    });
  }
  static bodyGap(a, b) {
    return Math.hypot(
      Math.max(0, Math.abs(a.schX - b.schX) - (a.width + b.width) / 2),
      Math.max(0, Math.abs(a.schY - b.schY) - (a.height + b.height) / 2)
    );
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(attrs, "rail", issue.railName);
    addAttr(attrs, "ground", issue.groundName);
    addAttr(
      attrs,
      "capacitorNames",
      issue.capacitorSchematicBoxes.map((box) => box.sourceComponentName || "component").join(", ")
    );
    addAttr(attrs, "maxBodyGap", issue.maxBodyGap);
    addAttr(attrs, "maxRecommendedBodyGap", issue.maxRecommendedBodyGap);
    addAttr(attrs, "message", issue.message);
    return `<DecouplingCapacitorsNotCloseTogether ${attrs.join(" ")} />`;
  }
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/utils/net-label-bounds.ts
function getNetLabelBounds(label) {
  const anchorSide = label.anchor_side;
  const isVertical = anchorSide === "top" || anchorSide === "bottom";
  if (isVertical) {
    const anchorY = label.anchor_position?.y ?? label.center.y;
    const textHalfExtent = (label.text?.length ?? 8) * 0.13 / 2 + 0.1;
    const left = label.center.x - 0.1;
    const right = label.center.x + 0.1;
    if (anchorSide === "top") {
      return {
        left,
        right,
        top: anchorY,
        bottom: anchorY - textHalfExtent * 2
      };
    }
    return { left, right, top: anchorY + textHalfExtent * 2, bottom: anchorY };
  }
  const anchorX = label.anchor_position?.x ?? label.center.x;
  const halfWidth = Math.abs(label.center.x - anchorX);
  const farHalfWidth = halfWidth + 0.1;
  const top = label.center.y + 0.1;
  const bottom = label.center.y - 0.1;
  if (label.center.x >= anchorX) {
    return {
      left: anchorX,
      right: label.center.x + farHalfWidth,
      top,
      bottom
    };
  }
  return { left: label.center.x - farHalfWidth, right: anchorX, top, bottom };
}

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/ComponentNetLabelCollisionSolver/ComponentNetLabelCollisionSolver.ts
import { BaseSolver as BaseSolver19 } from "@tscircuit/solver-utils";
var ComponentNetLabelCollisionSolver = class extends BaseSolver19 {
  constructor(params) {
    super();
    this.params = params;
    this.placements = params.ctx.componentPlacements;
    this.netLabelsByComponentId = this.buildNetLabelsByComponentId(
      params.ctx.circuitJson
    );
    this.solved = this.placements.length < 2;
  }
  params;
  placements;
  netLabelsByComponentId;
  rawCollisions = [];
  firstIndex = 0;
  secondIndex = 1;
  _step() {
    if (this.firstIndex >= this.placements.length - 1) {
      this.buildAndPushIssues();
      this.solved = true;
      return;
    }
    const compA = this.placements[this.firstIndex];
    const compB = this.placements[this.secondIndex];
    this.detectPair(compA, compB);
    this.secondIndex++;
    if (this.secondIndex >= this.placements.length) {
      this.firstIndex++;
      this.secondIndex = this.firstIndex + 1;
    }
  }
  detectPair(compA, compB) {
    if (compA.schematicSheetId !== compB.schematicSheetId) return;
    this.rawCollisions.push(...this.detectLabelLabel(compA, compB));
    this.rawCollisions.push(...this.detectBoxLabel(compA, compB));
    this.rawCollisions.push(...this.detectBoxLabel(compB, compA));
  }
  detectLabelLabel(firstComponent, secondComponent) {
    let leftComp = firstComponent;
    let rightComp = secondComponent;
    if (firstComponent.schX > secondComponent.schX) {
      leftComp = secondComponent;
      rightComp = firstComponent;
    }
    const leftId = leftComp.schematicComponentId;
    const rightId = rightComp.schematicComponentId;
    if (!leftId || !rightId) return [];
    const leftLabels = this.netLabelsByComponentId.get(leftId) ?? [];
    const rightLabels = this.netLabelsByComponentId.get(rightId) ?? [];
    if (leftLabels.length === 0 || rightLabels.length === 0) return [];
    const hits = [];
    for (const leftLabel of leftLabels) {
      for (const rightLabel of rightLabels) {
        const leftBounds = getNetLabelBounds(leftLabel);
        const rightBounds = getNetLabelBounds(rightLabel);
        if (rectOverlap(leftBounds, rightBounds)) {
          hits.push({
            type: "label-label",
            bounds: {
              left: Math.max(leftBounds.left, rightBounds.left),
              right: Math.min(leftBounds.right, rightBounds.right),
              top: Math.min(leftBounds.top, rightBounds.top),
              bottom: Math.max(leftBounds.bottom, rightBounds.bottom)
            },
            leftComp,
            rightComp,
            leftId,
            rightId,
            xSeparation: leftBounds.right - rightBounds.left + 0.1
          });
        }
      }
    }
    return hits;
  }
  detectBoxLabel(boxComp, labelComp) {
    const boxId = boxComp.schematicComponentId;
    const labelId = labelComp.schematicComponentId;
    if (!boxId || !labelId) return [];
    const labels = this.netLabelsByComponentId.get(labelId) ?? [];
    if (labels.length === 0) return [];
    const boxBounds = centeredRect(
      boxComp.schX,
      boxComp.schY,
      boxComp.width,
      boxComp.height
    );
    const boxIsLeft = boxComp.schX <= labelComp.schX;
    const hits = [];
    for (const label of labels) {
      const labelBounds = getNetLabelBounds(label);
      if (!rectOverlap(boxBounds, labelBounds)) continue;
      let xSeparation;
      if (boxIsLeft) {
        xSeparation = boxBounds.right - labelBounds.left + 0.1;
      } else {
        xSeparation = labelBounds.right - boxBounds.left + 0.1;
      }
      hits.push({
        type: "box-label",
        bounds: {
          left: Math.max(boxBounds.left, labelBounds.left),
          right: Math.min(boxBounds.right, labelBounds.right),
          top: Math.min(boxBounds.top, labelBounds.top),
          bottom: Math.max(boxBounds.bottom, labelBounds.bottom)
        },
        boxComp,
        labelComp,
        boxId,
        labelId,
        xSeparation
      });
    }
    return hits;
  }
  buildAndPushIssues() {
    if (this.rawCollisions.length === 0) return;
    const collisionsBySheet = /* @__PURE__ */ new Map();
    for (const collision of this.rawCollisions) {
      const placement = collision.type === "label-label" ? collision.leftComp : collision.boxComp;
      const sheetKey = placement.schematicSheetId ?? "";
      const sheetCollisions = collisionsBySheet.get(sheetKey);
      if (sheetCollisions) sheetCollisions.push(collision);
      else collisionsBySheet.set(sheetKey, [collision]);
    }
    for (const collisions of collisionsBySheet.values()) {
      this.buildAndPushIssueForSheet(collisions);
    }
  }
  buildAndPushIssueForSheet(collisions) {
    const globalFixes = this.computeGlobalFixes(collisions);
    if (globalFixes.size === 0) return;
    const seenPairs = /* @__PURE__ */ new Set();
    const pairs = [];
    for (const collision of collisions) {
      let comp1Name;
      let comp2Name;
      if (collision.type === "label-label") {
        comp1Name = collision.leftComp.sourceComponentName ?? "";
        comp2Name = collision.rightComp.sourceComponentName ?? "";
      } else {
        comp1Name = collision.boxComp.sourceComponentName ?? "";
        comp2Name = collision.labelComp.sourceComponentName ?? "";
      }
      const key = `${comp1Name}/${comp2Name}`;
      if (!seenPairs.has(key)) {
        seenPairs.add(key);
        pairs.push({ comp1Name, comp2Name });
      }
    }
    const firstCollision = collisions[0];
    const firstPlacement = firstCollision.type === "label-label" ? firstCollision.leftComp : firstCollision.boxComp;
    this.params.issues.push({
      lineItemType: "NetLabelCollision",
      schematicSheetId: firstPlacement.schematicSheetId,
      schematicSheetName: firstPlacement.schematicSheetName,
      pairs,
      collisionBounds: collisions.map((collision) => collision.bounds),
      moves: Array.from(globalFixes.values())
    });
  }
  computeGlobalFixes(collisions) {
    const compById = /* @__PURE__ */ new Map();
    for (const placement of this.placements) {
      if (placement.schematicComponentId)
        compById.set(placement.schematicComponentId, placement);
    }
    const constraintMap = /* @__PURE__ */ new Map();
    const addConstraint = (leftId, rightId, xSeparation) => {
      const leftComp = compById.get(leftId);
      const rightComp = compById.get(rightId);
      if (!leftComp || !rightComp) return;
      const minSep = rightComp.schX - leftComp.schX + xSeparation;
      const key = `${leftId}|${rightId}`;
      constraintMap.set(key, Math.max(constraintMap.get(key) ?? 0, minSep));
    };
    for (const collision of collisions) {
      if (collision.type === "label-label") {
        addConstraint(
          collision.leftId,
          collision.rightId,
          collision.xSeparation
        );
      } else if (collision.boxComp.schX <= collision.labelComp.schX) {
        addConstraint(collision.boxId, collision.labelId, collision.xSeparation);
      } else {
        addConstraint(collision.labelId, collision.boxId, collision.xSeparation);
      }
    }
    const constraints = [...constraintMap.entries()].map(
      ([key, minSep]) => {
        const pipeIndex = key.indexOf("|");
        return {
          leftId: key.slice(0, pipeIndex),
          rightId: key.slice(pipeIndex + 1),
          minSep
        };
      }
    );
    const allIds = /* @__PURE__ */ new Set();
    const adjacency = /* @__PURE__ */ new Map();
    for (const { leftId, rightId } of constraints) {
      allIds.add(leftId);
      allIds.add(rightId);
      if (!adjacency.has(leftId)) adjacency.set(leftId, /* @__PURE__ */ new Set());
      if (!adjacency.has(rightId)) adjacency.set(rightId, /* @__PURE__ */ new Set());
      adjacency.get(leftId).add(rightId);
      adjacency.get(rightId).add(leftId);
    }
    const visited = /* @__PURE__ */ new Set();
    const result = /* @__PURE__ */ new Map();
    for (const startId of allIds) {
      if (visited.has(startId)) continue;
      const group = [];
      const queue = [startId];
      visited.add(startId);
      while (queue.length) {
        const compId = queue.shift();
        group.push(compId);
        for (const neighbor of adjacency.get(compId) ?? []) {
          if (!visited.has(neighbor)) {
            visited.add(neighbor);
            queue.push(neighbor);
          }
        }
      }
      group.sort(
        (idA, idB) => (compById.get(idA)?.schX ?? 0) - (compById.get(idB)?.schX ?? 0)
      );
      const groupIds = new Set(group);
      const groupConstraints = constraints.filter(
        (c) => groupIds.has(c.leftId) && groupIds.has(c.rightId)
      );
      const assigned = /* @__PURE__ */ new Map();
      for (const compId of group) {
        let newX = compById.get(compId)?.schX ?? 0;
        for (const { leftId, rightId, minSep } of groupConstraints) {
          if (rightId === compId && assigned.has(leftId)) {
            newX = Math.max(newX, assigned.get(leftId) + minSep);
          }
        }
        assigned.set(compId, newX);
      }
      const totalPush = [...assigned.entries()].reduce(
        (sum, [compId, newX]) => sum + (newX - (compById.get(compId)?.schX ?? 0)),
        0
      );
      if (totalPush > 1e-9) {
        const pullBack = totalPush / group.length;
        const shifted = /* @__PURE__ */ new Map();
        for (const compId of group) {
          let newX = (compById.get(compId)?.schX ?? 0) - pullBack;
          for (const { leftId, rightId, minSep } of groupConstraints) {
            if (rightId === compId && shifted.has(leftId)) {
              newX = Math.max(newX, shifted.get(leftId) + minSep);
            }
          }
          shifted.set(compId, newX);
        }
        const maxDisplacement = (positions) => [...positions.entries()].reduce(
          (currentMax, [compId, newX]) => Math.max(
            currentMax,
            Math.abs(newX - (compById.get(compId)?.schX ?? 0))
          ),
          0
        );
        if (maxDisplacement(shifted) < maxDisplacement(assigned)) {
          for (const [compId, newX] of shifted) assigned.set(compId, newX);
        }
      }
      for (const [compId, newX] of assigned) {
        const comp = compById.get(compId);
        if (!comp || Math.abs(newX - comp.schX) < 1e-9) continue;
        result.set(compId, {
          componentName: comp.sourceComponentName || "component",
          newSchX: Math.round(newX * 100) / 100,
          newSchY: Math.round(comp.schY * 100) / 100
        });
      }
    }
    return result;
  }
  buildNetLabelsByComponentId(circuitJson) {
    const MATCH_EPSILON = 1e-4;
    const portPositions = [];
    for (const element of circuitJson) {
      if (element.type !== "schematic_port") continue;
      const port = element;
      if (!port.schematic_component_id) continue;
      portPositions.push({
        componentId: port.schematic_component_id,
        cx: port.center.x,
        cy: port.center.y,
        schematicSheetId: port.schematic_sheet_id
      });
    }
    const result = /* @__PURE__ */ new Map();
    for (const element of circuitJson) {
      if (element.type !== "schematic_net_label") continue;
      const label = element;
      if (!label.anchor_position) continue;
      const { x: anchorX, y: anchorY } = label.anchor_position;
      const matches = portPositions.filter(
        (port) => port.schematicSheetId === label.schematic_sheet_id && Math.hypot(port.cx - anchorX, port.cy - anchorY) < MATCH_EPSILON
      );
      if (matches.length === 0) continue;
      const componentIds = new Set(matches.map((match) => match.componentId));
      if (componentIds.size !== 1) continue;
      const componentId = matches[0].componentId;
      const labels = result.get(componentId) ?? [];
      labels.push(label);
      result.set(componentId, labels);
    }
    return result;
  }
  static netLabelCollisionToString(issue) {
    const pairAttrs = issue.pairs.map((pair, i) => `pair${i + 1}="${pair.comp1Name}/${pair.comp2Name}"`).join(" ");
    const moves = issue.moves.map(
      (move) => `    <Move componentName="${move.componentName}" newSchX="${move.newSchX}" newSchY="${move.newSchY}" />`
    );
    return [
      `<ComponentNetLabelCollision ${pairAttrs}>`,
      `  <SuggestedFix note="Apply all moves simultaneously. Set schAutoLayoutEnabled on your circuit.">`,
      ...moves,
      `  </SuggestedFix>`,
      `</ComponentNetLabelCollision>`
    ].join("\n");
  }
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/ComponentPinAlignmentSolver/ComponentPinAlignmentSolver.ts
import { BaseSolver as BaseSolver20 } from "@tscircuit/solver-utils";
var ComponentPinAlignmentSolver = class _ComponentPinAlignmentSolver extends BaseSolver20 {
  static ALIGNMENT_EPSILON = 0.01;
  ctx;
  out;
  constructor({
    ctx,
    issues
  }) {
    super();
    this.ctx = ctx;
    this.out = issues;
  }
  _step() {
    const portsById = new Map(
      this.ctx.circuitJson.filter((el) => el.type === "schematic_port").map((port) => [port.schematic_port_id, port])
    );
    const placementBySchematicComponentId = new Map(
      this.ctx.componentPlacements.flatMap(
        (placement) => placement.schematicComponentId ? [[placement.schematicComponentId, placement]] : []
      )
    );
    const pinPairsByComponentPair = /* @__PURE__ */ new Map();
    for (const trace of this.ctx.circuitJson.filter(
      (el) => el.type === "schematic_trace"
    )) {
      const pinPair = this.getTracePinPair(trace, portsById);
      if (!pinPair) continue;
      const firstComponentId = pinPair.firstPort.schematic_component_id;
      const secondComponentId = pinPair.secondPort.schematic_component_id;
      if (!firstComponentId || !secondComponentId || firstComponentId === secondComponentId) {
        continue;
      }
      const orderedPair = firstComponentId < secondComponentId ? pinPair : {
        firstPort: pinPair.secondPort,
        secondPort: pinPair.firstPort
      };
      const key = [firstComponentId, secondComponentId].sort().join("\0");
      const pairs = pinPairsByComponentPair.get(key) ?? [];
      const isDuplicate = pairs.some(
        (pair) => pair.firstPort.schematic_port_id === orderedPair.firstPort.schematic_port_id && pair.secondPort.schematic_port_id === orderedPair.secondPort.schematic_port_id
      );
      if (!isDuplicate) pairs.push(orderedPair);
      pinPairsByComponentPair.set(key, pairs);
    }
    for (const pinPairs of pinPairsByComponentPair.values()) {
      const issue = this.findVerticalShiftIssue(
        pinPairs,
        placementBySchematicComponentId
      );
      if (issue) this.out.push(issue);
    }
    this.solved = true;
  }
  getTracePinPair(trace, portsById) {
    const firstEdge = trace.edges?.[0];
    const lastEdge = trace.edges?.at(-1);
    if (!firstEdge || !lastEdge) return;
    const firstPortId = firstEdge.from_schematic_port_id ?? firstEdge.to_schematic_port_id;
    const secondPortId = lastEdge.to_schematic_port_id ?? lastEdge.from_schematic_port_id;
    const ports = [...portsById.values()];
    const firstPort = firstPortId ? portsById.get(firstPortId) : this.findPortAtPoint(ports, firstEdge.from, trace.schematic_sheet_id);
    const secondPort = secondPortId ? portsById.get(secondPortId) : this.findPortAtPoint(ports, lastEdge.to, trace.schematic_sheet_id);
    if (!firstPort || !secondPort) return;
    if (firstPort.schematic_port_id === secondPort.schematic_port_id) return;
    if (firstPort.schematic_sheet_id !== secondPort.schematic_sheet_id) return;
    return { firstPort, secondPort };
  }
  findPortAtPoint(ports, point2, schematicSheetId) {
    const { ALIGNMENT_EPSILON } = _ComponentPinAlignmentSolver;
    return ports.find(
      (port) => port.schematic_sheet_id === schematicSheetId && Math.abs(port.center.x - point2.x) <= ALIGNMENT_EPSILON && Math.abs(port.center.y - point2.y) <= ALIGNMENT_EPSILON
    );
  }
  findVerticalShiftIssue(pinPairs, placementBySchematicComponentId) {
    const firstPair = pinPairs[0];
    if (!firstPair) return;
    const firstPlacement = placementBySchematicComponentId.get(
      firstPair.firstPort.schematic_component_id
    );
    const secondPlacement = placementBySchematicComponentId.get(
      firstPair.secondPort.schematic_component_id
    );
    if (!firstPlacement || !secondPlacement) return;
    const [leftPlacement, rightPlacement] = firstPlacement.schX <= secondPlacement.schX ? [firstPlacement, secondPlacement] : [secondPlacement, firstPlacement];
    const horizontalPairs = pinPairs.flatMap((pair) => {
      const [leftPort, rightPort] = pair.firstPort.center.x <= pair.secondPort.center.x ? [pair.firstPort, pair.secondPort] : [pair.secondPort, pair.firstPort];
      return leftPort.facing_direction === "right" && rightPort.facing_direction === "left" ? [{ leftPort, rightPort }] : [];
    });
    if (horizontalPairs.length < 2) return;
    const { ALIGNMENT_EPSILON } = _ComponentPinAlignmentSolver;
    const currentlyAlignedPinCount = horizontalPairs.filter(
      ({ leftPort, rightPort }) => Math.abs(leftPort.center.y - rightPort.center.y) <= ALIGNMENT_EPSILON
    ).length;
    const candidateGroups = [];
    for (const pair of horizontalPairs) {
      const deltaSchY2 = pair.leftPort.center.y - pair.rightPort.center.y;
      if (Math.abs(deltaSchY2) <= ALIGNMENT_EPSILON) continue;
      const group = candidateGroups.find(
        (candidate) => Math.abs(candidate.deltaSchY - deltaSchY2) <= ALIGNMENT_EPSILON
      );
      if (group) group.pairs.push(pair);
      else candidateGroups.push({ deltaSchY: deltaSchY2, pairs: [pair] });
    }
    const bestCandidate = candidateGroups.sort(
      (a, b) => b.pairs.length - a.pairs.length || Math.abs(a.deltaSchY) - Math.abs(b.deltaSchY)
    )[0];
    if (!bestCandidate || bestCandidate.pairs.length < 2 || bestCandidate.pairs.length <= currentlyAlignedPinCount) {
      return;
    }
    const targetName = rightPlacement.sourceComponentName || "component";
    const deltaSchY = bestCandidate.deltaSchY;
    const newSchY = rightPlacement.schY + deltaSchY;
    return {
      lineItemType: "ComponentPinsWouldAlignWithVerticalShift",
      firstComponent: leftPlacement,
      secondComponent: rightPlacement,
      targetComponent: rightPlacement,
      deltaSchY,
      newSchY,
      currentlyAlignedPinCount,
      alignedPinCount: bestCandidate.pairs.length,
      alignedPinPairs: bestCandidate.pairs.map(({ leftPort, rightPort }) => ({
        firstPin: this.getPinLabel(leftPort),
        secondPin: this.getPinLabel(rightPort)
      })),
      message: `shift ${targetName} vertically by ${fmtDelta(deltaSchY)} to align ${bestCandidate.pairs.length} connected pin pairs`
    };
  }
  getPinLabel(port) {
    return port.display_pin_label ?? port.pin_number?.toString();
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(
      attrs,
      "firstComponentName",
      issue.firstComponent.sourceComponentName
    );
    addAttr(
      attrs,
      "secondComponentName",
      issue.secondComponent.sourceComponentName
    );
    addAttr(
      attrs,
      "targetComponentName",
      issue.targetComponent.sourceComponentName
    );
    addAttr(attrs, "deltaSchY", issue.deltaSchY);
    addAttr(attrs, "newSchY", issue.newSchY);
    addAttr(attrs, "currentlyAlignedPinCount", issue.currentlyAlignedPinCount);
    addAttr(attrs, "alignedPinCount", issue.alignedPinCount);
    addAttr(attrs, "message", issue.message);
    return `<ComponentPinsWouldAlignWithVerticalShift ${attrs.join(" ")} />`;
  }
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/CrystalLoadCapacitorPlacementSolver/CrystalLoadCapacitorPlacementSolver.ts
import { BaseSolver as BaseSolver21 } from "@tscircuit/solver-utils";
var CrystalLoadCapacitorPlacementSolver = class _CrystalLoadCapacitorPlacementSolver extends BaseSolver21 {
  static ALIGNMENT_TOLERANCE = 0.1;
  issues;
  networks;
  currentNetworkIndex = 0;
  constructor({
    ctx,
    issues
  }) {
    super();
    this.issues = issues;
    this.networks = this.findCrystalLoadNetworks(ctx);
    this.solved = this.networks.length === 0;
  }
  _step() {
    const network = this.networks[this.currentNetworkIndex];
    if (!network) {
      this.solved = true;
      return;
    }
    this.currentNetworkIndex += 1;
    this.solved = this.currentNetworkIndex >= this.networks.length;
    const deltaSchX = round2(network.newSchX - network.crystal.schX);
    const deltaSchY = round2(network.newSchY - network.crystal.schY);
    if (Math.abs(deltaSchX) <= _CrystalLoadCapacitorPlacementSolver.ALIGNMENT_TOLERANCE && Math.abs(deltaSchY) <= _CrystalLoadCapacitorPlacementSolver.ALIGNMENT_TOLERANCE) {
      return;
    }
    const crystalName = network.crystal.sourceComponentName ?? "the crystal";
    const firstCapacitorName = network.firstLoadCapacitor.sourceComponentName ?? "the first load capacitor";
    const secondCapacitorName = network.secondLoadCapacitor.sourceComponentName ?? "the second load capacitor";
    this.issues.push({
      lineItemType: "CrystalNotCenteredOverLoadCapacitors",
      crystalSchematicBox: network.crystal,
      firstLoadCapacitorSchematicBox: network.firstLoadCapacitor,
      secondLoadCapacitorSchematicBox: network.secondLoadCapacitor,
      deltaSchX,
      deltaSchY,
      newSchX: network.newSchX,
      newSchY: network.newSchY,
      message: `move ${crystalName} to schX=${network.newSchX}, schY=${network.newSchY} so it is centered between ${firstCapacitorName} and ${secondCapacitorName} and aligned with their load-side pins`
    });
  }
  findCrystalLoadNetworks(ctx) {
    const sourceComponents = /* @__PURE__ */ new Map();
    const sourcePortsByComponentId = /* @__PURE__ */ new Map();
    const schematicPortsBySourcePortId = /* @__PURE__ */ new Map();
    const placementBySourceComponentId = new Map(
      ctx.componentPlacements.flatMap(
        (placement) => placement.sourceComponentId ? [[placement.sourceComponentId, placement]] : []
      )
    );
    for (const element of ctx.circuitJson) {
      if (element.type === "source_component") {
        sourceComponents.set(element.source_component_id, {
          sourceComponentId: element.source_component_id,
          ftype: "ftype" in element && typeof element.ftype === "string" ? element.ftype : void 0
        });
      }
      if (element.type === "source_port" && typeof element.source_component_id === "string" && typeof element.subcircuit_connectivity_map_key === "string") {
        const sourcePort = {
          sourcePortId: element.source_port_id,
          sourceComponentId: element.source_component_id,
          connectivityKey: element.subcircuit_connectivity_map_key
        };
        const componentPorts = sourcePortsByComponentId.get(element.source_component_id) ?? [];
        componentPorts.push(sourcePort);
        sourcePortsByComponentId.set(
          element.source_component_id,
          componentPorts
        );
      }
      if (element.type === "schematic_port" && element.source_port_id) {
        schematicPortsBySourcePortId.set(element.source_port_id, element);
      }
    }
    const capacitorConnectionsByConnectivityKey = /* @__PURE__ */ new Map();
    for (const sourceComponent of sourceComponents.values()) {
      if (sourceComponent.ftype !== "simple_capacitor") continue;
      const capacitorPorts = sourcePortsByComponentId.get(sourceComponent.sourceComponentId) ?? [];
      if (capacitorPorts.length !== 2) continue;
      const firstCapacitorPort = capacitorPorts[0];
      const secondCapacitorPort = capacitorPorts[1];
      const capacitorPlacement = placementBySourceComponentId.get(
        sourceComponent.sourceComponentId
      );
      if (!capacitorPlacement) continue;
      for (const [loadPort, returnPort] of [
        [firstCapacitorPort, secondCapacitorPort],
        [secondCapacitorPort, firstCapacitorPort]
      ]) {
        const schematicLoadPort = schematicPortsBySourcePortId.get(
          loadPort.sourcePortId
        );
        if (!schematicLoadPort) continue;
        const connections = capacitorConnectionsByConnectivityKey.get(loadPort.connectivityKey) ?? [];
        connections.push({
          capacitor: capacitorPlacement,
          loadPort: schematicLoadPort,
          returnConnectivityKey: returnPort.connectivityKey
        });
        capacitorConnectionsByConnectivityKey.set(
          loadPort.connectivityKey,
          connections
        );
      }
    }
    const networks = [];
    for (const sourceComponent of sourceComponents.values()) {
      if (sourceComponent.ftype !== "simple_crystal" && sourceComponent.ftype !== "simple_chip") {
        continue;
      }
      const crystalPorts = sourcePortsByComponentId.get(sourceComponent.sourceComponentId) ?? [];
      if (crystalPorts.length !== 2 || crystalPorts[0].connectivityKey === crystalPorts[1].connectivityKey) {
        continue;
      }
      const firstCrystalConnectivityKey = crystalPorts[0].connectivityKey;
      const secondCrystalConnectivityKey = crystalPorts[1].connectivityKey;
      const hasOscillatorHost = [...sourcePortsByComponentId.entries()].some(
        ([sourceComponentId, sourcePorts]) => sourceComponentId !== sourceComponent.sourceComponentId && sourcePorts.length > 2 && sourcePorts.some(
          (port) => port.connectivityKey === firstCrystalConnectivityKey
        ) && sourcePorts.some(
          (port) => port.connectivityKey === secondCrystalConnectivityKey
        )
      );
      if (!hasOscillatorHost) continue;
      const crystalPlacement = placementBySourceComponentId.get(
        sourceComponent.sourceComponentId
      );
      if (!crystalPlacement) continue;
      const firstConnections = capacitorConnectionsByConnectivityKey.get(
        crystalPorts[0].connectivityKey
      ) ?? [];
      const secondConnections = capacitorConnectionsByConnectivityKey.get(
        crystalPorts[1].connectivityKey
      ) ?? [];
      const candidatePairs = firstConnections.flatMap(
        (firstConnection) => secondConnections.flatMap((secondConnection) => {
          if (firstConnection.capacitor.sourceComponentId === secondConnection.capacitor.sourceComponentId || firstConnection.returnConnectivityKey !== secondConnection.returnConnectivityKey || firstConnection.returnConnectivityKey === firstCrystalConnectivityKey || firstConnection.returnConnectivityKey === secondCrystalConnectivityKey || firstConnection.capacitor.schematicSheetId !== crystalPlacement.schematicSheetId || secondConnection.capacitor.schematicSheetId !== crystalPlacement.schematicSheetId) {
            return [];
          }
          return [{ firstConnection, secondConnection }];
        })
      );
      if (candidatePairs.length === 0) continue;
      const bestPair = candidatePairs.toSorted(
        (a, b) => pairDistance(a, crystalPlacement) - pairDistance(b, crystalPlacement)
      )[0];
      const loadPorts = [
        bestPair.firstConnection.loadPort,
        bestPair.secondConnection.loadPort
      ];
      const capacitors = [
        bestPair.firstConnection.capacitor,
        bestPair.secondConnection.capacitor
      ].toSorted((a, b) => a.schX - b.schX);
      networks.push({
        crystal: crystalPlacement,
        firstLoadCapacitor: capacitors[0],
        secondLoadCapacitor: capacitors[1],
        newSchX: round2((loadPorts[0].center.x + loadPorts[1].center.x) / 2),
        newSchY: round2((loadPorts[0].center.y + loadPorts[1].center.y) / 2)
      });
    }
    return networks;
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(attrs, "crystalName", issue.crystalSchematicBox.sourceComponentName);
    addAttr(
      attrs,
      "firstLoadCapacitorName",
      issue.firstLoadCapacitorSchematicBox.sourceComponentName
    );
    addAttr(
      attrs,
      "secondLoadCapacitorName",
      issue.secondLoadCapacitorSchematicBox.sourceComponentName
    );
    addAttr(attrs, "newSchX", issue.newSchX);
    addAttr(attrs, "newSchY", issue.newSchY);
    addAttr(attrs, "deltaSchX", issue.deltaSchX, { formatDelta: true });
    addAttr(attrs, "deltaSchY", issue.deltaSchY, { formatDelta: true });
    addAttr(attrs, "message", issue.message);
    return `<CrystalNotCenteredOverLoadCapacitors ${attrs.join(" ")} />`;
  }
};
var pairDistance = (pair, crystal) => distance5(pair.firstConnection.capacitor, crystal) + distance5(pair.secondConnection.capacitor, crystal);
var distance5 = (first, second) => Math.hypot(first.schX - second.schX, first.schY - second.schY);
var round2 = (value) => Math.round(value * 100) / 100;

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/DiodeResistorAlignmentSolver/DiodeResistorAlignmentSolver.ts
import { BaseSolver as BaseSolver22 } from "@tscircuit/solver-utils";
import { getSourcePortConnectivityMapFromCircuitJson as getSourcePortConnectivityMapFromCircuitJson2 } from "circuit-json-to-connectivity-map";
var DiodeResistorAlignmentSolver = class _DiodeResistorAlignmentSolver extends BaseSolver22 {
  static DIODE_FTYPES = /* @__PURE__ */ new Set(["simple_led", "simple_diode"]);
  ctx;
  out;
  schematicTraces;
  currentIndex = 0;
  sourceConnectivity;
  sourceComponentFtypeById;
  sourceComponentIdBySourcePortId;
  schematicPorts;
  schematicBoxBySourceComponentId;
  constructor({
    ctx,
    issues
  }) {
    super();
    this.ctx = ctx;
    this.out = issues;
    const { circuitJson } = ctx;
    this.sourceConnectivity = getSourcePortConnectivityMapFromCircuitJson2(circuitJson);
    this.sourceComponentFtypeById = this.buildSourceComponentFtypeById(circuitJson);
    this.sourceComponentIdBySourcePortId = this.buildSourceComponentIdBySourcePortId(circuitJson);
    this.schematicPorts = circuitJson.filter(
      (el) => el.type === "schematic_port"
    );
    this.schematicBoxBySourceComponentId = this.buildSchematicBoxBySourceComponentId();
    this.schematicTraces = circuitJson.filter(
      (el) => el.type === "schematic_trace"
    );
    this.solved = this.schematicTraces.length === 0;
  }
  _step() {
    const trace = this.schematicTraces[this.currentIndex];
    if (!trace) {
      this.solved = true;
      return;
    }
    this.currentIndex++;
    this.solved = this.currentIndex >= this.schematicTraces.length;
    if (!trace.edges || trace.edges.length === 0) return;
    const firstEdge = trace.edges[0];
    const lastEdge = trace.edges[trace.edges.length - 1];
    if (!firstEdge || !lastEdge) return;
    const start = firstEdge.from;
    const end = lastEdge.to;
    const schematicSheetId = trace.schematic_sheet_id;
    const startSourceCompId = this.findSourceComponentIdNearPoint(
      start,
      schematicSheetId
    );
    const endSourceCompId = this.findSourceComponentIdNearPoint(
      end,
      schematicSheetId
    );
    if (!startSourceCompId || !endSourceCompId) return;
    const startFtype = this.sourceComponentFtypeById.get(startSourceCompId);
    const endFtype = this.sourceComponentFtypeById.get(endSourceCompId);
    const { DIODE_FTYPES } = _DiodeResistorAlignmentSolver;
    const isDiodeResistorPair = DIODE_FTYPES.has(startFtype) && endFtype === "simple_resistor" || startFtype === "simple_resistor" && DIODE_FTYPES.has(endFtype);
    if (!isDiodeResistorPair) return;
    const diodeCompId = DIODE_FTYPES.has(startFtype) ? startSourceCompId : endSourceCompId;
    const resistorCompId = startFtype === "simple_resistor" ? startSourceCompId : endSourceCompId;
    const diodeBox = this.schematicBoxBySourceComponentId.get(diodeCompId);
    const resistorBox = this.schematicBoxBySourceComponentId.get(resistorCompId);
    if (!diodeBox || !resistorBox) return;
    const diodePort = this.findNearestPort(
      DIODE_FTYPES.has(startFtype) ? start : end,
      schematicSheetId
    );
    const resistorPort = this.findNearestPort(
      startFtype === "simple_resistor" ? start : end,
      schematicSheetId
    );
    if (!diodePort?.center || !resistorPort?.center) return;
    if (!this.sourceConnectivity.areIdsConnected(
      diodePort.source_port_id,
      resistorPort.source_port_id
    ))
      return;
    const diodeName = diodeBox.sourceComponentName || "component";
    const resistorName = resistorBox.sourceComponentName || "component";
    const diodePin = diodePort?.display_pin_label ?? diodePort?.pin_number?.toString();
    const resistorPin = resistorPort?.display_pin_label ?? resistorPort?.pin_number?.toString();
    const diodeFacing = diodePort?.facing_direction;
    const resistorFacing = resistorPort?.facing_direction;
    const diodePinDesc = diodePin ? `${diodeName}.${diodePin}` : diodeName;
    const resistorPinDesc = resistorPin ? `${resistorName}.${resistorPin}` : resistorName;
    const makeIssue = (message) => ({
      lineItemType: "DiodeResistorNotAligned",
      diodeSchematicBox: diodeBox,
      resistorSchematicBox: resistorBox,
      diodePin,
      resistorPin,
      diodePinFacingDirection: diodeFacing,
      resistorPinFacingDirection: resistorFacing,
      message
    });
    if (!_DiodeResistorAlignmentSolver.isCoLinear(
      diodePort.center,
      resistorPort.center
    )) {
      this.out.push(
        makeIssue(
          `trace has corners \u2014 align ${diodeName} and ${resistorName} on same axis and rotate so ${diodePinDesc} faces ${resistorPinDesc}`
        )
      );
      return;
    }
    if (diodeFacing && resistorFacing && !_DiodeResistorAlignmentSolver.pinsFacingEachOther(
      diodePort.center,
      diodeFacing,
      resistorPort.center,
      resistorFacing
    )) {
      this.out.push(
        makeIssue(
          `${diodePinDesc} and ${resistorPinDesc} face away from each other \u2014 rotate ${diodeName} so ${diodePinDesc} faces ${resistorPinDesc}`
        )
      );
    }
  }
  static isCoLinear(a, b, epsilon = 0.01) {
    return Math.abs(a.x - b.x) < epsilon || Math.abs(a.y - b.y) < epsilon;
  }
  static pinsFacingEachOther(aCenter, aFacing, bCenter, bFacing) {
    const dx = bCenter.x - aCenter.x;
    const dy = bCenter.y - aCenter.y;
    const aToward = aFacing === "right" && dx > 0 || aFacing === "left" && dx < 0 || aFacing === "up" && dy > 0 || aFacing === "down" && dy < 0;
    const bToward = bFacing === "right" && dx < 0 || bFacing === "left" && dx > 0 || bFacing === "up" && dy < 0 || bFacing === "down" && dy > 0;
    return aToward && bToward;
  }
  static dist(a, b) {
    return Math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2);
  }
  findNearestPort(point2, schematicSheetId) {
    let nearest;
    let minDist = Infinity;
    for (const port of this.schematicPorts) {
      if (port.schematic_sheet_id !== schematicSheetId) continue;
      if (!port.center) continue;
      const d = _DiodeResistorAlignmentSolver.dist(point2, port.center);
      if (d < minDist) {
        minDist = d;
        nearest = port;
      }
    }
    return nearest;
  }
  findSourceComponentIdNearPoint(point2, schematicSheetId) {
    const nearest = this.findNearestPort(point2, schematicSheetId);
    if (!nearest || !nearest.source_port_id) return void 0;
    return this.sourceComponentIdBySourcePortId.get(nearest.source_port_id);
  }
  buildSourceComponentFtypeById(circuitJson) {
    const map = /* @__PURE__ */ new Map();
    for (const el of circuitJson) {
      if (el.type === "source_component" && "source_component_id" in el && "ftype" in el && typeof el.ftype === "string") {
        map.set(el.source_component_id, el.ftype);
      }
    }
    return map;
  }
  buildSourceComponentIdBySourcePortId(circuitJson) {
    const map = /* @__PURE__ */ new Map();
    for (const el of circuitJson) {
      if (el.type === "source_port" && "source_port_id" in el && "source_component_id" in el && typeof el.source_port_id === "string" && typeof el.source_component_id === "string") {
        map.set(el.source_port_id, el.source_component_id);
      }
    }
    return map;
  }
  buildSchematicBoxBySourceComponentId() {
    const map = /* @__PURE__ */ new Map();
    for (const placement of this.ctx.componentPlacements) {
      if (placement.sourceComponentId) {
        map.set(placement.sourceComponentId, placement);
      }
    }
    return map;
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(
      attrs,
      "diodeComponentName",
      issue.diodeSchematicBox.sourceComponentName
    );
    addAttr(attrs, "diodePin", issue.diodePin);
    addAttr(
      attrs,
      "resistorComponentName",
      issue.resistorSchematicBox.sourceComponentName
    );
    addAttr(attrs, "resistorPin", issue.resistorPin);
    addAttr(attrs, "message", issue.message);
    return `<DiodeResistorNotAligned ${attrs.join(" ")} />`;
  }
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/FeedbackNetworkPlacementSolver/FeedbackNetworkPlacementSolver.ts
import { BaseSolver as BaseSolver23 } from "@tscircuit/solver-utils";
var FeedbackNetworkPlacementSolver = class _FeedbackNetworkPlacementSolver extends BaseSolver23 {
  // A readability heuristic in schematic units, not a PCB proximity constraint.
  static MIN_BODY_GAP = 4;
  index;
  amplifierIds;
  issues;
  currentIndex = 0;
  constructor({
    ctx,
    issues
  }) {
    super();
    this.issues = issues;
    this.index = new PlacementNetworkIndex(ctx);
    this.amplifierIds = [...this.index.components.values()].filter((component) => component.ftype === "simple_op_amp").map((component) => component.source_component_id);
    this.solved = this.amplifierIds.length === 0;
  }
  _step() {
    const id = this.amplifierIds[this.currentIndex++];
    this.solved = this.currentIndex >= this.amplifierIds.length;
    if (!id) return;
    const index = this.index;
    const amplifier = index.placement(id);
    const output = index.namedPort(id, "output");
    const input = index.namedPort(id, "inverting_input");
    if (!amplifier || !output || !input || !index.port(output) || !index.port(input))
      return;
    const outputNet = index.connected(output.source_port_id);
    const inputNet = index.connected(input.source_port_id);
    if (outputNet === inputNet || index.isRail(outputNet) || index.isRail(inputNet))
      return;
    if ((index.portsByNet.get(inputNet) ?? []).some(
      (port) => port.source_component_id !== id && index.components.get(port.source_component_id)?.ftype === "simple_op_amp"
    ))
      return;
    const feedbackComponents = [];
    const seen = /* @__PURE__ */ new Set();
    for (const port of index.portsByNet.get(outputNet) ?? []) {
      const componentId = port.source_component_id;
      if (seen.has(componentId)) continue;
      seen.add(componentId);
      const component = index.components.get(componentId);
      if (component?.ftype !== "simple_resistor" && component?.ftype !== "simple_capacitor")
        continue;
      if (component.ftype === "simple_resistor" && !(component.resistance > 0))
        continue;
      const nets = index.twoTerminalNets(componentId);
      if (!nets?.includes(inputNet) || !nets.includes(outputNet)) continue;
      const placement = index.placement(componentId);
      if (!placement || !index.sameLocalScope(amplifier, placement)) return;
      feedbackComponents.push(placement);
    }
    const distantComponents = feedbackComponents.flatMap((schematicBox) => {
      const bodyGap2 = distanceBetweenBoxes(amplifier, schematicBox);
      const maxRecommendedBodyGap = Math.max(
        _FeedbackNetworkPlacementSolver.MIN_BODY_GAP,
        3 * Math.max(schematicBox.width, schematicBox.height)
      );
      return bodyGap2 > maxRecommendedBodyGap ? [{ schematicBox, bodyGap: bodyGap2, maxRecommendedBodyGap }] : [];
    });
    if (distantComponents.length === 0) return;
    const names = distantComponents.map(
      ({ schematicBox }) => schematicBox.sourceComponentName || "component"
    ).join(", ");
    this.issues.push({
      lineItemType: "FeedbackNetworkNotCompact",
      amplifierSchematicBox: amplifier,
      feedbackComponents,
      distantComponents,
      outputSourcePortId: output.source_port_id,
      invertingInputSourcePortId: input.source_port_id,
      message: `consider grouping ${names} closer to ${amplifier.sourceComponentName || "component"}, with a compact feedback return path above or below the amplifier`
    });
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(
      attrs,
      "amplifierName",
      issue.amplifierSchematicBox.sourceComponentName
    );
    addAttr(
      attrs,
      "feedbackComponentNames",
      issue.feedbackComponents.map((box) => box.sourceComponentName || "component").join(", ")
    );
    addAttr(
      attrs,
      "distantComponentNames",
      issue.distantComponents.map(
        ({ schematicBox }) => schematicBox.sourceComponentName || "component"
      ).join(", ")
    );
    addAttr(attrs, "message", issue.message);
    return `<FeedbackNetworkNotCompact ${attrs.join(" ")} />`;
  }
};
function distanceBetweenBoxes(a, b) {
  return Math.hypot(
    Math.max(0, Math.abs(a.schX - b.schX) - (a.width + b.width) / 2),
    Math.max(0, Math.abs(a.schY - b.schY) - (a.height + b.height) / 2)
  );
}

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/PullResistorPlacementSolver/PullResistorPlacementSolver.ts
import { BaseSolver as BaseSolver24 } from "@tscircuit/solver-utils";

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/utils/switch-pull-resistor-pairs.ts
function getSwitchPullResistorPairs(index) {
  const pairs = [];
  const isHorizontal = (id) => {
    const ports = index.portsByComponent.get(id);
    if (ports?.length !== 2) return false;
    const a = index.port(ports[0]);
    const b = index.port(ports[1]);
    return !!a && !!b && Math.abs(a.center.y - b.center.y) < 0.01 && Math.abs(a.center.x - b.center.x) > 0.01;
  };
  for (const component of index.components.values()) {
    if (component.ftype !== "simple_resistor" || component.resistance <= 0)
      continue;
    const id = component.source_component_id;
    const nets = index.twoTerminalNets(id);
    if (!nets || nets.filter((net) => index.isRail(net)).length !== 1) continue;
    const rail = nets.find((net) => index.isRail(net));
    if (index.powerNets.has(rail) && index.groundNets.has(rail)) continue;
    const signal = nets.find((net) => net !== rail);
    const peers = index.portsByNet.get(signal) ?? [];
    const switches = peers.filter((port) => {
      const type = index.components.get(port.source_component_id)?.ftype;
      return type === "simple_switch" || type === "simple_push_button";
    });
    if (switches.length !== 1 || peers.filter(
      (port) => index.components.get(port.source_component_id)?.ftype === "simple_resistor"
    ).length !== 1)
      continue;
    const signalPort = switches[0];
    const switchId = signalPort.source_component_id;
    const switchType = index.components.get(switchId)?.ftype;
    const switchNets = index.twoTerminalNets(switchId);
    const otherRail = switchNets?.find((net) => net !== signal);
    if (!otherRail) continue;
    const pullDirection = index.powerNets.has(rail) ? "up" : "down";
    if (pullDirection === "up" ? !index.groundNets.has(otherRail) || index.powerNets.has(otherRail) : !index.powerNets.has(otherRail) || index.groundNets.has(otherRail))
      continue;
    if ([id, switchId].some(
      (componentId) => index.portsByComponent.get(componentId)?.some((port) => port.do_not_connect)
    ))
      continue;
    const resistor = index.placement(id);
    const switchBox = index.placement(switchId);
    const pin = index.port(signalPort);
    if (!resistor || !switchBox || !pin || !index.sameLocalScope(resistor, switchBox))
      continue;
    pairs.push({
      resistor,
      switchBox,
      signalPort,
      signalSchY: pin.center.y,
      pullDirection,
      horizontalPushbutton: switchType === "simple_push_button" && isHorizontal(id) && isHorizontal(switchId)
    });
  }
  return pairs;
}
function getHorizontalPushbuttonComponentIds(index) {
  return new Set(
    getSwitchPullResistorPairs(index).flatMap(
      (pair) => pair.horizontalPushbutton ? [pair.resistor.sourceComponentId, pair.switchBox.sourceComponentId] : []
    )
  );
}

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/PullResistorPlacementSolver/PullResistorPlacementSolver.ts
var PullResistorPlacementSolver = class _PullResistorPlacementSolver extends BaseSolver24 {
  // Ignore small offsets and resistors straddling the signal's horizontal line.
  static MIN_WRONG_SIDE_GAP = 1.5;
  index;
  resistorIds;
  horizontalPushbuttonComponentIds;
  issues;
  currentIndex = 0;
  constructor({
    ctx,
    issues
  }) {
    super();
    this.issues = issues;
    this.index = new PlacementNetworkIndex(ctx);
    this.horizontalPushbuttonComponentIds = getHorizontalPushbuttonComponentIds(
      this.index
    );
    this.resistorIds = [...this.index.components.values()].filter(
      (component) => component.ftype === "simple_resistor" && component.resistance > 0
    ).map((component) => component.source_component_id);
    this.solved = this.resistorIds.length === 0;
  }
  _step() {
    const id = this.resistorIds[this.currentIndex++];
    this.solved = this.currentIndex >= this.resistorIds.length;
    if (!id) return;
    if (this.horizontalPushbuttonComponentIds.has(id)) return;
    const index = this.index;
    const resistor = index.placement(id);
    const nets = index.twoTerminalNets(id);
    if (!resistor || !nets) return;
    const rails = nets.filter((net) => index.isRail(net));
    if (rails.length !== 1) return;
    const rail = rails[0];
    if (index.powerNets.has(rail) && index.groundNets.has(rail)) return;
    const pullDirection = index.groundNets.has(rail) ? "down" : "up";
    const signal = nets.find((net) => net !== rail);
    const signalPorts = index.portsByNet.get(signal) ?? [];
    const requiringPorts = signalPorts.filter(
      (port) => port.needs_external_pullup || port.needs_external_pulldown
    );
    if (requiringPorts.length !== 1) return;
    const signalPort = requiringPorts[0];
    if (signalPort.needs_external_pullup && signalPort.needs_external_pulldown)
      return;
    if (pullDirection === "up" ? !signalPort.needs_external_pullup : !signalPort.needs_external_pulldown)
      return;
    const host = index.placement(signalPort.source_component_id);
    const schematicPin = index.port(signalPort);
    if (!host || !schematicPin || !index.sameLocalScope(host, resistor)) return;
    if (signalPorts.some((port) => {
      const otherId = port.source_component_id;
      if (otherId === id || otherId === signalPort.source_component_id)
        return false;
      const type = index.components.get(otherId)?.ftype;
      if (type !== "simple_capacitor") return true;
      const capacitorNets = index.twoTerminalNets(otherId);
      const returnNet = capacitorNets?.find((net) => net !== signal);
      if (!returnNet || !index.groundNets.has(returnNet) || index.powerNets.has(returnNet))
        return true;
      const capacitor = index.placement(otherId);
      return !capacitor || !index.sameLocalScope(host, capacitor);
    }))
      return;
    const signalSchY = schematicPin.center.y;
    const wrongSideGap = pullDirection === "up" ? signalSchY - (resistor.schY + resistor.height / 2) : resistor.schY - resistor.height / 2 - signalSchY;
    if (wrongSideGap <= _PullResistorPlacementSolver.MIN_WRONG_SIDE_GAP) return;
    const preferredSide = pullDirection === "up" ? "above" : "below";
    this.issues.push({
      lineItemType: "PullResistorOnWrongSide",
      resistorSchematicBox: resistor,
      hostSchematicBox: host,
      signalSourcePortId: signalPort.source_port_id,
      signalPinName: signalPort.name,
      signalSchY,
      pullDirection,
      preferredSide,
      wrongSideGap,
      maxRecommendedWrongSideGap: _PullResistorPlacementSolver.MIN_WRONG_SIDE_GAP,
      message: `consider placing ${resistor.sourceComponentName || "component"} ${preferredSide} ${host.sourceComponentName || "component"}.${signalPort.name} so the pull-${pullDirection} branch reads toward ${pullDirection === "up" ? "power" : "ground"}`
    });
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(
      attrs,
      "resistorName",
      issue.resistorSchematicBox.sourceComponentName
    );
    addAttr(attrs, "hostName", issue.hostSchematicBox.sourceComponentName);
    addAttr(attrs, "signalPin", issue.signalPinName);
    addAttr(attrs, "pullDirection", issue.pullDirection);
    addAttr(attrs, "preferredSide", issue.preferredSide);
    addAttr(attrs, "signalSchY", issue.signalSchY);
    addAttr(attrs, "wrongSideGap", issue.wrongSideGap);
    addAttr(attrs, "message", issue.message);
    return `<PullResistorOnWrongSide ${attrs.join(" ")} />`;
  }
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/TwoPinComponentRailOrientationSolver/TwoPinComponentRailOrientationSolver.ts
import { BaseSolver as BaseSolver25 } from "@tscircuit/solver-utils";
var TwoPinComponentRailOrientationSolver = class _TwoPinComponentRailOrientationSolver extends BaseSolver25 {
  static EPSILON = 0.01;
  index;
  powerNets;
  groundNets;
  positiveVoltageNets = /* @__PURE__ */ new Set();
  componentIds;
  horizontalPushbuttonComponentIds;
  issues;
  currentIndex = 0;
  constructor({
    ctx,
    issues
  }) {
    super();
    this.issues = issues;
    this.index = new PlacementNetworkIndex(ctx);
    this.horizontalPushbuttonComponentIds = getHorizontalPushbuttonComponentIds(
      this.index
    );
    this.powerNets = new Set(this.index.powerNets);
    this.groundNets = new Set(this.index.groundNets);
    for (const element of ctx.circuitJson) {
      if (element.type === "source_net" && element.is_positive_voltage_source)
        this.positiveVoltageNets.add(
          this.index.connected(element.source_net_id)
        );
      if (element.type !== "source_port") continue;
      const net = this.index.connected(element.source_port_id);
      if (element.provides_power || element.requires_power)
        this.powerNets.add(net);
      if (element.provides_ground || element.requires_ground)
        this.groundNets.add(net);
    }
    this.componentIds = [...this.index.components.keys()].filter(
      (id) => this.index.portsByComponent.get(id)?.length === 2
    );
    this.solved = this.componentIds.length === 0;
  }
  _step() {
    const id = this.componentIds[this.currentIndex++];
    this.solved = this.currentIndex >= this.componentIds.length;
    if (!id) return;
    const index = this.index;
    const component = index.placement(id);
    const sourceComponent = index.components.get(id);
    const nets = index.twoTerminalNets(id);
    if (!component || !nets) return;
    if (sourceComponent?.ftype === "simple_inductor" && !nets.some((net) => this.groundNets.has(net)))
      return;
    if (sourceComponent?.ftype === "simple_diode" && nets.every((net) => this.powerNets.has(net)))
      return;
    if (nets.some((net) => this.powerNets.has(net) && this.groundNets.has(net)))
      return;
    const railTypes = nets.map(
      (net) => this.powerNets.has(net) ? "power" : this.groundNets.has(net) ? "ground" : void 0
    );
    if (railTypes.every((type) => type === void 0)) return;
    const railType = railTypes.includes("power") ? "power" : "ground";
    const candidates = nets.flatMap(
      (net, i) => railTypes[i] === railType ? [{ net, index: i }] : []
    );
    const railIndex = (candidates.find(
      ({ net }) => index.portsByNet.get(net)?.some(
        (port) => railType === "power" ? port.provides_power : port.provides_ground
      )
    ) ?? candidates.find(
      ({ net }) => (railType === "power" ? index.powerNets : index.groundNets).has(net)
    ) ?? candidates[0]).index;
    const rail = nets[railIndex];
    const sourcePorts = index.portsByComponent.get(id);
    const railSourcePort = sourcePorts.find(
      (port) => index.connected(port.source_port_id) === rail
    );
    const otherSourcePort = sourcePorts.find((port) => port !== railSourcePort);
    const railPort = index.port(railSourcePort);
    const otherPort = index.port(otherSourcePort);
    if (!railPort || !otherPort) return;
    const otherNet = index.connected(otherSourcePort.source_port_id);
    const otherIsGround = this.groundNets.has(otherNet);
    const isSupplyToSignalResistor = sourceComponent?.ftype === "simple_resistor" && !this.powerNets.has(otherNet) && !otherIsGround;
    const invertedRails = this.positiveVoltageNets.has(rail) && (otherIsGround || isSupplyToSignalResistor) && Math.abs(railPort.center.x - otherPort.center.x) <= _TwoPinComponentRailOrientationSolver.EPSILON && railPort.center.y < otherPort.center.y - _TwoPinComponentRailOrientationSolver.EPSILON && railPort.facing_direction === "down" && otherPort.facing_direction === "up";
    if (invertedRails) {
      this.issues.push({
        lineItemType: "TwoPinComponentHasInvertedRails",
        schematicBox: component,
        railSourcePortId: railSourcePort.source_port_id,
        railPinName: railSourcePort.name,
        railType: "power",
        deltaSchRotation: 180,
        suggestedRailFacingDirection: "up",
        message: `rotate ${component.sourceComponentName || "component"} by 180\xB0 so its positive-supply pin faces up and its ${otherIsGround ? "ground" : "signal"} pin faces down; preserve pin connections and reroute attached traces`
      });
      return;
    }
    const horizontal = Math.abs(railPort.center.y - otherPort.center.y) <= _TwoPinComponentRailOrientationSolver.EPSILON && Math.abs(railPort.center.x - otherPort.center.x) > _TwoPinComponentRailOrientationSolver.EPSILON && (railPort.facing_direction === "left" && otherPort.facing_direction === "right" || railPort.facing_direction === "right" && otherPort.facing_direction === "left");
    if (!horizontal) return;
    if (this.horizontalPushbuttonComponentIds.has(id)) return;
    const suggestedRailFacingDirection = railType === "power" ? "up" : "down";
    const deltaSchRotation = railPort.facing_direction === "left" === (railType === "power") ? -90 : 90;
    this.issues.push({
      lineItemType: "TwoPinComponentShouldBeVertical",
      schematicBox: component,
      railSourcePortId: railSourcePort.source_port_id,
      railPinName: railSourcePort.name,
      railType,
      deltaSchRotation,
      suggestedRailFacingDirection,
      message: `rotate ${component.sourceComponentName || "component"} by ${deltaSchRotation}\xB0 so its ${railType}-connected pin faces ${suggestedRailFacingDirection} and the component is vertical`
    });
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(attrs, "componentName", issue.schematicBox.sourceComponentName);
    addAttr(attrs, "railPin", issue.railPinName);
    addAttr(attrs, "railType", issue.railType);
    addAttr(attrs, "deltaSchRotation", issue.deltaSchRotation);
    addAttr(
      attrs,
      "suggestedRailFacingDirection",
      issue.suggestedRailFacingDirection
    );
    addAttr(attrs, "message", issue.message);
    return `<${issue.lineItemType} ${attrs.join(" ")} />`;
  }
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/utils/schematic-box-labels.ts
var PIN_LABEL_EDGE_PADDING = 0.1;
var PIN_LABEL_TEXT_HEIGHT = 0.15;
var INNER_LABEL_COLLISION_PADDING = 0.02;
var COLLISION_COMPARISON_EPSILON = 1e-9;
function getSchematicBoxLabelRects(box, ports, getLabelLength) {
  const bounds = {
    left: box.schX - box.width / 2,
    right: box.schX + box.width / 2,
    top: box.schY + box.height / 2,
    bottom: box.schY - box.height / 2
  };
  const rects = [];
  for (const port of ports) {
    if (!port.side_of_component) continue;
    if (!port.display_pin_label) continue;
    const labelLength = getLabelLength(port);
    const halfTextHeight = PIN_LABEL_TEXT_HEIGHT / 2;
    switch (port.side_of_component) {
      case "left": {
        const xMin = bounds.left + PIN_LABEL_EDGE_PADDING;
        rects.push({
          side: port.side_of_component,
          xMin,
          xMax: xMin + labelLength,
          yMin: port.center.y - halfTextHeight,
          yMax: port.center.y + halfTextHeight
        });
        break;
      }
      case "right": {
        const xMax = bounds.right - PIN_LABEL_EDGE_PADDING;
        rects.push({
          side: port.side_of_component,
          xMin: xMax - labelLength,
          xMax,
          yMin: port.center.y - halfTextHeight,
          yMax: port.center.y + halfTextHeight
        });
        break;
      }
      case "top": {
        const yMax = bounds.top - PIN_LABEL_EDGE_PADDING;
        rects.push({
          side: port.side_of_component,
          xMin: port.center.x - halfTextHeight,
          xMax: port.center.x + halfTextHeight,
          yMin: yMax - labelLength,
          yMax
        });
        break;
      }
      case "bottom": {
        const yMin = bounds.bottom + PIN_LABEL_EDGE_PADDING;
        rects.push({
          side: port.side_of_component,
          xMin: port.center.x - halfTextHeight,
          xMax: port.center.x + halfTextHeight,
          yMin,
          yMax: yMin + labelLength
        });
        break;
      }
    }
  }
  return rects;
}
function schematicLabelRectsOverlap(a, b, padding = INNER_LABEL_COLLISION_PADDING) {
  return schematicLabelIntervalsOverlap(a.xMin, a.xMax, b.xMin, b.xMax, padding) && schematicLabelIntervalsOverlap(a.yMin, a.yMax, b.yMin, b.yMax, padding);
}
function schematicLabelIntervalsOverlap(aMin, aMax, bMin, bMax, padding = INNER_LABEL_COLLISION_PADDING) {
  return Math.min(aMax, bMax) - Math.max(aMin, bMin) + padding > COLLISION_COMPARISON_EPSILON;
}

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/utils/schematic-box-components.ts
function getSchematicBoxComponentIds(circuitJson) {
  return new Set(
    circuitJson.flatMap(
      (element) => element.type === "schematic_component" && element.is_box_with_pins !== false && !element.symbol_name && !element.schematic_symbol_id ? [element.schematic_component_id] : []
    )
  );
}

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/utils/schematic-text-geometry.ts
var rectPolygon = (bounds) => [
  { x: bounds.left, y: bounds.bottom },
  { x: bounds.right, y: bounds.bottom },
  { x: bounds.right, y: bounds.top },
  { x: bounds.left, y: bounds.top }
];
var advance = (character) => {
  if (/\s/.test(character)) return 0.28;
  if (/[ilI.,:;!'|]/.test(character)) return 0.25;
  if (/[MW@%]/.test(character)) return 0.9;
  if (/[mw]/.test(character)) return 0.8;
  if (/[A-Z]/.test(character)) return 0.67;
  return 0.56;
};
var widthInEm = (text) => Array.from(text).reduce((width, character) => width + advance(character), 0);
var getSchematicTextWidth = (text, fontSize) => widthInEm(text) * fontSize;
function getSchematicTextPolygons(text) {
  const size = text.font_size;
  if (!Number.isFinite(size) || size <= 0 || !Number.isFinite(text.rotation) || !Number.isFinite(text.position.x) || !Number.isFinite(text.position.y))
    return [];
  const anchor = text.anchor;
  const horizontal = anchor.includes("left") ? 0 : anchor.includes("right") ? 1 : 0.5;
  const top = anchor.includes("top") ? 0 : anchor.includes("bottom") ? size : size / 2;
  const radians = -text.rotation * Math.PI / 180;
  const cos = Math.cos(radians);
  const sin = Math.sin(radians);
  return text.text.split("\n").flatMap((line, index) => {
    const visible = line.trim();
    if (!visible) return [];
    const leading = line.length - line.trimStart().length;
    const left = (widthInEm(line.slice(0, leading)) - widthInEm(line) * horizontal) * size;
    const polygon = rectPolygon({
      left,
      right: left + widthInEm(visible) * size,
      // Leave the small whitespace at the top/bottom of an em outside the
      // collision region. Otherwise a readable caption just above a wire
      // (e.g. 100V at y=4.8, size=0.22 above a wire at y=4.7) is a false hit.
      top: top - index * size - size * 0.05,
      bottom: top - (index + 1) * size + size * 0.05
    });
    return [
      polygon.map(({ x, y }) => ({
        x: text.position.x + x * cos - y * sin,
        y: text.position.y + x * sin + y * cos
      }))
    ];
  });
}
function polygonsOverlap(a, b) {
  for (const polygon of [a, b]) {
    for (let i = 0; i < polygon.length; i++) {
      const p = polygon[i];
      const q2 = polygon[(i + 1) % polygon.length];
      const length = Math.hypot(q2.x - p.x, q2.y - p.y);
      if (length < 1e-9) continue;
      const nx = -(q2.y - p.y) / length;
      const ny = (q2.x - p.x) / length;
      const project = (points) => points.map(({ x, y }) => x * nx + y * ny);
      const pa = project(a);
      const pb = project(b);
      if (Math.min(Math.max(...pa), Math.max(...pb)) - Math.max(Math.min(...pa), Math.min(...pb)) <= 1e-6)
        return false;
    }
  }
  return true;
}
function traceSegmentPolygon(from, to) {
  const length = Math.hypot(to.x - from.x, to.y - from.y);
  if (length < 1e-9) return void 0;
  const dx = -(to.y - from.y) / length * 0.01;
  const dy = (to.x - from.x) / length * 0.01;
  return [
    { x: from.x + dx, y: from.y + dy },
    { x: to.x + dx, y: to.y + dy },
    { x: to.x - dx, y: to.y - dy },
    { x: from.x - dx, y: from.y - dy }
  ];
}
function segmentCrossesPolygon(from, to, polygon) {
  if (Math.hypot(to.x - from.x, to.y - from.y) < 1e-9) return false;
  let low = 0;
  let high = 1;
  for (let i = 0; i < polygon.length; i++) {
    const p = polygon[i];
    const q2 = polygon[(i + 1) % polygon.length];
    const length = Math.hypot(q2.x - p.x, q2.y - p.y);
    if (length < 1e-9) continue;
    const nx = -(q2.y - p.y) / length;
    const ny = (q2.x - p.x) / length;
    const start = (from.x - p.x) * nx + (from.y - p.y) * ny - 1e-6;
    const end = (to.x - p.x) * nx + (to.y - p.y) * ny - 1e-6;
    if (start <= 0 && end <= 0) return false;
    if (start <= 0) low = Math.max(low, -start / (end - start));
    if (end <= 0) high = Math.min(high, -start / (end - start));
    if (high <= low) return false;
  }
  return high > low;
}
var polygonBounds = (polygons) => {
  const points = polygons.flat();
  return {
    left: Math.min(...points.map((p) => p.x)),
    right: Math.max(...points.map((p) => p.x)),
    top: Math.max(...points.map((p) => p.y)),
    bottom: Math.min(...points.map((p) => p.y))
  };
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/SchematicBoxInnerLabelCollisionSolver/SchematicBoxInnerLabelCollisionSolver.ts
import { BaseSolver as BaseSolver26 } from "@tscircuit/solver-utils";
var SchematicBoxInnerLabelCollisionSolver = class extends BaseSolver26 {
  constructor(params) {
    super();
    this.params = params;
    const { circuitJson, componentPlacements } = params.ctx;
    this.placementById = this.getPlacementBySchematicComponentId(componentPlacements);
    const boxIds = getSchematicBoxComponentIds(circuitJson);
    this.entries = Array.from(
      this.getPortsBySchematicComponentId(circuitJson)
    ).filter(([id]) => boxIds.has(id));
    this.solved = this.entries.length === 0;
  }
  params;
  entries;
  placementById;
  currentIndex = 0;
  _step() {
    const entry = this.entries[this.currentIndex++];
    if (!entry) {
      this.solved = true;
      return;
    }
    this.solved = this.currentIndex >= this.entries.length;
    const [schematicComponentId, ports] = entry;
    const schematicBox = this.placementById.get(schematicComponentId);
    if (!schematicBox) return;
    const labelRects = getSchematicBoxLabelRects(
      schematicBox,
      ports,
      (port) => getSchematicTextWidth(port.display_pin_label, 0.15)
    );
    if (labelRects.length === 0) return;
    const collisionSummary = this.getCollisionSummary(labelRects);
    if (collisionSummary.overlappingSides.length === 0) return;
    this.params.issues.push({
      lineItemType: "SchematicBoxInnerLabelCollision",
      schematicBox,
      overlappingSides: collisionSummary.overlappingSides,
      message: this.getMessage(collisionSummary.overlappingSides)
    });
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(attrs, "message", issue.message);
    addAttr(attrs, "componentName", issue.schematicBox.sourceComponentName);
    addAttr(attrs, "currentSchWidth", issue.schematicBox.width);
    addAttr(attrs, "currentSchHeight", issue.schematicBox.height);
    addAttr(attrs, "overlappingSides", issue.overlappingSides.join(","));
    return `<SchematicBoxInnerLabelCollision ${attrs.join(" ")} />`;
  }
  getMessage(sides) {
    const dimension = sides.every((side) => side === "left" || side === "right") ? "schWidth" : sides.every((side) => side === "top" || side === "bottom") ? "schHeight" : "schWidth or schHeight";
    return `Inner labels are colliding. Increase the ${dimension}.`;
  }
  isSchematicPort(el) {
    return el.type === "schematic_port";
  }
  isSchematicSide(side) {
    return side === "left" || side === "right" || side === "top" || side === "bottom";
  }
  getPlacementBySchematicComponentId(componentPlacements) {
    return new Map(
      componentPlacements.filter((p) => p.schematicComponentId).map((p) => [p.schematicComponentId, p])
    );
  }
  getPortsBySchematicComponentId(circuitJson) {
    const map = /* @__PURE__ */ new Map();
    for (const port of circuitJson.filter((el) => this.isSchematicPort(el))) {
      if (!port.schematic_component_id) continue;
      if (!this.isSchematicSide(port.side_of_component)) continue;
      const ports = map.get(port.schematic_component_id);
      if (ports) ports.push(port);
      else map.set(port.schematic_component_id, [port]);
    }
    return map;
  }
  getCollisionSummary(rects) {
    const overlappingSides = /* @__PURE__ */ new Set();
    for (let i = 0; i < rects.length; i++) {
      for (let j = i + 1; j < rects.length; j++) {
        const a = rects[i];
        const b = rects[j];
        if (a.side === b.side) continue;
        if (!schematicLabelRectsOverlap(a, b)) continue;
        overlappingSides.add(a.side);
        overlappingSides.add(b.side);
      }
    }
    return {
      overlappingSides: this.sortSides(Array.from(overlappingSides))
    };
  }
  sortSides(sides) {
    const order = {
      left: 0,
      right: 1,
      top: 2,
      bottom: 3
    };
    return sides.sort((a, b) => order[a] - order[b]);
  }
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/SchematicBoxOverlapSolver/SchematicBoxOverlapSolver.ts
import { BaseSolver as BaseSolver27 } from "@tscircuit/solver-utils";
var SchematicBoxOverlapSolver = class _SchematicBoxOverlapSolver extends BaseSolver27 {
  constructor(params) {
    super();
    this.params = params;
    this.placements = params.ctx.componentPlacements;
    this.solved = this.placements.length < 2;
  }
  params;
  placements;
  firstIndex = 0;
  secondIndex = 1;
  _step() {
    if (this.firstIndex >= this.placements.length - 1) {
      this.solved = true;
      return;
    }
    const overlap = this.getComponentOverlap(
      this.placements[this.firstIndex],
      this.placements[this.secondIndex]
    );
    if (overlap) this.params.issues.push(overlap);
    this.secondIndex++;
    if (this.secondIndex >= this.placements.length) {
      this.firstIndex++;
      this.secondIndex = this.firstIndex + 1;
    }
    this.solved = this.firstIndex >= this.placements.length - 1;
  }
  getCenteredRectBounds(box) {
    return {
      left: box.schX - box.width / 2,
      right: box.schX + box.width / 2,
      top: box.schY - box.height / 2,
      bottom: box.schY + box.height / 2
    };
  }
  getOverlapCorrectionSuggestions({
    firstComponent,
    secondComponent,
    overlapWidth,
    overlapHeight
  }) {
    const firstArea = firstComponent.width * firstComponent.height;
    const secondArea = secondComponent.width * secondComponent.height;
    const target = firstArea <= secondArea ? firstComponent : secondComponent;
    const other = target === firstComponent ? secondComponent : firstComponent;
    const deltaSchX = target.schX <= other.schX ? -overlapWidth : overlapWidth;
    const deltaSchY = target.schY <= other.schY ? -overlapHeight : overlapHeight;
    return [
      {
        targetComponentName: target.sourceComponentName,
        deltaSchX,
        deltaSchY: 0,
        newSchX: target.schX + deltaSchX,
        newSchY: target.schY
      },
      {
        targetComponentName: target.sourceComponentName,
        deltaSchX: 0,
        deltaSchY,
        newSchX: target.schX,
        newSchY: target.schY + deltaSchY
      }
    ];
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(attrs, "component1Name", issue.firstComponent.sourceComponentName);
    addAttr(attrs, "component2Name", issue.secondComponent.sourceComponentName);
    addAttr(attrs, "component1SchX", issue.firstComponent.schX);
    addAttr(attrs, "component1SchY", issue.firstComponent.schY);
    addAttr(attrs, "component2SchX", issue.secondComponent.schX);
    addAttr(attrs, "component2SchY", issue.secondComponent.schY);
    addAttr(attrs, "overlapWidth", issue.overlapWidth);
    addAttr(attrs, "overlapHeight", issue.overlapHeight);
    return [
      `<ComponentOverlap ${attrs.join(" ")}>`,
      ...issue.correctionSuggestions.map(
        _SchematicBoxOverlapSolver.correctionSuggestionToString
      ),
      "</ComponentOverlap>"
    ].join("\n");
  }
  static correctionSuggestionToString(suggestion) {
    const attrs = [];
    addAttr(attrs, "target", suggestion.targetComponentName);
    if (suggestion.deltaSchX !== 0) {
      addAttr(attrs, "newSchX", suggestion.newSchX);
      addAttr(attrs, "deltaSchX", suggestion.deltaSchX, { formatDelta: true });
    }
    if (suggestion.deltaSchY !== 0) {
      addAttr(attrs, "newSchY", suggestion.newSchY);
      addAttr(attrs, "deltaSchY", suggestion.deltaSchY, { formatDelta: true });
    }
    return `<OverlapCorrectionSuggestion ${attrs.join(" ")} />`;
  }
  getComponentOverlap(firstComponent, secondComponent) {
    if (firstComponent.schematicSheetId !== secondComponent.schematicSheetId)
      return null;
    const a = this.getCenteredRectBounds(firstComponent);
    const b = this.getCenteredRectBounds(secondComponent);
    const overlapWidth = Math.min(a.right, b.right) - Math.max(a.left, b.left);
    const overlapHeight = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
    if (overlapWidth <= 0 || overlapHeight <= 0) return null;
    return {
      lineItemType: "ComponentOverlap",
      firstComponent,
      secondComponent,
      overlapWidth,
      overlapHeight,
      correctionSuggestions: this.getOverlapCorrectionSuggestions({
        firstComponent,
        secondComponent,
        overlapWidth,
        overlapHeight
      })
    };
  }
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/utils/schematic-box-graphics.ts
function getSchematicBoxGraphicBounds(circuitJson, componentId) {
  let bounds;
  for (const element of circuitJson) {
    if (element.type !== "schematic_path" && element.type !== "schematic_circle" && element.type !== "schematic_rect" || element.schematic_component_id !== componentId)
      continue;
    const stroke2 = (element.stroke_width ?? 0.02) / 2;
    let current;
    if (element.type === "schematic_path") {
      if (!element.points.length) continue;
      current = {
        xMin: Math.min(...element.points.map((p) => p.x)),
        xMax: Math.max(...element.points.map((p) => p.x)),
        yMin: Math.min(...element.points.map((p) => p.y)),
        yMax: Math.max(...element.points.map((p) => p.y))
      };
    } else {
      const angle = element.type === "schematic_rect" ? (element.rotation ?? 0) * Math.PI / 180 : 0;
      const width = element.type === "schematic_circle" ? 2 * element.radius : element.width;
      const height = element.type === "schematic_circle" ? 2 * element.radius : element.height;
      const halfWidth = (Math.abs(width * Math.cos(angle)) + Math.abs(height * Math.sin(angle))) / 2;
      const halfHeight = (Math.abs(width * Math.sin(angle)) + Math.abs(height * Math.cos(angle))) / 2;
      current = {
        xMin: element.center.x - halfWidth,
        xMax: element.center.x + halfWidth,
        yMin: element.center.y - halfHeight,
        yMax: element.center.y + halfHeight
      };
    }
    current.xMin -= stroke2;
    current.xMax += stroke2;
    current.yMin -= stroke2;
    current.yMax += stroke2;
    bounds = bounds ? {
      xMin: Math.min(bounds.xMin, current.xMin),
      xMax: Math.max(bounds.xMax, current.xMax),
      yMin: Math.min(bounds.yMin, current.yMin),
      yMax: Math.max(bounds.yMax, current.yMax)
    } : current;
  }
  return bounds;
}

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/utils/schematic-box-resize.ts
var MINIMUM_RESIZE_LABEL_BANK_GAP = 0.2;
var getPinLabelLength = (port) => Array.from(port.display_pin_label ?? "").length * 0.095;
function getSafeSchematicBoxResize(box, ports, pinSpacing, proposed, minimumReduction = 0, graphics) {
  if (!Number.isFinite(pinSpacing) || pinSpacing <= 0) return;
  if (ports.some((port) => !port.side_of_component)) return;
  if (!contentsFit(box, ports, INNER_LABEL_COLLISION_PADDING, graphics)) return;
  let minWidth = 0;
  let minHeight = 0;
  for (const port of ports) {
    if (port.side_of_component === "left" || port.side_of_component === "right") {
      minHeight = Math.max(
        minHeight,
        2 * (Math.abs(port.center.y - box.schY) + pinSpacing)
      );
    } else {
      minWidth = Math.max(
        minWidth,
        2 * (Math.abs(port.center.x - box.schX) + pinSpacing)
      );
    }
  }
  const width = proposed.width === void 0 ? box.width : Math.max(
    proposed.width,
    minWidth,
    getContentLimitedDimension(box, ports, "width", graphics)
  );
  const height = proposed.height === void 0 ? box.height : Math.max(
    proposed.height,
    minHeight,
    getContentLimitedDimension(box, ports, "height", graphics)
  );
  const isUsefulReduction = (reduction) => reduction > 1e-9 && reduction >= minimumReduction - 1e-9;
  const suggestedWidth = isUsefulReduction(box.width - width) ? width : void 0;
  const suggestedHeight = isUsefulReduction(box.height - height) ? height : void 0;
  if (suggestedWidth === void 0 && suggestedHeight === void 0) return;
  const candidates = [
    { width: suggestedWidth, height: suggestedHeight }
  ];
  if (suggestedWidth !== void 0 && suggestedHeight !== void 0) {
    candidates.push({ width: suggestedWidth }, { height: suggestedHeight });
  }
  const area = (candidate) => (candidate.width ?? box.width) * (candidate.height ?? box.height);
  candidates.sort((a, b) => area(a) - area(b));
  return candidates.find(
    (candidate) => contentsFit(
      {
        ...box,
        width: candidate.width ?? box.width,
        height: candidate.height ?? box.height
      },
      ports,
      MINIMUM_RESIZE_LABEL_BANK_GAP,
      graphics
    )
  );
}
function getContentLimitedDimension(box, ports, dimension, graphics) {
  const current = box[dimension];
  const center = dimension === "width" ? box.schX : box.schY;
  const minKey = dimension === "width" ? "xMin" : "yMin";
  const maxKey = dimension === "width" ? "xMax" : "yMax";
  const otherMinKey = dimension === "width" ? "yMin" : "xMin";
  const otherMaxKey = dimension === "width" ? "yMax" : "xMax";
  const speed = (label) => {
    if (dimension === "width") {
      return label.side === "left" ? -0.5 : label.side === "right" ? 0.5 : 0;
    }
    return label.side === "bottom" ? -0.5 : label.side === "top" ? 0.5 : 0;
  };
  let minimum = 0;
  const constrainGap = (gap, rate, requiredGap = 0) => {
    if (rate > 0)
      minimum = Math.max(minimum, current + (requiredGap - gap) / rate);
  };
  const labels = getSchematicBoxLabelRects(
    box,
    ports,
    getPinLabelLength
  );
  if (graphics) labels.push(graphics);
  for (let i = 0; i < labels.length; i++) {
    const a = labels[i];
    constrainGap(a[minKey] - (center - current / 2), speed(a) + 0.5);
    constrainGap(center + current / 2 - a[maxKey], 0.5 - speed(a));
    for (let j = i + 1; j < labels.length; j++) {
      const b = labels[j];
      const requiredGap = a.side && b.side && a.side !== b.side ? MINIMUM_RESIZE_LABEL_BANK_GAP : INNER_LABEL_COLLISION_PADDING;
      if (!schematicLabelIntervalsOverlap(
        a[otherMinKey],
        a[otherMaxKey],
        b[otherMinKey],
        b[otherMaxKey],
        requiredGap
      ))
        continue;
      const [first, second] = a[maxKey] <= b[minKey] ? [a, b] : [b, a];
      constrainGap(
        second[minKey] - first[maxKey],
        speed(second) - speed(first),
        requiredGap
      );
    }
  }
  return minimum;
}
function contentsFit(resized, ports, labelBankGap = INNER_LABEL_COLLISION_PADDING, graphics) {
  if (!Number.isFinite(resized.width) || !Number.isFinite(resized.height))
    return false;
  const labels = getSchematicBoxLabelRects(
    resized,
    ports,
    getPinLabelLength
  );
  if (graphics) labels.push(graphics);
  for (let i = 0; i < labels.length; i++) {
    const a = labels[i];
    if (a.xMin < resized.schX - resized.width / 2 - 1e-9 || a.xMax > resized.schX + resized.width / 2 + 1e-9 || a.yMin < resized.schY - resized.height / 2 - 1e-9 || a.yMax > resized.schY + resized.height / 2 + 1e-9)
      return false;
    for (let j = i + 1; j < labels.length; j++) {
      const b = labels[j];
      const gap = a.side && b.side && a.side !== b.side ? labelBankGap : INNER_LABEL_COLLISION_PADDING;
      if (schematicLabelRectsOverlap(a, b, gap)) return false;
    }
  }
  return true;
}

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/SchematicBoxTooWideSolver/SchematicBoxTooWideSolver.ts
import { BaseSolver as BaseSolver28 } from "@tscircuit/solver-utils";
var SchematicBoxTooWideSolver = class extends BaseSolver28 {
  constructor(params) {
    super();
    this.params = params;
    const { circuitJson, componentPlacements } = params.ctx;
    this.placementById = this.getPlacementBySchematicComponentId(componentPlacements);
    this.schematicComponentById = new Map(
      circuitJson.filter((element) => element.type === "schematic_component").map((component) => [component.schematic_component_id, component])
    );
    this.sourceComponentById = this.getSourceComponentById(circuitJson);
    const boxIds = getSchematicBoxComponentIds(circuitJson);
    this.entries = Array.from(
      this.getPortsBySchematicComponentId(circuitJson)
    ).filter(([id]) => boxIds.has(id));
    this.solved = this.entries.length === 0;
  }
  params;
  SCHEMATIC_BOX_TOO_WIDE_MESSAGE = "Shrink schematic box width";
  PIN_HEADER_MAX_ALLOWED_GAP = 0.1;
  GENERIC_MAX_ALLOWED_GAP = 1;
  PIN_LABEL_EDGE_PADDING = 0.1;
  GAP_COMPARISON_EPSILON = 1e-9;
  entries;
  placementById;
  schematicComponentById;
  sourceComponentById;
  currentIndex = 0;
  _step() {
    const entry = this.entries[this.currentIndex++];
    if (!entry) {
      this.solved = true;
      return;
    }
    this.solved = this.currentIndex >= this.entries.length;
    const [schematicComponentId, ports] = entry;
    const schematicBox = this.placementById.get(schematicComponentId);
    if (!schematicBox) return;
    const bounds = this.getCenteredRectBounds(schematicBox);
    const leftCol = this.getLabelColumn("left", ports);
    const rightCol = this.getLabelColumn("right", ports);
    const ftype = this.getSourceComponentFtype(
      schematicBox,
      this.sourceComponentById
    );
    let measuredSpace;
    if (leftCol && rightCol) {
      measuredSpace = this.getInnerLabelEdge(bounds, rightCol) - this.getInnerLabelEdge(bounds, leftCol);
    } else if (leftCol && leftCol.labelCount >= 4) {
      measuredSpace = bounds.right - this.getInnerLabelEdge(bounds, leftCol);
    } else if (rightCol && rightCol.labelCount >= 4) {
      measuredSpace = this.getInnerLabelEdge(bounds, rightCol) - bounds.left;
    }
    if (measuredSpace === void 0) return;
    const maxAllowed = ftype === "simple_pin_header" ? this.PIN_HEADER_MAX_ALLOWED_GAP : this.GENERIC_MAX_ALLOWED_GAP;
    if (!this.exceedsMaxAllowedGap(measuredSpace, maxAllowed)) return;
    const proposedWidth = this.getSuggestedWidth({
      measuredInnerLabelHorizontalEmptySpace: measuredSpace,
      maxAllowedInnerLabelHorizontalEmptySpace: maxAllowed,
      currentWidth: schematicBox.width
    });
    const pinSpacing = this.schematicComponentById.get(schematicComponentId)?.pin_spacing;
    if (pinSpacing === void 0) return;
    const resize = getSafeSchematicBoxResize(
      schematicBox,
      ports,
      pinSpacing,
      { width: proposedWidth },
      0,
      getSchematicBoxGraphicBounds(
        this.params.ctx.circuitJson,
        schematicComponentId
      )
    );
    if (resize?.width === void 0) return;
    const suggestedSchWidth = resize.width;
    if (ftype === "simple_pin_header") {
      this.params.issues.push({
        lineItemType: "PinHeaderSchematicBoxTooWide",
        schematicBox,
        measuredInnerLabelHorizontalEmptySpace: measuredSpace,
        maxAllowedInnerLabelHorizontalEmptySpace: maxAllowed,
        suggestedSchWidth,
        message: this.SCHEMATIC_BOX_TOO_WIDE_MESSAGE
      });
    } else {
      this.params.issues.push({
        lineItemType: "GenericSchematicBoxTooWide",
        schematicBox,
        measuredInnerLabelHorizontalEmptySpace: measuredSpace,
        maxAllowedInnerLabelHorizontalEmptySpace: maxAllowed,
        suggestedSchWidth,
        message: this.SCHEMATIC_BOX_TOO_WIDE_MESSAGE
      });
    }
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(attrs, "message", issue.message);
    addAttr(attrs, "componentName", issue.schematicBox.sourceComponentName);
    addAttr(attrs, "currentSchWidth", issue.schematicBox.width);
    addAttr(
      attrs,
      "measuredInnerLabelHorizontalEmptySpace",
      issue.measuredInnerLabelHorizontalEmptySpace
    );
    addAttr(
      attrs,
      "maxAllowedInnerLabelHorizontalEmptySpace",
      issue.maxAllowedInnerLabelHorizontalEmptySpace
    );
    addAttr(attrs, "suggestedSchWidth", issue.suggestedSchWidth);
    return `<${issue.lineItemType} ${attrs.join(" ")} />`;
  }
  isSchematicPort(el) {
    return el.type === "schematic_port";
  }
  getSourceComponentWithFtype(el) {
    if (el.type !== "source_component" || !("source_component_id" in el) || typeof el.source_component_id !== "string")
      return null;
    return {
      type: "source_component",
      source_component_id: el.source_component_id,
      ftype: "ftype" in el && typeof el.ftype === "string" ? el.ftype : void 0
    };
  }
  exceedsMaxAllowedGap(measured, maxAllowed) {
    return measured - maxAllowed > this.GAP_COMPARISON_EPSILON;
  }
  getCenteredRectBounds(box) {
    return {
      left: box.schX - box.width / 2,
      right: box.schX + box.width / 2,
      top: box.schY + box.height / 2,
      bottom: box.schY - box.height / 2
    };
  }
  getSourceComponentById(circuitJson) {
    return new Map(
      circuitJson.flatMap((el) => {
        const sc = this.getSourceComponentWithFtype(el);
        return sc ? [sc] : [];
      }).map((sc) => [sc.source_component_id, sc])
    );
  }
  getPlacementBySchematicComponentId(componentPlacements) {
    return new Map(
      componentPlacements.filter((p) => p.schematicComponentId).map((p) => [p.schematicComponentId, p])
    );
  }
  getPortsBySchematicComponentId(circuitJson) {
    const map = /* @__PURE__ */ new Map();
    for (const port of circuitJson.filter((el) => this.isSchematicPort(el))) {
      if (!port.schematic_component_id) continue;
      const ports = map.get(port.schematic_component_id);
      if (ports) ports.push(port);
      else map.set(port.schematic_component_id, [port]);
    }
    return map;
  }
  getSourceComponentFtype(schematicBox, sourceComponentById) {
    return schematicBox.sourceComponentId ? sourceComponentById.get(schematicBox.sourceComponentId)?.ftype : void 0;
  }
  getLabelColumn(side, ports) {
    const widths = ports.filter((p) => p.side_of_component === side).flatMap((p) => p.display_pin_label ? [getPinLabelLength(p)] : []);
    if (widths.length === 0) return null;
    return {
      side,
      labelCount: widths.length,
      maxLabelWidth: Math.max(...widths)
    };
  }
  getInnerLabelEdge(bounds, col) {
    return col.side === "left" ? bounds.left + this.PIN_LABEL_EDGE_PADDING + col.maxLabelWidth : bounds.right - this.PIN_LABEL_EDGE_PADDING - col.maxLabelWidth;
  }
  getSuggestedWidth(input) {
    return input.currentWidth - input.measuredInnerLabelHorizontalEmptySpace + input.maxAllowedInnerLabelHorizontalEmptySpace;
  }
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/SchematicPinPaddingToEdgeSolver/SchematicPinPaddingToEdgeSolver.ts
import { BaseSolver as BaseSolver29 } from "@tscircuit/solver-utils";
var SchematicPinPaddingToEdgeSolver = class extends BaseSolver29 {
  constructor(params) {
    super();
    this.params = params;
    const { circuitJson, componentPlacements } = params.ctx;
    this.placementById = this.getPlacementBySchematicComponentId(componentPlacements);
    this.schematicComponentById = this.getSchematicComponentById(circuitJson);
    this.sourcePortById = this.getSourcePortById(circuitJson);
    const boxIds = getSchematicBoxComponentIds(circuitJson);
    this.entries = Array.from(
      this.getPortsBySchematicComponentId(circuitJson)
    ).filter(([id]) => boxIds.has(id));
    this.solved = this.entries.length === 0;
  }
  params;
  MESSAGE = "Move schematic pins closer to the box edge or change the schematic box";
  GAP_COMPARISON_EPSILON = 1e-9;
  entries;
  placementById;
  schematicComponentById;
  sourcePortById;
  currentIndex = 0;
  _step() {
    const entry = this.entries[this.currentIndex++];
    if (!entry) {
      this.solved = true;
      return;
    }
    this.solved = this.currentIndex >= this.entries.length;
    const [schematicComponentId, ports] = entry;
    const schematicBox = this.placementById.get(schematicComponentId);
    if (!schematicBox) return;
    const pinSpacing = this.getPinSpacing(
      schematicBox,
      this.schematicComponentById
    );
    if (pinSpacing === null) return;
    const maxLabelLengthBySide = this.getMaxLabelLengthBySide(ports);
    const portsBySide = /* @__PURE__ */ new Map();
    for (const port of ports) {
      if (!this.isSchematicSide(port.side_of_component)) continue;
      const sidePorts = portsBySide.get(port.side_of_component) ?? [];
      sidePorts.push(port);
      portsBySide.set(port.side_of_component, sidePorts);
    }
    const candidates = [];
    for (const [pinSide, sidePorts] of portsBySide) {
      if (sidePorts.length === 1) continue;
      for (const edgeSide of this.getBoxEdgeSidesForPinSide(pinSide)) {
        const outerPin = this.getOuterPinBySide(edgeSide, sidePorts);
        if (!outerPin) continue;
        const measuredPadding = this.getPinPaddingToEdge(
          schematicBox,
          outerPin,
          edgeSide
        );
        const maxAllowedPadding = Math.max(
          pinSpacing,
          this.getMaxAllowedPinPadding(
            pinSpacing,
            edgeSide,
            maxLabelLengthBySide
          )
        );
        if (!this.exceedsMaxAllowedGap(
          measuredPadding,
          maxAllowedPadding + pinSpacing
        ))
          continue;
        candidates.push({
          schematicBox,
          pinSide,
          edgeSide,
          pinName: this.getPinName(outerPin, this.sourcePortById),
          measuredPadding,
          maxAllowedPadding
        });
      }
    }
    if (!candidates.length) return;
    const details = candidates.map((candidate) => this.createIssue(candidate));
    const widths = details.flatMap(
      (detail) => detail.suggestedSchWidth === void 0 ? [] : [detail.suggestedSchWidth]
    );
    const heights = details.flatMap(
      (detail) => detail.suggestedSchHeight === void 0 ? [] : [detail.suggestedSchHeight]
    );
    const resize = getSafeSchematicBoxResize(
      schematicBox,
      ports,
      pinSpacing,
      {
        width: widths.length ? Math.max(...widths) : void 0,
        height: heights.length ? Math.max(...heights) : void 0
      },
      2 * pinSpacing,
      getSchematicBoxGraphicBounds(
        this.params.ctx.circuitJson,
        schematicComponentId
      )
    );
    if (!resize) return;
    const applicableDetails = details.filter(
      (detail) => resize.width !== void 0 && detail.suggestedSchWidth !== void 0 || resize.height !== void 0 && detail.suggestedSchHeight !== void 0
    );
    const representative = applicableDetails.reduce(
      (a, b) => b.excessPadding > a.excessPadding ? b : a
    );
    const dimensions = [
      resize.width === void 0 ? "" : "width",
      resize.height === void 0 ? "" : "height"
    ].filter(Boolean).join(" and ");
    this.params.issues.push({
      ...representative,
      paddingDetails: applicableDetails.map(
        ({
          pinSide,
          edgeSide,
          pinName,
          measuredPadding,
          maxAllowedPadding,
          excessPadding
        }) => ({
          pinSide,
          edgeSide,
          pinName,
          measuredPadding,
          maxAllowedPadding,
          excessPadding
        })
      ),
      suggestedSchWidth: resize.width,
      suggestedSchHeight: resize.height,
      message: `${this.MESSAGE} ${dimensions}`
    });
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(attrs, "message", issue.message);
    addAttr(attrs, "componentName", issue.schematicBox.sourceComponentName);
    if (issue.paddingDetails) {
      addAttr(
        attrs,
        "pinSides",
        [...new Set(issue.paddingDetails.map((detail) => detail.pinSide))].join(
          ","
        )
      );
      addAttr(
        attrs,
        "edgeSides",
        [
          ...new Set(issue.paddingDetails.map((detail) => detail.edgeSide))
        ].join(",")
      );
    } else {
      addAttr(attrs, "pinSide", issue.pinSide);
      addAttr(attrs, "edgeSide", issue.edgeSide);
      addAttr(attrs, "pinName", issue.pinName);
      addAttr(attrs, "measuredPadding", issue.measuredPadding);
      addAttr(attrs, "maxAllowedPadding", issue.maxAllowedPadding);
      addAttr(attrs, "excessPadding", issue.excessPadding);
    }
    addAttr(attrs, "suggestedSchWidth", issue.suggestedSchWidth);
    addAttr(attrs, "suggestedSchHeight", issue.suggestedSchHeight);
    return `<SchematicPinPaddingToEdgeTooLarge ${attrs.join(" ")} />`;
  }
  isSchematicPort(el) {
    return el.type === "schematic_port";
  }
  isSourcePort(el) {
    return el.type === "source_port";
  }
  isSchematicComponent(el) {
    return el.type === "schematic_component";
  }
  isHorizontalSide(side) {
    return side === "left" || side === "right";
  }
  isVerticalSide(side) {
    return side === "top" || side === "bottom";
  }
  isSchematicSide(side) {
    return this.isHorizontalSide(side) || this.isVerticalSide(side);
  }
  exceedsMaxAllowedGap(measured, maxAllowed) {
    return measured - maxAllowed > this.GAP_COMPARISON_EPSILON;
  }
  getCenteredRectBounds(box) {
    return {
      left: box.schX - box.width / 2,
      right: box.schX + box.width / 2,
      top: box.schY + box.height / 2,
      bottom: box.schY - box.height / 2
    };
  }
  getSourcePortById(circuitJson) {
    return new Map(
      circuitJson.filter((el) => this.isSourcePort(el)).map((sp) => [sp.source_port_id, sp])
    );
  }
  getSchematicComponentById(circuitJson) {
    return new Map(
      circuitJson.filter((el) => this.isSchematicComponent(el)).map((sc) => [sc.schematic_component_id, sc])
    );
  }
  getPlacementBySchematicComponentId(componentPlacements) {
    return new Map(
      componentPlacements.filter((p) => p.schematicComponentId).map((p) => [p.schematicComponentId, p])
    );
  }
  getPortsBySchematicComponentId(circuitJson) {
    const map = /* @__PURE__ */ new Map();
    for (const port of circuitJson.filter((el) => this.isSchematicPort(el))) {
      if (!port.schematic_component_id) continue;
      const ports = map.get(port.schematic_component_id);
      if (ports) ports.push(port);
      else map.set(port.schematic_component_id, [port]);
    }
    return map;
  }
  getPinSpacing(schematicBox, schematicComponentById) {
    if (!schematicBox.schematicComponentId) return null;
    const sc = schematicComponentById.get(schematicBox.schematicComponentId);
    return typeof sc?.pin_spacing === "number" ? sc.pin_spacing : null;
  }
  getPinName(port, sourcePortById) {
    const sp = sourcePortById.get(port.source_port_id);
    if (sp?.name) return sp.name;
    if (port.display_pin_label) return port.display_pin_label;
    if (sp?.pin_number !== void 0) return String(sp.pin_number);
    return void 0;
  }
  getMaxLabelLengthBySide(ports) {
    const result = {
      left: 0,
      right: 0,
      top: 0,
      bottom: 0
    };
    for (const port of ports) {
      if (!this.isSchematicSide(port.side_of_component)) continue;
      if (!port.display_pin_label) continue;
      result[port.side_of_component] = Math.max(
        result[port.side_of_component],
        getPinLabelLength(port)
      );
    }
    return result;
  }
  getOuterPinBySide(edgeSide, ports) {
    if (ports.length === 0) return null;
    switch (edgeSide) {
      case "top":
        return ports.reduce((a, b) => b.center.y > a.center.y ? b : a);
      case "bottom":
        return ports.reduce((a, b) => b.center.y < a.center.y ? b : a);
      case "left":
        return ports.reduce((a, b) => b.center.x < a.center.x ? b : a);
      case "right":
        return ports.reduce((a, b) => b.center.x > a.center.x ? b : a);
    }
  }
  getPinPaddingToEdge(schematicBox, port, edgeSide) {
    const bounds = this.getCenteredRectBounds(schematicBox);
    switch (edgeSide) {
      case "top":
        return Math.max(0, bounds.top - port.center.y);
      case "bottom":
        return Math.max(0, port.center.y - bounds.bottom);
      case "left":
        return Math.max(0, port.center.x - bounds.left);
      case "right":
        return Math.max(0, bounds.right - port.center.x);
    }
  }
  getBoxEdgeSidesForPinSide(pinSide) {
    return this.isHorizontalSide(pinSide) ? ["top", "bottom"] : ["left", "right"];
  }
  getMaxAllowedPinPadding(spacing, edgeSide, maxLabelLengthBySide) {
    const sides = this.isHorizontalSide(
      edgeSide
    ) ? ["left", "right"] : ["top", "bottom"];
    return (maxLabelLengthBySide[sides[0]] + maxLabelLengthBySide[sides[1]] + spacing) / 2;
  }
  createIssue(candidate) {
    const excessPadding = Math.max(
      0,
      candidate.measuredPadding - candidate.maxAllowedPadding
    );
    const reduction = excessPadding * 2;
    return {
      lineItemType: "SchematicPinPaddingToEdgeTooLarge",
      pinSide: candidate.pinSide,
      edgeSide: candidate.edgeSide,
      pinName: candidate.pinName,
      schematicBox: candidate.schematicBox,
      measuredPadding: candidate.measuredPadding,
      maxAllowedPadding: candidate.maxAllowedPadding,
      excessPadding,
      suggestedSchWidth: this.isHorizontalSide(candidate.pinSide) ? void 0 : Math.max(0, candidate.schematicBox.width - reduction),
      suggestedSchHeight: this.isHorizontalSide(candidate.pinSide) ? Math.max(0, candidate.schematicBox.height - reduction) : void 0,
      message: this.isHorizontalSide(candidate.pinSide) ? `${this.MESSAGE} height` : `${this.MESSAGE} width`
    };
  }
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/SchematicPlacementPipeline/SchematicPlacementPipeline.ts
import {
  BasePipelineSolver,
  definePipelineStep
} from "@tscircuit/solver-utils";

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/utils/placements.ts
import { cju as cju11 } from "@tscircuit/circuit-json-util";

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/utils/schematic-sheets.ts
var getSchematicSheetNamesById = (circuitJson) => {
  const map = /* @__PURE__ */ new Map();
  for (const element of circuitJson) {
    if (element.type === "schematic_sheet" && element.name) {
      map.set(element.schematic_sheet_id, element.name);
    }
  }
  return map;
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/utils/placements.ts
var isSchematicBox = (el) => el.type === "schematic_box";
var isSchematicComponent = (el) => el.type === "schematic_component";
var getSchematicSheetId = (el) => el.schematic_sheet_id;
var getSourceComponentName = (circuitJson, sourceComponentId) => {
  if (!sourceComponentId) return void 0;
  return cju11(circuitJson).source_component.get(sourceComponentId)?.name;
};
var getSourceComponentMetadata = (schematicBox, circuitJson) => {
  if (!schematicBox.schematic_component_id) return {};
  const util = cju11(circuitJson);
  const sc = util.schematic_component.get(schematicBox.schematic_component_id);
  if (!sc?.source_component_id) return {};
  const sourceComponent = util.source_component.get(sc.source_component_id);
  return {
    sourceComponentId: sc.source_component_id,
    sourceComponentName: sourceComponent?.name
  };
};
var schematicComponentToPlacement = (schematicComponent, circuitJson, schematicSheetNameById, schematicBox) => {
  let schematicSheetId = getSchematicSheetId(schematicComponent);
  if (schematicSheetId === void 0 && schematicBox) {
    schematicSheetId = getSchematicSheetId(schematicBox);
  }
  let schematicSheetName;
  if (schematicSheetId) {
    schematicSheetName = schematicSheetNameById.get(schematicSheetId);
  }
  const placement = {
    lineItemType: "SchematicBoxPlacement",
    positionAnchor: "center",
    schX: schematicComponent.center.x,
    schY: schematicComponent.center.y,
    width: schematicBox?.width ?? schematicComponent.size.width,
    height: schematicBox?.height ?? schematicComponent.size.height,
    sourceComponentId: schematicComponent.source_component_id,
    sourceComponentName: getSourceComponentName(
      circuitJson,
      schematicComponent.source_component_id
    ),
    schematicComponentId: schematicComponent.schematic_component_id,
    schematicSymbolId: schematicBox?.schematic_symbol_id ?? schematicComponent.schematic_symbol_id,
    subcircuitId: schematicComponent.subcircuit_id ?? schematicBox?.subcircuit_id
  };
  if (schematicSheetId) {
    placement.schematicSheetId = schematicSheetId;
  }
  if (schematicSheetName) {
    placement.schematicSheetName = schematicSheetName;
  }
  return placement;
};
var schematicBoxToPlacement = (schematicBox, circuitJson, schematicSheetNameById) => {
  const schematicSheetId = getSchematicSheetId(schematicBox);
  let schematicSheetName;
  if (schematicSheetId) {
    schematicSheetName = schematicSheetNameById.get(schematicSheetId);
  }
  const placement = {
    lineItemType: "SchematicBoxPlacement",
    positionAnchor: "center",
    // Circuit JSON stores a box's lower-left corner; placements use centres.
    schX: schematicBox.x + schematicBox.width / 2,
    schY: schematicBox.y + schematicBox.height / 2,
    width: schematicBox.width,
    height: schematicBox.height,
    ...getSourceComponentMetadata(schematicBox, circuitJson),
    schematicComponentId: schematicBox.schematic_component_id,
    schematicSymbolId: schematicBox.schematic_symbol_id,
    subcircuitId: schematicBox.subcircuit_id
  };
  if (schematicSheetId) {
    placement.schematicSheetId = schematicSheetId;
  }
  if (schematicSheetName) {
    placement.schematicSheetName = schematicSheetName;
  }
  return placement;
};
var buildSolverContext = (circuitJson) => {
  const schematicBoxes = circuitJson.filter(isSchematicBox).filter((box) => box.schematic_component_id || box.schematic_symbol_id);
  const schematicSheetNameById = getSchematicSheetNamesById(circuitJson);
  const schematicComponentIds = new Set(
    circuitJson.filter(isSchematicComponent).map((sc) => sc.schematic_component_id)
  );
  const componentPlacements = [
    ...circuitJson.filter(isSchematicComponent).map(
      (sc) => schematicComponentToPlacement(
        sc,
        circuitJson,
        schematicSheetNameById,
        schematicBoxes.find(
          (sb) => sb.schematic_component_id === sc.schematic_component_id
        )
      )
    ),
    ...schematicBoxes.filter(
      (sb) => !sb.schematic_component_id || !schematicComponentIds.has(sb.schematic_component_id)
    ).map(
      (sb) => schematicBoxToPlacement(sb, circuitJson, schematicSheetNameById)
    )
  ];
  return { circuitJson, componentPlacements };
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/SwitchPullResistorPlacementSolver/SwitchPullResistorPlacementSolver.ts
import { BaseSolver as BaseSolver30 } from "@tscircuit/solver-utils";
var SwitchPullResistorPlacementSolver = class extends BaseSolver30 {
  constructor(params) {
    super();
    this.params = params;
  }
  params;
  _step() {
    const index = new PlacementNetworkIndex(this.params.ctx);
    for (const pair of getSwitchPullResistorPairs(index)) {
      const { resistor, switchBox, signalPort, signalSchY, pullDirection } = pair;
      if (pair.horizontalPushbutton) continue;
      const signal = index.connected(signalPort.source_port_id);
      if (index.portsByNet.get(signal)?.length !== 2) continue;
      if (signalPort.needs_external_pullup || signalPort.needs_external_pulldown)
        continue;
      const wrongSideGap = pullDirection === "up" ? signalSchY - (resistor.schY + resistor.height / 2) : resistor.schY - resistor.height / 2 - signalSchY;
      if (wrongSideGap <= 1.5) continue;
      const preferredSide = pullDirection === "up" ? "above" : "below";
      this.params.issues.push({
        lineItemType: "PullResistorOnWrongSide",
        resistorSchematicBox: resistor,
        hostSchematicBox: switchBox,
        signalSourcePortId: signalPort.source_port_id,
        signalPinName: signalPort.name,
        signalSchY,
        pullDirection,
        preferredSide,
        wrongSideGap,
        maxRecommendedWrongSideGap: 1.5,
        message: `place ${resistor.sourceComponentName} ${preferredSide} ${switchBox.sourceComponentName} so the pull-${pullDirection} branch reads toward ${pullDirection === "up" ? "power" : "ground"}`
      });
    }
    this.solved = true;
  }
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/utils/trace-name.ts
function getTraceName(circuitJson, trace) {
  const sourceTrace = circuitJson.find(
    (e) => e.type === "source_trace" && e.source_trace_id === trace.source_trace_id
  );
  if (sourceTrace?.type === "source_trace" && sourceTrace.name)
    return sourceTrace.name;
  const first = trace.edges[0];
  const last = trace.edges.at(-1);
  const endpointName = (point2, id) => {
    const ports = circuitJson.filter(
      (e) => e.type === "schematic_port" && e.schematic_sheet_id === trace.schematic_sheet_id && (id ? e.schematic_port_id === id : Math.hypot(e.center.x - point2.x, e.center.y - point2.y) <= 0.01)
    );
    if (ports.length !== 1 || ports[0]?.type !== "schematic_port") return;
    const port = ports[0];
    const sourcePort = circuitJson.find(
      (e) => e.type === "source_port" && e.source_port_id === port.source_port_id
    );
    const component = circuitJson.find(
      (e) => e.type === "schematic_component" && e.schematic_component_id === port.schematic_component_id
    );
    const sourceComponentId = sourcePort?.type === "source_port" ? sourcePort.source_component_id : component?.type === "schematic_component" ? component.source_component_id : void 0;
    const sourceComponent = circuitJson.find(
      (e) => e.type === "source_component" && e.source_component_id === sourceComponentId
    );
    if (sourceComponent?.type !== "source_component" || !sourceComponent.name)
      return;
    const pin = sourcePort?.type === "source_port" && sourcePort.name ? sourcePort.name : port.pin_number !== void 0 ? `pin${port.pin_number}` : port.display_pin_label;
    return pin ? `${sourceComponent.name}.${pin}` : sourceComponent.name;
  };
  const from = first && endpointName(first.from, first.from_schematic_port_id);
  const to = last && endpointName(last.to, last.to_schematic_port_id);
  if (from && to) return `${from} to ${to}`;
  return sourceTrace?.type === "source_trace" && sourceTrace.display_name || from || to || "trace";
}

// node_modules/calculate-elbow/lib/calculateElbowBends.ts
var calculateElbowBends = (p1, p2, overshootAmount) => {
  const result = [{ x: p1.x, y: p1.y }];
  const midX = (p1.x + p2.x) / 2;
  const midY = (p1.y + p2.y) / 2;
  const p2Target = { x: p2.x, y: p2.y };
  switch (p2.facingDirection) {
    case "x+":
      p2Target.x += overshootAmount;
      break;
    case "x-":
      p2Target.x -= overshootAmount;
      break;
    case "y+":
      p2Target.y += overshootAmount;
      break;
    case "y-":
      p2Target.y -= overshootAmount;
      break;
  }
  const startDir = p1.facingDirection ?? "none";
  const endDir = p2.facingDirection ?? "none";
  const push = (pt2) => {
    const last = result[result.length - 1];
    if (last.x !== pt2.x || last.y !== pt2.y) result.push(pt2);
  };
  const yAligned = Math.abs(p1.y - p2.y) <= Math.max(1e-6, overshootAmount * 0.1);
  const xAligned = Math.abs(p1.x - p2.x) <= Math.max(1e-6, overshootAmount * 0.1);
  if (startDir === "none" && endDir === "none") {
    globalThis.__DEBUG_CALCULATE_ELBOW_CASE = 1;
    push({ x: midX, y: p1.y });
    push({ x: midX, y: p2.y });
  } else if (startDir === "x+" && endDir === "y+") {
    globalThis.__DEBUG_CALCULATE_ELBOW_CASE = 2;
    if (p1.x > p2.x && p1.y < p2.y) {
      globalThis.__DEBUG_CALCULATE_ELBOW_CASE = 2.1;
      push({ x: p1.x + overshootAmount, y: p1.y });
      push({ x: p1.x + overshootAmount, y: p2.y + overshootAmount });
      push({ x: p2.x, y: p2.y + overshootAmount });
    } else if (!xAligned && !yAligned && p1.x < p2.x && p1.y > p2.y) {
      globalThis.__DEBUG_CALCULATE_ELBOW_CASE = 2.2;
      push({ x: p2.x, y: p1.y });
    } else if (xAligned) {
      globalThis.__DEBUG_CALCULATE_ELBOW_CASE = 2.3;
      push({ x: p1.x + overshootAmount, y: p1.y });
      push({ x: p1.x + overshootAmount, y: p2.y + overshootAmount });
      push({ x: p2.x, y: p2.y + overshootAmount });
    } else {
      if (p1.x < p2.x) {
        globalThis.__DEBUG_CALCULATE_ELBOW_CASE = 2.4;
        push({ x: midX, y: p1.y });
        push({ x: midX, y: p2Target.y });
        push({ x: p2.x, y: p2Target.y });
      } else if (p1.y <= p2.y + overshootAmount) {
        globalThis.__DEBUG_CALCULATE_ELBOW_CASE = 2.5;
        push({ x: p1.x + overshootAmount, y: p1.y });
        push({ x: p1.x + overshootAmount, y: p1.y + overshootAmount });
        push({ x: p2.x, y: p1.y + overshootAmount });
        push({ x: p2.x, y: p2.y });
      } else {
        globalThis.__DEBUG_CALCULATE_ELBOW_CASE = 2.6;
        push({ x: p1.x + overshootAmount, y: p1.y });
        push({ x: p1.x + overshootAmount, y: (p1.y + p2.y) / 2 });
        push({ x: p2.x, y: (p1.y + p2.y) / 2 });
      }
    }
  } else if (startDir === "x+" && endDir === "x+" && !yAligned) {
    globalThis.__DEBUG_CALCULATE_ELBOW_CASE = 3;
    const commonX = Math.max(p1.x + overshootAmount, p2Target.x);
    push({ x: commonX, y: p1.y });
    push({ x: commonX, y: p2.y });
  } else if (startDir === "x+" && endDir === "x+" && yAligned) {
    globalThis.__DEBUG_CALCULATE_ELBOW_CASE = 3.1;
    push({ x: p1.x + overshootAmount, y: p1.y });
    push({ x: p1.x + overshootAmount, y: p1.y + overshootAmount });
    push({ x: p2.x + overshootAmount, y: p1.y + overshootAmount });
    push({ x: p2.x + overshootAmount, y: p2.y });
  } else if (startDir === "x+" && endDir === "y-") {
    if (xAligned && p1.y <= p2.y) {
      globalThis.__DEBUG_CALCULATE_ELBOW_CASE = 4.11;
      push({ x: p1.x + overshootAmount, y: p1.y });
      push({ x: p1.x + overshootAmount, y: midY });
      push({ x: p2.x, y: midY });
    } else if (xAligned && p1.y > p2.y) {
      globalThis.__DEBUG_CALCULATE_ELBOW_CASE = 4.12;
      push({ x: p1.x + overshootAmount, y: p1.y });
      push({ x: p1.x + overshootAmount, y: p2.y - overshootAmount });
      push({ x: p2.x, y: p2.y - overshootAmount });
    } else if (p1.x < p2.x && p1.y < p2.y) {
      globalThis.__DEBUG_CALCULATE_ELBOW_CASE = 4.2;
      push({ x: p2.x, y: p1.y });
    } else {
      if (p1.x > p2.x && p1.y < p2.y) {
        globalThis.__DEBUG_CALCULATE_ELBOW_CASE = 4.3;
        const p1OvershootX = p1.x + overshootAmount;
        push({ x: p1OvershootX, y: p1.y });
        push({ x: p1OvershootX, y: midY });
        push({ x: p2.x, y: midY });
      } else if (p1.x > p2.x && p1.y > p2.y) {
        globalThis.__DEBUG_CALCULATE_ELBOW_CASE = 4.4;
        const p1OvershootX = p1.x + overshootAmount;
        push({ x: p1OvershootX, y: p1.y });
        push({ x: p1OvershootX, y: p2Target.y });
        push({ x: p2.x, y: p2Target.y });
      } else if (p1.y === p2.y) {
        globalThis.__DEBUG_CALCULATE_ELBOW_CASE = 4.5;
        push({ x: p1.x + overshootAmount, y: p1.y });
        push({ x: p1.x + overshootAmount, y: p1.y - overshootAmount });
        push({ x: p2.x, y: p1.y - overshootAmount });
      } else {
        globalThis.__DEBUG_CALCULATE_ELBOW_CASE = 4.6;
        push({ x: midX, y: p1.y });
        push({ x: midX, y: p2Target.y });
        push({ x: p2.x, y: p2Target.y });
      }
    }
  } else if (startDir === "x+" && endDir === "x-" && p1.x + overshootAmount >= p2.x - overshootAmount && !yAligned) {
    globalThis.__DEBUG_CALCULATE_ELBOW_CASE = 5;
    const p1OvershootX = p1.x + overshootAmount;
    push({ x: p1OvershootX, y: p1.y });
    push({ x: p1OvershootX, y: midY });
    push({ x: p2Target.x, y: midY });
    push({ x: p2Target.x, y: p2Target.y });
  } else if (startDir === "x+" && endDir === "x-" && yAligned && p2.x > p1.x) {
  } else if (startDir === "x+" && endDir === "x-" && yAligned) {
    globalThis.__DEBUG_CALCULATE_ELBOW_CASE = 7;
    push({ x: p1.x + overshootAmount, y: p1.y });
    push({ x: p1.x + overshootAmount, y: p1.y + overshootAmount });
    push({ x: p2.x - overshootAmount, y: p1.y + overshootAmount });
    push({ x: p2.x - overshootAmount, y: p1.y });
  } else {
    globalThis.__DEBUG_CALCULATE_ELBOW_CASE = 8;
    if (startDir === "x+") {
      push({ x: p1.x + overshootAmount, y: p1.y });
    }
    push({ x: midX, y: result[result.length - 1].y });
    push({ x: midX, y: p2Target.y });
    push({ x: p2Target.x, y: p2Target.y });
  }
  push({ x: p2.x, y: p2.y });
  return result;
};

// node_modules/calculate-elbow/lib/index.ts
var calculateElbow = (point1, point2, options = {}) => {
  let p1 = point1;
  let p2 = point2;
  let orderFlipped = false;
  if (p1.x > p2.x || p1.x === p2.x && p1.y > p2.y) {
    orderFlipped = true;
    [p1, p2] = [p2, p1];
  }
  const mirrorX = p1.facingDirection === "x-";
  const mirrorY = p1.facingDirection === "y-";
  const mirrorPoint = (pt2) => {
    const x = mirrorX ? p1.x - (pt2.x - p1.x) : pt2.x;
    const y = mirrorY ? p1.y - (pt2.y - p1.y) : pt2.y;
    let facing = pt2.facingDirection;
    if (mirrorX) {
      if (facing === "x+") facing = "x-";
      else if (facing === "x-") facing = "x+";
    }
    if (mirrorY) {
      if (facing === "y+") facing = "y-";
      else if (facing === "y-") facing = "y+";
    }
    return { x, y, facingDirection: facing };
  };
  const rotateCW = (pt2, centre) => {
    const dx = pt2.x - centre.x;
    const dy = pt2.y - centre.y;
    const x = centre.x + dy;
    const y = centre.y - dx;
    let facing = pt2.facingDirection;
    switch (facing) {
      case "x+":
        facing = "y-";
        break;
      case "y-":
        facing = "x-";
        break;
      case "x-":
        facing = "y+";
        break;
      case "y+":
        facing = "x+";
        break;
    }
    return { x, y, facingDirection: facing };
  };
  const rotateCCW = (pt2, centre) => {
    const dx = pt2.x - centre.x;
    const dy = pt2.y - centre.y;
    return { x: centre.x - dy, y: centre.y + dx };
  };
  const mp1 = mirrorX || mirrorY ? mirrorPoint(p1) : p1;
  const mp2 = mirrorX || mirrorY ? mirrorPoint(p2) : p2;
  let rp1 = mp1;
  let rp2 = mp2;
  let rotated = false;
  if (mp1.facingDirection === "y+") {
    rotated = true;
    rp1 = { ...mp1, facingDirection: "x+" };
    rp2 = rotateCW(mp2, mp1);
  }
  const overshootAmount = options?.overshoot ?? 0.1 * Math.max(Math.abs(rp1.x - rp2.x), Math.abs(rp1.y - rp2.y));
  let result = calculateElbowBends(
    rp1,
    rp2,
    overshootAmount
  );
  if (rotated) {
    result = result.map((pt2) => rotateCCW(pt2, rp1));
  }
  if (mirrorX || mirrorY) {
    result = result.map(({ x, y }) => ({
      x: mirrorX ? p1.x - (x - p1.x) : x,
      y: mirrorY ? p1.y - (y - p1.y) : y
    }));
  }
  return orderFlipped ? result.reverse() : result;
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/TraceSimplificationSolver/TraceSimplificationSolver.ts
import { BaseSolver as BaseSolver31 } from "@tscircuit/solver-utils";
var TraceSimplificationSolver = class _TraceSimplificationSolver extends BaseSolver31 {
  static EPSILON = 0.01;
  ctx;
  out;
  constructor({
    ctx,
    issues
  }) {
    super();
    this.ctx = ctx;
    this.out = issues;
  }
  _step() {
    const ports = this.ctx.circuitJson.filter(
      (element) => element.type === "schematic_port"
    );
    const portsById = new Map(
      ports.map((port) => [port.schematic_port_id, port])
    );
    const placementsByComponentId = new Map(
      this.ctx.componentPlacements.flatMap(
        (placement) => placement.schematicComponentId ? [[placement.schematicComponentId, placement]] : []
      )
    );
    const emittedMoves = /* @__PURE__ */ new Set();
    for (const trace of this.ctx.circuitJson.filter(
      (element) => element.type === "schematic_trace"
    )) {
      const points = this.getTracePoints(trace);
      const currentTurnCount = this.countTurns(points);
      if (currentTurnCount !== 3) continue;
      const candidates = [
        this.getCandidate({
          trace,
          points,
          atStart: true,
          currentTurnCount,
          ports,
          portsById,
          placementsByComponentId
        }),
        this.getCandidate({
          trace,
          points,
          atStart: false,
          currentTurnCount,
          ports,
          portsById,
          placementsByComponentId
        })
      ].filter((candidate) => Boolean(candidate));
      for (const candidate of [...candidates]) {
        if (!candidate.target.sourceComponentName?.startsWith("U")) continue;
        for (const point2 of [points[0], points.at(-1)]) {
          const port = this.findPortAtPoint(
            ports,
            point2,
            trace.schematic_sheet_id
          );
          const target = port?.schematic_component_id ? placementsByComponentId.get(port.schematic_component_id) : void 0;
          if (!target || !/^[CR]/.test(target.sourceComponentName ?? ""))
            continue;
          candidates.push({
            target,
            deltaSchX: -candidate.deltaSchX,
            deltaSchY: -candidate.deltaSchY,
            currentTurnCount,
            suggestedTurnCount: candidate.suggestedTurnCount
          });
        }
      }
      const priority = (candidate) => /^[CR]/.test(candidate.target.sourceComponentName ?? "") ? 0 : candidate.target.sourceComponentName?.startsWith("U") ? 2 : 1;
      candidates.sort((a, b) => priority(a) - priority(b));
      for (const candidate of candidates) {
        if (this.wouldOverlapAnotherComponent(candidate)) continue;
        if (!this.validateMove(trace, candidate, ports)) continue;
        const moveKey = [
          candidate.target.schematicComponentId,
          candidate.deltaSchX.toFixed(3),
          candidate.deltaSchY.toFixed(3)
        ].join("\0");
        if (emittedMoves.has(moveKey)) break;
        emittedMoves.add(moveKey);
        this.out.push(this.makeIssue(trace, candidate));
        break;
      }
    }
    this.solved = true;
  }
  getCandidate({
    trace,
    points,
    atStart,
    currentTurnCount,
    ports,
    portsById,
    placementsByComponentId
  }) {
    if (points.length < 4) return;
    const terminalIndex = atStart ? 0 : points.length - 1;
    const leadIndex = atStart ? 1 : points.length - 2;
    const acrossIndex = atStart ? 2 : points.length - 3;
    const retainedIndex = atStart ? 3 : points.length - 4;
    const terminalPoint = points[terminalIndex];
    const leadPoint = points[leadIndex];
    const acrossPoint = points[acrossIndex];
    const retainedPoint = points[retainedIndex];
    const terminalEdge = atStart ? trace.edges[0] : trace.edges.at(-1);
    if (!terminalEdge) return;
    const portId = atStart ? terminalEdge.from_schematic_port_id : terminalEdge.to_schematic_port_id;
    const port = portId ? portsById.get(portId) : this.findPortAtPoint(ports, terminalPoint, trace.schematic_sheet_id);
    if (!port?.schematic_component_id || !port.facing_direction) return;
    const leadAxis = this.getAxis(terminalPoint, leadPoint);
    const shiftAxis = this.getAxis(leadPoint, acrossPoint);
    const retainedAxis = this.getAxis(acrossPoint, retainedPoint);
    const portAxis = port.facing_direction === "left" || port.facing_direction === "right" ? "horizontal" : "vertical";
    if (!leadAxis || !shiftAxis || !retainedAxis) return;
    if (leadAxis !== portAxis || shiftAxis === portAxis || retainedAxis !== portAxis) {
      return;
    }
    if (!this.isPointInFacingDirection(
      terminalPoint,
      leadPoint,
      port.facing_direction
    ) || !this.isPointInFacingDirection(
      acrossPoint,
      retainedPoint,
      port.facing_direction
    )) {
      return;
    }
    const target = placementsByComponentId.get(port.schematic_component_id);
    if (!target) return;
    const deltaSchX = acrossPoint.x - leadPoint.x;
    const deltaSchY = acrossPoint.y - leadPoint.y;
    if (Math.abs(deltaSchX) <= _TraceSimplificationSolver.EPSILON && Math.abs(deltaSchY) <= _TraceSimplificationSolver.EPSILON) {
      return;
    }
    const movedTerminalPoint = {
      x: terminalPoint.x + deltaSchX,
      y: terminalPoint.y + deltaSchY
    };
    const suggestedPoints = atStart ? [movedTerminalPoint, ...points.slice(2)] : [...points.slice(0, -2), movedTerminalPoint];
    const suggestedTurnCount = this.countTurns(suggestedPoints);
    if (suggestedTurnCount === void 0 || suggestedTurnCount !== 1 || suggestedTurnCount >= currentTurnCount) {
      return;
    }
    return {
      target,
      deltaSchX,
      deltaSchY,
      currentTurnCount,
      suggestedTurnCount
    };
  }
  /** calculate-elbow proposes geometry, not obstacle avoidance. Only report a
   * move when every attached route can be preserved or improved and the exact
   * proposed geometry is clear. Unsupported junctions are deliberately skipped. */
  validateMove(targetTrace, candidate, ports) {
    const componentId = candidate.target.schematicComponentId;
    const sheetId = candidate.target.schematicSheetId;
    const sheetPorts = ports.filter((p) => p.schematic_sheet_id === sheetId);
    const movingPorts = sheetPorts.filter(
      (p) => p.schematic_component_id === componentId
    );
    const traces = this.ctx.circuitJson.filter(
      (e) => e.type === "schematic_trace" && e.schematic_sheet_id === sheetId
    );
    const touchesPort = (trace, port) => trace.edges.some(
      (edge) => edge.from_schematic_port_id === port.schematic_port_id || edge.to_schematic_port_id === port.schematic_port_id || this.pointsEqual(edge.from, port.center) || this.pointsEqual(edge.to, port.center)
    );
    const affected = traces.filter(
      (trace) => movingPorts.some((port) => touchesPort(trace, port))
    );
    if (!affected.includes(targetTrace)) return false;
    if (this.ctx.circuitJson.some(
      (e) => e.type === "schematic_net_label" && e.schematic_sheet_id === sheetId && movingPorts.some(
        (p) => this.pointsEqual(e.anchor_position ?? e.center, p.center)
      )
    ))
      return false;
    const shift = (point2) => ({
      x: point2.x + candidate.deltaSchX,
      y: point2.y + candidate.deltaSchY
    });
    const directions2 = {
      left: "x-",
      right: "x+",
      up: "y+",
      down: "y-"
    };
    const endpoint = (port, moved) => ({
      ...moved && port.schematic_component_id === componentId ? shift(port.center) : port.center,
      facingDirection: directions2[port.facing_direction]
    });
    const length = (points) => points.slice(1).reduce(
      (sum, p, i) => sum + Math.abs(p.x - points[i].x) + Math.abs(p.y - points[i].y),
      0
    );
    const segments = (points) => points.slice(1).map((to, i) => ({ from: points[i], to }));
    const movedBounds = centeredRect(
      candidate.target.schX + candidate.deltaSchX,
      candidate.target.schY + candidate.deltaSchY,
      candidate.target.width,
      candidate.target.height
    );
    const unaffected = traces.filter((trace) => !affected.includes(trace));
    if (unaffected.some(
      (trace) => trace.edges.some(
        (edge) => segmentCrossesPolygon(edge.from, edge.to, rectPolygon(movedBounds))
      )
    ))
      return false;
    const textPolygons = this.ctx.circuitJson.flatMap((e) => {
      if (e.type === "schematic_net_label" && e.schematic_sheet_id === sheetId)
        return [rectPolygon(getNetLabelBounds(e))];
      if (e.type !== "schematic_text" || e.schematic_sheet_id !== sheetId)
        return [];
      return getSchematicTextPolygons(
        e.schematic_component_id === componentId ? { ...e, position: shift(e.position) } : e
      );
    });
    if (textPolygons.some(
      (polygon) => polygonsOverlap(polygon, rectPolygon(movedBounds))
    ))
      return false;
    const proposed = [];
    for (const trace of affected) {
      const oldPoints = this.getTracePoints(trace);
      if (oldPoints.length < 2 || trace.junctions?.length) return false;
      const resolve = (point2, id) => {
        const matches = sheetPorts.filter(
          (p) => id ? p.schematic_port_id === id : this.pointsEqual(p.center, point2)
        );
        return matches.length === 1 && this.pointsEqual(matches[0].center, point2) ? matches[0] : void 0;
      };
      const start = resolve(
        oldPoints[0],
        trace.edges[0].from_schematic_port_id
      );
      const end = resolve(
        oldPoints.at(-1),
        trace.edges.at(-1).to_schematic_port_id
      );
      if (!start?.facing_direction || !end?.facing_direction) return false;
      if (movingPorts.some(
        (p) => touchesPort(trace, p) && p !== start && p !== end
      ))
        return false;
      const isInteriorConnection = (point2) => !this.pointsEqual(point2, start.center) && !this.pointsEqual(point2, end.center) && segments(oldPoints).some(
        ({ from, to }) => Math.abs(
          Math.hypot(point2.x - from.x, point2.y - from.y) + Math.hypot(point2.x - to.x, point2.y - to.y) - Math.hypot(to.x - from.x, to.y - from.y)
        ) < 1e-6
      );
      if (traces.some(
        (other) => other !== trace && other.edges.some(
          (edge) => isInteriorConnection(edge.from) || isInteriorConnection(edge.to)
        )
      ))
        return false;
      if (this.ctx.circuitJson.some(
        (e) => e.type === "schematic_net_label" && e.schematic_sheet_id === sheetId && isInteriorConnection(e.anchor_position ?? e.center)
      ))
        return false;
      const points = calculateElbow(
        endpoint(start, true),
        endpoint(end, true)
      ).filter(
        (point2, i, all) => i === 0 || !this.pointsEqual(point2, all[i - 1])
      );
      const turns = this.countTurns(points);
      const oldTurns = this.countTurns(oldPoints);
      if (points.length < 2 || turns === void 0 || oldTurns === void 0 || turns > oldTurns || length(points) > length(oldPoints) + 1e-6)
        return false;
      if (!this.isPointInFacingDirection(
        points[0],
        points[1],
        start.facing_direction
      ) || !this.isPointInFacingDirection(
        points.at(-1),
        points.at(-2),
        end.facing_direction
      ))
        return false;
      if (trace === targetTrace) {
        const baselineTurns = this.countTurns(
          calculateElbow(endpoint(start, false), endpoint(end, false))
        );
        if (turns >= oldTurns || baselineTurns === void 0 || turns >= baselineTurns)
          return false;
        candidate.suggestedTurnCount = turns;
      }
      for (const segment of segments(points)) {
        if (textPolygons.some(
          (polygon2) => segmentCrossesPolygon(segment.from, segment.to, polygon2)
        ))
          return false;
        if (this.ctx.componentPlacements.some((p) => {
          if (p.schematicSheetId !== sheetId) return false;
          const bounds = p.schematicComponentId === componentId ? movedBounds : centeredRect(p.schX, p.schY, p.width, p.height);
          return segmentCrossesPolygon(
            segment.from,
            segment.to,
            rectPolygon(bounds)
          );
        }))
          return false;
        const polygon = traceSegmentPolygon(segment.from, segment.to);
        if (!polygon) continue;
        const otherSegments = [
          ...unaffected.flatMap((t) => t.edges),
          ...proposed.flatMap((t) => segments(t.points))
        ];
        if (otherSegments.some((edge) => {
          if ([start, end].some(
            (port) => port.schematic_component_id !== componentId && [segment.from, segment.to].some(
              (p) => this.pointsEqual(p, port.center)
            ) && [edge.from, edge.to].some(
              (p) => this.pointsEqual(p, port.center)
            )
          ) && this.getAxis(segment.from, segment.to) !== this.getAxis(edge.from, edge.to))
            return false;
          const other = traceSegmentPolygon(edge.from, edge.to);
          return other && polygonsOverlap(polygon, other);
        }))
          return false;
      }
      proposed.push({ schematicTraceId: trace.schematic_trace_id, points });
    }
    candidate.suggestedTraces = proposed;
    return true;
  }
  getTracePoints(trace) {
    const firstEdge = trace.edges[0];
    if (!firstEdge) return [];
    const points = [firstEdge.from];
    for (const edge of trace.edges) {
      const previousPoint = points.at(-1);
      if (!this.pointsEqual(previousPoint, edge.from)) return [];
      points.push(edge.to);
    }
    return points;
  }
  countTurns(points) {
    const axes = [];
    for (const [index, point2] of points.slice(1).entries()) {
      const previousPoint = points[index];
      if (this.pointsEqual(previousPoint, point2)) continue;
      const axis = this.getAxis(previousPoint, point2);
      if (!axis) return;
      axes.push(axis);
    }
    return axes.slice(1).filter((axis, index) => axis !== axes[index]).length;
  }
  pointsEqual(a, b) {
    const { EPSILON: EPSILON5 } = _TraceSimplificationSolver;
    return Math.abs(a.x - b.x) <= EPSILON5 && Math.abs(a.y - b.y) <= EPSILON5;
  }
  getAxis(a, b) {
    const dx = Math.abs(b.x - a.x);
    const dy = Math.abs(b.y - a.y);
    const { EPSILON: EPSILON5 } = _TraceSimplificationSolver;
    if (dx <= EPSILON5 && dy > EPSILON5) return "vertical";
    if (dy <= EPSILON5 && dx > EPSILON5) return "horizontal";
    return void 0;
  }
  isPointInFacingDirection(origin, point2, facingDirection) {
    const { EPSILON: EPSILON5 } = _TraceSimplificationSolver;
    switch (facingDirection) {
      case "left":
        return point2.x < origin.x - EPSILON5;
      case "right":
        return point2.x > origin.x + EPSILON5;
      case "up":
        return point2.y > origin.y + EPSILON5;
      case "down":
        return point2.y < origin.y - EPSILON5;
    }
  }
  findPortAtPoint(ports, point2, schematicSheetId) {
    const { EPSILON: EPSILON5 } = _TraceSimplificationSolver;
    return ports.find(
      (port) => port.schematic_sheet_id === schematicSheetId && Math.abs(port.center.x - point2.x) <= EPSILON5 && Math.abs(port.center.y - point2.y) <= EPSILON5
    );
  }
  wouldOverlapAnotherComponent(candidate) {
    const movedBounds = centeredRect(
      candidate.target.schX + candidate.deltaSchX,
      candidate.target.schY + candidate.deltaSchY,
      candidate.target.width,
      candidate.target.height
    );
    return this.ctx.componentPlacements.some((placement) => {
      if (placement === candidate.target) return false;
      if (placement.schematicSheetId !== candidate.target.schematicSheetId) {
        return false;
      }
      return Boolean(
        rectOverlap(
          movedBounds,
          centeredRect(
            placement.schX,
            placement.schY,
            placement.width,
            placement.height
          )
        )
      );
    });
  }
  makeIssue(trace, candidate) {
    const targetName = candidate.target.sourceComponentName || "component";
    const direction = this.getMoveDirection(
      candidate.deltaSchX,
      candidate.deltaSchY
    );
    const distance6 = Math.abs(candidate.deltaSchX || candidate.deltaSchY);
    const newSchX = candidate.target.schX + candidate.deltaSchX;
    const newSchY = candidate.target.schY + candidate.deltaSchY;
    return {
      lineItemType: "TraceCanBeSimplifiedByMovingComponent",
      schematicTraceId: trace.schematic_trace_id,
      traceName: getTraceName(this.ctx.circuitJson, trace),
      targetComponent: candidate.target,
      deltaSchX: candidate.deltaSchX,
      deltaSchY: candidate.deltaSchY,
      newSchX,
      newSchY,
      currentTurnCount: candidate.currentTurnCount,
      suggestedTurnCount: candidate.suggestedTurnCount,
      suggestedTraces: candidate.suggestedTraces,
      message: `move ${targetName} ${direction} by ${fmtNumber(distance6)} (to schX=${fmtNumber(newSchX)}, schY=${fmtNumber(newSchY)}) to reduce this trace from ${candidate.currentTurnCount} turns to ${candidate.suggestedTurnCount}`
    };
  }
  getMoveDirection(deltaSchX, deltaSchY) {
    if (Math.abs(deltaSchX) > _TraceSimplificationSolver.EPSILON) {
      return deltaSchX > 0 ? "right" : "left";
    }
    return deltaSchY > 0 ? "up" : "down";
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(attrs, "traceName", issue.traceName);
    addAttr(
      attrs,
      "targetComponentName",
      issue.targetComponent.sourceComponentName
    );
    addAttr(attrs, "deltaSchX", issue.deltaSchX, { formatDelta: true });
    addAttr(attrs, "deltaSchY", issue.deltaSchY, { formatDelta: true });
    addAttr(attrs, "newSchX", issue.newSchX);
    addAttr(attrs, "newSchY", issue.newSchY);
    addAttr(attrs, "currentTurnCount", issue.currentTurnCount);
    addAttr(attrs, "suggestedTurnCount", issue.suggestedTurnCount);
    addAttr(attrs, "message", issue.message);
    return `<TraceCanBeSimplifiedByMovingComponent ${attrs.join(" ")} />`;
  }
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/TwoPinComponentOrientationSolver/TwoPinComponentOrientationSolver.ts
import { BaseSolver as BaseSolver32 } from "@tscircuit/solver-utils";

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/TwoPinComponentOrientationSolver/getPowerOrGroundConnectionIds.ts
import {
  findConnectedNetworks as findConnectedNetworks2,
  getSourcePortConnectivityMapFromCircuitJson as getSourcePortConnectivityMapFromCircuitJson3
} from "circuit-json-to-connectivity-map";
function getPowerOrGroundConnectionIds(circuitJson) {
  const powerOrGroundIds = /* @__PURE__ */ new Set();
  const idsByConnectivityKey = /* @__PURE__ */ new Map();
  for (const element of circuitJson) {
    if (element.type !== "source_net" && element.type !== "source_port")
      continue;
    const id = element.type === "source_net" ? element.source_net_id : element.source_port_id;
    const isPowerOrGround = element.type === "source_net" ? element.is_power || element.is_ground || element.is_positive_voltage_source : element.provides_power || element.requires_power || element.provides_ground || element.requires_ground;
    if (isPowerOrGround) powerOrGroundIds.add(id);
    const key = element.subcircuit_connectivity_map_key;
    if (key !== void 0) {
      const ids = idsByConnectivityKey.get(key) ?? [];
      ids.push(id);
      idsByConnectivityKey.set(key, ids);
    }
  }
  const sourceConnectivity = getSourcePortConnectivityMapFromCircuitJson3(circuitJson);
  const networks = findConnectedNetworks2([
    ...Object.values(sourceConnectivity.netMap),
    ...idsByConnectivityKey.values()
  ]);
  for (const ids of Object.values(networks)) {
    if (ids.some((id) => powerOrGroundIds.has(id))) {
      for (const id of ids) powerOrGroundIds.add(id);
    }
  }
  return powerOrGroundIds;
}

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/TwoPinComponentOrientationSolver/TwoPinComponentOrientationSolver.ts
var TwoPinComponentOrientationSolver = class _TwoPinComponentOrientationSolver extends BaseSolver32 {
  static EPSILON = 0.01;
  ctx;
  out;
  powerOrGroundConnectionIds;
  constructor({
    ctx,
    issues
  }) {
    super();
    this.ctx = ctx;
    this.out = issues;
    this.powerOrGroundConnectionIds = getPowerOrGroundConnectionIds(
      ctx.circuitJson
    );
  }
  _step() {
    const ports = this.ctx.circuitJson.filter(
      (element) => element.type === "schematic_port"
    );
    const portsById = new Map(
      ports.map((port) => [port.schematic_port_id, port])
    );
    const portsByComponentId = /* @__PURE__ */ new Map();
    for (const port of ports) {
      if (!port.schematic_component_id) continue;
      const componentPorts = portsByComponentId.get(port.schematic_component_id) ?? [];
      componentPorts.push(port);
      portsByComponentId.set(port.schematic_component_id, componentPorts);
    }
    const placementsByComponentId = new Map(
      this.ctx.componentPlacements.flatMap(
        (placement) => placement.schematicComponentId ? [[placement.schematicComponentId, placement]] : []
      )
    );
    const bestCandidateByComponentId = /* @__PURE__ */ new Map();
    for (const trace of this.ctx.circuitJson.filter(
      (element) => element.type === "schematic_trace"
    )) {
      const points = this.getTracePoints(trace);
      const currentTurnCount = this.countTurns(points);
      if (currentTurnCount === void 0 || currentTurnCount < 2) continue;
      const endpoints = this.getTraceEndpoints(trace, points, ports, portsById);
      if (!endpoints) continue;
      for (const [targetEndpoint, connectedEndpoint] of [
        endpoints,
        [endpoints[1], endpoints[0]]
      ]) {
        const candidate = this.getFlipCandidate({
          trace,
          targetEndpoint,
          connectedEndpoint,
          currentTurnCount,
          portsByComponentId,
          placementsByComponentId
        });
        if (!candidate) continue;
        const componentId = candidate.targetPort.schematic_component_id;
        const existing = bestCandidateByComponentId.get(componentId);
        if (!existing || this.isBetterCandidate(candidate, existing)) {
          bestCandidateByComponentId.set(componentId, candidate);
        }
      }
    }
    for (const candidate of bestCandidateByComponentId.values()) {
      this.out.push(this.makeIssue(candidate));
    }
    this.solved = true;
  }
  getFlipCandidate({
    trace,
    targetEndpoint,
    connectedEndpoint,
    currentTurnCount,
    portsByComponentId,
    placementsByComponentId
  }) {
    const targetPort = targetEndpoint.port;
    const connectedPort = connectedEndpoint.port;
    const targetComponentId = targetPort.schematic_component_id;
    const connectedComponentId = connectedPort.schematic_component_id;
    if (!targetComponentId || !connectedComponentId || targetComponentId === connectedComponentId || targetPort.schematic_sheet_id !== connectedPort.schematic_sheet_id) {
      return;
    }
    const componentPorts = portsByComponentId.get(targetComponentId);
    if (componentPorts?.length !== 2) return;
    if (componentPorts.some(
      (port) => port.source_port_id && this.powerOrGroundConnectionIds.has(port.source_port_id)
    )) {
      return;
    }
    const connectedComponentPorts = portsByComponentId.get(connectedComponentId) ?? [];
    if (connectedComponentPorts.length <= 2) return;
    const otherPort = componentPorts.find(
      (port) => port.schematic_port_id !== targetPort.schematic_port_id
    );
    if (!otherPort || !this.areOppositePorts(targetPort, otherPort)) return;
    const currentFacingDirection = targetPort.facing_direction;
    const suggestedFacingDirection = otherPort.facing_direction;
    if (!currentFacingDirection || !suggestedFacingDirection) return;
    if (!this.traceLeavesPortInFacingDirection(targetEndpoint)) return;
    const connectedPoint = connectedPort.center;
    if (this.isPointInFacingDirection(
      targetPort.center,
      connectedPoint,
      currentFacingDirection
    ) || !this.isPointInFacingDirection(
      otherPort.center,
      connectedPoint,
      suggestedFacingDirection
    ) || !connectedPort.facing_direction || !this.isPointInFacingDirection(
      connectedPoint,
      otherPort.center,
      connectedPort.facing_direction
    )) {
      return;
    }
    const suggestedTurnCount = this.getMinimumTurnCount(
      otherPort.center,
      connectedPoint,
      suggestedFacingDirection
    );
    if (suggestedTurnCount >= currentTurnCount) return;
    const targetPlacement = placementsByComponentId.get(targetComponentId);
    const connectedPlacement = placementsByComponentId.get(connectedComponentId);
    if (!targetPlacement || !connectedPlacement) return;
    return {
      trace,
      targetPort,
      targetPlacement,
      connectedPlacement,
      suggestedFacingDirection,
      currentTurnCount,
      suggestedTurnCount,
      traceLength: this.getTraceLength(targetEndpoint.pointsFromEndpoint)
    };
  }
  getTraceEndpoints(trace, points, ports, portsById) {
    const firstEdge = trace.edges[0];
    const lastEdge = trace.edges.at(-1);
    if (!firstEdge || !lastEdge || points.length < 2) return;
    const startPort = firstEdge.from_schematic_port_id ? portsById.get(firstEdge.from_schematic_port_id) : this.findPortAtPoint(ports, points[0], trace.schematic_sheet_id);
    const endPort = lastEdge.to_schematic_port_id ? portsById.get(lastEdge.to_schematic_port_id) : this.findPortAtPoint(ports, points.at(-1), trace.schematic_sheet_id);
    if (!startPort || !endPort) return;
    return [
      { port: startPort, pointsFromEndpoint: points },
      { port: endPort, pointsFromEndpoint: [...points].reverse() }
    ];
  }
  getTracePoints(trace) {
    const firstEdge = trace.edges[0];
    if (!firstEdge) return [];
    const points = [firstEdge.from];
    for (const edge of trace.edges) {
      if (!this.pointsEqual(points.at(-1), edge.from)) return [];
      points.push(edge.to);
    }
    return points;
  }
  countTurns(points) {
    const axes = [];
    for (const [index, point2] of points.slice(1).entries()) {
      const previousPoint = points[index];
      if (this.pointsEqual(previousPoint, point2)) continue;
      const axis = this.getAxis(previousPoint, point2);
      if (!axis) return;
      if (axes.at(-1) !== axis) axes.push(axis);
    }
    return Math.max(0, axes.length - 1);
  }
  traceLeavesPortInFacingDirection(endpoint) {
    const nextPoint = endpoint.pointsFromEndpoint.find(
      (point2) => !this.pointsEqual(point2, endpoint.port.center)
    );
    return Boolean(
      nextPoint && endpoint.port.facing_direction && this.isPointInFacingDirection(
        endpoint.port.center,
        nextPoint,
        endpoint.port.facing_direction
      )
    );
  }
  areOppositePorts(a, b) {
    const horizontal = (a.facing_direction === "left" && b.facing_direction === "right" || a.facing_direction === "right" && b.facing_direction === "left") && Math.abs(a.center.y - b.center.y) <= _TwoPinComponentOrientationSolver.EPSILON;
    const vertical = (a.facing_direction === "up" && b.facing_direction === "down" || a.facing_direction === "down" && b.facing_direction === "up") && Math.abs(a.center.x - b.center.x) <= _TwoPinComponentOrientationSolver.EPSILON;
    return horizontal || vertical;
  }
  getMinimumTurnCount(from, to, facingDirection) {
    const alignedWithFacingAxis = facingDirection === "left" || facingDirection === "right" ? Math.abs(from.y - to.y) <= _TwoPinComponentOrientationSolver.EPSILON : Math.abs(from.x - to.x) <= _TwoPinComponentOrientationSolver.EPSILON;
    return alignedWithFacingAxis ? 0 : 1;
  }
  isPointInFacingDirection(origin, point2, facingDirection) {
    const { EPSILON: EPSILON5 } = _TwoPinComponentOrientationSolver;
    switch (facingDirection) {
      case "left":
        return point2.x < origin.x - EPSILON5;
      case "right":
        return point2.x > origin.x + EPSILON5;
      case "up":
        return point2.y > origin.y + EPSILON5;
      case "down":
        return point2.y < origin.y - EPSILON5;
    }
  }
  getAxis(a, b) {
    const dx = Math.abs(a.x - b.x);
    const dy = Math.abs(a.y - b.y);
    const { EPSILON: EPSILON5 } = _TwoPinComponentOrientationSolver;
    if (dx <= EPSILON5 && dy > EPSILON5) return "vertical";
    if (dy <= EPSILON5 && dx > EPSILON5) return "horizontal";
    return void 0;
  }
  pointsEqual(a, b) {
    const { EPSILON: EPSILON5 } = _TwoPinComponentOrientationSolver;
    return Math.abs(a.x - b.x) <= EPSILON5 && Math.abs(a.y - b.y) <= EPSILON5;
  }
  findPortAtPoint(ports, point2, schematicSheetId) {
    return ports.find(
      (port) => port.schematic_sheet_id === schematicSheetId && this.pointsEqual(port.center, point2)
    );
  }
  getTraceLength(points) {
    return points.slice(1).reduce((length, point2, index) => {
      const previousPoint = points[index];
      return length + Math.abs(point2.x - previousPoint.x) + Math.abs(point2.y - previousPoint.y);
    }, 0);
  }
  isBetterCandidate(candidate, existing) {
    const improvement = candidate.currentTurnCount - candidate.suggestedTurnCount;
    const existingImprovement = existing.currentTurnCount - existing.suggestedTurnCount;
    return improvement > existingImprovement || improvement === existingImprovement && candidate.traceLength > existing.traceLength;
  }
  makeIssue(candidate) {
    const targetName = candidate.targetPlacement.sourceComponentName || "component";
    const connectedName = candidate.connectedPlacement.sourceComponentName || "component";
    const targetPin = candidate.targetPort.pin_number ? `pin${candidate.targetPort.pin_number}` : candidate.targetPort.display_pin_label;
    return {
      lineItemType: "TwoPinComponentCouldBeFlipped",
      schematicTraceId: candidate.trace.schematic_trace_id,
      traceName: getTraceName(this.ctx.circuitJson, candidate.trace),
      targetComponent: candidate.targetPlacement,
      connectedComponent: candidate.connectedPlacement,
      targetPin,
      currentFacingDirection: candidate.targetPort.facing_direction,
      suggestedFacingDirection: candidate.suggestedFacingDirection,
      deltaSchRotation: 180,
      currentTurnCount: candidate.currentTurnCount,
      suggestedTurnCount: candidate.suggestedTurnCount,
      message: `rotate ${targetName} by 180\xB0 so ${targetPin ?? "its connected pin"} faces ${connectedName} and reduce this trace from ${candidate.currentTurnCount} turns to ${candidate.suggestedTurnCount}`
    };
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(attrs, "traceName", issue.traceName);
    addAttr(
      attrs,
      "targetComponentName",
      issue.targetComponent.sourceComponentName
    );
    addAttr(
      attrs,
      "connectedComponentName",
      issue.connectedComponent.sourceComponentName
    );
    addAttr(attrs, "targetPin", issue.targetPin);
    addAttr(attrs, "currentFacingDirection", issue.currentFacingDirection);
    addAttr(attrs, "suggestedFacingDirection", issue.suggestedFacingDirection);
    addAttr(attrs, "deltaSchRotation", issue.deltaSchRotation);
    addAttr(attrs, "currentTurnCount", issue.currentTurnCount);
    addAttr(attrs, "suggestedTurnCount", issue.suggestedTurnCount);
    addAttr(attrs, "message", issue.message);
    return `<TwoPinComponentCouldBeFlipped ${attrs.join(" ")} />`;
  }
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/VerboseNetLabelSolver/VerboseNetLabelSolver.ts
import { BaseSolver as BaseSolver33 } from "@tscircuit/solver-utils";
var VerboseNetLabelSolver = class extends BaseSolver33 {
  constructor(params) {
    super();
    this.params = params;
    const { circuitJson } = params.ctx;
    this.netLabels = circuitJson.filter((el) => this.isSchematicNetLabel(el));
    this.tokenToInvolvedPin = this.buildTokenToInvolvedPinMap(circuitJson);
    this.schematicSheetNameById = getSchematicSheetNamesById(circuitJson);
    this.solved = this.netLabels.length === 0;
  }
  params;
  VERBOSE_NET_LABEL_MESSAGE = "Create trace with schDisplayLabel";
  netLabels;
  tokenToInvolvedPin;
  schematicSheetNameById;
  currentIndex = 0;
  seen = /* @__PURE__ */ new Set();
  _step() {
    const label = this.netLabels[this.currentIndex++];
    if (!label) {
      this.solved = true;
      return;
    }
    this.solved = this.currentIndex >= this.netLabels.length;
    const seenKey = `${label.schematic_sheet_id ?? ""}:${label.text}`;
    if (!label.text.includes("/") || this.seen.has(seenKey)) return;
    this.seen.add(seenKey);
    let schematicSheetName;
    if (label.schematic_sheet_id) {
      schematicSheetName = this.schematicSheetNameById.get(
        label.schematic_sheet_id
      );
    }
    const issue = {
      lineItemType: "VerboseSchematicNetLabel",
      schematicNetLabelId: label.schematic_net_label_id,
      sourceNetId: label.source_net_id,
      schematicSheetId: label.schematic_sheet_id,
      schematicSheetName,
      text: label.text,
      involvedPins: this.getInvolvedPins(label.text, this.tokenToInvolvedPin),
      schX: label.center.x,
      schY: label.center.y,
      message: this.VERBOSE_NET_LABEL_MESSAGE
    };
    this.params.issues.push(issue);
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(attrs, "message", issue.message);
    addAttr(attrs, "text", issue.text);
    addAttr(attrs, "involvedPins", issue.involvedPins.join(","));
    addAttr(attrs, "schSheetName", issue.schematicSheetName);
    addAttr(attrs, "schX", issue.schX);
    addAttr(attrs, "schY", issue.schY);
    return `<VerboseSchematicNetLabel ${attrs.join(" ")} />`;
  }
  isSchematicNetLabel(el) {
    return el.type === "schematic_net_label";
  }
  isSourcePort(el) {
    return el.type === "source_port";
  }
  getSourceComponentWithName(el) {
    if (el.type !== "source_component" || !("source_component_id" in el) || !("name" in el) || typeof el.source_component_id !== "string" || typeof el.name !== "string")
      return null;
    return { source_component_id: el.source_component_id, name: el.name };
  }
  getSourcePortNameCandidates(port) {
    return [
      port.most_frequently_referenced_by_name,
      port.name,
      ...port.port_hints ?? [],
      port.pin_number === void 0 ? void 0 : String(port.pin_number)
    ].filter((n) => Boolean(n));
  }
  getBestSourcePortName(port) {
    return port.most_frequently_referenced_by_name ?? port.name ?? (port.pin_number === void 0 ? "" : `pin${port.pin_number}`);
  }
  buildTokenToInvolvedPinMap(circuitJson) {
    const sourceComponentById = new Map(
      circuitJson.flatMap((el) => {
        const sc = this.getSourceComponentWithName(el);
        return sc ? [sc] : [];
      }).map((sc) => [sc.source_component_id, sc])
    );
    const map = /* @__PURE__ */ new Map();
    for (const port of circuitJson.filter((el) => this.isSourcePort(el))) {
      if (!port.source_component_id) continue;
      const sc = sourceComponentById.get(port.source_component_id);
      if (!sc?.name) continue;
      const involvedPin = `${sc.name}.${this.getBestSourcePortName(port)}`;
      for (const name of this.getSourcePortNameCandidates(port)) {
        map.set(`${sc.name}_${name}`, involvedPin);
      }
    }
    return map;
  }
  getInvolvedPins(text, tokenToInvolvedPin) {
    const pins = /* @__PURE__ */ new Set();
    for (const token of text.split("/")) {
      const pin = tokenToInvolvedPin.get(token);
      if (pin) pins.add(pin);
    }
    return Array.from(pins);
  }
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/SchematicTextClearanceSolver/SchematicTextClearanceSolver.ts
import { BaseSolver as BaseSolver34 } from "@tscircuit/solver-utils";
var SchematicTextClearanceSolver = class extends BaseSolver34 {
  constructor(params) {
    super();
    this.params = params;
    const { ctx } = params;
    this.sheetNames = getSchematicSheetNamesById(ctx.circuitJson);
    const customSymbolIds = new Set(
      ctx.circuitJson.flatMap(
        (element) => element.type === "schematic_component" && element.is_box_with_pins === false && !element.symbol_name ? [element.schematic_component_id] : []
      )
    );
    const seenText = /* @__PURE__ */ new Set();
    this.texts = ctx.circuitJson.flatMap((element) => {
      if (element.type !== "schematic_text") return [];
      if (element.schematic_component_id || element.schematic_symbol_id)
        return [];
      const polygons = getSchematicTextPolygons(element);
      if (!polygons.length) return [];
      const sheetId = element.schematic_sheet_id;
      const fingerprint = JSON.stringify([
        sheetId,
        element.text,
        element.position.x,
        element.position.y,
        element.font_size,
        element.anchor,
        element.rotation,
        element.color
      ]);
      if (seenText.has(fingerprint)) return [];
      seenText.add(fingerprint);
      return [
        {
          text: element,
          isTraceLabel: Boolean(
            "source_trace_id" in element && element.source_trace_id
          ),
          polygons,
          sheetId,
          object: {
            type: "text",
            id: element.schematic_text_id,
            text: element.text
          }
        }
      ];
    });
    this.obstacles = [
      ...ctx.componentPlacements.flatMap(
        (p) => (
          // Custom path/circle symbols can have empty corners in their bounds.
          // Their ink geometry must be known before treating that area as a body.
          p.schematicComponentId && !customSymbolIds.has(p.schematicComponentId) ? [
            {
              object: {
                type: "component",
                id: p.schematicComponentId,
                componentName: p.sourceComponentName,
                schematicComponentId: p.schematicComponentId
              },
              polygons: [
                rectPolygon(centeredRect(p.schX, p.schY, p.width, p.height))
              ],
              sheetId: p.schematicSheetId
            }
          ] : []
        )
      ),
      ...ctx.circuitJson.flatMap(
        (element) => element.type === "schematic_trace" ? [
          {
            object: {
              type: "trace",
              id: element.schematic_trace_id
            },
            sheetId: element.schematic_sheet_id,
            segments: element.edges,
            polygons: element.edges.flatMap((edge) => {
              const polygon = traceSegmentPolygon(edge.from, edge.to);
              return polygon ? [polygon] : [];
            })
          }
        ] : []
      )
    ];
    this.solved = this.texts.length === 0;
  }
  params;
  texts;
  obstacles;
  sheetNames;
  index = 0;
  _step() {
    const text = this.texts[this.index];
    const targets = [...this.obstacles, ...this.texts.slice(this.index + 1)];
    const collisions = targets.filter((target) => this.collides(text, target));
    if (collisions.length) {
      const suggestedMove = text.isTraceLabel ? void 0 : this.findClearPosition(text);
      for (const target of collisions) {
        const targetName = target.object.componentName ?? target.object.text;
        this.params.issues.push({
          lineItemType: "SchematicTextCollision",
          schematicSheetId: text.sheetId,
          schematicSheetName: text.sheetId ? this.sheetNames.get(text.sheetId) : void 0,
          schematicTextId: text.text.schematic_text_id,
          text: text.text.text,
          collidingObject: target.object,
          textBounds: polygonBounds(text.polygons),
          collidingObjectBounds: polygonBounds(target.polygons),
          suggestedMove,
          message: `Text "${text.text.text}" overlaps ${target.object.type}${targetName ? ` ${targetName}` : ""}; ${text.isTraceLabel ? "adjust the owning trace's label placement or remove stale duplicates to leave the visible text area clear." : "reposition the text to leave its visible area clear."}`
        });
      }
    }
    this.index++;
    this.solved = this.index >= this.texts.length;
  }
  collides(text, obstacle) {
    if (text.sheetId !== obstacle.sheetId) return false;
    return text.polygons.some(
      (a) => obstacle.segments ? obstacle.segments.some(
        (edge) => segmentCrossesPolygon(edge.from, edge.to, a)
      ) : obstacle.polygons.some((b) => polygonsOverlap(a, b))
    );
  }
  findClearPosition(text) {
    const obstacles = [
      ...this.obstacles,
      ...this.texts.filter((t) => t !== text)
    ];
    const step = Math.max(0.1, text.text.font_size / 2);
    for (let distance6 = step; distance6 <= Math.max(4, text.text.font_size * 8); distance6 += step) {
      for (const [dx, dy] of [
        [0, distance6],
        [0, -distance6],
        [-distance6, 0],
        [distance6, 0]
      ]) {
        const newSchX = Math.round((text.text.position.x + dx) * 1e3) / 1e3;
        const newSchY = Math.round((text.text.position.y + dy) * 1e3) / 1e3;
        const moved = {
          ...text,
          polygons: getSchematicTextPolygons({
            ...text.text,
            position: { x: newSchX, y: newSchY }
          })
        };
        if (obstacles.every((obstacle) => !this.collides(moved, obstacle)))
          return { newSchX, newSchY };
      }
    }
    return void 0;
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(attrs, "text", issue.text);
    addAttr(attrs, "collidingObjectType", issue.collidingObject.type);
    addAttr(attrs, "collidingText", issue.collidingObject.text);
    addAttr(attrs, "newSchX", issue.suggestedMove?.newSchX);
    addAttr(attrs, "newSchY", issue.suggestedMove?.newSchY);
    addAttr(attrs, "message", issue.message);
    return `<SchematicTextCollision ${attrs.join(" ")} />`;
  }
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/ResetNetworkGroupingSolver/ResetNetworkGroupingSolver.ts
import { BaseSolver as BaseSolver35 } from "@tscircuit/solver-utils";
var ResetNetworkGroupingSolver = class _ResetNetworkGroupingSolver extends BaseSolver35 {
  constructor(params) {
    super();
    this.params = params;
    this.networks = this.findNetworks(params.ctx);
    this.solved = this.networks.length === 0;
  }
  params;
  // Readability heuristic in schematic units, not an electrical/PCB constraint.
  // Measure from the reset pin, so a large host symbol does not cause a warning.
  static MIN_DISTANCE = 6;
  networks;
  index = 0;
  _step() {
    const network = this.networks[this.index];
    const rcMembers = network.members.slice(0, 2);
    const threshold = Math.max(
      _ResetNetworkGroupingSolver.MIN_DISTANCE,
      ...rcMembers.map((p) => 3 * Math.max(p.width, p.height))
    );
    const distances = rcMembers.map(
      (p) => Math.hypot(
        Math.max(0, Math.abs(p.schX - network.pinPosition.x) - p.width / 2),
        Math.max(0, Math.abs(p.schY - network.pinPosition.y) - p.height / 2)
      )
    );
    if (distances.some((distance6) => distance6 > threshold)) {
      const hostName = network.host.sourceComponentName || "component";
      const resetPin = resetPinName(network.pin);
      const memberNames = rcMembers.map((p) => p.sourceComponentName || "component").join(", ");
      this.params.issues.push({
        lineItemType: "ResetNetworkNotGrouped",
        hostSchematicBox: network.host,
        resetSourcePortId: network.pin.source_port_id,
        resetPinName: resetPin,
        supportNetworkComponents: network.members,
        maxDistanceFromResetPin: Math.round(Math.max(...distances) * 100) / 100,
        maxRecommendedDistance: threshold,
        message: `Group ${memberNames} near ${hostName}.${resetPin} so the reset pull-up and capacitor can be read together. Preserve all net connections; associated test points may remain in a debug area.`
      });
    }
    this.index++;
    this.solved = this.index >= this.networks.length;
  }
  findNetworks(ctx) {
    const root = getSourceConnectivity(ctx.circuitJson);
    const sources = ctx.circuitJson.filter((e) => e.type === "source_component");
    const sourceById = new Map(sources.map((e) => [e.source_component_id, e]));
    const ports = ctx.circuitJson.filter((e) => e.type === "source_port");
    const portsByComponent = /* @__PURE__ */ new Map();
    const portsByNet = /* @__PURE__ */ new Map();
    const power = /* @__PURE__ */ new Set();
    const ground = /* @__PURE__ */ new Set();
    for (const port of ports) {
      if (!port.source_component_id) continue;
      const componentPorts = portsByComponent.get(port.source_component_id) ?? [];
      componentPorts.push(port);
      portsByComponent.set(port.source_component_id, componentPorts);
      const net = root(port.source_port_id);
      const netPorts = portsByNet.get(net) ?? [];
      netPorts.push(port);
      portsByNet.set(net, netPorts);
      if (port.provides_power || port.requires_power) power.add(net);
      if (port.provides_ground || port.requires_ground) ground.add(net);
    }
    for (const element of ctx.circuitJson) {
      if (element.type !== "source_net") continue;
      if (element.is_power || element.is_positive_voltage_source)
        power.add(root(element.source_net_id));
      if (element.is_ground) ground.add(root(element.source_net_id));
    }
    const placementBySource = new Map(
      ctx.componentPlacements.flatMap(
        (p) => p.sourceComponentId ? [[p.sourceComponentId, p]] : []
      )
    );
    const schematicPorts = ctx.circuitJson.filter(
      (e) => e.type === "schematic_port"
    );
    const schematicComponents = new Map(
      ctx.circuitJson.filter((e) => e.type === "schematic_component").map((e) => [e.schematic_component_id, e])
    );
    const networks = [];
    const seen = /* @__PURE__ */ new Set();
    for (const pin of ports) {
      if (!pin.source_component_id || !resetPinName(pin) || pin.do_not_connect)
        continue;
      if (sourceById.get(pin.source_component_id)?.ftype !== "simple_chip")
        continue;
      const net = root(pin.source_port_id);
      if (seen.has(net) || power.has(net) || ground.has(net)) continue;
      seen.add(net);
      const peers = portsByNet.get(net) ?? [];
      const chips = new Set(
        peers.filter(
          (p) => p.source_component_id && sourceById.get(p.source_component_id)?.ftype === "simple_chip"
        ).map((p) => p.source_component_id)
      );
      if (chips.size !== 1) continue;
      const host = placementBySource.get(pin.source_component_id);
      const schematicPin = schematicPorts.find(
        (p) => p.source_port_id === pin.source_port_id && p.schematic_component_id === host?.schematicComponentId
      );
      if (!host || !schematicPin || schematicPin.schematic_sheet_id !== host.schematicSheetId)
        continue;
      const pullups = [];
      const capacitors = [];
      const testpoints = [];
      let unsupported = false;
      for (const id of new Set(peers.map((p) => p.source_component_id))) {
        if (!id || id === pin.source_component_id) continue;
        const type = sourceById.get(id)?.ftype;
        const componentPorts = portsByComponent.get(id) ?? [];
        const placement = placementBySource.get(id);
        if (type === "simple_connector" || type === "simple_pin_header")
          continue;
        if (!placement) {
          unsupported = true;
          break;
        }
        if (type === "simple_test_point" && componentPorts.length === 1) {
          testpoints.push(placement);
          continue;
        }
        if (componentPorts.length !== 2) {
          unsupported = true;
          break;
        }
        const other = componentPorts.find((p) => root(p.source_port_id) !== net);
        if (!other) {
          unsupported = true;
          break;
        }
        const otherNet = root(other.source_port_id);
        if (type === "simple_resistor" && power.has(otherNet) && !ground.has(otherNet))
          pullups.push(placement);
        else if (type === "simple_capacitor" && ground.has(otherNet) && !power.has(otherNet))
          capacitors.push(placement);
        else {
          unsupported = true;
          break;
        }
      }
      if (unsupported || pullups.length !== 1 || capacitors.length !== 1)
        continue;
      const members = [...pullups, ...capacitors, ...testpoints];
      const hostGroup = host.schematicComponentId ? schematicComponents.get(host.schematicComponentId)?.schematic_group_id : void 0;
      if (members.some((member) => {
        const group = member.schematicComponentId ? schematicComponents.get(member.schematicComponentId)?.schematic_group_id : void 0;
        return member.schematicSheetId !== host.schematicSheetId || member.subcircuitId !== host.subcircuitId || group !== hostGroup;
      }))
        continue;
      networks.push({ host, pin, pinPosition: schematicPin.center, members });
    }
    return networks;
  }
  static issueToString(issue) {
    const attrs = [];
    addAttr(
      attrs,
      "hostComponentName",
      issue.hostSchematicBox.sourceComponentName
    );
    addAttr(attrs, "resetPin", issue.resetPinName);
    addAttr(
      attrs,
      "supportNetworkComponents",
      issue.supportNetworkComponents.map((p) => p.sourceComponentName || "component").join(",")
    );
    addAttr(attrs, "maxDistanceFromResetPin", issue.maxDistanceFromResetPin);
    addAttr(attrs, "maxRecommendedDistance", issue.maxRecommendedDistance);
    addAttr(attrs, "message", issue.message);
    return `<ResetNetworkNotGrouped ${attrs.join(" ")} />`;
  }
};
var resetPinName = (port) => [port.name, ...port.port_hints ?? []].find(
  (name) => /^N?(RESET|RST)(N|B)?$/.test(name.toUpperCase().replace(/[_\-!~#/]/g, ""))
);

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/solvers/SchematicPlacementPipeline/SchematicPlacementPipeline.ts
var solversByIssueType = {
  SeriesLedChainNotOrdered: [SeriesLedChainPlacementSolver],
  RailPathTooSpreadOut: [RailPathVisibilitySolver],
  ResistorSeparatedFromChipPin: [ChipPinResistorPlacementSolver],
  CapacitorSeparatedFromChipPins: [ChipPinPairCapacitorPlacementSolver],
  DiodeCapacitorJunctionTooSpreadOut: [DiodeCapacitorStagePlacementSolver],
  PiFilterComponentsNotGrouped: [PiFilterPlacementSolver],
  MosfetGateNetworkNotGrouped: [MosfetGateNetworkPlacementSolver],
  FlybackDiodeSeparatedFromRelayCoil: [RelayFlybackDiodePlacementSolver],
  ComponentOverlap: [SchematicBoxOverlapSolver],
  // Retained in the issue union, but no solver currently emits this type.
  SchematicBoxHasALotOfSurroundingWhitespace: [],
  CapacitorSymbolHorizontal: [
    CapacitorOrientationSolver,
    TwoPinComponentRailOrientationSolver
  ],
  VerboseSchematicNetLabel: [VerboseNetLabelSolver],
  PinHeaderSchematicBoxTooWide: [SchematicBoxTooWideSolver],
  GenericSchematicBoxTooWide: [SchematicBoxTooWideSolver],
  SchematicBoxInnerLabelCollision: [SchematicBoxInnerLabelCollisionSolver],
  SchematicPinPaddingToEdgeTooLarge: [SchematicPinPaddingToEdgeSolver],
  DiodeResistorNotAligned: [DiodeResistorAlignmentSolver],
  ParallelRcNotAligned: [ParallelRcPlacementSolver],
  ParallelDiodeResistorNotAligned: [ParallelDiodeResistorPlacementSolver],
  ComponentPinsWouldAlignWithVerticalShift: [ComponentPinAlignmentSolver],
  TraceCanBeSimplifiedByMovingComponent: [TraceSimplificationSolver],
  CrystalNotCenteredOverLoadCapacitors: [CrystalLoadCapacitorPlacementSolver],
  ComponentNetLabelCollision: [ComponentNetLabelCollisionSolver],
  ComponentBoxNetLabelCollision: [ComponentNetLabelCollisionSolver],
  NetLabelCollision: [ComponentNetLabelCollisionSolver],
  FeedbackNetworkNotCompact: [FeedbackNetworkPlacementSolver],
  PullResistorOnWrongSide: [
    PullResistorPlacementSolver,
    SwitchPullResistorPlacementSolver
  ],
  SchematicTextCollision: [SchematicTextClearanceSolver],
  ResetNetworkNotGrouped: [ResetNetworkGroupingSolver],
  TwoPinComponentCouldBeFlipped: [TwoPinComponentOrientationSolver],
  TwoPinComponentShouldBeVertical: [TwoPinComponentRailOrientationSolver],
  TwoPinComponentHasInvertedRails: [TwoPinComponentRailOrientationSolver],
  DecouplingCapacitorsNotCloseTogether: [DecouplingCapacitorGroupingSolver],
  ConnectorPositionCausesTraceDetours: [ConnectorPlacementSolver],
  LowSideTransistorNotAlignedWithLoad: [LowSideTransistorPlacementSolver],
  UsbSeriesResistorsNotAligned: [UsbSeriesResistorPlacementSolver],
  CurrentSenseShuntSeparatedFromInputs: [CurrentSenseShuntPlacementSolver],
  VoltageDividerSupplyResistorBelowGroundResistor: [
    VoltageDividerPlacementSolver
  ],
  RegulatorCapacitorsOnWrongSides: [
    RegulatorInputOutputCapacitorPlacementSolver
  ]
};
var SchematicPlacementPipeline = class extends BasePipelineSolver {
  ctx;
  issues = [];
  pipelineDef = [
    definePipelineStep(
      "SeriesLedChainPlacementSolver",
      SeriesLedChainPlacementSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "ParallelRcPlacementSolver",
      ParallelRcPlacementSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "ParallelDiodeResistorPlacementSolver",
      ParallelDiodeResistorPlacementSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "SchematicTextClearanceSolver",
      SchematicTextClearanceSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "ResetNetworkGroupingSolver",
      ResetNetworkGroupingSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "SchematicBoxOverlapSolver",
      SchematicBoxOverlapSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "CapacitorOrientationSolver",
      CapacitorOrientationSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "VerboseNetLabelSolver",
      VerboseNetLabelSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "SchematicBoxTooWideSolver",
      SchematicBoxTooWideSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "SchematicPinPaddingToEdgeSolver",
      SchematicPinPaddingToEdgeSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "SchematicBoxInnerLabelCollisionSolver",
      SchematicBoxInnerLabelCollisionSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "DiodeResistorAlignmentSolver",
      DiodeResistorAlignmentSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "ComponentPinAlignmentSolver",
      ComponentPinAlignmentSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "TraceSimplificationSolver",
      TraceSimplificationSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "CrystalLoadCapacitorPlacementSolver",
      CrystalLoadCapacitorPlacementSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "TwoPinComponentOrientationSolver",
      TwoPinComponentOrientationSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "FeedbackNetworkPlacementSolver",
      FeedbackNetworkPlacementSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "TwoPinComponentRailOrientationSolver",
      TwoPinComponentRailOrientationSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "PullResistorPlacementSolver",
      PullResistorPlacementSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "SwitchPullResistorPlacementSolver",
      SwitchPullResistorPlacementSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "ComponentNetLabelCollisionSolver",
      ComponentNetLabelCollisionSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "DecouplingCapacitorGroupingSolver",
      DecouplingCapacitorGroupingSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "ConnectorPlacementSolver",
      ConnectorPlacementSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "LowSideTransistorPlacementSolver",
      LowSideTransistorPlacementSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "UsbSeriesResistorPlacementSolver",
      UsbSeriesResistorPlacementSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "RegulatorInputOutputCapacitorPlacementSolver",
      RegulatorInputOutputCapacitorPlacementSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "VoltageDividerPlacementSolver",
      VoltageDividerPlacementSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "CurrentSenseShuntPlacementSolver",
      CurrentSenseShuntPlacementSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "RelayFlybackDiodePlacementSolver",
      RelayFlybackDiodePlacementSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "DiodeCapacitorStagePlacementSolver",
      DiodeCapacitorStagePlacementSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "PiFilterPlacementSolver",
      PiFilterPlacementSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "MosfetGateNetworkPlacementSolver",
      MosfetGateNetworkPlacementSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "ChipPinResistorPlacementSolver",
      ChipPinResistorPlacementSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "ChipPinPairCapacitorPlacementSolver",
      ChipPinPairCapacitorPlacementSolver,
      (p) => [
        { ctx: p.ctx, issues: p.issues }
      ]
    ),
    definePipelineStep(
      "RailPathVisibilitySolver",
      RailPathVisibilitySolver,
      (p) => [
        {
          ctx: p.ctx,
          issues: p.issues,
          maxSpan: p.railPathVisibility?.maxSpan,
          maxLength: p.railPathVisibility?.maxPathLength
        }
      ]
    )
  ];
  selectedIssueTypes;
  railPathVisibility;
  constructor(circuitJson, options = {}) {
    super(circuitJson);
    this.railPathVisibility = options.railPathVisibility;
    if (options.issueTypes !== void 0) {
      this.selectedIssueTypes = new Set(options.issueTypes);
      const selectedSolvers = new Set(
        options.issueTypes.flatMap(
          (type) => solversByIssueType[type]
        )
      );
      this.pipelineDef = this.pipelineDef.filter(
        (step) => selectedSolvers.has(step.solverClass)
      );
    }
  }
  _setup() {
    this.ctx = buildSolverContext(this.inputProblem);
  }
  getOutput() {
    const railOrientationComponentIds = new Set(
      this.issues.flatMap(
        (issue) => issue.lineItemType === "TwoPinComponentShouldBeVertical" && issue.schematicBox.schematicComponentId ? [issue.schematicBox.schematicComponentId] : []
      )
    );
    return {
      issues: this.issues.filter(
        (issue) => issue.lineItemType !== "CapacitorSymbolHorizontal" || !railOrientationComponentIds.has(
          issue.schematicBox.schematicComponentId ?? ""
        )
      ).filter(
        (issue) => this.selectedIssueTypes === void 0 || this.selectedIssueTypes.has(issue.lineItemType)
      ),
      componentPlacements: this.ctx.componentPlacements
    };
  }
};

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/utils/issue-context.ts
var POSITION_EPSILON = 0.01;
var getRelevantPlacementsForIssues = ({
  issues,
  componentPlacements,
  circuitJson
}) => {
  const relevantPlacements = /* @__PURE__ */ new Set();
  const placementByComponentId = new Map(
    componentPlacements.flatMap(
      (placement) => placement.schematicComponentId ? [[placement.schematicComponentId, placement]] : []
    )
  );
  const placementsByName = /* @__PURE__ */ new Map();
  for (const placement of componentPlacements) {
    if (!placement.sourceComponentName) continue;
    const namedPlacements = placementsByName.get(placement.sourceComponentName);
    if (namedPlacements) namedPlacements.push(placement);
    else placementsByName.set(placement.sourceComponentName, [placement]);
  }
  const addPlacement = (placement) => {
    if (!placement) return;
    const canonicalPlacement = placement.schematicComponentId ? placementByComponentId.get(placement.schematicComponentId) : componentPlacements.find(
      (candidate) => candidate.sourceComponentId === placement.sourceComponentId && candidate.schX === placement.schX && candidate.schY === placement.schY
    );
    if (canonicalPlacement) relevantPlacements.add(canonicalPlacement);
  };
  const addComponentName = (componentName, schematicSheetId) => {
    if (!componentName) return;
    for (const placement of placementsByName.get(componentName) ?? []) {
      if (schematicSheetId === void 0 || placement.schematicSheetId === schematicSheetId) {
        relevantPlacements.add(placement);
      }
    }
  };
  for (const issue of issues) {
    switch (issue.lineItemType) {
      case "SeriesLedChainNotOrdered":
        for (const placement of issue.ledSchematicBoxes) addPlacement(placement);
        break;
      case "ResistorSeparatedFromChipPin":
        addPlacement(issue.hostSchematicBox);
        addPlacement(issue.resistorSchematicBox);
        break;
      case "CapacitorSeparatedFromChipPins":
        addPlacement(issue.hostSchematicBox);
        addPlacement(issue.capacitorSchematicBox);
        break;
      case "DiodeCapacitorJunctionTooSpreadOut":
        addPlacement(issue.capacitorSchematicBox);
        for (const diode of issue.diodeSchematicBoxes) addPlacement(diode);
        break;
      case "PiFilterComponentsNotGrouped":
        addPlacement(issue.inductorSchematicBox);
        addPlacement(issue.firstCapacitorSchematicBox);
        addPlacement(issue.secondCapacitorSchematicBox);
        break;
      case "MosfetGateNetworkNotGrouped":
        addPlacement(issue.mosfetSchematicBox);
        addPlacement(issue.seriesGateResistorSchematicBox);
        addPlacement(issue.gateSourceResistorSchematicBox);
        break;
      case "FlybackDiodeSeparatedFromRelayCoil":
        addPlacement(issue.relaySchematicBox);
        addPlacement(issue.diodeSchematicBox);
        break;
      case "CurrentSenseShuntSeparatedFromInputs":
        addPlacement(issue.amplifierSchematicBox);
        addPlacement(issue.shuntSchematicBox);
        break;
      case "VoltageDividerSupplyResistorBelowGroundResistor":
        addPlacement(issue.supplyResistorSchematicBox);
        addPlacement(issue.groundResistorSchematicBox);
        break;
      case "RegulatorCapacitorsOnWrongSides":
        addPlacement(issue.regulatorSchematicBox);
        addPlacement(issue.inputCapacitorSchematicBox);
        addPlacement(issue.outputCapacitorSchematicBox);
        break;
      case "UsbSeriesResistorsNotAligned":
        addPlacement(issue.positiveResistorSchematicBox);
        addPlacement(issue.negativeResistorSchematicBox);
        break;
      case "LowSideTransistorNotAlignedWithLoad":
        addPlacement(issue.transistorSchematicBox);
        addPlacement(issue.loadSchematicBox);
        addPlacement(issue.baseResistorSchematicBox);
        addPlacement(issue.clampDiodeSchematicBox);
        break;
      case "DecouplingCapacitorsNotCloseTogether":
        for (const placement of issue.capacitorSchematicBoxes)
          addPlacement(placement);
        break;
      case "ConnectorPositionCausesTraceDetours":
        addPlacement(issue.connectorSchematicBox);
        for (const placement of issue.connectedComponents)
          addPlacement(placement);
        break;
      case "ResetNetworkNotGrouped":
        addPlacement(issue.hostSchematicBox);
        for (const placement of issue.supportNetworkComponents)
          addPlacement(placement);
        break;
      case "SchematicTextCollision":
        if (issue.collidingObject.schematicComponentId)
          addPlacement(
            placementByComponentId.get(
              issue.collidingObject.schematicComponentId
            )
          );
        if (issue.collidingObject.type === "trace") {
          for (const placement of getTraceEndpointPlacements({
            schematicTraceId: issue.collidingObject.id,
            circuitJson,
            placementByComponentId
          }))
            addPlacement(placement);
        }
        break;
      case "ComponentOverlap":
        addPlacement(issue.firstComponent);
        addPlacement(issue.secondComponent);
        break;
      case "SchematicBoxHasALotOfSurroundingWhitespace":
      case "CapacitorSymbolHorizontal":
      case "PinHeaderSchematicBoxTooWide":
      case "GenericSchematicBoxTooWide":
      case "SchematicBoxInnerLabelCollision":
      case "SchematicPinPaddingToEdgeTooLarge":
        addPlacement(issue.schematicBox);
        break;
      case "VerboseSchematicNetLabel":
        for (const pin of issue.involvedPins) {
          addComponentName(getComponentNameFromPin(pin), issue.schematicSheetId);
        }
        break;
      case "ParallelRcNotAligned":
        addPlacement(issue.resistorSchematicBox);
        addPlacement(issue.capacitorSchematicBox);
        break;
      case "ParallelDiodeResistorNotAligned":
      case "DiodeResistorNotAligned":
        addPlacement(issue.diodeSchematicBox);
        addPlacement(issue.resistorSchematicBox);
        break;
      case "ComponentPinsWouldAlignWithVerticalShift":
        addPlacement(issue.firstComponent);
        addPlacement(issue.secondComponent);
        addPlacement(issue.targetComponent);
        break;
      case "TraceCanBeSimplifiedByMovingComponent":
        addPlacement(issue.targetComponent);
        for (const placement of getTraceEndpointPlacements({
          schematicTraceId: issue.schematicTraceId,
          circuitJson,
          placementByComponentId
        })) {
          relevantPlacements.add(placement);
        }
        break;
      case "CrystalNotCenteredOverLoadCapacitors":
        addPlacement(issue.crystalSchematicBox);
        addPlacement(issue.firstLoadCapacitorSchematicBox);
        addPlacement(issue.secondLoadCapacitorSchematicBox);
        break;
      case "TwoPinComponentCouldBeFlipped":
        addPlacement(issue.targetComponent);
        addPlacement(issue.connectedComponent);
        break;
      case "FeedbackNetworkNotCompact":
        addPlacement(issue.amplifierSchematicBox);
        for (const component of issue.feedbackComponents)
          addPlacement(component);
        break;
      case "TwoPinComponentShouldBeVertical":
      case "TwoPinComponentHasInvertedRails":
        addPlacement(issue.schematicBox);
        break;
      case "RailPathTooSpreadOut":
        addPlacement(issue.hostSchematicBox);
        for (const placement of issue.supportSchematicBoxes)
          addPlacement(placement);
        break;
      case "PullResistorOnWrongSide":
        addPlacement(issue.resistorSchematicBox);
        addPlacement(issue.hostSchematicBox);
        break;
      case "ComponentNetLabelCollision":
        addPlacement(issue.firstComponent);
        addPlacement(issue.secondComponent);
        break;
      case "ComponentBoxNetLabelCollision":
        addPlacement(issue.boxComponent);
        addPlacement(issue.labelComponent);
        break;
      case "NetLabelCollision":
        for (const pair of issue.pairs) {
          addComponentName(pair.comp1Name, issue.schematicSheetId);
          addComponentName(pair.comp2Name, issue.schematicSheetId);
        }
        for (const move of issue.moves) {
          addComponentName(move.componentName, issue.schematicSheetId);
        }
        break;
    }
  }
  return componentPlacements.filter(
    (placement) => relevantPlacements.has(placement)
  );
};
var getIssueSchematicSheetContext = (issue) => {
  if ("schematicSheetId" in issue || "schematicSheetName" in issue) {
    const schematicSheetId = "schematicSheetId" in issue && typeof issue.schematicSheetId === "string" ? issue.schematicSheetId : void 0;
    const schematicSheetName = "schematicSheetName" in issue && typeof issue.schematicSheetName === "string" ? issue.schematicSheetName : void 0;
    if (schematicSheetId || schematicSheetName) {
      return { schematicSheetId, schematicSheetName };
    }
  }
  for (const value of Object.values(issue).flat()) {
    if (isSchematicBoxPlacement(value)) {
      return {
        schematicSheetId: value.schematicSheetId,
        schematicSheetName: value.schematicSheetName
      };
    }
  }
  return {};
};
var getComponentNameFromPin = (pin) => {
  const separatorIndex = pin.lastIndexOf(".");
  return separatorIndex === -1 ? pin : pin.slice(0, separatorIndex);
};
var isSchematicBoxPlacement = (value) => Boolean(
  value && typeof value === "object" && "positionAnchor" in value && value.positionAnchor === "center" && "schX" in value && "schY" in value && "width" in value && "height" in value
);
var getTraceEndpointPlacements = ({
  schematicTraceId,
  circuitJson,
  placementByComponentId
}) => {
  const trace = circuitJson.find(
    (element) => element.type === "schematic_trace" && element.schematic_trace_id === schematicTraceId
  );
  const firstEdge = trace?.edges[0];
  const lastEdge = trace?.edges.at(-1);
  if (!trace || !firstEdge || !lastEdge) return [];
  const ports = circuitJson.filter(
    (element) => element.type === "schematic_port"
  );
  const portsById = new Map(ports.map((port) => [port.schematic_port_id, port]));
  const endpointPorts = [
    firstEdge.from_schematic_port_id ? portsById.get(firstEdge.from_schematic_port_id) : findPortAtPoint(ports, firstEdge.from, trace.schematic_sheet_id),
    lastEdge.to_schematic_port_id ? portsById.get(lastEdge.to_schematic_port_id) : findPortAtPoint(ports, lastEdge.to, trace.schematic_sheet_id)
  ];
  return endpointPorts.flatMap((port) => {
    const placement = port?.schematic_component_id ? placementByComponentId.get(port.schematic_component_id) : void 0;
    return placement ? [placement] : [];
  });
};
var findPortAtPoint = (ports, point2, schematicSheetId) => ports.find(
  (port) => port.schematic_sheet_id === schematicSheetId && Math.abs(port.center.x - point2.x) <= POSITION_EPSILON && Math.abs(port.center.y - point2.y) <= POSITION_EPSILON
);

// node_modules/@tscircuit/circuit-json-schematic-placement-analysis/lib/analyze-schematic-placement.ts
var SchematicPlacementAnalysis = class {
  constructor(lineItems, groupBySchematicSheet = false) {
    this.lineItems = lineItems;
    this.groupBySchematicSheet = groupBySchematicSheet;
  }
  lineItems;
  groupBySchematicSheet;
  getLineItems() {
    return this.lineItems;
  }
  /** Filter emitted issues without rerunning or changing the solvers. */
  getIssues(filter = {}) {
    return this.lineItems.flatMap(
      (item) => item.lineItemType === "SchematicPlacementIssues" ? item.issues : []
    ).filter(
      (issue) => (filter.issueTypes === void 0 || filter.issueTypes.includes(issue.lineItemType)) && (filter.schematicSheetId === void 0 || (getIssueSchematicSheetContext(issue).schematicSheetId ?? "") === filter.schematicSheetId)
    );
  }
  /** Counts emitted issue objects, including zero counts for known types. */
  getIssueCounts(filter = {}) {
    const counts = {
      FlybackDiodeSeparatedFromRelayCoil: 0,
      ComponentOverlap: 0,
      SchematicBoxHasALotOfSurroundingWhitespace: 0,
      CapacitorSymbolHorizontal: 0,
      VerboseSchematicNetLabel: 0,
      PinHeaderSchematicBoxTooWide: 0,
      GenericSchematicBoxTooWide: 0,
      SchematicBoxInnerLabelCollision: 0,
      SchematicPinPaddingToEdgeTooLarge: 0,
      DiodeResistorNotAligned: 0,
      ParallelRcNotAligned: 0,
      ParallelDiodeResistorNotAligned: 0,
      ComponentPinsWouldAlignWithVerticalShift: 0,
      TraceCanBeSimplifiedByMovingComponent: 0,
      CrystalNotCenteredOverLoadCapacitors: 0,
      ComponentNetLabelCollision: 0,
      ComponentBoxNetLabelCollision: 0,
      NetLabelCollision: 0,
      FeedbackNetworkNotCompact: 0,
      PullResistorOnWrongSide: 0,
      SchematicTextCollision: 0,
      ResetNetworkNotGrouped: 0,
      TwoPinComponentCouldBeFlipped: 0,
      TwoPinComponentShouldBeVertical: 0,
      TwoPinComponentHasInvertedRails: 0,
      DecouplingCapacitorsNotCloseTogether: 0,
      ConnectorPositionCausesTraceDetours: 0,
      LowSideTransistorNotAlignedWithLoad: 0,
      UsbSeriesResistorsNotAligned: 0,
      RegulatorCapacitorsOnWrongSides: 0,
      VoltageDividerSupplyResistorBelowGroundResistor: 0,
      CurrentSenseShuntSeparatedFromInputs: 0,
      DiodeCapacitorJunctionTooSpreadOut: 0,
      PiFilterComponentsNotGrouped: 0,
      MosfetGateNetworkNotGrouped: 0,
      CapacitorSeparatedFromChipPins: 0,
      ResistorSeparatedFromChipPin: 0,
      RailPathTooSpreadOut: 0,
      SeriesLedChainNotOrdered: 0
    };
    for (const issue of this.getIssues(filter)) counts[issue.lineItemType]++;
    return counts;
  }
  getString() {
    return this.toString();
  }
  schematicBoxPlacementsToString(lineItem) {
    const attrs = [];
    addAttr(attrs, "componentName", lineItem.sourceComponentName);
    addAttr(attrs, "positionAnchor", lineItem.positionAnchor);
    addAttr(attrs, "schX", lineItem.schX);
    addAttr(attrs, "schY", lineItem.schY);
    addAttr(attrs, "width", lineItem.width);
    addAttr(attrs, "height", lineItem.height);
    return `<SchematicBoxPlacement ${attrs.join(" ")} />`;
  }
  schematicIssuesToString(issue) {
    switch (issue.lineItemType) {
      case "SeriesLedChainNotOrdered":
        return SeriesLedChainPlacementSolver.issueToString(issue);
      case "ResistorSeparatedFromChipPin":
        return ChipPinResistorPlacementSolver.issueToString(issue);
      case "CapacitorSeparatedFromChipPins":
        return ChipPinPairCapacitorPlacementSolver.issueToString(issue);
      case "DiodeCapacitorJunctionTooSpreadOut":
        return DiodeCapacitorStagePlacementSolver.issueToString(issue);
      case "PiFilterComponentsNotGrouped":
        return PiFilterPlacementSolver.issueToString(issue);
      case "MosfetGateNetworkNotGrouped":
        return MosfetGateNetworkPlacementSolver.issueToString(issue);
      case "CurrentSenseShuntSeparatedFromInputs":
        return CurrentSenseShuntPlacementSolver.issueToString(issue);
      case "ComponentOverlap":
        return SchematicBoxOverlapSolver.issueToString(issue);
      case "CapacitorSymbolHorizontal":
        return CapacitorOrientationSolver.issueToString(issue);
      case "DecouplingCapacitorsNotCloseTogether":
        return DecouplingCapacitorGroupingSolver.issueToString(issue);
      case "VerboseSchematicNetLabel":
        return VerboseNetLabelSolver.issueToString(issue);
      case "PinHeaderSchematicBoxTooWide":
      case "GenericSchematicBoxTooWide":
        return SchematicBoxTooWideSolver.issueToString(issue);
      case "SchematicBoxInnerLabelCollision":
        return SchematicBoxInnerLabelCollisionSolver.issueToString(issue);
      case "SchematicPinPaddingToEdgeTooLarge":
        return SchematicPinPaddingToEdgeSolver.issueToString(issue);
      case "ParallelRcNotAligned":
        return ParallelRcPlacementSolver.issueToString(issue);
      case "ParallelDiodeResistorNotAligned":
        return ParallelDiodeResistorPlacementSolver.issueToString(issue);
      case "DiodeResistorNotAligned":
        return DiodeResistorAlignmentSolver.issueToString(issue);
      case "ComponentPinsWouldAlignWithVerticalShift":
        return ComponentPinAlignmentSolver.issueToString(issue);
      case "TraceCanBeSimplifiedByMovingComponent":
        return TraceSimplificationSolver.issueToString(issue);
      case "CrystalNotCenteredOverLoadCapacitors":
        return CrystalLoadCapacitorPlacementSolver.issueToString(issue);
      case "TwoPinComponentCouldBeFlipped":
        return TwoPinComponentOrientationSolver.issueToString(issue);
      case "FeedbackNetworkNotCompact":
        return FeedbackNetworkPlacementSolver.issueToString(issue);
      case "TwoPinComponentShouldBeVertical":
      case "TwoPinComponentHasInvertedRails":
        return TwoPinComponentRailOrientationSolver.issueToString(issue);
      case "RailPathTooSpreadOut":
        return RailPathVisibilitySolver.issueToString(issue);
      case "PullResistorOnWrongSide":
        return PullResistorPlacementSolver.issueToString(issue);
      case "NetLabelCollision":
        return ComponentNetLabelCollisionSolver.netLabelCollisionToString(issue);
      case "SchematicTextCollision":
        return SchematicTextClearanceSolver.issueToString(issue);
      case "ResetNetworkNotGrouped":
        return ResetNetworkGroupingSolver.issueToString(issue);
      case "ConnectorPositionCausesTraceDetours":
        return ConnectorPlacementSolver.issueToString(issue);
      case "LowSideTransistorNotAlignedWithLoad":
        return LowSideTransistorPlacementSolver.issueToString(issue);
      case "FlybackDiodeSeparatedFromRelayCoil":
        return RelayFlybackDiodePlacementSolver.issueToString(issue);
      case "VoltageDividerSupplyResistorBelowGroundResistor":
        return VoltageDividerPlacementSolver.issueToString(issue);
      case "RegulatorCapacitorsOnWrongSides":
        return RegulatorInputOutputCapacitorPlacementSolver.issueToString(issue);
      case "UsbSeriesResistorsNotAligned":
        return UsbSeriesResistorPlacementSolver.issueToString(issue);
      default:
        return "";
    }
  }
  toString() {
    const schematicBoxPlacements = this.lineItems.filter(
      (lineItem) => lineItem.lineItemType === "SchematicBoxPlacement"
    );
    const issues = this.lineItems.flatMap(
      (lineItem) => lineItem.lineItemType === "SchematicPlacementIssues" ? lineItem.issues : []
    );
    if (issues.length === 0) return "";
    if (!this.groupBySchematicSheet) {
      return this.issueContextToLines(schematicBoxPlacements, issues).join("\n");
    }
    const groups = /* @__PURE__ */ new Map();
    const getOrCreateGroup = (context) => {
      const key = context.schematicSheetId ?? context.schematicSheetName ?? "__default__";
      const existingGroup = groups.get(key);
      if (existingGroup) return existingGroup;
      const group = { ...context, placements: [], issues: [] };
      groups.set(key, group);
      return group;
    };
    for (const issue of issues) {
      getOrCreateGroup(getIssueSchematicSheetContext(issue)).issues.push(issue);
    }
    for (const placement of schematicBoxPlacements) {
      getOrCreateGroup({
        schematicSheetId: placement.schematicSheetId,
        schematicSheetName: placement.schematicSheetName
      }).placements.push(placement);
    }
    return [...groups.values()].flatMap((group) => {
      const sheetAttrs = [];
      addAttr(sheetAttrs, "name", group.schematicSheetName);
      addAttr(sheetAttrs, "id", group.schematicSheetId);
      return [
        `<SchematicSheet${sheetAttrs.length > 0 ? ` ${sheetAttrs.join(" ")}` : ""}>`,
        ...this.issueContextToLines(group.placements, group.issues),
        "</SchematicSheet>"
      ];
    }).join("\n");
  }
  issueContextToLines(placements, issues) {
    return [
      ...placements.length > 0 ? [
        "<SchematicBoxPositions>",
        ...placements.map(this.schematicBoxPlacementsToString),
        "</SchematicBoxPositions>"
      ] : [],
      "<SchematicPlacementIssues>",
      ...issues.map(this.schematicIssuesToString),
      "</SchematicPlacementIssues>"
    ];
  }
};
var analyzeSchematicPlacement = (circuitJson, options = {}) => {
  const pipeline = new SchematicPlacementPipeline(circuitJson, options);
  pipeline.solve();
  const { issues, componentPlacements } = pipeline.getOutput();
  const relevantPlacements = getRelevantPlacementsForIssues({
    issues,
    componentPlacements,
    circuitJson
  });
  const lineItems = [
    ...relevantPlacements,
    ...issues.length > 0 ? [{ lineItemType: "SchematicPlacementIssues", issues }] : []
  ];
  const schematicSheetIds = new Set(
    circuitJson.flatMap(
      (element) => "schematic_sheet_id" in element && typeof element.schematic_sheet_id === "string" ? [element.schematic_sheet_id] : []
    )
  );
  return new SchematicPlacementAnalysis(lineItems, schematicSheetIds.size > 1);
};

// lib/check-schematic-placement.ts
import { cju as cju12 } from "@tscircuit/circuit-json-util";
var enabledIssueTypes = [
  "TwoPinComponentHasInvertedRails",
  "RegulatorCapacitorsOnWrongSides",
  "PullResistorOnWrongSide",
  "VoltageDividerSupplyResistorBelowGroundResistor",
  "SeriesLedChainNotOrdered",
  "ParallelRcNotAligned"
];
function checkSchematicPlacement(circuitJson) {
  const analysis = analyzeSchematicPlacement(circuitJson, {
    issueTypes: enabledIssueTypes
  });
  const db = cju12(circuitJson);
  return analysis.getIssues().flatMap((issue) => {
    let schematicComponentId;
    let stylingIssueType;
    let message;
    switch (issue.lineItemType) {
      case "TwoPinComponentHasInvertedRails": {
        schematicComponentId = issue.schematicBox.schematicComponentId;
        const componentName = getReadableNameForElementId(
          circuitJson,
          schematicComponentId ?? ""
        );
        stylingIssueType = "inverted_rails";
        message = `${componentName} has its positive-supply pin facing down. Rotate ${componentName} by 180\xB0 so that pin faces up, preserving pin connections, and reroute attached traces.`;
        break;
      }
      case "RegulatorCapacitorsOnWrongSides": {
        schematicComponentId = issue.regulatorSchematicBox.schematicComponentId;
        const regulatorName = getReadableNameForElementId(
          circuitJson,
          schematicComponentId ?? ""
        );
        const inputCapacitorName = getReadableNameForElementId(
          circuitJson,
          issue.inputCapacitorSchematicBox.schematicComponentId ?? ""
        );
        const outputCapacitorName = getReadableNameForElementId(
          circuitJson,
          issue.outputCapacitorSchematicBox.schematicComponentId ?? ""
        );
        stylingIssueType = "regulator_capacitors_on_wrong_sides";
        message = `${inputCapacitorName} and ${outputCapacitorName} are on the wrong sides of ${regulatorName}. Move them beside their connected regulator pins, preserving connections and rerouting traces.`;
        break;
      }
      case "PullResistorOnWrongSide":
        schematicComponentId = issue.resistorSchematicBox.schematicComponentId;
        stylingIssueType = "pull_resistor_on_wrong_side";
        message = `consider placing ${getReadableNameForElementId(circuitJson, schematicComponentId ?? "")} ${issue.preferredSide} ${getReadableNameForElementId(circuitJson, issue.hostSchematicBox.schematicComponentId ?? "")}.${getReadableNameForElementId(circuitJson, issue.signalSourcePortId)} so the pull-${issue.pullDirection} branch reads toward ${issue.pullDirection === "up" ? "power" : "ground"}`;
        break;
      case "VoltageDividerSupplyResistorBelowGroundResistor": {
        schematicComponentId = issue.supplyResistorSchematicBox.schematicComponentId;
        const supplyResistorName = getReadableNameForElementId(
          circuitJson,
          schematicComponentId ?? ""
        );
        const groundResistorName = getReadableNameForElementId(
          circuitJson,
          issue.groundResistorSchematicBox.schematicComponentId ?? ""
        );
        stylingIssueType = "voltage_divider_supply_resistor_below_ground_resistor";
        message = `${supplyResistorName}, connected to the supply, is below ${groundResistorName}, connected to ground. Place ${supplyResistorName} above ${groundResistorName} so their shared divider tap is easy to follow. Preserve pin connections and reroute affected traces; exact alignment is not required.`;
        break;
      }
      case "SeriesLedChainNotOrdered": {
        schematicComponentId = issue.ledSchematicBoxes[0]?.schematicComponentId;
        const ledNames = issue.ledSchematicBoxes.map(
          (box) => getReadableNameForElementId(
            circuitJson,
            box.schematicComponentId ?? ""
          )
        ).join(", ");
        stylingIssueType = "series_led_chain_not_ordered";
        message = `The series chain ${ledNames} requires long connections behind LED pins. Arrange the LEDs in their connected order, preserving anode/cathode connections, and reroute affected traces. A horizontal, vertical, or clearly connected folded chain is acceptable.`;
        break;
      }
      case "ParallelRcNotAligned": {
        schematicComponentId = issue.resistorSchematicBox.schematicComponentId;
        const resistorName = getReadableNameForElementId(
          circuitJson,
          schematicComponentId ?? ""
        );
        const capacitorName = getReadableNameForElementId(
          circuitJson,
          issue.capacitorSchematicBox.schematicComponentId ?? ""
        );
        stylingIssueType = "parallel_rc_not_aligned";
        message = `${resistorName} and ${capacitorName} share chip-pin and ground connections but are not drawn as adjacent parallel branches. Place their shared connections at matching ends, preserving pin connections and capacitor polarity, and reroute affected traces.`;
        break;
      }
      default:
        return [];
    }
    if (!schematicComponentId) return [];
    const component = db.schematic_component.get(schematicComponentId);
    if (!component) return [];
    const group = component.schematic_group_id ? db.schematic_group.get(component.schematic_group_id) : void 0;
    return [
      {
        type: "schematic_component_styling_warning",
        schematic_component_styling_warning_id: `schematic_component_styling_warning_${schematicComponentId}_${stylingIssueType}`,
        warning_type: "schematic_component_styling_warning",
        styling_issue_type: stylingIssueType,
        message,
        schematic_component_id: schematicComponentId,
        source_component_id: component.source_component_id,
        schematic_sheet_id: component.schematic_sheet_id,
        subcircuit_id: component.subcircuit_id ?? group?.subcircuit_id,
        schematic_port_ids: db.schematic_port.list().filter(
          (port) => port.schematic_component_id === schematicComponentId
        ).map((port) => port.schematic_port_id)
      }
    ];
  });
}

// node_modules/@tscircuit/circuit-json-pcb-style-analysis/dist/index.js
var Vt = Object.create;
var { getPrototypeOf: Jt, defineProperty: Lt, getOwnPropertyNames: qt } = Object;
var bt = Object.prototype.hasOwnProperty;
function Kt(t) {
  return this[t];
}
var Zt;
var Qt;
var te = (t, e, r) => {
  var n = t != null && typeof t === "object";
  if (n) {
    var o = e ? Zt ??= /* @__PURE__ */ new WeakMap() : Qt ??= /* @__PURE__ */ new WeakMap(), m = o.get(t);
    if (m) return m;
  }
  r = t != null ? Vt(Jt(t)) : {};
  let a = e || !t || !t.__esModule || !bt.call(t, "default") ? Lt(r, "default", { value: t, enumerable: true }) : r;
  if (t && typeof t === "object" || typeof t === "function") {
    for (let f of qt(t)) if (!bt.call(a, f)) Lt(a, f, { get: Kt.bind(t, f), enumerable: true });
  }
  if (n) o.set(t, a);
  return a;
};
var ee = (t, e) => () => (e || t((e = { exports: {} }).exports, e), e.exports);
var Pt = ee(function(lt, ft) {
  (function(t, e) {
    typeof lt === "object" && typeof ft < "u" ? ft.exports = e() : typeof define === "function" && define.amd ? define(e) : (t = typeof globalThis < "u" ? globalThis : t || self, t.svgson = e());
  })(lt, function() {
    var t = function(x) {
      return x != null && (e(x) || r(x) || !!x._isBuffer);
    };
    function e(x) {
      return !!x.constructor && typeof x.constructor.isBuffer === "function" && x.constructor.isBuffer(x);
    }
    function r(x) {
      return typeof x.readFloatLE === "function" && typeof x.slice === "function" && e(x.slice(0, 0));
    }
    var n = Object.prototype.toString, o = function(s) {
      if (typeof s > "u") return "undefined";
      if (s === null) return "null";
      if (s === true || s === false || s instanceof Boolean) return "boolean";
      if (typeof s === "string" || s instanceof String) return "string";
      if (typeof s === "number" || s instanceof Number) return "number";
      if (typeof s === "function" || s instanceof Function) return "function";
      if (typeof Array.isArray < "u" && Array.isArray(s)) return "array";
      if (s instanceof RegExp) return "regexp";
      if (s instanceof Date) return "date";
      var i = n.call(s);
      if (i === "[object RegExp]") return "regexp";
      if (i === "[object Date]") return "date";
      if (i === "[object Arguments]") return "arguments";
      if (i === "[object Error]") return "error";
      if (t(s)) return "buffer";
      if (i === "[object Set]") return "set";
      if (i === "[object WeakSet]") return "weakset";
      if (i === "[object Map]") return "map";
      if (i === "[object WeakMap]") return "weakmap";
      if (i === "[object Symbol]") return "symbol";
      if (i === "[object Int8Array]") return "int8array";
      if (i === "[object Uint8Array]") return "uint8array";
      if (i === "[object Uint8ClampedArray]") return "uint8clampedarray";
      if (i === "[object Int16Array]") return "int16array";
      if (i === "[object Uint16Array]") return "uint16array";
      if (i === "[object Int32Array]") return "int32array";
      if (i === "[object Uint32Array]") return "uint32array";
      if (i === "[object Float32Array]") return "float32array";
      if (i === "[object Float64Array]") return "float64array";
      return "object";
    };
    function m(x, s) {
      return s = { exports: {} }, x(s, s.exports), s.exports;
    }
    var a = m(function(x) {
      (function() {
        function s(i, S) {
          if (typeof S !== "function") return i;
          var u = {};
          for (var L in i) if (Object.prototype.hasOwnProperty.call(i, L)) u[S(L, i[L]) || L] = i[L];
          return u;
        }
        if (x.exports) x.exports = s;
        else window.rename = s;
      })();
    }), f = function x(s, i) {
      var S = o(s);
      if (S !== "object" && S !== "array") throw Error("expected an object");
      var u = [];
      if (S === "object") s = a(s, i), u = {};
      for (var L in s) if (s.hasOwnProperty(L)) {
        var T = s[L];
        if (o(T) === "object" || o(T) === "array") u[L] = x(T, i);
        else u[L] = T;
      }
      return u;
    }, O = m(function(x) {
      var s = Object.prototype.hasOwnProperty, i = "~";
      function S() {
      }
      if (Object.create) {
        if (S.prototype = /* @__PURE__ */ Object.create(null), !new S().__proto__) i = false;
      }
      function u(T, w, M) {
        this.fn = T, this.context = w, this.once = M || false;
      }
      function L() {
        this._events = new S(), this._eventsCount = 0;
      }
      L.prototype.eventNames = function() {
        var w = [], M, g;
        if (this._eventsCount === 0) return w;
        for (g in M = this._events) if (s.call(M, g)) w.push(i ? g.slice(1) : g);
        if (Object.getOwnPropertySymbols) return w.concat(Object.getOwnPropertySymbols(M));
        return w;
      }, L.prototype.listeners = function(w, M) {
        var g = i ? i + w : w, A = this._events[g];
        if (M) return !!A;
        if (!A) return [];
        if (A.fn) return [A.fn];
        for (var y = 0, P = A.length, b = Array(P); y < P; y++) b[y] = A[y].fn;
        return b;
      }, L.prototype.emit = function(w, M, g, A, y, P) {
        var b = i ? i + w : w;
        if (!this._events[b]) return false;
        var d = this._events[b], E = arguments.length, R, _;
        if (d.fn) {
          if (d.once) this.removeListener(w, d.fn, void 0, true);
          switch (E) {
            case 1:
              return d.fn.call(d.context), true;
            case 2:
              return d.fn.call(d.context, M), true;
            case 3:
              return d.fn.call(d.context, M, g), true;
            case 4:
              return d.fn.call(d.context, M, g, A), true;
            case 5:
              return d.fn.call(d.context, M, g, A, y), true;
            case 6:
              return d.fn.call(d.context, M, g, A, y, P), true;
          }
          for (_ = 1, R = Array(E - 1); _ < E; _++) R[_ - 1] = arguments[_];
          d.fn.apply(d.context, R);
        } else {
          var F2 = d.length, D;
          for (_ = 0; _ < F2; _++) {
            if (d[_].once) this.removeListener(w, d[_].fn, void 0, true);
            switch (E) {
              case 1:
                d[_].fn.call(d[_].context);
                break;
              case 2:
                d[_].fn.call(d[_].context, M);
                break;
              case 3:
                d[_].fn.call(d[_].context, M, g);
                break;
              case 4:
                d[_].fn.call(d[_].context, M, g, A);
                break;
              default:
                if (!R) for (D = 1, R = Array(E - 1); D < E; D++) R[D - 1] = arguments[D];
                d[_].fn.apply(d[_].context, R);
            }
          }
        }
        return true;
      }, L.prototype.on = function(w, M, g) {
        var A = new u(M, g || this), y = i ? i + w : w;
        if (!this._events[y]) this._events[y] = A, this._eventsCount++;
        else if (!this._events[y].fn) this._events[y].push(A);
        else this._events[y] = [this._events[y], A];
        return this;
      }, L.prototype.once = function(w, M, g) {
        var A = new u(M, g || this, true), y = i ? i + w : w;
        if (!this._events[y]) this._events[y] = A, this._eventsCount++;
        else if (!this._events[y].fn) this._events[y].push(A);
        else this._events[y] = [this._events[y], A];
        return this;
      }, L.prototype.removeListener = function(w, M, g, A) {
        var y = i ? i + w : w;
        if (!this._events[y]) return this;
        if (!M) {
          if (--this._eventsCount === 0) this._events = new S();
          else delete this._events[y];
          return this;
        }
        var P = this._events[y];
        if (P.fn) {
          if (P.fn === M && (!A || P.once) && (!g || P.context === g)) if (--this._eventsCount === 0) this._events = new S();
          else delete this._events[y];
        } else {
          for (var b = 0, d = [], E = P.length; b < E; b++) if (P[b].fn !== M || A && !P[b].once || g && P[b].context !== g) d.push(P[b]);
          if (d.length) this._events[y] = d.length === 1 ? d[0] : d;
          else if (--this._eventsCount === 0) this._events = new S();
          else delete this._events[y];
        }
        return this;
      }, L.prototype.removeAllListeners = function(w) {
        var M;
        if (w) {
          if (M = i ? i + w : w, this._events[M]) if (--this._eventsCount === 0) this._events = new S();
          else delete this._events[M];
        } else this._events = new S(), this._eventsCount = 0;
        return this;
      }, L.prototype.off = L.prototype.removeListener, L.prototype.addListener = L.prototype.on, L.prototype.setMaxListeners = function() {
        return this;
      }, L.prefixed = i, L.EventEmitter = L, x.exports = L;
    });
    function l(x, s, i) {
      if (s in x) Object.defineProperty(x, s, { value: i, enumerable: true, configurable: true, writable: true });
      else x[s] = i;
      return x;
    }
    var k = function() {
    }, h = { data: "state-data", cdata: "state-cdata", tagBegin: "state-tag-begin", tagName: "state-tag-name", tagEnd: "state-tag-end", attributeNameStart: "state-attribute-name-start", attributeName: "state-attribute-name", attributeNameEnd: "state-attribute-name-end", attributeValueBegin: "state-attribute-value-begin", attributeValue: "state-attribute-value" }, c = { lt: "action-lt", gt: "action-gt", space: "action-space", equal: "action-equal", quote: "action-quote", slash: "action-slash", char: "action-char", error: "action-error" }, v = { text: "text", openTag: "open-tag", closeTag: "close-tag", attributeName: "attribute-name", attributeValue: "attribute-value" }, N = { " ": c.space, "	": c.space, "\n": c.space, "\r": c.space, "<": c.lt, ">": c.gt, '"': c.quote, "'": c.quote, "=": c.equal, "/": c.slash }, W = function(s) {
      return N[s] || c.char;
    }, z = function(s) {
      var i, S, u, L, T, w, M, g, A, y;
      s = Object.assign({ debug: false }, s);
      var P = new O(), b = h.data, d = "", E = "", R = "", _ = "", F2 = "", D = "", C = function(j, X) {
        if (E[0] === "?" || E[0] === "!") return;
        var tt = { type: j, value: X };
        if (s.debug) console.log("emit:", tt);
        P.emit("data", tt);
      };
      P.stateMachine = (y = {}, l(y, h.data, (i = {}, l(i, c.lt, function() {
        if (d.trim()) C(v.text, d);
        E = "", F2 = false, b = h.tagBegin;
      }), l(i, c.char, function(I) {
        d += I;
      }), i)), l(y, h.cdata, l({}, c.char, function(I) {
        if (d += I, d.substr(-3) === "]]>") C(v.text, d.slice(0, -3)), d = "", b = h.data;
      })), l(y, h.tagBegin, (S = {}, l(S, c.space, k), l(S, c.char, function(I) {
        E = I, b = h.tagName;
      }), l(S, c.slash, function() {
        E = "", F2 = true;
      }), S)), l(y, h.tagName, (u = {}, l(u, c.space, function() {
        if (F2) b = h.tagEnd;
        else b = h.attributeNameStart, C(v.openTag, E);
      }), l(u, c.gt, function() {
        if (F2) C(v.closeTag, E);
        else C(v.openTag, E);
        d = "", b = h.data;
      }), l(u, c.slash, function() {
        b = h.tagEnd, C(v.openTag, E);
      }), l(u, c.char, function(I) {
        if (E += I, E === "![CDATA[") b = h.cdata, d = "", E = "";
      }), u)), l(y, h.tagEnd, (L = {}, l(L, c.gt, function() {
        C(v.closeTag, E), d = "", b = h.data;
      }), l(L, c.char, k), L)), l(y, h.attributeNameStart, (T = {}, l(T, c.char, function(I) {
        R = I, b = h.attributeName;
      }), l(T, c.gt, function() {
        d = "", b = h.data;
      }), l(T, c.space, k), l(T, c.slash, function() {
        F2 = true, b = h.tagEnd;
      }), T)), l(y, h.attributeName, (w = {}, l(w, c.space, function() {
        b = h.attributeNameEnd;
      }), l(w, c.equal, function() {
        C(v.attributeName, R), b = h.attributeValueBegin;
      }), l(w, c.gt, function() {
        _ = "", C(v.attributeName, R), C(v.attributeValue, _), d = "", b = h.data;
      }), l(w, c.slash, function() {
        F2 = true, _ = "", C(v.attributeName, R), C(v.attributeValue, _), b = h.tagEnd;
      }), l(w, c.char, function(I) {
        R += I;
      }), w)), l(y, h.attributeNameEnd, (M = {}, l(M, c.space, k), l(M, c.equal, function() {
        C(v.attributeName, R), b = h.attributeValueBegin;
      }), l(M, c.gt, function() {
        _ = "", C(v.attributeName, R), C(v.attributeValue, _), d = "", b = h.data;
      }), l(M, c.char, function(I) {
        _ = "", C(v.attributeName, R), C(v.attributeValue, _), R = I, b = h.attributeName;
      }), M)), l(y, h.attributeValueBegin, (g = {}, l(g, c.space, k), l(g, c.quote, function(I) {
        D = I, _ = "", b = h.attributeValue;
      }), l(g, c.gt, function() {
        _ = "", C(v.attributeValue, _), d = "", b = h.data;
      }), l(g, c.char, function(I) {
        D = "", _ = I, b = h.attributeValue;
      }), g)), l(y, h.attributeValue, (A = {}, l(A, c.space, function(I) {
        if (D) _ += I;
        else C(v.attributeValue, _), b = h.attributeNameStart;
      }), l(A, c.quote, function(I) {
        if (D === I) C(v.attributeValue, _), b = h.attributeNameStart;
        else _ += I;
      }), l(A, c.gt, function(I) {
        if (D) _ += I;
        else C(v.attributeValue, _), d = "", b = h.data;
      }), l(A, c.slash, function(I) {
        if (D) _ += I;
        else C(v.attributeValue, _), F2 = true, b = h.tagEnd;
      }), l(A, c.char, function(I) {
        _ += I;
      }), A)), y);
      var Ht = function(j) {
        if (s.debug) console.log(b, j);
        var X = P.stateMachine[b], tt = X[W(j)] || X[c.error] || X[c.char];
        tt(j);
      };
      return P.write = function(I) {
        var j = I.length;
        for (var X = 0; X < j; X++) Ht(I[X]);
      }, P;
    }, Z = { State: h, Action: c, Type: v, create: z }, p = Z.Type, B = { element: "element", text: "text" }, Y = function(s) {
      return Object.assign({ name: "", type: B.element, value: "", parent: null, attributes: {}, children: [] }, s);
    }, Q = function(s) {
      s = Object.assign({ stream: false, parentNodes: true, doneEvent: "done", tagPrefix: "tag:", emitTopLevelOnly: false, debug: false }, s);
      var i = void 0, S = void 0, u = void 0, L = void 0, T = new O(), w = function(g) {
        switch (g.type) {
          case p.openTag:
            if (u === null) u = S, u.name = g.value;
            else {
              var A = Y({ name: g.value, parent: u });
              u.children.push(A), u = A;
            }
            break;
          case p.closeTag:
            var y = u.parent;
            if (!s.parentNodes) u.parent = null;
            if (u.name !== g.value) break;
            if (s.stream && y === S) S.children = [], u.parent = null;
            if (!s.emitTopLevelOnly || y === S) T.emit(s.tagPrefix + u.name, u), T.emit("tag", u.name, u);
            if (u === S) i.removeAllListeners("data"), T.emit(s.doneEvent, u), S = null;
            u = y;
            break;
          case p.text:
            if (u) u.children.push(Y({ type: B.text, value: g.value, parent: s.parentNodes ? u : null }));
            break;
          case p.attributeName:
            L = g.value, u.attributes[L] = "";
            break;
          case p.attributeValue:
            u.attributes[L] = g.value;
            break;
        }
      };
      return T.reset = function() {
        i = Z.create({ debug: s.debug }), i.on("data", w), S = Y(), u = null, L = "", T.parse = i.write;
      }, T.reset(), T;
    }, Rt = function(s, i) {
      i = Object.assign({}, i, { stream: false, tagPrefix: ":" });
      var S = Q(i), u = void 0;
      return S.on("done", function(L) {
        u = L;
      }), S.parse(s), u;
    }, Dt = { parseSync: Rt, create: Q, NodeType: B }, $t = Dt.parseSync, Ut = function(s) {
      var i = $t("<root>".concat(s, "</root>"), { parentNodes: false }), S = i.children && i.children.length > 0 && i.children.every(function(u) {
        return u.name === "svg";
      });
      if (S) return i.children.length === 1 ? i.children[0] : i.children;
      else throw Error("nothing to parse");
    }, Bt = function(s) {
      return f(s, function(i) {
        if (!Xt(i)) return Ft(i);
        return i;
      });
    }, Ft = function(s) {
      return s.replace(/[-|:]([a-z])/gi, function(i, S) {
        return S.toUpperCase();
      });
    }, Xt = function(s) {
      return /^(data|aria)(-\w+)/.test(s);
    }, Yt = function(s) {
      if (s) {
        var i = String(s);
        return /[&<>]/.test(i) ? "<![CDATA[".concat(i.replace(/]]>/, "]]]]><![CDATA[>"), "]]>") : i;
      }
      return "";
    }, Wt = function(s) {
      return String(s).replace(/&/g, "&amp;").replace(/'/g, "&apos;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }, xt = function(s) {
      var i = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, S = i.transformNode, u = S === void 0 ? function(M) {
        return M;
      } : S, L = i.camelcase, T = L === void 0 ? false : L, w = function(g) {
        var A = u(g);
        if (T) A = Bt(A);
        return A;
      };
      return w(Ut(s));
    };
    function jt() {
      for (var x = arguments.length, s = Array(x), i = 0; i < x; i++) s[i] = arguments[i];
      return new Promise(function(S, u) {
        try {
          var L = xt.apply(void 0, s);
          S(L);
        } catch (T) {
          u(T);
        }
      });
    }
    var zt = function x(s) {
      var i = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, S = i.transformAttr, u = S === void 0 ? function(b, d, E) {
        return "".concat(b, '="').concat(E(d), '"');
      } : S, L = i.transformNode, T = L === void 0 ? function(b) {
        return b;
      } : L, w = i.selfClose, M = w === void 0 ? true : w;
      if (Array.isArray(s)) return s.map(function(b) {
        return x(b, { transformAttr: u, selfClose: M, transformNode: T });
      }).join("");
      var g = T(s);
      if (g.type === "text") return Yt(g.value);
      var A = "";
      for (var y in g.attributes) {
        var P = u(y, g.attributes[y], Wt, g.name);
        A += P ? " ".concat(P) : "";
      }
      return g.children && g.children.length > 0 || !M ? "<".concat(g.name).concat(A, ">").concat(x(g.children, { transformAttr: u, transformNode: T, selfClose: M }), "</").concat(g.name, ">") : "<".concat(g.name).concat(A, "/>");
    }, Gt = Object.assign({}, { parse: jt, parseSync: xt, stringify: zt });
    return Gt;
  });
});
var St = { "0": "M0.301025 0.257813 L0.206593 0.283385 L0.122042 0.361307 L0.075923 0.474441 L0.064942 0.642221 L0.091296 0.78289 L0.159376 0.899463 L0.257104 0.961214 L0.344948 0.961214 L0.442678 0.899463 L0.510757 0.78289 L0.537111 0.642221 L0.526131 0.474441 L0.480012 0.361307 L0.39546 0.283385 L0.301025 0.257813", "1": "M0.220426 0.40845 L0.381626 0.270996 L0.381626 0.948966", "2": "M0.110409 0.39212 L0.125621 0.342293 L0.170571 0.295823 L0.244237 0.26431 L0.291518 0.257813 L0.373319 0.263799 L0.434683 0.290705 L0.468239 0.331966 L0.480292 0.379913 L0.479492 0.411806 L0.465088 0.465192 L0.402571 0.568988 L0.245134 0.766438 L0.07959 0.948045 L0.522462 0.948045", "3": "M0.081606 0.345073 L0.119154 0.315633 L0.178996 0.284091 L0.255265 0.257813 L0.349133 0.263062 L0.43127 0.289348 L0.48994 0.336662 L0.525141 0.394491 L0.513407 0.457577 L0.466472 0.504892 L0.384334 0.541692 L0.290464 0.56272 L0.20833 0.573235 L0.290464 0.583749 L0.384334 0.610035 L0.466472 0.652092 L0.519274 0.709922 L0.531007 0.773007 L0.50754 0.841351 L0.454738 0.899179 L0.3726 0.946494 L0.310412 0.961214 L0.209503 0.959111 L0.127367 0.946494 L0.071046 0.929671", "4": "M0.418494 0.270996 L0.048828 0.724199 L0.553224 0.724199 M0.414181 0.578167 L0.414181 0.94897", "5": "M0.074951 0.270996 L0.074951 0.614701 L0.267655 0.5695 L0.405247 0.586502 L0.460002 0.617189 L0.498028 0.660731 L0.527101 0.779401 L0.513352 0.841049 L0.477274 0.889568 L0.406378 0.93463 L0.324445 0.958337 L0.247399 0.962139 L0.182516 0.949767 L0.130068 0.925508 L0.074951 0.875607 M0.074951 0.270996 L0.527101 0.270996", "6": "M0.428549 0.257813 L0.341433 0.285053 L0.26073 0.312099 L0.192188 0.360182 L0.138902 0.410969 L0.098219 0.500422 L0.070249 0.584267 L0.067264 0.670716 L0.065164 0.756863 L0.087163 0.820973 L0.108168 0.861042 L0.157916 0.913131 L0.210981 0.948192 L0.29279 0.961214 L0.384548 0.956206 L0.456409 0.924151 L0.507262 0.881077 L0.5349 0.821975 L0.537111 0.771889 L0.521634 0.718798 L0.498418 0.67372 L0.463042 0.636657 L0.414398 0.613617 L0.34696 0.598591 L0.28284 0.595587 L0.215403 0.605604 L0.145756 0.641665 L0.109274 0.678729 L0.064942 0.724006", "7": "M0.071534 0.270996 L0.530519 0.270996 L0.495935 0.291702 L0.477752 0.305407 L0.435186 0.346112 L0.412067 0.374136 L0.388565 0.40796 L0.365315 0.448098 L0.342943 0.495062 L0.322081 0.549366 L0.303364 0.611524 L0.287416 0.68205 L0.270077 0.80465 L0.26253 0.94897", "8": "M0.286761 0.257813 L0.210684 0.27162 L0.1414 0.305622 L0.092494 0.382125 L0.111513 0.450128 L0.16857 0.502193 L0.228345 0.539382 L0.377781 0.594635 L0.470161 0.645637 L0.52586 0.706203 L0.538087 0.792269 L0.506841 0.87621 L0.438915 0.927212 L0.339743 0.961214 L0.263666 0.959089 L0.174004 0.929337 L0.102003 0.881523 L0.063965 0.811395 L0.066682 0.741266 L0.102003 0.671139 L0.180797 0.608448 L0.259591 0.580822 L0.358762 0.548945 L0.456576 0.49688 L0.486463 0.446941 L0.487822 0.362999 L0.453859 0.302434 L0.384574 0.265245 L0.286761 0.257813", "9": "M0.511026 0.437812 L0.491026 0.347812 L0.451026 0.297812 L0.391026 0.267812 L0.311026 0.257813 L0.231026 0.267812 L0.161026 0.297812 L0.111026 0.347812 L0.091026 0.417812 L0.111026 0.487812 L0.161026 0.537812 L0.231026 0.567812 L0.311026 0.577812 L0.391026 0.557812 L0.451026 0.517812 L0.491026 0.477812 L0.511026 0.437812 M0.510026 0.438812 L0.434026 0.636812 L0.381026 0.777812 L0.337026 0.879812 L0.301026 0.957812", "!": "M0.301026 0.270996 L0.301026 0.749566 M0.251466 0.94897 L0.350587 0.94897", '"': "M0.16504 0.270996 L0.16504 0.523022 M0.437013 0.270996 L0.437013 0.523022", "#": "M0.20958 0.282227 L0.146515 0.949754 M0.461844 0.282227 L0.398779 0.949754 M0.032999 0.526969 L0.600587 0.452796 M0.001465 0.82366 L0.569055 0.749486", $: "M0.307121 0.240234 L0.307121 1.083502 M0.490031 0.415915 L0.404676 0.328075 L0.23396 0.310507 L0.136407 0.398347 L0.099828 0.521324 L0.124213 0.591596 L0.197379 0.644299 L0.429061 0.697003 L0.502224 0.749708 L0.526613 0.837547 L0.477836 0.960526 L0.355897 1.013228 L0.197379 0.99566 L0.112021 0.942957 L0.07544 0.837547", "'": "M0.301026 0.270996 L0.301026 0.523022", "(": "M0.413087 0.241211 L0.372337 0.28347 L0.331589 0.334184 L0.290838 0.393349 L0.25009 0.460965 L0.219528 0.528584 L0.199153 0.5962 L0.188966 0.655364 L0.199153 0.714529 L0.219528 0.782146 L0.25009 0.849764 L0.290838 0.91738 L0.331589 0.976544 L0.372337 1.027258 L0.413087 1.069491", ")": "M0.188966 0.241211 L0.229716 0.28347 L0.270466 0.334184 L0.311213 0.393349 L0.351964 0.460965 L0.382526 0.528584 L0.4029 0.5962 L0.413087 0.655364 L0.4029 0.714529 L0.382526 0.782146 L0.351964 0.849764 L0.311213 0.91738 L0.270466 0.976544 L0.229716 1.027258 L0.188966 1.069491", "*": "M0.301026 0.458702 L0.301026 0.681942 M0.301026 0.458702 L0.520997 0.536834 M0.301026 0.458702 L0.439954 0.257813 M0.301026 0.458702 L0.162098 0.257813 M0.301026 0.458702 L0.081055 0.536834", "+": "M0.042969 0.66845 L0.559083 0.66845 M0.301023 0.428223 L0.301023 0.908661", ",": "M0.38672 0.852051 L0.215333 1.030661 L0.301025 1.119971", "-": "M0.173829 0.686035 L0.428224 0.686035", ".": "M0.362549 0.851074 L0.239503 0.851074", "/": "M0.062501 1.035249 L0.539551 0.270996", "<": "M0.559083 0.441895 L0.042969 0.66939 L0.042969 0.66939 L0.559083 0.896902", "=": "M0.042969 0.545898 L0.559083 0.545898 M0.042969 0.80837 L0.559083 0.80837", ">": "M0.042969 0.441895 L0.559083 0.66939 L0.559083 0.66939 L0.042969 0.896902", A: "M0.018067 0.94897 L0.290179 0.270996 L0.583986 0.94897 M0.155303 0.684521 L0.433548 0.684521", B: "M0.063965 0.94897 L0.063965 0.278953 L0.209356 0.270996 L0.342486 0.294394 L0.432179 0.37292 L0.418224 0.48773 L0.312686 0.549166 L0.084728 0.575531 L0.306377 0.589434 L0.468877 0.647456 L0.538087 0.736658 L0.5324 0.85202 L0.501247 0.902983 L0.42355 0.944398 L0.063965 0.94897", C: "M0.529054 0.419847 L0.498425 0.345196 L0.442238 0.292341 L0.33583 0.257813 L0.257199 0.268357 L0.187906 0.303748 L0.120243 0.385432 L0.072998 0.599844 L0.110073 0.815385 L0.165381 0.902183 L0.222883 0.942801 L0.334904 0.961214 L0.43253 0.937679 L0.504816 0.868999 L0.529054 0.772065", D: "M0.064454 0.94897 L0.071838 0.285078 L0.171217 0.270996 L0.247348 0.272633 L0.37101 0.306078 L0.462461 0.378304 L0.514748 0.475555 L0.535591 0.576392 L0.537599 0.652313 L0.528065 0.717381 L0.508562 0.772419 L0.445948 0.855695 L0.362356 0.90871 L0.225203 0.945862 L0.064454 0.94897", E: "M0.080078 0.270996 L0.080078 0.94897 M0.080078 0.270996 L0.521974 0.270996 M0.080078 0.609981 L0.389405 0.609981 M0.080078 0.94897 L0.521974 0.94897", F: "M0.086426 0.270996 L0.086426 0.94897 M0.091304 0.275607 L0.515626 0.275607 M0.091304 0.607677 L0.447344 0.607677", G: "M0.498034 0.284943 L0.374621 0.257813 L0.244219 0.268648 L0.160577 0.311997 L0.094556 0.398116 L0.056397 0.58404 L0.076752 0.785532 L0.120865 0.858197 L0.188947 0.916734 L0.271008 0.953591 L0.357069 0.961214 L0.43715 0.932047 L0.501262 0.858539 L0.545656 0.648611 L0.329595 0.648131", H: "M0.066895 0.270996 L0.066895 0.94897 M0.066895 0.595658 L0.530009 0.595658 M0.535157 0.270996 L0.535157 0.94897", I: "M0.301026 0.270996 L0.301026 0.94897", J: "M0.506839 0.270996 L0.507814 0.782193 L0.498468 0.846168 L0.480733 0.880789 L0.455864 0.90832 L0.426095 0.929408 L0.360746 0.954812 L0.302508 0.962139 L0.223573 0.953638 L0.16538 0.930312 L0.137072 0.907715 L0.116428 0.880312 L0.102822 0.848819 L0.095633 0.813947 L0.094239 0.776413", K: "M0.035401 0.270996 L0.035401 0.94897 M0.502258 0.316194 L0.035401 0.687823 M0.212484 0.582361 L0.566652 0.933903", L: "M0.07544 0.270996 L0.07544 0.94897 L0.526613 0.94897", M: "M0.042481 0.94897 L0.042481 0.270996 L0.301027 0.712492 L0.559571 0.270996 L0.559571 0.94897", N: "M0.067871 0.94897 L0.067871 0.270996 L0.534181 0.94897 L0.525031 0.270996", O: "M0.287293 0.961214 L0.19843 0.933567 L0.1172 0.849451 L0.057129 0.563945 L0.114348 0.350255 L0.18455 0.289392 L0.306101 0.257813 L0.42054 0.29572 L0.487543 0.365003 L0.544923 0.625294 L0.516366 0.789624 L0.465476 0.884596 L0.375084 0.949287 L0.287293 0.961214", P: "M0.070557 0.94897 L0.070557 0.28379 L0.20704 0.270996 L0.329134 0.278993 L0.408525 0.300514 L0.444022 0.317908 L0.500637 0.368929 L0.525796 0.423728 L0.531496 0.50384 L0.508934 0.554205 L0.473724 0.582043 L0.417577 0.604365 L0.336375 0.620372 L0.226014 0.629268 L0.082368 0.630258", Q: "M0.282435 1.050813 L0.195447 1.019646 L0.115933 0.924817 L0.057129 0.602943 L0.113139 0.362034 L0.18186 0.293418 L0.300844 0.257813 L0.412868 0.300553 L0.478457 0.37866 L0.534625 0.672103 L0.506671 0.857367 L0.456855 0.964437 L0.368371 1.037368 L0.282435 1.050813 M0.341225 0.815559 L0.544923 1.070653", R: "M0.034912 0.944112 L0.034912 0.288556 L0.227127 0.270996 L0.362038 0.276867 L0.443423 0.294907 L0.477644 0.309614 L0.505809 0.328757 L0.526616 0.352817 L0.544963 0.418061 L0.543241 0.475921 L0.524463 0.517817 L0.49076 0.546518 L0.444265 0.564799 L0.355195 0.578739 L0.047653 0.589627 M0.303054 0.617306 L0.56714 0.94897", S: "M0.483037 0.364333 L0.407613 0.267477 L0.22883 0.257813 L0.128623 0.327565 L0.087712 0.455539 L0.104656 0.518727 L0.168054 0.573307 L0.41928 0.617318 L0.503796 0.669342 L0.535157 0.759324 L0.493846 0.900055 L0.367668 0.961214 L0.205436 0.956661 L0.116711 0.907038 L0.066895 0.790334", T: "M0.022949 0.270996 L0.579103 0.270996 M0.309284 0.270996 L0.309284 0.94897", U: "M0.072022 0.270996 L0.07308 0.648875 L0.080372 0.75167 L0.099024 0.827813 L0.134786 0.885729 L0.181571 0.924023 L0.251464 0.95168 L0.339655 0.962139 L0.401553 0.951668 L0.45232 0.924086 L0.482701 0.891771 L0.495745 0.870529 L0.515699 0.81637 L0.525014 0.744626 L0.530031 0.272017", V: "M0.027832 0.270996 L0.320083 0.94897 L0.57422 0.270996", W: "M0 0.270996 L0.079799 0.940377 L0.285198 0.472884 L0.505255 0.94897 L0.602052 0.270996", X: "M0.009034 0.270996 L0.586805 0.94897 M0.593019 0.270996 L0.015246 0.94897", Y: "M0.018067 0.270996 L0.293132 0.574135 M0.583986 0.271959 L0.294954 0.57606 L0.305277 0.94897", Z: "M0.053711 0.270996 L0.548341 0.270996 L0.053711 0.94897 L0.548341 0.94897", "[": "M0.404542 0.240234 L0.197511 0.240234 L0.197511 1.069424 L0.404542 1.069424", "\\": "M0.062501 0.270996 L0.539551 1.035249", "]": "M0.19751 0.240234 L0.404542 0.240234 L0.404542 1.069424 L0.19751 1.069424", "^": "M0.035156 0.523931 L0.301024 0.270996 L0.566896 0.523931", _: "M0 1.160601 L0.602052 1.160601", a: "M0.527101 0.439941 L0.527101 0.973965 M0.527101 0.553824 L0.451366 0.477535 L0.376759 0.439941 L0.263722 0.439941 L0.187989 0.477535 L0.112255 0.553824 L0.074951 0.66881 L0.074951 0.745099 L0.112255 0.85898 L0.187989 0.93527 L0.263722 0.973965 L0.376759 0.973965 L0.451366 0.93527 L0.527101 0.85898", b: "M0.07666 0.240234 L0.07666 0.959985 M0.07666 0.582737 L0.151822 0.514237 L0.225865 0.480483 L0.338045 0.480483 L0.413211 0.514237 L0.488374 0.582737 L0.525392 0.685983 L0.525392 0.754485 L0.488374 0.856739 L0.413211 0.92524 L0.338045 0.959985 L0.225865 0.959985 L0.151822 0.92524 L0.07666 0.856739", c: "M0.512452 0.553823 L0.441624 0.477535 L0.371854 0.439941 L0.26614 0.439941 L0.195312 0.477535 L0.124486 0.553823 L0.0896 0.668808 L0.0896 0.745099 L0.124486 0.858979 L0.195312 0.93527 L0.26614 0.973965 L0.371854 0.973965 L0.441624 0.93527 L0.512452 0.858979", d: "M0.525392 0.240234 L0.525392 0.959985 M0.525392 0.582737 L0.450232 0.514237 L0.376189 0.480483 L0.264006 0.480483 L0.188844 0.514237 L0.11368 0.582737 L0.076661 0.685983 L0.076661 0.754485 L0.11368 0.856739 L0.188844 0.92524 L0.264006 0.959985 L0.376189 0.959985 L0.450232 0.92524 L0.525392 0.856739", e: "M0.059571 0.668808 L0.542482 0.668808 M0.542482 0.592521 L0.502641 0.516231 L0.461594 0.477535 L0.381914 0.439941 L0.261186 0.439941 L0.180299 0.477535 L0.099412 0.553823 L0.059571 0.668808 L0.059571 0.745099 L0.099412 0.858979 L0.180299 0.93527 L0.261186 0.973965 L0.381914 0.973965 L0.461594 0.93527 L0.542482 0.858979", f: "M0.512941 0.240234 L0.406984 0.240234 L0.301026 0.274346 L0.248047 0.374731 L0.248047 0.946817 M0.089112 0.476088 L0.459965 0.476088", g: "M0.525392 0.439941 L0.525392 0.989395 L0.488373 1.091918 L0.45023 1.126757 L0.376189 1.160601 L0.264004 1.160601 L0.188844 1.126757 L0.113681 1.058075 L0.076661 0.954555 M0.525392 0.542467 L0.45023 0.473786 L0.376189 0.439941 L0.264004 0.439941 L0.188844 0.473786 L0.113681 0.542467 L0.076661 0.645988 L0.076661 0.714669 L0.113681 0.817193 L0.188844 0.885875 L0.264004 0.920713 L0.376189 0.920713 L0.45023 0.885875 L0.525392 0.817193", h: "M0.092041 0.240234 L0.092041 0.946817 M0.092041 0.61058 L0.205937 0.509225 L0.282214 0.476086 L0.396109 0.476086 L0.47187 0.509225 L0.510011 0.61058 L0.510011 0.946817", i: "M0.261026 0.240234 L0.341026 0.240234 M0.300978 0.476089 L0.300978 0.946817", j: "M0.3853 0.240234 L0.447023 0.240234 M0.416159 0.465708 L0.416159 1.011689 L0.383887 1.108586 L0.252832 1.140264 L0.15503 1.108586", k: "M0.065186 0.240234 L0.065186 0.946817 M0.493824 0.476086 L0.065186 0.812323 M0.236758 0.677829 L0.536867 0.946817", l: "M0.301026 0.234863 L0.301026 0.946441", m: "M0.050538 0.439941 L0.050538 0.960796 M0.050538 0.588758 L0.114405 0.476607 L0.157178 0.439941 L0.236864 0.439941 L0.279637 0.476607 L0.32241 0.588758 L0.32241 0.960796 M0.32241 0.588758 L0.386281 0.476607 L0.428467 0.439941 L0.50874 0.439941 L0.551515 0.476607 L0.551515 0.960796", n: "M0.092041 0.439941 L0.092041 0.960796 M0.092041 0.588758 L0.205936 0.476607 L0.282216 0.439941 L0.396113 0.439941 L0.471871 0.476607 L0.510011 0.588758 L0.510011 0.960796", o: "M0.247175 0.439941 L0.175178 0.477535 L0.103186 0.553823 L0.066895 0.668808 L0.066895 0.745099 L0.103186 0.858979 L0.175178 0.93527 L0.247175 0.973965 L0.354874 0.973965 L0.426872 0.93527 L0.498866 0.858979 L0.535157 0.745099 L0.535157 0.668808 L0.498866 0.553823 L0.426872 0.477535 L0.354874 0.439941 L0.247175 0.439941", p: "M0.076904 0.439941 L0.076904 1.154244 M0.076904 0.541563 L0.151986 0.473487 L0.225944 0.439941 L0.338005 0.439941 L0.413087 0.473487 L0.488166 0.541563 L0.525148 0.644169 L0.525148 0.712246 L0.488166 0.813866 L0.413087 0.881942 L0.338005 0.916471 L0.225944 0.916471 L0.151986 0.881942 L0.076904 0.813866", q: "M0.525148 0.441895 L0.525148 1.156195 M0.525148 0.5435 L0.450067 0.47544 L0.376106 0.441895 L0.264042 0.441895 L0.188966 0.47544 L0.113885 0.5435 L0.076905 0.646108 L0.076905 0.714187 L0.113885 0.815809 L0.188966 0.883886 L0.264042 0.918418 L0.376106 0.918418 L0.450067 0.883886 L0.525148 0.815809", r: "M0.107422 0.439941 L0.107422 0.960796 M0.107422 0.663164 L0.155824 0.551014 L0.252626 0.476607 L0.349428 0.439941 L0.49463 0.439941", s: "M0.475556 0.477535 L0.400757 0.439941 L0.276092 0.439941 L0.176361 0.477535 L0.101563 0.553823 L0.101563 0.630112 L0.176361 0.668808 L0.301024 0.668808 L0.425688 0.745099 L0.50049 0.821387 L0.50049 0.897677 L0.425688 0.93527 L0.325956 0.973965 L0.201295 0.973965 L0.126496 0.93527 L0.101563 0.858979", t: "M0.246032 0.297852 L0.246032 0.826549 L0.301023 0.919323 L0.411011 0.950848 L0.520997 0.950848 M0.081055 0.515799 L0.466004 0.515799", u: "M0.092041 0.454102 L0.092041 0.826134 L0.13018 0.937211 L0.205936 0.974954 L0.319832 0.974954 L0.396113 0.937211 L0.510011 0.826134 M0.510011 0.454102 L0.510011 0.974954", v: "M0.048828 0.453125 L0.301026 0.961719 M0.553224 0.453125 L0.301026 0.961719", w: "M0 0.453125 L0.150512 0.961719 M0.301024 0.453125 L0.150512 0.961719 M0.301024 0.453125 L0.451539 0.961719 M0.602052 0.453125 L0.451539 0.961719", x: "M0.03711 0.453125 L0.564943 0.961719 M0.564943 0.453125 L0.03711 0.961719", y: "M0.084618 0.453125 L0.320232 0.921476 M0.55713 0.453125 L0.320232 0.921476 L0.242119 1.055289 L0.163369 1.122196 L0.084618 1.155166 L0.044922 1.155166", z: "M0.505373 0.452148 L0.09668 0.961651 M0.09668 0.452148 L0.505373 0.452148 M0.09668 0.961651 L0.505373 0.961651" };
var Mt = {};
for (let t in St) {
  Mt[t] = [];
  let e = St[t].split("M").slice(1).map((r) => r.split("L").map((n) => n.trim().split(" ").map(parseFloat)));
  for (let r of e) for (let n = 0; n < r.length - 1; n++) Mt[t].push({ x1: r[n][0], y1: 1 - r[n][1], x2: r[n + 1][0], y2: 1 - r[n + 1][1] });
}
var He = (() => {
  let t = new Uint8Array(4), e = new Uint32Array(t.buffer);
  return !((e[0] = 1) & t[0]);
})();
var Ve = { int8: globalThis.Int8Array, uint8: globalThis.Uint8Array, int16: globalThis.Int16Array, uint16: globalThis.Uint16Array, int32: globalThis.Int32Array, uint32: globalThis.Uint32Array, uint64: globalThis.BigUint64Array, int64: globalThis.BigInt64Array, float32: globalThis.Float32Array, float64: globalThis.Float64Array };
var ne = [];
for (let t = 0; t < 256; t++) {
  let e = t;
  for (let r = 0; r < 8; r++) if (e & 1) e = 3988292384 ^ e >>> 1;
  else e = e >>> 1;
  ne[t] = e;
}
var ce = new Uint16Array([255]);
var le = new Uint8Array(ce.buffer);
var nn = le[0] === 255;
var fe = new Uint16Array([255]);
var he = new Uint8Array(fe.buffer);
var on = he[0] === 255;
var an = new Uint8Array(0);
var ln = Uint8Array.of(137, 80, 78, 71, 13, 10, 26, 10);
var un = new TextDecoder("latin1");
var { cos: gr, sin: yr, PI: xr } = Math;
var { tan: vr } = Math;
var _e = te(Pt(), 1);
function J(t, e) {
  if (t.points) for (let r of t.points) r.step = e;
  if (t.lines) for (let r of t.lines) r.step = e;
  if (t.infiniteLines) for (let r of t.infiniteLines) r.step = e;
  if (t.polygons) for (let r of t.polygons) r.step = e;
  if (t.rects) for (let r of t.rects) r.step = e;
  if (t.circles) for (let r of t.circles) r.step = e;
  if (t.texts) for (let r of t.texts) r.step = e;
  return t;
}
var q = class {
  MAX_ITERATIONS = 1e5;
  solved = false;
  failed = false;
  iterations = 0;
  progress = 0;
  error = null;
  activeSubSolver;
  failedSubSolvers;
  timeToSolve;
  stats = {};
  _setupDone = false;
  getSolverName() {
    return this.constructor.name;
  }
  setup() {
    if (this._setupDone) return;
    this._setup(), this._setupDone = true;
  }
  _setup() {
  }
  step() {
    if (!this._setupDone) this.setup();
    if (this.solved) return;
    if (this.failed) return;
    this.iterations++;
    try {
      this._step();
    } catch (t) {
      throw this.error = `${this.getSolverName()} error: ${t}`, this.failed = true, t;
    }
    if (!this.solved && this.iterations >= this.MAX_ITERATIONS) this.tryFinalAcceptance();
    if (!this.solved && this.iterations >= this.MAX_ITERATIONS) this.error = `${this.getSolverName()} ran out of iterations`, this.failed = true;
    if ("computeProgress" in this) this.progress = this.computeProgress();
  }
  _step() {
  }
  getConstructorParams() {
    throw Error("getConstructorParams not implemented");
  }
  getOutput() {
    return null;
  }
  solve() {
    let t = Date.now();
    while (!this.solved && !this.failed) this.step();
    let e = Date.now();
    this.timeToSolve = e - t;
  }
  visualize() {
    return { lines: [], points: [], rects: [], circles: [] };
  }
  tryFinalAcceptance() {
  }
  preview() {
    return { lines: [], points: [], rects: [], circles: [] };
  }
};
function nt(t, e, r, n = {}) {
  return { solverName: t, solverClass: e, getConstructorParams: r, onSolved: n.onSolved };
}
var Ct = class extends q {
  startTimeOfStage = {};
  endTimeOfStage = {};
  timeSpentOnStage = {};
  firstIterationOfStage = {};
  currentPipelineStageIndex = 0;
  inputProblem;
  pipelineOutputs = {};
  constructor(t) {
    super();
    this.inputProblem = t, this.MAX_ITERATIONS = 1e6;
  }
  _step() {
    let t = this.pipelineDef[this.currentPipelineStageIndex];
    if (!t) {
      this.solved = true;
      return;
    }
    if (this.activeSubSolver) {
      if (this.activeSubSolver.step(), this.activeSubSolver.solved) {
        this.endTimeOfStage[t.solverName] = performance.now(), this.timeSpentOnStage[t.solverName] = this.endTimeOfStage[t.solverName] - this.startTimeOfStage[t.solverName];
        let r = this.activeSubSolver.getOutput();
        if (r !== null) this.pipelineOutputs[t.solverName] = r;
        t.onSolved?.(this), this.activeSubSolver = null, this.currentPipelineStageIndex++;
      } else if (this.activeSubSolver.failed) this.error = this.activeSubSolver?.error, this.failed = true, this.activeSubSolver = null;
      return;
    }
    let e = t.getConstructorParams(this);
    this.activeSubSolver = new t.solverClass(...e), this[t.solverName] = this.activeSubSolver, this.timeSpentOnStage[t.solverName] = 0, this.startTimeOfStage[t.solverName] = performance.now(), this.firstIterationOfStage[t.solverName] = this.iterations;
  }
  solveUntilStage(t) {
    while (this.getCurrentStageName().toLowerCase() !== t.toLowerCase()) if (this.step(), this.failed || this.solved) break;
  }
  getCurrentStageName() {
    return this.pipelineDef[this.currentPipelineStageIndex]?.solverName ?? "none";
  }
  getStageProgress() {
    let t = this.pipelineDef.length;
    if (t === 0) return 1;
    let e = this.activeSubSolver?.progress ?? 0;
    return (this.currentPipelineStageIndex + e) / t;
  }
  getStageStats() {
    let t = {};
    for (let e of this.pipelineDef) {
      let r = this.timeSpentOnStage[e.solverName] || 0, n = this.firstIterationOfStage[e.solverName] || 0, o = this.iterations, m = e.solverName === this.getCurrentStageName() ? o - n : 0, a = this.currentPipelineStageIndex > this.pipelineDef.findIndex((f) => f.solverName === e.solverName);
      t[e.solverName] = { timeSpent: r, iterations: m, completed: a };
    }
    return t;
  }
  initialVisualize() {
    return null;
  }
  finalVisualize() {
    return null;
  }
  visualize() {
    if (!this.solved && this.activeSubSolver) return this.activeSubSolver.visualize();
    let t = 0, e = this.initialVisualize();
    if (e) J(e, 0), t = 1;
    let r = null;
    if (this.solved) r = this.finalVisualize();
    let n = [e].filter(Boolean).concat(this.pipelineDef.map((o, m) => {
      let f = this[o.solverName]?.visualize();
      if (!f) return null;
      return J(f, m + t), f;
    }).filter(Boolean));
    if (n.length === 0) return { points: [], rects: [], lines: [], circles: [], texts: [] };
    if (this.solved && r) J(r, n.length + t + 1), n.push(r);
    if (n.length === 1) return n[0];
    return { points: n.flatMap((o) => o.points || []), rects: n.flatMap((o) => o.rects || []), lines: n.flatMap((o) => o.lines || []), circles: n.flatMap((o) => o.circles || []), texts: n.flatMap((o) => o.texts || []) };
  }
  preview() {
    if (this.activeSubSolver) return this.activeSubSolver.preview();
    return super.preview();
  }
  computeProgress() {
    return this.getStageProgress();
  }
  getStageOutput(t) {
    return this.pipelineOutputs[t];
  }
  getAllOutputs() {
    return { ...this.pipelineOutputs };
  }
  hasStageOutput(t) {
    return t in this.pipelineOutputs;
  }
  getSolver(t) {
    return this[t];
  }
};
function Ot(t, e) {
  if (t.route_type === "through_pad") return e ? t.end : t.start;
  return { x: t.x, y: t.y };
}
function ht(t, e) {
  if (t.route_type === "wire") return t.layer;
  if (t.route_type === "via") return e ? t.to_layer : t.from_layer;
  return e ? t.end_layer : t.start_layer;
}
function rt(t) {
  let e = /* @__PURE__ */ new Set();
  for (let n of t) {
    if (n.type !== "source_bus") continue;
    if (n.max_length_skew === void 0 && n.target_length === void 0 && !n.length_match_source_trace_ids?.length) continue;
    for (let o of n.source_trace_ids) e.add(o);
    for (let o of n.length_match_source_trace_ids ?? []) e.add(o);
  }
  let r = [];
  for (let [n, o] of t.entries()) {
    if (o.type !== "pcb_trace") continue;
    for (let m = 0; m < o.route.length - 1; m++) {
      let a = o.route[m], f = o.route[m + 1], O = (N) => ["wire", "via", "through_pad"].includes(N.route_type);
      if (!O(a) || !O(f)) throw Error(o.pcb_trace_id + ": unsupported route point at " + m);
      if (a.route_type !== "wire" && f.route_type !== "wire") continue;
      if (ht(a, true) !== ht(f, false)) continue;
      let l = Ot(a, true), k = Ot(f, false);
      if (![l.x, l.y, k.x, k.y].every(Number.isFinite)) throw Error(o.pcb_trace_id + ": nonfinite route coordinates at " + m);
      let h = Math.hypot(k.x - l.x, k.y - l.y);
      if (h <= 1e-9) continue;
      let c = a.route_type === "wire" ? a : f, v = c.route_type === "wire" ? Math.max(c.width, c.end_width ?? c.width) : 0;
      if (!Number.isFinite(v) || v <= 0) throw Error(o.pcb_trace_id + ": invalid wire width at " + m);
      r.push({ pcbTraceId: o.pcb_trace_id, sourceTraceId: o.source_trace_id, pcbGroupId: o.pcb_group_id, subcircuitId: o.subcircuit_id, circuitJsonIndex: n, startRouteIndex: m, endRouteIndex: m + 1, layer: ht(a, true), start: { ...l }, end: { ...k }, width: v, lengthMm: h });
    }
  }
  return { circuitJson: t, segments: r, lengthMatchedSourceTraceIds: e };
}
function it(t) {
  return t.map((e) => ({ issue: e, color: "#ff5555", message: e.message }));
}
function U(t, e) {
  let r = it(e);
  return { coordinateSystem: "cartesian", lines: [...t.segments.map((n) => ({ points: [n.start, n.end], strokeColor: n.layer === "bottom" ? "#60a5fa" : "#94a3b8", strokeWidth: n.width })), ...r.flatMap(({ issue: n, color: o, message: m }) => (n.constituentSegments ?? [n]).map((a) => ({ points: [a.start, a.end], strokeColor: o, strokeWidth: Math.max(a.width * 2, 0.25), label: m })))], points: r.map(({ issue: n, color: o, message: m }, a) => ({ ...n.location, color: o, label: a + 1 + ": " + m })) };
}
function Ee(t, e, r) {
  let n = r.x - e.x, o = r.y - e.y, m = n * n + o * o, a = m ? Math.max(0, Math.min(1, ((t.x - e.x) * n + (t.y - e.y) * o) / m)) : 0;
  return Math.hypot(t.x - e.x - a * n, t.y - e.y - a * o);
}
function st(t) {
  let e = [], r = (n) => {
    let o = [[0, n.length - 1]];
    while (o.length) {
      let [m, a] = o.pop();
      if (m === a) continue;
      let f = n[m].start, O = n[a].end, l = 1 / 0, k = -1, h = m;
      for (let v = m; v <= a; v++) {
        if (l = Math.min(l, n[v].width), v === a) continue;
        let N = Ee(n[v].end, f, O);
        if (N > k) k = N, h = v;
      }
      if (k > l / 2 + 1e-9) {
        o.push([h + 1, a], [m, h]);
        continue;
      }
      let c = n.slice(m, a + 1);
      e.push({ ...n[m], endRouteIndex: n[a].endRouteIndex, end: O, width: c.reduce((v, N) => Math.max(v, N.width), 0), lengthMm: Math.hypot(O.x - f.x, O.y - f.y), constituentSegments: c, maxCenterlineDeviationMm: k <= 1e-9 ? 0 : k });
    }
  };
  for (let n of ut(t)) r(n);
  return [...t.segments.filter((n) => !ot(t, n)), ...e];
}
function ot(t, e) {
  return e.sourceTraceId !== void 0 && (t.lengthMatchedSourceTraceIds?.has(e.sourceTraceId) ?? false);
}
function ut(t) {
  let e = [], r = [];
  for (let n of t.segments) {
    if (ot(t, n)) {
      if (r.length) e.push(r);
      r = [];
      continue;
    }
    let o = r.at(-1);
    if (o) {
      let m = t.circuitJson[n.circuitJsonIndex];
      if (!(o.circuitJsonIndex === n.circuitJsonIndex && m.type === "pcb_trace" && m.route.slice(o.endRouteIndex, n.startRouteIndex + 1).every((O) => O.route_type === "wire" && O.layer === n.layer)) || o.layer !== n.layer || Math.hypot(o.end.x - n.start.x, o.end.y - n.start.y) > 1e-9) e.push(r), r = [];
    }
    r.push(n);
  }
  if (r.length) e.push(r);
  return e;
}
var dt = class extends q {
  params;
  segments = [];
  nextSegment = 0;
  candidates;
  constructor(t) {
    super();
    this.params = t;
    if (!Number.isFinite(t.maxSegmentLengthMm) || t.maxSegmentLengthMm <= 0) throw Error("maxSegmentLengthMm must be finite and positive");
    this.candidates = st(t.ctx), this.MAX_ITERATIONS = this.candidates.length + 2;
  }
  _step() {
    let t = this.candidates[this.nextSegment++];
    if (!t) {
      this.solved = true, this.progress = 1;
      return;
    }
    if (t.lengthMm > this.params.maxSegmentLengthMm) this.segments.push(t);
    this.progress = this.nextSegment / this.candidates.length, this.stats = { segmentsChecked: this.nextSegment, candidateCount: this.segments.length };
  }
  getOutput() {
    return this.segments;
  }
  visualize() {
    return U(this.params.ctx, []);
  }
  getConstructorParams() {
    return [this.params];
  }
};
function at(t, e) {
  let { start: r, end: n } = t, m = (t.constituentSegments ?? [t]).reduce((a, f) => ({ minX: Math.min(a.minX, f.start.x - f.width / 2, f.end.x - f.width / 2), minY: Math.min(a.minY, f.start.y - f.width / 2, f.end.y - f.width / 2), maxX: Math.max(a.maxX, f.start.x + f.width / 2, f.end.x + f.width / 2), maxY: Math.max(a.maxY, f.start.y + f.width / 2, f.end.y + f.width / 2) }), { minX: 1 / 0, minY: 1 / 0, maxX: -1 / 0, maxY: -1 / 0 });
  return { ...t, issueId: e + ":" + t.circuitJsonIndex + ":" + t.startRouteIndex, severity: "error", message: "", location: { x: (r.x + n.x) / 2, y: (r.y + n.y) / 2 }, bounds: m };
}
var K = class extends q {
  ctx;
  issues = [];
  nextSegment = 0;
  constructor(t) {
    super();
    this.ctx = t;
    this.MAX_ITERATIONS = t.segments.length + 2;
  }
  _step() {
    let t = this.ctx.segments[this.nextSegment++];
    if (!t) {
      this.solved = true, this.progress = 1;
      return;
    }
    let e = this.checkSegment(t);
    if (e) this.issues.push(e);
    this.progress = this.nextSegment / this.ctx.segments.length, this.stats = { segmentsChecked: this.nextSegment, issueCount: this.issues.length };
  }
  getOutput() {
    return this.issues;
  }
  visualize() {
    return U(this.ctx, this.issues);
  }
};
var pt = class extends K {
  params;
  constructor(t) {
    super({ ...t.ctx, segments: t.candidateSegments ?? st(t.ctx) });
    this.params = t;
    if (!Number.isFinite(t.maxSegmentLengthMm) || t.maxSegmentLengthMm <= 0) throw Error("maxSegmentLengthMm must be finite and positive");
    if (!Number.isFinite(t.angleToleranceDegrees) || t.angleToleranceDegrees < 0 || t.angleToleranceDegrees >= 22.5) throw Error("angleToleranceDegrees must be in [0, 22.5)");
    let e = /* @__PURE__ */ new Set();
    for (let r of this.ctx.segments) {
      if (!r.constituentSegments || !this.checkSegment(r)) continue;
      for (let n of r.constituentSegments) e.add(n.circuitJsonIndex + ":" + n.startRouteIndex);
    }
    this.ctx = { ...this.ctx, segments: this.ctx.segments.filter((r) => r.constituentSegments || !e.has(r.circuitJsonIndex + ":" + r.startRouteIndex)) };
  }
  checkSegment(t) {
    if (ot(this.params.ctx, t)) return;
    if (t.lengthMm <= this.params.maxSegmentLengthMm) return;
    let e = (Math.atan2(t.end.y - t.start.y, t.end.x - t.start.x) * 180 / Math.PI + 360) % 360, r = Math.round(e / 45) * 45, n = Math.abs(e - r), o = Math.atan2(2 * (t.maxCenterlineDeviationMm ?? 0), t.lengthMm) * 180 / Math.PI;
    if (n <= this.params.angleToleranceDegrees + o + 1e-10) return;
    return { ...at(t, "odd-angle"), lineItemType: "PcbTraceSegmentOddAngle", maxSegmentLengthMm: this.params.maxSegmentLengthMm, angleDegrees: e, nearestAllowedAngleDegrees: r % 360, deviationDegrees: n, angleToleranceDegrees: this.params.angleToleranceDegrees, ...t.constituentSegments ? { angleUncertaintyDegrees: o } : {}, message: t.pcbTraceId + (t.constituentSegments ? " run " + t.startRouteIndex + " \u2192 " + t.endRouteIndex : " segment " + t.startRouteIndex) + " on " + t.layer + " is " + t.lengthMm.toFixed(3) + " mm long (threshold " + this.params.maxSegmentLengthMm + " mm) and at " + e.toFixed(3) + "\xB0; nearest allowed direction " + r % 360 + "\xB0 (deviation " + n.toFixed(3) + "\xB0, tolerance " + this.params.angleToleranceDegrees + "\xB0" + (o ? ", approximation allowance " + o.toFixed(3) + "\xB0" : "") + ")" };
  }
  visualize() {
    return U(this.params.ctx, this.issues);
  }
  getConstructorParams() {
    return [this.params];
  }
};
function Pe(t) {
  return (Math.atan2(t.end.y - t.start.y, t.end.x - t.start.x) * 180 / Math.PI + 360) % 360;
}
function mt(t, e) {
  return Math.abs((t - e + 540) % 360 - 180);
}
var gt = class extends K {
  params;
  bendCounts = /* @__PURE__ */ new Map();
  constructor(t) {
    super({ ...t.ctx, segments: [] });
    this.params = t;
    let e = t.minStaircaseBends ?? 6, r = t.minStaircaseLengthMm ?? 2, n = t.maxStairStepLengthMm ?? 1;
    if (!Number.isInteger(e) || e < 2) throw Error("minStaircaseBends must be an integer of at least 2");
    if (!Number.isFinite(r) || r <= 0) throw Error("minStaircaseLengthMm must be finite and positive");
    if (!Number.isFinite(n) || n <= 0) throw Error("maxStairStepLengthMm must be finite and positive");
    let o = [];
    for (let m of ut(t.ctx)) {
      let a = [];
      for (let f of m) {
        let O = Pe(f), l = a.at(-1);
        if (l && mt(l.direction, O) <= 4.0000000001) l.parts.push(f), l.lengthMm += f.lengthMm;
        else a.push({ direction: O, parts: [f], lengthMm: f.lengthMm });
      }
      for (let f = 0; f < a.length - 1; ) {
        let O = a[f], l = a[f + 1], k = mt(O.direction, l.direction);
        if (k < 14.9999999999 || k > 90.0000000001 || O.lengthMm > n + 1e-9 || l.lengthMm > n + 1e-9) {
          f++;
          continue;
        }
        let h = f + 2;
        while (h < a.length && mt(a[h].direction, a[f + (h - f) % 2].direction) <= 4.0000000001 && a[h].lengthMm <= n + 1e-9) h++;
        let c = a.slice(f, h).flatMap((N) => N.parts), v = c.reduce((N, W) => N + W.lengthMm, 0);
        if (h - f - 1 >= e && v + 1e-9 >= r) {
          let N = { ...c[0], end: c.at(-1).end, endRouteIndex: c.at(-1).endRouteIndex, width: c.reduce((W, z) => Math.max(W, z.width), 0), lengthMm: v, constituentSegments: c };
          o.push(N), this.bendCounts.set(N, h - f - 1), f = h;
        } else f = h - 1;
      }
    }
    this.ctx = { ...t.ctx, segments: o }, this.MAX_ITERATIONS = o.length + 2;
  }
  checkSegment(t) {
    let e = this.bendCounts.get(t);
    return { ...at(t, "staircase"), lineItemType: "PcbTraceStaircase", bendCount: e, minStaircaseBends: this.params.minStaircaseBends ?? 6, minStaircaseLengthMm: this.params.minStaircaseLengthMm ?? 2, maxStairStepLengthMm: this.params.maxStairStepLengthMm ?? 1, message: `${t.pcbTraceId} route ${t.startRouteIndex} \u2192 ${t.endRouteIndex} on ${t.layer} has ${e} alternating staircase bends over ${t.lengthMm.toFixed(3)} mm` };
  }
  visualize() {
    return U(this.params.ctx, this.issues);
  }
  getConstructorParams() {
    return [this.params];
  }
};
var yt = class extends Ct {
  options;
  ctx;
  pipelineDef = [nt("LongTraceSegmentSolver", dt, (t) => [{ ctx: t.ctx, maxSegmentLengthMm: t.options.maxSegmentLengthMm ?? 5 }]), nt("OddAngleTraceSegmentSolver", pt, (t) => [{ ctx: t.ctx, candidateSegments: t.getSolver("LongTraceSegmentSolver").getOutput(), maxSegmentLengthMm: t.options.maxSegmentLengthMm ?? 5, angleToleranceDegrees: t.options.angleToleranceDegrees ?? 4 }]), nt("StaircaseTraceSolver", gt, (t) => [{ ctx: t.ctx, minStaircaseBends: t.options.minStaircaseBends, minStaircaseLengthMm: t.options.minStaircaseLengthMm, maxStairStepLengthMm: t.options.maxStairStepLengthMm }])];
  constructor(t, e = {}) {
    super(t);
    this.options = e;
    if (e.issueTypes) {
      let r = e.issueTypes.includes("PcbTraceSegmentOddAngle"), n = e.issueTypes.includes("PcbTraceStaircase");
      this.pipelineDef = this.pipelineDef.filter((o) => o.solverName === "StaircaseTraceSolver" ? n : r);
    }
    this.MAX_ITERATIONS = t.reduce((r, n) => r + (n.type === "pcb_trace" ? n.route.length * 5 : 0), 10);
  }
  _setup() {
    this.ctx = rt(this.inputProblem);
  }
  getOutput() {
    return { issues: [...this.getSolver("OddAngleTraceSegmentSolver")?.getOutput() ?? [], ...this.getSolver("StaircaseTraceSolver")?.getOutput() ?? []] };
  }
  getConstructorParams() {
    return [this.inputProblem, this.options];
  }
  initialVisualize() {
    return this.setup(), U(this.ctx, []);
  }
  finalVisualize() {
    return this.setup(), U(this.ctx, this.getOutput().issues);
  }
};
function Nt(t, e = {}) {
  let r = new yt(t, e);
  if (r.solve(), r.failed) throw Error(r.error ?? "PCB style analysis failed");
  return r.getOutput();
}

// lib/check-pcb-trace-style.ts
function checkPcbTraceStyle(circuitJson) {
  return Nt(circuitJson, {
    issueTypes: ["PcbTraceSegmentOddAngle"]
  }).issues.filter((issue) => issue.lineItemType === "PcbTraceSegmentOddAngle").map((issue) => ({
    type: "pcb_trace_style_warning",
    pcb_trace_style_warning_id: `pcb_trace_style_warning_${issue.pcbTraceId}_${issue.startRouteIndex}_${issue.endRouteIndex}`,
    warning_type: "pcb_trace_style_warning",
    styling_issue_type: "long_segment_at_odd_angle",
    pcb_trace_id: issue.pcbTraceId,
    source_trace_id: issue.sourceTraceId,
    subcircuit_id: issue.subcircuitId,
    layer: issue.layer,
    start_route_index: issue.startRouteIndex,
    end_route_index: issue.endRouteIndex,
    segment_start: issue.start,
    segment_end: issue.end,
    center: issue.location,
    segment_length: issue.lengthMm,
    minimum_segment_length: issue.maxSegmentLengthMm,
    angle_degrees: issue.angleDegrees,
    nearest_allowed_angle_degrees: issue.nearestAllowedAngleDegrees,
    angle_deviation_degrees: issue.deviationDegrees,
    angle_tolerance_degrees: issue.angleToleranceDegrees,
    // Analyzer messages include IDs; format readable circuit names instead.
    message: `${getReadableNameForTrace(circuitJson, issue.pcbTraceId)} has a ${issue.lengthMm.toFixed(2)} mm segment on ${issue.layer} at ${issue.angleDegrees.toFixed(2)}\xB0, ${issue.deviationDegrees.toFixed(2)}\xB0 from the nearest allowed direction (${issue.nearestAllowedAngleDegrees}\xB0). Prefer a multiple of 45\xB0 for segments longer than ${issue.maxSegmentLengthMm} mm (tolerance ${issue.angleToleranceDegrees}\xB0).`
  }));
}

// lib/check-pcb-routing-constraints.ts
import Flatbush5 from "flatbush";
import {
  pcb_bus_routing_constraint_error,
  pcb_bus_routing_constraint_warning
} from "circuit-json";

// lib/util/measure-route.ts
function measureRoute(source, traces, circuit) {
  if (source.connected_source_port_ids.length !== 2 || !traces.length) return;
  const ports = source.connected_source_port_ids.map(
    (id) => circuit.filter(
      (e) => e.type === "pcb_port" && e.source_port_id === id
    )
  );
  if (ports.some((p) => p.length !== 1)) return;
  const nodes = /* @__PURE__ */ new Map();
  const edges = /* @__PURE__ */ new Set();
  const segments = [];
  const key = (p, layer) => `${p.x.toFixed(6)},${p.y.toFixed(6)},${layer}`;
  let valid = true;
  const add = (a, al, b, bl, width) => {
    if (![a.x, a.y, b.x, b.y, width].every(Number.isFinite)) {
      valid = false;
      return;
    }
    const ak = key(a, al), bk = key(b, bl);
    if (ak === bk) return;
    const edge = [ak, bk].sort().join("|");
    if (edges.has(edge)) {
      valid = false;
      return;
    }
    edges.add(edge);
    for (const [k, p, l, other] of [
      [ak, a, al, bk],
      [bk, b, bl, ak]
    ]) {
      if (!nodes.has(k)) nodes.set(k, { point: p, layer: l, edges: /* @__PURE__ */ new Set() });
      nodes.get(k).edges.add(other);
    }
    if (al === bl) {
      if (width <= 0) valid = false;
      segments.push({ a, b, layer: al, width });
    } else if (Math.hypot(a.x - b.x, a.y - b.y) > 1e-6) valid = false;
  };
  for (const trace of traces) {
    for (let i = 0; i < trace.route.length; i++) {
      const p = trace.route[i], q2 = trace.route[i + 1];
      if (p.route_type === "through_pad" || q2?.route_type === "through_pad")
        return;
      if (p.route_type === "wire" && p.width_interpolation_mode) return;
      if (p.route_type === "via") add(p, p.from_layer, p, p.to_layer, 0);
      if (!q2) continue;
      const pl = p.route_type === "wire" ? p.layer : p.to_layer;
      const ql = q2.route_type === "wire" ? q2.layer : q2.from_layer;
      if (pl !== ql) {
        valid = false;
        continue;
      }
      const width = p.route_type === "wire" ? Math.max(p.width, p.end_width ?? p.width) : q2.route_type === "wire" ? q2.width : 0;
      add(p, pl, q2, ql, width);
    }
  }
  for (const via of circuit.filter((e) => e.type === "pcb_via")) {
    const present = via.layers.filter((layer) => nodes.has(key(via, layer)));
    if (present.length > 2) {
      valid = false;
      continue;
    }
    if (present.length === 2) {
      const a = key(via, present[0]), b = key(via, present[1]);
      if (!edges.has([a, b].sort().join("|")))
        add(via, present[0], via, present[1], 0);
    }
  }
  if (!valid || !segments.length || [...nodes.values()].some((n) => n.edges.size > 2))
    return;
  const ends = [...nodes.entries()].filter(([, n]) => n.edges.size === 1);
  if (ends.length !== 2) return;
  const matches = (p, n) => p.layers.includes(n.layer) && Math.hypot(p.x - n.point.x, p.y - n.point.y) <= 1e-5;
  const [first, last] = ports.map((p) => p[0]);
  if (!(matches(first, ends[0][1]) && matches(last, ends[1][1])) && !(matches(first, ends[1][1]) && matches(last, ends[0][1])))
    return;
  const seen = /* @__PURE__ */ new Set(), pending = [ends[0][0]];
  while (pending.length) {
    const k = pending.pop();
    if (seen.has(k)) continue;
    seen.add(k);
    pending.push(...nodes.get(k).edges);
  }
  if (seen.size !== nodes.size) return;
  return {
    length: segments.reduce(
      (s, e) => s + Math.hypot(e.a.x - e.b.x, e.a.y - e.b.y),
      0
    ),
    manhattan: Math.abs(first.x - last.x) + Math.abs(first.y - last.y),
    segments
  };
}

// lib/util/check-route-spacing.ts
var dot2 = (a, b) => a.x * b.x + a.y * b.y;
var subtract = (a, b) => ({ x: a.x - b.x, y: a.y - b.y });
function capsuleIntervals(a, b, radius) {
  const v = subtract(a.b, a.a), u = subtract(b.b, b.a), d = subtract(a.a, b.a);
  const uu = dot2(u, u);
  if (uu === 0) return [];
  const start = dot2(d, u) / uu, slope = dot2(v, u) / uu;
  const cuts = [0, 1];
  if (Math.abs(slope) > 1e-15) {
    for (const t of [-start / slope, (1 - start) / slope])
      if (t > 0 && t < 1) cuts.push(t);
  }
  cuts.sort((x, y) => x - y);
  const intervals = [];
  for (let i = 0; i < cuts.length - 1; i++) {
    const lo = cuts[i], hi = cuts[i + 1], projection = start + slope * (lo + hi) / 2;
    let base = d, velocity = v;
    if (projection >= 1) base = subtract(a.a, b.b);
    else if (projection > 0) {
      base = { x: d.x - u.x * start, y: d.y - u.y * start };
      velocity = { x: v.x - u.x * slope, y: v.y - u.y * slope };
    }
    const A = dot2(velocity, velocity), B = 2 * dot2(base, velocity), C = dot2(base, base) - radius * radius;
    if (A < 1e-20) {
      if (C < -1e-12) intervals.push([lo, hi]);
      continue;
    }
    const discriminant = B * B - 4 * A * C;
    if (discriminant <= 0) continue;
    const root = Math.sqrt(discriminant);
    const from = Math.max(lo, (-B - root) / (2 * A)), to = Math.min(hi, (-B + root) / (2 * A));
    if (to - from > 1e-10) intervals.push([from, to]);
  }
  return intervals;
}
function segmentSeparation(a, b) {
  const cross = (p, q2, r) => (q2.x - p.x) * (r.y - p.y) - (q2.y - p.y) * (r.x - p.x);
  const overlap = (p, q2, r, s) => Math.max(Math.min(p, q2), Math.min(r, s)) <= Math.min(Math.max(p, q2), Math.max(r, s));
  if (overlap(a.a.x, a.b.x, b.a.x, b.b.x) && overlap(a.a.y, a.b.y, b.a.y, b.b.y) && cross(a.a, a.b, b.a) * cross(a.a, a.b, b.b) <= 0 && cross(b.a, b.b, a.a) * cross(b.a, b.b, a.b) <= 0)
    return 0;
  const pointDistance = (p, segment) => {
    const dx = segment.b.x - segment.a.x, dy = segment.b.y - segment.a.y;
    const lengthSquared = dx * dx + dy * dy;
    const t = lengthSquared ? Math.max(
      0,
      Math.min(
        1,
        ((p.x - segment.a.x) * dx + (p.y - segment.a.y) * dy) / lengthSquared
      )
    ) : 0;
    return Math.hypot(p.x - segment.a.x - t * dx, p.y - segment.a.y - t * dy);
  };
  return Math.min(
    pointDistance(a.a, b),
    pointDistance(a.b, b),
    pointDistance(b.a, a),
    pointDistance(b.b, a)
  );
}

// lib/check-pcb-routing-constraints.ts
var EPS3 = 1e-8;
var hasSourceBusRoutingConstraints = (bus) => [
  bus.length_match_source_trace_ids,
  bus.min_length,
  bus.max_length,
  bus.target_length,
  bus.length_tolerance,
  bus.pcb_trace_spacing,
  bus.pcb_spacing_to_other_signals,
  bus.target_impedance_min,
  bus.target_impedance_max,
  bus.target_differential_impedance_min,
  bus.target_differential_impedance_max
].some((v) => v !== void 0);
function checkPcbRoutingConstraints(circuit) {
  const findings = [];
  const buses = circuit.filter((e) => e.type === "source_bus");
  const sources = new Map(
    circuit.filter((e) => e.type === "source_trace").map((e) => [e.source_trace_id, e])
  );
  const traces = circuit.filter((e) => e.type === "pcb_trace");
  const tracesBySource = /* @__PURE__ */ new Map();
  for (const trace of traces) {
    if (!trace.source_trace_id) continue;
    const list = tracesBySource.get(trace.source_trace_id) ?? [];
    list.push(trace);
    tracesBySource.set(trace.source_trace_id, list);
  }
  const measures = /* @__PURE__ */ new Map();
  const measure = (id) => {
    if (!measures.has(id)) {
      const source = sources.get(id);
      measures.set(
        id,
        source && measureRoute(source, tracesBySource.get(id) ?? [], circuit)
      );
    }
    return measures.get(id);
  };
  const copper = [];
  for (const trace of traces) {
    for (let i = 0; i < trace.route.length - 1; i++) {
      const p = trace.route[i], q2 = trace.route[i + 1];
      if (p.route_type === "through_pad" || q2.route_type === "through_pad")
        continue;
      const pl = p.route_type === "wire" ? p.layer : p.to_layer;
      const ql = q2.route_type === "wire" ? q2.layer : q2.from_layer;
      const width = Math.max(
        p.route_type === "wire" ? Math.max(p.width, p.end_width ?? p.width) : 0,
        q2.route_type === "wire" ? Math.max(q2.width, q2.end_width ?? q2.width) : 0
      );
      if (pl !== ql || width <= 0 || ![p.x, p.y, q2.x, q2.y, width].every(Number.isFinite))
        continue;
      copper.push({ trace, segment: { a: p, b: q2, layer: pl, width } });
    }
  }
  const index = copper.length ? new Flatbush5(copper.length) : void 0;
  let maxWidth = 0;
  for (const { segment: s } of copper) {
    maxWidth = Math.max(maxWidth, s.width);
    index.add(
      Math.min(s.a.x, s.b.x),
      Math.min(s.a.y, s.b.y),
      Math.max(s.a.x, s.b.x),
      Math.max(s.a.y, s.b.y)
    );
  }
  index?.finish();
  const separation = (spacing, width) => typeof spacing === "number" ? spacing : spacing.width_multiplier * width;
  const pairPartners = new Set(
    buses.filter((b) => b.differential_pair).map(
      (b) => [
        b.differential_pair.positive_source_trace_id,
        b.differential_pair.negative_source_trace_id
      ].sort().join("|")
    )
  );
  for (const bus of buses) {
    if (!hasSourceBusRoutingConstraints(bus)) continue;
    const members = [...new Set(bus.source_trace_ids)];
    const matchMembers = [
      .../* @__PURE__ */ new Set([...members, ...bus.length_match_source_trace_ids ?? []])
    ];
    const context = (ids, warning, message) => ({
      message: `${warning ? "Unverified " : ""}bus ${getReadableNameForElementId(circuit, bus.source_bus_id)}: ${message}`,
      source_bus_id: bus.source_bus_id,
      source_trace_ids: ids,
      pcb_trace_ids: ids.flatMap(
        (id) => (tracesBySource.get(id) ?? []).map((trace) => trace.pcb_trace_id)
      ),
      subcircuit_id: bus.subcircuit_id
    });
    const reportWarning = (rule, message, id = members[0]) => {
      findings.push(
        pcb_bus_routing_constraint_warning.parse({
          type: "pcb_bus_routing_constraint_warning",
          pcb_bus_routing_constraint_warning_id: `pcb_bus_routing_constraint_warning_${bus.source_bus_id}_${findings.length}`,
          ...context([id], true, message),
          routing_rule: rule
        })
      );
    };
    const reportError = (violation, message, id = members[0]) => {
      const ids = violation.routing_rule === "length_skew" ? matchMembers : [id];
      findings.push(
        pcb_bus_routing_constraint_error.parse({
          type: "pcb_bus_routing_constraint_error",
          pcb_bus_routing_constraint_error_id: `pcb_bus_routing_constraint_error_${bus.source_bus_id}_${findings.length}`,
          ...context(ids, false, message),
          ...violation
        })
      );
    };
    const complete = (ids, rule) => {
      const missing = ids.find((id) => !measure(id));
      if (missing)
        reportWarning(
          rule,
          "a signal lacks complete, unbranched pad-to-pad geometry",
          missing
        );
      return !missing;
    };
    if (bus.max_length_skew !== void 0 && complete(matchMembers, "route_geometry")) {
      const lengths = matchMembers.map((id) => measure(id).length);
      const skew = Math.max(...lengths) - Math.min(...lengths);
      if (skew > bus.max_length_skew + EPS3)
        reportError(
          {
            routing_rule: "length_skew",
            actual_length_skew: skew,
            maximum_length_skew: bus.max_length_skew
          },
          `planar length skew is ${skew.toFixed(3)} mm`,
          matchMembers[lengths.indexOf(Math.max(...lengths))]
        );
    }
    const resolveLength = (length) => {
      if (length === void 0 || typeof length === "number") return length;
      const ids = length.source_trace_ids ?? matchMembers;
      if (!ids.length || !complete(ids, "reference_geometry")) return;
      return Math.max(...ids.map((id) => measure(id).manhattan)) + (length.offset ?? 0);
    };
    const min = resolveLength(bus.min_length), max = resolveLength(bus.max_length), target = resolveLength(bus.target_length);
    if (bus.target_length !== void 0 && bus.length_tolerance === void 0)
      reportWarning(
        "target_length",
        "a target length requires an explicit length tolerance"
      );
    else if (bus.length_tolerance !== void 0 && bus.target_length === void 0)
      reportWarning(
        "target_length",
        "a length tolerance requires an explicit target length"
      );
    if ([bus.min_length, bus.max_length, bus.target_length].some(
      (v) => v !== void 0
    ) && complete(members, "route_geometry")) {
      for (const id of members) {
        const length = measure(id).length;
        if (min !== void 0 && length < min - EPS3)
          reportError(
            {
              routing_rule: "min_length",
              actual_trace_length: length,
              minimum_trace_length: min
            },
            "planar length is below the declared minimum",
            id
          );
        if (max !== void 0 && length > max + EPS3)
          reportError(
            {
              routing_rule: "max_length",
              actual_trace_length: length,
              maximum_trace_length: max
            },
            "planar length exceeds the declared maximum",
            id
          );
        if (target !== void 0 && bus.length_tolerance !== void 0 && Math.abs(length - target) > bus.length_tolerance + EPS3)
          reportError(
            {
              routing_rule: "target_length",
              actual_trace_length: length,
              target_trace_length: target,
              length_tolerance: bus.length_tolerance
            },
            "planar length is outside the target tolerance",
            id
          );
      }
    }
    for (const id of members) {
      if (bus.pcb_trace_spacing === void 0 && bus.pcb_spacing_to_other_signals === void 0)
        break;
      const measured = measure(id);
      if (!measured) {
        reportWarning(
          "spacing_geometry",
          "spacing requires supported route geometry",
          id
        );
        continue;
      }
      const failed = /* @__PURE__ */ new Set();
      for (const a of measured.segments) {
        const margin = Math.max(
          ...[bus.pcb_trace_spacing, bus.pcb_spacing_to_other_signals].filter((v) => v !== void 0).map((v) => separation(v, Math.max(a.width, maxWidth)))
        );
        for (const k of index?.search(
          Math.min(a.a.x, a.b.x) - margin,
          Math.min(a.a.y, a.b.y) - margin,
          Math.max(a.a.x, a.b.x) + margin,
          Math.max(a.a.y, a.b.y) + margin
        ) ?? []) {
          const { trace, segment: b } = copper[k], otherId = trace.source_trace_id;
          if (id === otherId || a.layer !== b.layer || otherId && pairPartners.has([id, otherId].sort().join("|")))
            continue;
          if (otherId && sources.get(id)?.connected_source_net_ids.some(
            (net) => sources.get(otherId)?.connected_source_net_ids.includes(net)
          ))
            continue;
          const internal = otherId !== void 0 && members.includes(otherId);
          const spacing = internal ? bus.pcb_trace_spacing : bus.pcb_spacing_to_other_signals;
          if (spacing === void 0) continue;
          const required = separation(spacing, Math.max(a.width, b.width));
          if (capsuleIntervals(a, b, required - EPS3).length) {
            const rule = internal ? "pcb_trace_spacing" : "pcb_spacing_to_other_signals";
            if (!failed.has(rule))
              reportError(
                {
                  routing_rule: rule,
                  other_pcb_trace_id: trace.pcb_trace_id,
                  other_source_trace_id: otherId,
                  actual_centerline_spacing: segmentSeparation(a, b),
                  minimum_centerline_spacing: required
                },
                `${getReadableNameForElementId(circuit, id)} falls below declared centreline spacing`,
                id
              );
            failed.add(rule);
          }
        }
      }
    }
    for (const [target2, min2, max2] of [
      [
        bus.target_impedance,
        bus.target_impedance_min,
        bus.target_impedance_max
      ],
      [
        bus.target_differential_impedance,
        bus.target_differential_impedance_min,
        bus.target_differential_impedance_max
      ]
    ]) {
      if ([target2, min2, max2].every((v) => v === void 0)) continue;
      if (target2 !== void 0 && (min2 !== void 0 && target2 < min2 - EPS3 || max2 !== void 0 && target2 > max2 + EPS3))
        reportError(
          {
            routing_rule: "impedance_target",
            target_impedance: target2,
            minimum_impedance: min2,
            maximum_impedance: max2
          },
          "declared impedance target is outside its bounds"
        );
      reportWarning(
        "physical_impedance",
        "actual impedance requires physical stackup analysis; declared targets are not measured impedance"
      );
    }
  }
  return findings;
}

// lib/run-all-checks.ts
import { getFullConnectivityMapFromCircuitJson as getFullConnectivityMapFromCircuitJson15 } from "circuit-json-to-connectivity-map";

// lib/check-pcb-bus-length-skew.ts
var checkPcbBusLengthSkew = (circuitJson) => {
  const buses = circuitJson.filter(
    (e) => e.type === "source_bus"
  );
  const tracesBySource = getPcbTracesBySourceTraceId(circuitJson);
  const errors = [];
  for (const bus of buses) {
    if (bus.max_length_skew === void 0 || hasSourceBusRoutingConstraints(bus))
      continue;
    const members = [...new Set(bus.source_trace_ids)].flatMap((id) => {
      const traces = tracesBySource.get(id)?.filter((t) => t.trace_length !== void 0 || t.route.length > 1);
      if (!traces?.length) return [];
      return [
        {
          id,
          traces,
          length: traces.reduce((sum, t) => sum + getPcbTraceLength(t), 0)
        }
      ];
    });
    if (members.length < 2) continue;
    const skew = Math.max(...members.map((m) => m.length)) - Math.min(...members.map((m) => m.length));
    if (skew <= bus.max_length_skew + 1e-9) continue;
    errors.push({
      type: "pcb_bus_length_skew_error",
      pcb_bus_length_skew_error_id: `pcb_bus_length_skew_error_${bus.source_bus_id}`,
      error_type: "pcb_bus_length_skew_error",
      message: `PCB bus ${getReadableNameForElementId(circuitJson, bus.source_bus_id)} has ${skew.toFixed(2)}mm length skew, exceeding the ${bus.max_length_skew}mm maximum`,
      source_bus_id: bus.source_bus_id,
      source_trace_ids: members.map((m) => m.id),
      pcb_trace_ids: members.flatMap(
        (m) => m.traces.map((t) => t.pcb_trace_id)
      ),
      actual_length_skew: skew,
      maximum_length_skew: bus.max_length_skew,
      subcircuit_id: bus.subcircuit_id
    });
  }
  return errors;
};

// lib/consolidate-pcb-overlap-errors.ts
import { getPrimaryId as getPrimaryId14 } from "@tscircuit/circuit-json-util";
function consolidatePcbOverlapErrors(circuitJson, errors) {
  const ownerByElementId = /* @__PURE__ */ new Map();
  const elementById = /* @__PURE__ */ new Map();
  for (const element of circuitJson) {
    const id = getPrimaryId14(element);
    elementById.set(id, element);
    if ("pcb_component_id" in element && element.pcb_component_id) {
      ownerByElementId.set(id, element.pcb_component_id);
    }
  }
  const rawErrors = errors.flatMap(
    (error) => error.type === "pcb_footprint_overlap_error" ? error.related_errors ?? [error] : [error]
  );
  const groups = /* @__PURE__ */ new Map();
  const keyByError = /* @__PURE__ */ new Map();
  for (const error of rawErrors) {
    let componentIds;
    if (error.type === "pcb_footprint_overlap_error") {
      if (error.pcb_keepout_ids?.length) continue;
      const overlap = error;
      const elementIds = [
        ...error.pcb_smtpad_ids ?? [],
        ...error.pcb_plated_hole_ids ?? [],
        ...error.pcb_hole_ids ?? []
      ];
      if (elementIds.some((id) => !ownerByElementId.has(id))) continue;
      componentIds = overlap.pcb_component_ids ?? elementIds.map((id) => ownerByElementId.get(id));
    } else if (error.type === "pcb_pad_pad_clearance_error") {
      if (error.pcb_pad_ids.some((id) => !ownerByElementId.has(id))) continue;
      componentIds = error.pcb_pad_ids.map((id) => ownerByElementId.get(id));
    } else if (error.type === "pcb_courtyard_overlap_error") {
      componentIds = error.pcb_component_ids;
    } else {
      continue;
    }
    componentIds = [...new Set(componentIds)].sort();
    if (componentIds.length !== 2) continue;
    const key = JSON.stringify(componentIds);
    keyByError.set(error, key);
    const group = groups.get(key) ?? [];
    group.push(error);
    groups.set(key, group);
  }
  const summaries = /* @__PURE__ */ new Map();
  for (const [key, group] of groups) {
    const overlaps = group.filter(
      (e) => e.type === "pcb_footprint_overlap_error"
    );
    if (group.length < 2 || overlaps.length === 0) continue;
    const componentIds = JSON.parse(key);
    const names = componentIds.map((id) => {
      const component = elementById.get(id);
      const source = component?.type === "pcb_component" ? elementById.get(component.source_component_id) : void 0;
      return source?.type === "source_component" ? source.name : id;
    });
    const counts = [
      [overlaps.length, "footprint overlap"],
      [
        group.filter((e) => e.type === "pcb_pad_pad_clearance_error").length,
        "pad clearance violation"
      ],
      [
        group.filter((e) => e.type === "pcb_courtyard_overlap_error").length,
        "courtyard conflict"
      ]
    ];
    const details = counts.filter(([count]) => count > 0).map(([count, label]) => `${count} ${label}${count === 1 ? "" : "s"}`);
    const summary = {
      type: "pcb_footprint_overlap_error",
      error_type: "pcb_footprint_overlap_error",
      pcb_error_id: `pcb_component_overlap_${componentIds.join("_")}`,
      pcb_component_ids: componentIds,
      message: `${names.join(" overlaps ")}: ${details.join(", ")}. Move the components apart.`,
      related_errors: group
    };
    if (group.some((error) => error.is_fatal)) summary.is_fatal = true;
    const affectedIds = /* @__PURE__ */ new Set();
    for (const error of group) {
      if (error.type === "pcb_footprint_overlap_error") {
        for (const id of [
          ...error.pcb_smtpad_ids ?? [],
          ...error.pcb_plated_hole_ids ?? [],
          ...error.pcb_hole_ids ?? []
        ])
          affectedIds.add(id);
      } else if (error.type === "pcb_pad_pad_clearance_error") {
        for (const id of error.pcb_pad_ids) affectedIds.add(id);
      }
    }
    for (const [field, type] of [
      ["pcb_smtpad_ids", "pcb_smtpad"],
      ["pcb_plated_hole_ids", "pcb_plated_hole"],
      ["pcb_hole_ids", "pcb_hole"]
    ]) {
      const ids = [...affectedIds].filter((id) => elementById.get(id)?.type === type).sort();
      if (ids.length) summary[field] = ids;
    }
    summaries.set(key, summary);
  }
  const emitted = /* @__PURE__ */ new Set();
  return rawErrors.flatMap((error) => {
    const key = keyByError.get(error);
    const summary = key === void 0 ? void 0 : summaries.get(key);
    if (!summary || key === void 0) return [error];
    if (emitted.has(key)) return [];
    emitted.add(key);
    return [summary];
  });
}

// lib/check-same-name-nets-are-connected.ts
function checkSameNameNetsAreConnected(circuitJson) {
  const parents = /* @__PURE__ */ new Map();
  const find = (id) => {
    let root = id;
    while (parents.has(root) && parents.get(root) !== root) {
      root = parents.get(root);
    }
    while (parents.has(id) && parents.get(id) !== root) {
      const next = parents.get(id);
      parents.set(id, root);
      id = next;
    }
    return root;
  };
  const connect = (ids) => {
    if (ids.length < 2) return;
    const root = find(ids[0]);
    for (const id of ids.slice(1)) parents.set(find(id), root);
  };
  const netsByName = /* @__PURE__ */ new Map();
  for (const element of circuitJson) {
    if (element.type === "source_net" && element.name.trim()) {
      const nets = netsByName.get(element.name) ?? [];
      nets.push(element);
      netsByName.set(element.name, nets);
    }
    if (element.type === "source_trace") {
      connect([
        ...element.connected_source_net_ids.map((id) => `net:${id}`),
        ...element.connected_source_port_ids.map((id) => `port:${id}`)
      ]);
    }
    if (element.type === "source_component_internal_connection") {
      connect(element.source_port_ids.map((id) => `port:${id}`));
    }
    if (element.type === "source_component") {
      for (const ids of element.internally_connected_source_port_ids ?? []) {
        connect(ids.map((id) => `port:${id}`));
      }
    }
  }
  const warnings = [];
  for (const [name, nets] of netsByName) {
    const islands = new Set(nets.map((net) => find(`net:${net.source_net_id}`)));
    if (islands.size < 2) continue;
    const ids = nets.map((net) => net.source_net_id).sort();
    warnings.push({
      type: "source_confusing_net_name_warning",
      source_confusing_net_name_warning_id: `source_confusing_net_name_warning_${ids[0]}`,
      warning_type: "source_confusing_net_name_warning",
      message: `Nets named "${name}" are not all connected (${islands.size} separate electrical networks). Connect them or use distinct names to avoid confusion.`,
      source_net_ids: ids,
      net_name: name,
      ...nets.every((net) => net.subcircuit_id === nets[0].subcircuit_id) ? { subcircuit_id: nets[0].subcircuit_id } : {}
    });
  }
  return warnings;
}

// lib/check-connector-accessible-orientation.ts
import { getBoardBounds } from "@tscircuit/circuit-json-util";
function getFacingDirectionFromInsertionDirection(component) {
  switch (component.insertion_direction) {
    case "from_left":
      return "x-";
    case "from_right":
      return "x+";
    case "from_top":
      return "y+";
    case "from_bottom":
      return "y-";
    case "from_above":
    case "from_below":
      return null;
    default:
      return null;
  }
}
function getFacingDirection(component) {
  if (component.insertion_direction) {
    return getFacingDirectionFromInsertionDirection(component);
  }
  if (!component.center || !component.cable_insertion_center) return null;
  const dx = component.cable_insertion_center.x - component.center.x;
  const dy = component.cable_insertion_center.y - component.center.y;
  if (Math.abs(dx) < 1e-6 && Math.abs(dy) < 1e-6) return null;
  if (Math.abs(dx) >= Math.abs(dy)) {
    return dx >= 0 ? "x+" : "x-";
  }
  return dy >= 0 ? "y+" : "y-";
}
function getRecommendedFacingDirection(component, bounds) {
  if (!component.center) return null;
  const distances = [
    { direction: "x-", distance: component.center.x - bounds.minX },
    { direction: "x+", distance: bounds.maxX - component.center.x },
    { direction: "y-", distance: component.center.y - bounds.minY },
    { direction: "y+", distance: bounds.maxY - component.center.y }
  ];
  distances.sort((a, b) => a.distance - b.distance);
  return distances[0]?.direction ?? null;
}
function checkConnectorAccessibleOrientation(circuitJson) {
  const board = circuitJson.find(
    (el) => el.type === "pcb_board"
  );
  if (!board) return [];
  const bounds = (() => {
    try {
      return getBoardBounds(board);
    } catch {
      return null;
    }
  })();
  if (!bounds) return [];
  const warnings = [];
  const components = circuitJson.filter(
    (el) => el.type === "pcb_component"
  );
  const pinHeaderSourceIds = new Set(
    circuitJson.filter(
      (el) => el.type === "source_component" && el.ftype === "simple_pin_header"
    ).map((el) => el.source_component_id)
  );
  for (const component of components) {
    if (!component.insertion_direction && pinHeaderSourceIds.has(component.source_component_id))
      continue;
    const facingDirection = getFacingDirection(component);
    const recommendedFacingDirection = getRecommendedFacingDirection(
      component,
      bounds
    );
    if (!facingDirection || !recommendedFacingDirection) continue;
    if (facingDirection === recommendedFacingDirection) continue;
    const componentName = getReadableNameForComponent(
      circuitJson,
      component.pcb_component_id
    );
    const message = component.insertion_direction ? `${componentName} is facing ${facingDirection} but should face ${recommendedFacingDirection} so the connector is accessible from the board edge` : `${componentName} is inferred to face ${facingDirection} from its cable insertion center because no explicit footprint insertionDirection is defined, but should face ${recommendedFacingDirection} so the connector is accessible from the board edge. Set insertionDirection on the <footprint> to specify the actual direction in the footprint's unrotated orientation; for example, <footprint insertionDirection="from_above"> for a connector accessed from above the PCB (+Z).`;
    warnings.push({
      type: "pcb_connector_not_in_accessible_orientation_warning",
      warning_type: "pcb_connector_not_in_accessible_orientation_warning",
      pcb_connector_not_in_accessible_orientation_warning_id: `pcb_connector_not_in_accessible_orientation_warning_${component.pcb_component_id}`,
      message,
      pcb_component_id: component.pcb_component_id,
      source_component_id: component.source_component_id,
      pcb_board_id: board.pcb_board_id,
      facing_direction: facingDirection,
      recommended_facing_direction: recommendedFacingDirection,
      subcircuit_id: component.subcircuit_id
    });
  }
  return warnings;
}

// lib/check-courtyard-overlap/checkCourtyardOverlap.ts
import {
  doSegmentsIntersect,
  isPointInsidePolygon as isPointInsidePolygon2
} from "@tscircuit/math-utils";
function getCourtyardPolygon(el) {
  if (el.type === "pcb_courtyard_rect") {
    const hw = el.width / 2;
    const hh = el.height / 2;
    const corners = [
      { x: -hw, y: -hh },
      { x: +hw, y: -hh },
      { x: +hw, y: +hh },
      { x: -hw, y: +hh }
    ];
    const angle = (el.ccw_rotation ?? 0) * Math.PI / 180;
    const cos = Math.cos(angle);
    const sin = Math.sin(angle);
    return corners.map(({ x, y }) => ({
      x: el.center.x + x * cos - y * sin,
      y: el.center.y + x * sin + y * cos
    }));
  }
  if (el.type === "pcb_courtyard_circle") {
    const N = 32;
    return Array.from({ length: N }, (_, i) => {
      const a = 2 * Math.PI * i / N;
      return {
        x: el.center.x + el.radius * Math.cos(a),
        y: el.center.y + el.radius * Math.sin(a)
      };
    });
  }
  return el.outline;
}
function getComponentName2(circuitJson, pcbComponentId) {
  return getReadableNameForComponent(circuitJson, pcbComponentId);
}
function polygonsOverlap2(polyA, polyB) {
  if (polyA.some((p) => isPointInsidePolygon2(p, polyB))) return true;
  if (polyB.some((p) => isPointInsidePolygon2(p, polyA))) return true;
  for (let i = 0; i < polyA.length; i++) {
    const a1 = polyA[i];
    const a2 = polyA[(i + 1) % polyA.length];
    for (let j = 0; j < polyB.length; j++) {
      const b1 = polyB[j];
      const b2 = polyB[(j + 1) % polyB.length];
      if (doSegmentsIntersect(a1, a2, b1, b2)) return true;
    }
  }
  return false;
}
function checkCourtyardOverlap(circuitJson) {
  const doNotPlaceComponentIds = new Set(
    circuitJson.flatMap(
      (el) => el.type === "pcb_component" && el.do_not_place ? [el.pcb_component_id] : []
    )
  );
  const courtyards = circuitJson.filter(
    (el) => el.type === "pcb_courtyard_rect" || el.type === "pcb_courtyard_circle" || el.type === "pcb_courtyard_outline"
  ).filter((el) => !doNotPlaceComponentIds.has(el.pcb_component_id));
  const byComponent = /* @__PURE__ */ new Map();
  for (const el of courtyards) {
    const id = el.pcb_component_id;
    if (!byComponent.has(id)) byComponent.set(id, []);
    byComponent.get(id).push(el);
  }
  const componentIds = Array.from(byComponent.keys());
  const errors = [];
  for (let i = 0; i < componentIds.length; i++) {
    for (let j = i + 1; j < componentIds.length; j++) {
      const idA = componentIds[i];
      const idB = componentIds[j];
      let overlapping = false;
      outer: for (const a of byComponent.get(idA)) {
        for (const b of byComponent.get(idB)) {
          if ("layer" in a && "layer" in b && a.layer !== b.layer) {
            continue;
          }
          const polyA = getCourtyardPolygon(a);
          const polyB = getCourtyardPolygon(b);
          if (polygonsOverlap2(polyA, polyB)) {
            overlapping = true;
            break outer;
          }
        }
      }
      if (overlapping) {
        errors.push({
          type: "pcb_courtyard_overlap_error",
          pcb_error_id: `pcb_courtyard_overlap_${idA}_${idB}`,
          error_type: "pcb_courtyard_overlap_error",
          message: `Courtyard of ${getComponentName2(circuitJson, idA)} overlaps with courtyard of ${getComponentName2(circuitJson, idB)}`,
          pcb_component_ids: [idA, idB]
        });
      }
    }
  }
  return errors;
}

// lib/check-hole-trace-clearance.ts
function checkHoleTraceClearance(circuitJson, { minClearance } = {}) {
  const required = minClearance ?? getBoardDrcValue(
    getPcbBoard(circuitJson),
    "min_trace_to_hole_edge_clearance"
  ) ?? jlcMinTolerances.min_trace_to_hole_edge_clearance;
  if (!Number.isFinite(required) || required < 0) {
    throw new Error("Trace-to-hole clearance must be finite and non-negative");
  }
  const holes = getHoleGeometries(circuitJson);
  if (holes.length === 0) return [];
  const index = new SpatialObjectIndex({
    objects: holes,
    getId: (hole) => hole.elementId,
    getBounds: (hole) => ({
      minX: hole.bounds.xmin,
      minY: hole.bounds.ymin,
      maxX: hole.bounds.xmax,
      maxY: hole.bounds.ymax
    })
  });
  const errors = /* @__PURE__ */ new Map();
  const overlappingPairIds = /* @__PURE__ */ new Set();
  for (const trace of circuitJson) {
    if (trace.type !== "pcb_trace") continue;
    for (let i = 1; i < trace.route.length; i++) {
      const a = trace.route[i - 1];
      const b = trace.route[i];
      if (a.route_type !== "wire" && a.route_type !== "via" || b.route_type !== "wire" && b.route_type !== "via")
        continue;
      if (a.route_type !== "wire" && b.route_type !== "wire") continue;
      if (a.route_type === "wire" && b.route_type === "wire" && a.layer !== b.layer)
        continue;
      const halfWidth = Math.max(
        a.route_type === "wire" ? a.width : 0,
        b.route_type === "wire" ? b.width : 0
      ) / 2;
      const candidates = index.getObjectsInBounds(
        {
          minX: Math.min(a.x, b.x),
          minY: Math.min(a.y, b.y),
          maxX: Math.max(a.x, b.x),
          maxY: Math.max(a.y, b.y)
        },
        required + halfWidth
      );
      for (const geometry of candidates) {
        const hole = geometry.sourceElement;
        if (hole.type !== "pcb_hole") continue;
        const { gap, center } = getTraceHoleClearance(
          { x1: a.x, y1: a.y, x2: b.x, y2: b.y, thickness: halfWidth * 2 },
          geometry
        );
        const pairId = `${trace.pcb_trace_id}_${hole.pcb_hole_id}`;
        if (isTraceObstacleOverlap(gap)) {
          errors.delete(pairId);
          overlappingPairIds.add(pairId);
          continue;
        }
        if (overlappingPairIds.has(pairId)) continue;
        if (gap + 1e-6 >= required) continue;
        if ((errors.get(pairId)?.gap ?? Infinity) <= gap) continue;
        errors.set(pairId, {
          gap,
          error: {
            type: "pcb_trace_error",
            error_type: "pcb_trace_error",
            pcb_trace_error_id: `overlap_${pairId}`,
            pcb_trace_id: trace.pcb_trace_id,
            source_trace_id: trace.source_trace_id ?? "",
            pcb_component_ids: hole.pcb_component_id ? [hole.pcb_component_id] : [],
            pcb_port_ids: [],
            center,
            message: `Trace ${getReadableNameForTrace(circuitJson, trace.pcb_trace_id)} is too close to non-plated hole ${getReadableNameForElementId(circuitJson, hole.pcb_hole_id)} (gap: ${gap.toFixed(6)}mm, required: ${required}mm)`
          }
        });
      }
    }
  }
  return Array.from(errors.values(), ({ error }) => error);
}

// lib/check-testpoint-accessibility.ts
import { isPointInsidePolygon as isPointInsidePolygon3 } from "@tscircuit/math-utils";
var isCourtyardElement3 = (element) => element.type === "pcb_courtyard_circle" || element.type === "pcb_courtyard_outline" || element.type === "pcb_courtyard_polygon" || element.type === "pcb_courtyard_rect";
var isPointInsideCourtyard = (point2, courtyard) => {
  if (courtyard.type === "pcb_courtyard_circle") {
    const dx = point2.x - courtyard.center.x;
    const dy = point2.y - courtyard.center.y;
    return dx * dx + dy * dy <= courtyard.radius * courtyard.radius;
  }
  if (courtyard.type === "pcb_courtyard_rect") {
    const angle = -1 * (courtyard.ccw_rotation ?? 0) * Math.PI / 180;
    const dx = point2.x - courtyard.center.x;
    const dy = point2.y - courtyard.center.y;
    const localX = dx * Math.cos(angle) - dy * Math.sin(angle);
    const localY = dx * Math.sin(angle) + dy * Math.cos(angle);
    return Math.abs(localX) <= courtyard.width / 2 && Math.abs(localY) <= courtyard.height / 2;
  }
  const polygon = courtyard.type === "pcb_courtyard_polygon" ? courtyard.points : courtyard.outline;
  return isPointInsidePolygon3(point2, polygon);
};
var getPcbComponentName = (circuitJson, pcbComponentId) => {
  const pcbComponent = circuitJson.find(
    (element) => element.type === "pcb_component" && element.pcb_component_id === pcbComponentId
  );
  const sourceComponent = circuitJson.find(
    (element) => element.type === "source_component" && element.source_component_id === pcbComponent?.source_component_id
  );
  return (sourceComponent && "name" in sourceComponent ? sourceComponent.name : void 0) ?? getReadableNameForComponent(circuitJson, pcbComponentId);
};
function checkTestPointAccessibility(circuitJson) {
  const sourceTestPoints = circuitJson.filter(
    (element) => element.type === "source_component" && element.ftype === "simple_test_point"
  );
  const sourceTestPointIds = new Set(
    sourceTestPoints.map((testPoint) => testPoint.source_component_id)
  );
  const testPointNames = new Map(
    sourceTestPoints.map((testPoint) => [
      testPoint.source_component_id,
      testPoint.name
    ])
  );
  const testPointComponents = circuitJson.filter(
    (element) => element.type === "pcb_component" && sourceTestPointIds.has(element.source_component_id)
  );
  const courtyards = circuitJson.filter(isCourtyardElement3);
  const errors = [];
  const reportedComponentPairs = /* @__PURE__ */ new Set();
  for (const testPoint of testPointComponents) {
    for (const courtyard of courtyards) {
      if (courtyard.pcb_component_id === testPoint.pcb_component_id) continue;
      if (courtyard.layer !== testPoint.layer) continue;
      if (!isPointInsideCourtyard(testPoint.center, courtyard)) continue;
      const componentPair = `${testPoint.pcb_component_id}:${courtyard.pcb_component_id}`;
      if (reportedComponentPairs.has(componentPair)) continue;
      reportedComponentPairs.add(componentPair);
      const testPointName = testPointNames.get(testPoint.source_component_id) ?? "Test point";
      const obstructingComponentName = getPcbComponentName(
        circuitJson,
        courtyard.pcb_component_id
      );
      errors.push({
        type: "pcb_placement_error",
        pcb_placement_error_id: `testpoint_in_courtyard_${testPoint.pcb_component_id}_${courtyard.pcb_component_id}`,
        error_type: "pcb_placement_error",
        message: `Test point ${testPointName} is not accessible because it is inside the courtyard of ${obstructingComponentName}`,
        subcircuit_id: testPoint.subcircuit_id
      });
    }
  }
  return errors;
}

// lib/run-all-checks.ts
async function runAllPlacementChecks(circuitJson, { consolidateOverlaps = true } = {}) {
  const errors = [
    ...checkCopperToBoardEdgeClearance(circuitJson),
    ...checkViasInPads(circuitJson),
    ...checkPcbComponentsOutOfBoard(circuitJson),
    ...checkPcbComponentOverCutout(circuitJson),
    ...checkCopperToCutoutClearance(circuitJson, {
      elementTypes: [
        "pcb_via",
        "pcb_smtpad",
        "pcb_plated_hole",
        "pcb_copper_pour"
      ]
    }),
    ...checkPcbCopperOverKeepout(circuitJson),
    ...checkPcbBendZonePlacement(circuitJson),
    ...checkPcbCourtyardOverKeepout(circuitJson),
    ...checkPcbComponentOverlap(circuitJson),
    ...checkPcbComponentsMissingCourtyard(circuitJson),
    ...checkPadPadClearance(circuitJson),
    ...checkCourtyardOverlap(circuitJson),
    ...checkConnectorAccessibleOrientation(circuitJson),
    ...checkTestPointAccessibility(circuitJson)
  ];
  return consolidateOverlaps ? consolidatePcbOverlapErrors(circuitJson, errors) : errors;
}
async function runAllNetlistChecks(circuitJson) {
  return [
    ...checkPinMustBeConnected(circuitJson),
    ...checkSourcePinVoltageCompatibility(circuitJson),
    ...checkSameNameNetsAreConnected(circuitJson),
    ...checkTwoTerminalSwitchContactsOnDifferentNets(circuitJson)
  ];
}
async function runAllSchematicChecks(circuitJson) {
  return [
    ...checkSchematicComponentExcessiveVerticalPadding(circuitJson),
    ...checkSchematicComponentMissingReferenceDesignatorText(circuitJson),
    ...checkSchematicComponentPortsOutsideBody(circuitJson),
    ...checkSchematicPlacement(circuitJson)
  ];
}
async function runAllPinSpecificationChecks(circuitJson) {
  return [
    ...checkAllPinsInComponentAreUnderspecified(circuitJson),
    ...checkNoPowerPinDefined(circuitJson),
    ...checkNoGroundPinDefined(circuitJson)
  ];
}
async function runAllRoutingChecks(circuitJson) {
  addStartAndEndPortIdsIfMissing(circuitJson);
  const connectivity = {
    connMap: getFullConnectivityMapFromCircuitJson15(circuitJson),
    pcbConnectivityMap: createIndexedPcbConnectivityMap(circuitJson)
  };
  return [
    ...checkEachPcbPortConnectedToPcbTraces(circuitJson, connectivity),
    ...checkSourceTracesHavePcbTraces(circuitJson, connectivity),
    ...checkSourceTracesMatchPcbTraceThickness(circuitJson),
    ...checkPcbBendZoneTraces(circuitJson),
    ...checkCopperToCutoutClearance(circuitJson, {
      elementTypes: ["pcb_trace"]
    }),
    ...checkPcbTraceLengths(circuitJson),
    ...checkPcbTraceStyle(circuitJson),
    ...checkPcbBusLengthSkew(circuitJson),
    ...checkPcbRoutingConstraints(circuitJson),
    ...checkPcbTraceViaCounts(circuitJson),
    ...checkEachPcbTraceNonOverlapping(circuitJson, connectivity),
    ...checkCopperPourShorts(circuitJson, connectivity),
    ...checkCopperPourIslands(circuitJson, connectivity),
    ...checkPadTraceClearance(circuitJson, connectivity),
    ...checkHoleTraceClearance(circuitJson),
    ...checkViaTraceClearance(circuitJson, connectivity),
    ...checkViaPadClearance(circuitJson, connectivity),
    ...checkSameNetViaSpacing(circuitJson, connectivity),
    ...checkDifferentNetViaSpacing(circuitJson, connectivity),
    ...checkTracesAreContiguous(circuitJson, connectivity),
    ...checkDanglingTraces(circuitJson, connectivity),
    ...checkPcbTracesOutOfBoard(circuitJson)
  ];
}
async function runAllChecks(circuitJson) {
  return [
    ...await runAllPlacementChecks(circuitJson),
    ...await runAllSchematicChecks(circuitJson),
    ...await runAllNetlistChecks(circuitJson),
    ...await runAllPinSpecificationChecks(circuitJson),
    ...await runAllRoutingChecks(circuitJson)
  ];
}
export {
  NetManager,
  checkAllPinsInComponentAreUnderspecified,
  checkConnectorAccessibleOrientation,
  checkCopperPourIslands,
  checkCopperPourShorts,
  checkCopperToBoardEdgeClearance,
  checkCopperToCutoutClearance,
  checkDanglingTraces,
  checkDifferentNetViaSpacing,
  checkEachPcbPortConnectedToPcbTraces,
  checkEachPcbTraceNonOverlapping,
  checkHoleTraceClearance,
  checkNoGroundPinDefined,
  checkNoPowerPinDefined,
  checkPadPadClearance,
  checkPadTraceClearance,
  checkPcbBendZonePlacement,
  checkPcbBendZoneTraces,
  checkPcbBusLengthSkew,
  checkPcbComponentOverCutout,
  checkPcbComponentOverlap,
  checkPcbComponentsMissingCourtyard,
  checkPcbComponentsOutOfBoard,
  checkPcbCopperOverKeepout,
  checkPcbCourtyardOverKeepout,
  checkPcbRoutingConstraints,
  checkPcbTraceLengths,
  checkPcbTraceSelfShorts,
  checkPcbTraceStyle,
  checkPcbTraceViaCounts,
  checkPcbTracesOutOfBoard,
  checkPinMustBeConnected,
  checkSameNameNetsAreConnected,
  checkSameNetViaSpacing,
  checkSchematicComponentExcessiveVerticalPadding,
  checkSchematicComponentMissingReferenceDesignatorText,
  checkSchematicComponentPortsOutsideBody,
  checkSchematicPlacement,
  checkSourcePinVoltageCompatibility,
  checkSourceTracesHavePcbTraces,
  checkSourceTracesMatchPcbTraceThickness,
  checkTestPointAccessibility,
  checkTracesAreContiguous,
  checkTwoTerminalSwitchContactsOnDifferentNets,
  checkViaPadClearance,
  checkViaTraceClearance,
  checkViasInPads,
  checkViasOffBoard,
  consolidatePcbOverlapErrors,
  dedupePcbDrcErrors,
  runAllChecks,
  runAllNetlistChecks,
  runAllPinSpecificationChecks,
  runAllPlacementChecks,
  runAllRoutingChecks,
  runAllSchematicChecks
};
/*! Bundled license information:

@tscircuit/circuit-json-pcb-style-analysis/dist/index.js:
  (*!
  * Determine if an object is a Buffer
  *
  * @author   Feross Aboukhadijeh <https://feross.org>
  * @license  MIT
  *)
*/
//# sourceMappingURL=index.js.map