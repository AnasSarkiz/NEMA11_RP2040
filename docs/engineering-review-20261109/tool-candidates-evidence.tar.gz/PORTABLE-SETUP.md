# Portable reproduction

The archive excludes node_modules, caches, duplicate supplier imports and whole copied board. It includes fixed-version package.json/package-lock.json, exact checker bundles, upstream source excerpts/patches, immutable board JSON, tests, minimal render fixtures, and an analyzer source copy with pristine baseline source overrides.

1. Extract to a new scratch directory. Run `npm ci` using its supplied package and lock. This installs tools only there; do not run this in the production board. npm package installation requires normal network access.
2. Run `node prepare-portable-runtime.mjs`. It verifies the exact core bundle SHA256 before constructing isolated original/patched copies. Original installed dependencies remain unchanged.
3. Run `node --test regression.test.mjs` and `node --test core-regression.test.mjs`. Repeat with `TARGET_MODE=original` to demonstrate the expected pristine failures.
4. Run `node core-size-probe.mjs` and `node_modules/.bin/bun analyzer-probe.ts`. Analyzer source defaults to the included full-board-replay/analyzer. Alternatively set ANALYZER_ROOT to an absolute directory containing the same 0.0.83 library sources.
5. To replay a native JSON using original analyzer: `BASELINE=1 node --loader ./full-board-replay/analyzer/validation/loader.mjs full-board-replay/analyzer/replay.mjs board-fixture.json output-prefix`. Omit BASELINE for the separately labeled bootstrap candidate.

Core source owner: tscircuit/core lib/utils/schematic/getAllDimensionsForSchematicBox.ts, published package 0.0.2304. Checks owner: tscircuit/checks 0.0.270, source-map recovered TypeScript included. Analyzer owner: tscircuit/circuit-json-schematic-placement-analysis 0.0.83 tag 9a3660921ddf7d262e705cbe628ede716c0c0110. Its baseline-src restores exactly the three separately patched bootstrap files; inner-label solver and utilities are unchanged. These artifacts do not establish upstream approval or full-suite success.

The copied native-board build remains separately documented in full-board-replay. Do not interpret minimal fixture success as a full-board patched build. No full production integration is performed by these steps.
