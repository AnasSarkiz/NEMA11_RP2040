// Run from archive root after npm ci using the included exact package-lock.json.
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
const provenance=JSON.parse(fs.readFileSync('provenance.json','utf8'))
const original=fs.readFileSync('node_modules/@tscircuit/core/dist/index.js')
const hash=crypto.createHash('sha256').update(original).digest('hex')
if(hash!==provenance.core_bundle_sha256)throw Error('Core does not match tested original SHA256')
for(const mode of ['original','patched']){
 fs.cpSync('node_modules/@tscircuit/core/dist',`core-${mode}`,{recursive:true})
 const link=`core-${mode}/node_modules`;if(!fs.existsSync(link))fs.symlinkSync('../node_modules/@tscircuit/core/node_modules',link,'dir')
}
const target='core-patched/index.js';const s=fs.readFileSync(target,'utf8');const old='(label) => label.length * ESTIMATED_PIN_LABEL_CHARACTER_WIDTH'
if(s.split(old).length!==2)throw Error('Unexpected patch match count')
fs.writeFileSync(target,s.replace(old,'(label) => getEstimatedPinLabelWidth(label)'))
const analyzerLink='full-board-replay/analyzer/node_modules';if(!fs.existsSync(analyzerLink))fs.symlinkSync('../../node_modules',analyzerLink,'dir')
console.log('Prepared isolated exact-version core copies. No production dependency was patched.')
