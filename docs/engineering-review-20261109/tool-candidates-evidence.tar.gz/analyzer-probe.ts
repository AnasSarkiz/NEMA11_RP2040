import fs from 'node:fs'
import assert from 'node:assert/strict'
const analyzerRoot = process.env.ANALYZER_ROOT ? new URL('file://' + process.env.ANALYZER_ROOT.replace(/\/$/, '') + '/') : new URL('./full-board-replay/analyzer/', import.meta.url)
const { SchematicBoxInnerLabelCollisionSolver } = await import(new URL('lib/solvers/SchematicBoxInnerLabelCollisionSolver/SchematicBoxInnerLabelCollisionSolver.ts', analyzerRoot).href)
const report=[]
for(const mode of ['original','patched'])for(const name of ['U_TEMP','D_STATUS'])for(const form of ['array','string']){
 const circuitJson=JSON.parse(fs.readFileSync(new URL(`./size-${mode}-${name}-${form}.json`,import.meta.url),'utf8'))
 const componentPlacements=circuitJson.filter(e=>e.type==='schematic_component').map(e=>({schematicComponentId:e.schematic_component_id,sourceComponentName:name,schX:e.center.x,schY:e.center.y,width:e.size.width,height:e.size.height,positionAnchor:'center'}))
 const issues=[];const solver=new SchematicBoxInnerLabelCollisionSolver({ctx:{circuitJson,componentPlacements} as any,issues});solver.solve();report.push({mode,name,form,issues});console.log(mode,name,form,issues.map(i=>({type:i.lineItemType,suggestedSchWidth:i.suggestedSchWidth})))
}
for (const row of report) {
 const failing = row.mode === 'original' && row.form === 'array'
 assert.equal(row.issues.length, failing ? 1 : 0)
 if(failing) assert.equal(row.issues[0].suggestedSchWidth, row.name === 'U_TEMP' ? 1.289 : 1.272)
}
console.log('All 8 exact analyzer expectations passed.')
fs.writeFileSync(new URL('./analyzer-results.json',import.meta.url),JSON.stringify(report,null,2))
