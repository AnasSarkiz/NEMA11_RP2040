import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import * as before from './checks-original.mjs'
const after = await import(process.env.TARGET_MODE === 'original' ? './checks-original.mjs' : './checks-patched.mjs')
const fixture = (attrs, ftype='simple_chip', name='U1') => [
 {type:'source_component',source_component_id:'c1',ftype,name},
 ...attrs.map((a,i)=>({type:'source_port',source_component_id:'c1',source_port_id:`p${i}`,name:`pin${i+1}`,pin_number:i+1,...a}))
]
const underspecified=m=>m.checkAllPinsInComponentAreUnderspecified
const ground=m=>m.checkNoGroundPinDefined
for(const key of ['is_passive','is_input','is_output','is_bidirectional']) {
 test(`${key} is a specified pin attribute`,()=> {
  const f=fixture([{[key]:true},{}]);assert.equal(underspecified(before)(f).length,1);assert.equal(underspecified(after)(f).length,0)
 })
}
test('empty attributes still warn, including misleading component names',()=>{
 for(const name of ['U1','J_MOTOR','Y_MCU','D_TVS','Q_BUZZER']) {
  const f=fixture([{},{}],'simple_chip',name);assert.equal(underspecified(after)(f).length,1);assert.equal(ground(after)(f).length,1);assert.equal(after.checkNoPowerPinDefined(f).length,1)
 }
})
test('only explicit all-passive connectable pins remove chip supply assumption',()=>{
 const f=fixture([{is_passive:true},{is_passive:true}]);assert.equal(ground(before)(f).length,1);assert.equal(ground(after)(f).length,0);assert.equal(after.checkNoPowerPinDefined(f).length,0)
})
test('untyped or active pin preserves ground warning',()=>{
 for(const a of [{},{is_passive:false},{is_input:true},{is_output:true},{is_bidirectional:true}]) assert.equal(ground(after)(fixture([{is_passive:true},a])).length,1)
})
test('NC excluded exactly as existing power check',()=>{
 const f=fixture([{is_passive:true},{is_passive:true},{do_not_connect:true}]);assert.equal(ground(after)(f).length,0)
})
test('explicit ground and non-chip behavior unchanged',()=>{
 assert.equal(ground(after)(fixture([{requires_ground:true},{}])).length,0)
 assert.equal(ground(after)(fixture([{},{}],'simple_resistor')).length,0)
})
test('real board: original 30 and candidate 26, exactly four justified warnings removed',async()=>{
 const f=JSON.parse(fs.readFileSync(new URL('./board-fixture.json',import.meta.url)));const original=await before.runAllPinSpecificationChecks(f);const candidate=await after.runAllPinSpecificationChecks(f);
 assert.equal(original.length,30);assert.equal(candidate.length,26)
 const key=x=>`${x.type}:${x.source_component_id}`;const candidateKeys=new Set(candidate.map(key));const removed=original.filter(x=>!candidateKeys.has(key(x)))
 const names=Object.fromEntries(f.filter(x=>x.type==='source_component').map(x=>[x.source_component_id,x.name]))
 assert.deepEqual(removed.map(x=>[x.type,names[x.source_component_id]]).sort(),['Y_MCU','J_MOTOR'].flatMap(n=>[['source_component_pins_underspecified_warning',n],['source_no_ground_pin_defined_warning',n]]).sort())
 for(const warning of candidate) assert.deepEqual(warning,original.find(x=>key(x)===key(warning)))
 fs.writeFileSync(new URL('./candidate-result.json',import.meta.url),JSON.stringify(candidate,null,2))
})
