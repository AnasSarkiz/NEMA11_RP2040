import test from 'node:test'
import assert from 'node:assert/strict'
import React from 'react'
const {Circuit}=await import(`./core-${process.env.TARGET_MODE==='original'?'original':'patched'}/index.js`)
async function size(pinLabels,extra={}){
 const c=new Circuit();c.add(React.createElement('board',{width:10,height:10,pcbDisabled:true,routingDisabled:true},React.createElement('chip',{name:'U1',pinLabels,...extra})));await c.renderUntilSettled();return c.getCircuitJson().find(x=>x.type==='schematic_component').size
}
for(const [name,labels]of Object.entries({TMP102:['SCL','GND','ALERT','ADD0','V_POS','SDA'],RGB:['R_NEG','G_NEG','B_NEG','_POS']})){
 test(`${name}: singleton alias arrays match identical displayed string labels`,async()=>{
  const scalar=Object.fromEntries(labels.map((x,i)=>[`pin${i+1}`,x]));const array=Object.fromEntries(labels.map((x,i)=>[`pin${i+1}`,[x]]));assert.deepEqual(await size(array),await size(scalar))
 })
}
test('extra hidden aliases do not change automatic size',async()=>{
 const base={pin1:['A'],pin2:['B']};assert.deepEqual(await size(base),await size({pin1:['A','one','two','three','four','five','six','seven'],pin2:['B']}))
})
test('explicit width remains caller controlled',async()=>{
 assert.equal((await size({pin1:['LONG_LEFT'],pin2:['LONG_RIGHT']},{schWidth:0.7})).width,0.7)
})
test('ordinary string labels retain existing sizing',async()=>{
 assert.equal((await size({pin1:'ALERT',pin2:'V_POS'})).width,1.6)
})
