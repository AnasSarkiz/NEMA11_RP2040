import { test } from "node:test"
import assert from "node:assert/strict"
import { readFileSync, writeFileSync } from "node:fs"
import type { CircuitJson } from "circuit-json"
import { analyzeSchematicPlacement } from "../../lib/analyze-schematic-placement"
import { createSchematicAnalysisFixtureSvg } from "../fixtures/create-schematic-analysis-fixture-svg"

// Immutable native export, not a native build or fabricated production geometry.
const original = JSON.parse(
  readFileSync(
    new URL("../assets/local-floating-chip-capacitor.json", import.meta.url),
    "utf8",
  ),
) as CircuitJson
const targetId = "source_component_11"
const swId = "source_port_45"
const bstId = "source_port_46"
const targetIssues = (circuit: CircuitJson) =>
  analyzeSchematicPlacement(circuit)
    .getLineItems()
    .flatMap((item) =>
      item.lineItemType === "SchematicPlacementIssues" ? item.issues : [],
    )
    .filter(
      (issue) =>
        "schematicBox" in issue &&
        issue.schematicBox.sourceComponentId === targetId &&
        [
          "TwoPinComponentShouldBeVertical",
          "CapacitorSymbolHorizontal",
        ].includes(issue.lineItemType),
    )
const port = (circuit: CircuitJson, id: string) =>
  circuit.find(
    (e) => e.type === "source_port" && e.source_port_id === id,
  ) as Extract<CircuitJson[number], { type: "source_port" }>
const declareNet = (circuit: CircuitJson, id: string, flags: object) =>
  circuit.push({
    type: "source_net",
    source_net_id: "control_net",
    name: "arbitrary",
    subcircuit_connectivity_map_key: port(circuit, id)
      .subcircuit_connectivity_map_key,
    ...flags,
  } as CircuitJson[number])

test("local floating chip capacitors do not imply rail orientation; explicit rails and ground remain checked", () => {
  const variants: [string, (c: CircuitJson) => void, boolean][] = [
    ["bootstrap", () => {}, false],
    [
      "provided-voltage",
      (c) => {
        port(c, swId).provides_voltage = 3.3
      },
      true,
    ],
    [
      "required-zero-voltage",
      (c) => {
        port(c, bstId).requires_voltage = 0
      },
      true,
    ],
    [
      "renamed",
      (c) => {
        for (const e of c) {
          if ("name" in e) e.name = "neutral"
          if (e.type === "source_port") e.port_hints = []
        }
      },
      false,
    ],
    ["explicit-power", (c) => declareNet(c, swId, { is_power: true }), true],
    [
      "explicit-positive",
      (c) => declareNet(c, swId, { is_positive_voltage_source: true }),
      true,
    ],
    ["explicit-ground", (c) => declareNet(c, bstId, { is_ground: true }), true],
    [
      "pin-ground",
      (c) => {
        port(c, bstId).requires_ground = true
      },
      true,
    ],
    [
      "provided-ground",
      (c) => {
        port(c, bstId).provides_ground = true
      },
      true,
    ],
    [
      "second-supply",
      (c) => {
        port(c, bstId).requires_power = true
      },
      true,
    ],
    [
      "different-chip",
      (c) => {
        port(c, bstId).source_component_id = "source_component_8"
      },
      true,
    ],
    [
      "requires-only",
      (c) => {
        port(c, swId).provides_power = false
        port(c, swId).requires_power = true
      },
      true,
    ],
    [
      "external-load",
      (c) => {
        c.push({
          ...port(c, swId),
          source_port_id: "extra-load",
          source_component_id: "source_component_8",
          provides_power: false,
          requires_power: true,
        })
      },
      true,
    ],
    [
      "other-scope",
      (c) => {
        const host = c.find(
          (e) =>
            e.type === "schematic_component" &&
            e.source_component_id === "source_component_9",
        )
        if (host?.type === "schematic_component")
          host.schematic_group_id = "other"
      },
      true,
    ],
    [
      "resistor",
      (c) => {
        const component = c.find(
          (e) =>
            e.type === "source_component" && e.source_component_id === targetId,
        )
        Object.assign(component!, {
          ftype: "simple_resistor",
          resistance: 10000,
        })
      },
      true,
    ],
  ]
  for (const [name, change, warned] of variants) {
    const circuit = structuredClone(original)
    change(circuit)
    const before = JSON.stringify(circuit)
    const issues = targetIssues(circuit)
    assert.equal(
      issues.some((i) => i.lineItemType === "TwoPinComponentShouldBeVertical"),
      warned,
      name,
    )
    if (!warned) assert.equal(issues.length, 0, name)
    const analysis = analyzeSchematicPlacement(circuit)
    const svg = createSchematicAnalysisFixtureSvg({
      circuitJson: circuit,
      analysis,
    }).replace(/[ \t]+$/gm, "")
    const snapshot = new URL(
      `./__snapshots__/local-floating-chip-capacitor-${name}.snap.svg`,
      import.meta.url,
    )
    if (process.env.UPDATE_SNAPSHOTS === "1") writeFileSync(snapshot, svg)
    assert.equal(
      svg,
      readFileSync(snapshot, "utf8"),
      `${name} stacked schematic/analysis snapshot`,
    )
    assert.equal(
      JSON.stringify(circuit),
      before,
      "analysis must not mutate input",
    )
  }
  // Existing native controls retain horizontal decoupling and pull resistor warnings.
  const text = analyzeSchematicPlacement(original).toString()
  for (const name of [
    "C_BUCK_IN",
    "C_BUCK_OUT1",
    "C_BUCK_OUT2",
    "C_PD",
    "R_PD",
    "R_PD_CFG",
    "R_PG",
  ]) {
    assert.ok(
      text.includes(`<TwoPinComponentShouldBeVertical componentName="${name}"`),
      name,
    )
  }
})
